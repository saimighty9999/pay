package com.asktech.pgateway.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;



import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
@Entity
@Table(name = "distributor_merchant_association_details")
public class DistributorMerchantDetails extends AbstractTimeStampAndId {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name="created_by")
	private String createdBy;
	@Column(name="updated_by")
	private String updatedBy;
	private String uuid;
	@Column(name="distributor_id")
	private String distributorID;
	@Column(name="merchant_id")
	private String merchantID;
	@Column(name="status")
	private String status; 
	@Column(name="region")
	private String region;
	@Column(name="rights")
	private String rights;
	private Boolean flagValue;
	private String approval;
	private String info1;
	private String info2;
	private String info3;
	private String info4;
	private String info5;

}
