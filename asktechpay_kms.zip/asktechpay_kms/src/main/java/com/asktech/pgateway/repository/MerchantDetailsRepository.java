package com.asktech.pgateway.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.asktech.pgateway.model.MerchantDetails;
/**@author abhimanyu-kumar*/
public interface MerchantDetailsRepository extends JpaRepository<MerchantDetails, Long>{

	MerchantDetails findByMerchantName(String merchantName);

	MerchantDetails findByAppID(String encryptCardNumberOrExpOrCvv);

	MerchantDetails findByMerchantEMail(String userNameOrEmail);

	MerchantDetails findByuuid(String uuid);	

	MerchantDetails findByMerchantID(String merchantId);
	@Query(value = "select * from merchant_details  where merchantid in :merchantID", nativeQuery=true )
	List<MerchantDetails> findAllByMerchantID(@Param("merchantID") List<String> merchantID);

	MerchantDetails findByPhoneNumber(String phoneNumber);


	

}
