package com.asktech.pgateway.constants.payout;

public interface Payout {

	String payoutUrl = "http://localhost:8080/merchant/";
	String payoutBaseUrl = "http://localhost:8080/";
	String payoutVanSecret = "4zTmmKYw6a2jxKLbrNcQBqpNkiDWTv-RxuI5FUVs6vQ=";

}
