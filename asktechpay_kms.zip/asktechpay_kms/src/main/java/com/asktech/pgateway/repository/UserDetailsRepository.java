package com.asktech.pgateway.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.pgateway.model.UserDetails;

public interface UserDetailsRepository extends JpaRepository<UserDetails, String>{
		
	//UserDetails findAllByEmailIdAndPhoneNumberAndCardNumberAndMerchantId(String customerEmail, String customerPhone,String card_number, String string);
	
	UserDetails findAllByEmailIdAndPhoneNumberAndMerchantId(String customerEmail, String customerPhone, String string);

	List<UserDetails> findAllByEmailIdOrPhoneNumber(String custEmailorPhone, String custEmailorPhone2);

	//UserDetails findAllByEmailIdAndPhoneNumberAndMerchantIdAndCustomerNameAndPaymentOptionAndPaymentCode(String emailId,
	//		String phoneNumber, String merchantId, String customerName, String paymentOption, String paymentCode);

	//UserDetails findAllByEmailIdAndPhoneNumberAndPaymentCodeAndMerchantId(String string, String string2, String string3,
	//		String merchantID);

	//UserDetails findAllByEmailIdAndPhoneNumberAndVpaUPIAndMerchantId(String string, String string2, String string3,
	//		String merchantID);

	UserDetails findById(long userID);

}
