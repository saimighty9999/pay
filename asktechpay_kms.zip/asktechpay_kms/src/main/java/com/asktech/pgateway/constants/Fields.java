package com.asktech.pgateway.constants;

public interface Fields {
	String CUSTOMERNAME = "customerName";
	String CUSTOMERPHONE = "customerPhone";
	String CUSTOMEREMAIL = "customerEmail";
	String ORDERID = "orderid";
	String PAYMENTOPTION = "paymentOption";	
	String SIGNATURE = "signature";
	String CUSTOMERID = "customerid";
	String ORDERCURRENCY ="orderCurrency";
	String ORDERNOTE = "orderNote";
	String RETURNURL = "returnUrl";
	String NOTIFYURL = "notifyUrl";
	String ORDERAMOUNT = "orderAmount";
	
}
