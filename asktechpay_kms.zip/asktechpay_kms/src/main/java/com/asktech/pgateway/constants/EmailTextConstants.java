package com.asktech.pgateway.constants;

public interface EmailTextConstants {

	String CREATE_MERCHANT	= "Welcome to EazyPaymentz , Please find your Merchant id : merchantId and password is :: - passWord";
	String CREATE_COMPLAINT	= "Hi Partner , Your complaint has been raised , please find the complaint Id ::";
	String SEND_MAIL_TO_CUSTOMER= "Hello , Your transaction ";
}
