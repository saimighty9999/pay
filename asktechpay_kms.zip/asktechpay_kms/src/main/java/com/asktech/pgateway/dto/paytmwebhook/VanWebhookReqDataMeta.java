package com.asktech.pgateway.dto.paytmwebhook;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class VanWebhookReqDataMeta {

	private String branch;
	private String section;
}
