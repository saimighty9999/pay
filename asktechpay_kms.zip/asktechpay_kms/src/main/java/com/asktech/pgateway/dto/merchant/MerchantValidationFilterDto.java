package com.asktech.pgateway.dto.merchant;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MerchantValidationFilterDto {
	private String status;
	private String msg;
}
