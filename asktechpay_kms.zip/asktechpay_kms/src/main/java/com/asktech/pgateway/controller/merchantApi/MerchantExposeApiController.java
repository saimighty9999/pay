package com.asktech.pgateway.controller.merchantApi;

import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.asktech.pgateway.controller.PGGatewayAdminController;
import com.asktech.pgateway.dto.merchant.MerchantRefundResponse;
import com.asktech.pgateway.dto.merchant.MerchantTransaction;
import com.asktech.pgateway.exception.JWTException;
import com.asktech.pgateway.exception.SessionExpiredException;
import com.asktech.pgateway.exception.UserException;
import com.asktech.pgateway.exception.ValidationExceptions;
import com.asktech.pgateway.service.merchantApi.ServiceMerchantApiExposer;
import com.asktech.pgateway.util.GeneralUtils;
import com.fasterxml.jackson.core.JsonProcessingException;

@Controller
@RequestMapping("/merchantApi")
public class MerchantExposeApiController {

	@Autowired
	ServiceMerchantApiExposer serviceMerchantApiExposer;
	
	static Logger logger = LoggerFactory.getLogger(PGGatewayAdminController.class);

	@RequestMapping(value = "/transactionStatus", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> merchantTrStatus(@RequestBody MultiValueMap<String, String>  formData, @RequestHeader("Authorization")  String tokenInfo)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, NoSuchAlgorithmException, JsonProcessingException {	
		logger.info("merchantTrStatus ::"+GeneralUtils.MultiValueMaptoJson(formData));
		MerchantTransaction merchantTransaction = serviceMerchantApiExposer.transactionStatus(tokenInfo, formData);		
		
		return ResponseEntity.ok().header("Authorization",merchantTransaction.getHeader() ).body(merchantTransaction.getListMerchantTransactionResponse());
	}
	
	@RequestMapping(value = "/refundRequest", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> refundRequest(@RequestBody MultiValueMap<String, String>  formData, @RequestHeader("Authorization")  String tokenInfo)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, NoSuchAlgorithmException, JsonProcessingException {	
		
		MerchantRefundResponse merchantRefundResponse = serviceMerchantApiExposer.generateRefundRequest(tokenInfo, formData);		
		
		return ResponseEntity.ok().header("Authorization",merchantRefundResponse.getHeader() ).body(merchantRefundResponse.getRefundDetails());
	}
	
}
