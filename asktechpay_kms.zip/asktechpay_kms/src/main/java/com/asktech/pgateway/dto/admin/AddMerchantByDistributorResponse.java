package com.asktech.pgateway.dto.admin;

import java.io.Serializable;

import com.asktech.pgateway.model.AddMerchantByDistributorRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddMerchantByDistributorResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1724607435680219808L;
	
	private int status;
	private String message;
	private  AddMerchantByDistributorRequest addMerchantByDistributorRequest;

}
