package com.asktech.pgateway.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.asktech.pgateway.dto.admin.MerchantRechargeRequest;
import com.asktech.pgateway.model.MerchantRechargeRequest.MerchantRechargeRequestDetails;

@Repository
public interface MerchantRechargeRequestDetailsRepository extends JpaRepository<MerchantRechargeRequestDetails, Long> {

 
  List< MerchantRechargeRequestDetails>findByMerchantID(String merchantID);

  MerchantRechargeRequestDetails save(MerchantRechargeRequest merchantrechargeRequest);



}
