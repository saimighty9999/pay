package com.asktech.pgateway.customInterface;

public interface IMerchantTransaction {

	String getMerchantId();;
	String getStatus();
	Integer getAmount();
	
}
