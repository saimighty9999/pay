package com.asktech.pgateway.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.asktech.pgateway.constants.ErrorValues;
import com.asktech.pgateway.enums.AskTechGateway;
import com.asktech.pgateway.enums.FormValidationExceptionEnums;
import com.asktech.pgateway.exception.UserException;
import com.asktech.pgateway.exception.ValidationExceptions;
import com.fasterxml.jackson.core.JsonProcessingException;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Component
public class SmsCallTemplate implements  ErrorValues{

	static Logger logger = LoggerFactory.getLogger(SmsCallTemplate.class);
	private static String smsApi = "https://api-alerts.kaleyra.com/v4/?";
	private static String apiKey = "A7e3cefd77660c94c31e05bb5ac2f4909";
	private static String smsSender_Id = "IMONEY";
	private static String apiType = "sms";
	
	
	public void smsSendbyApi(String message, String mobileNo, String senderId) throws UserException, JsonProcessingException, ValidationExceptions {
		HttpResponse<String> dto = (HttpResponse<String>) Unirest.get(smsApi + "api_key=" + apiKey + "&method="+apiType+"&message="+message+"&to="+mobileNo+"&sender="+senderId).asString();
		logger.info("sms using ikontel==> " + Utility.convertDTO2JsonString(dto.getBody()));
		
		if (!dto.isSuccess()) {
			logger.error("sms using ikontel==> "+"Ikontel is down :: "+AskTechGateway.REST_TEMPLATE_NOT_CALL);
			throw new ValidationExceptions(EXCEPTION_IN_SMS_SENDING, FormValidationExceptionEnums.EXCEPTION_IN_SMS_SENDING);
		}
	}

	public static void main(String args[]) throws JsonProcessingException, UserException, ValidationExceptions {
		//smsSendbyApi("Test123","9051093937","ANLYTQ");
	}
	
}
