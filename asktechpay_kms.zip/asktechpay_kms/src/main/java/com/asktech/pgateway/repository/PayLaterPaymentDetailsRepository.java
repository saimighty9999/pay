package com.asktech.pgateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.pgateway.model.PayLaterPaymentDetails;

public interface PayLaterPaymentDetailsRepository extends JpaRepository<PayLaterPaymentDetails, String>{

}
