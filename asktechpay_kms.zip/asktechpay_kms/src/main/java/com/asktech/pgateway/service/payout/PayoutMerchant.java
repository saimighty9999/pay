package com.asktech.pgateway.service.payout;




import org.springframework.stereotype.Service;

import com.asktech.pgateway.constants.payout.Payout;
import com.asktech.pgateway.dto.payout.merchant.AccountTransferMerReq;
import com.asktech.pgateway.dto.payout.merchant.TransactionReportMerReq;
import com.asktech.pgateway.dto.payout.merchant.TransferStatusReq;
import com.asktech.pgateway.dto.payout.merchant.WalletTransferMerReq;

import kong.unirest.Unirest;



@Service
public class PayoutMerchant implements Payout{


	public String WalletTransfer(WalletTransferMerReq dto, String merchantid) {
		String res =  Unirest.post(payoutUrl+"walletTransfer/"+merchantid)
				.header("Content-Type", "application/json")
				.body(dto).asString().getBody();
		return res;
	}

	public String AccountTransfer(AccountTransferMerReq dto, String merchantid) {
		String res =  Unirest.post(payoutUrl+"accountTransfer/"+merchantid)
				.header("Content-Type", "application/json")
				.body(dto).asString().getBody();
		return res;

	}

	public String BalanceCheck(String merchantid) {
		String res =  Unirest.get(payoutUrl+"balanceCheck/"+merchantid)
				.header("Content-Type", "application/json")
				.asString().getBody();
		return res;

	}

	public String TransactionReport(String merchantid, TransactionReportMerReq dto) {
		String res =  Unirest.post(payoutUrl+"transactionReport/"+merchantid)
				.header("Content-Type", "application/json")
				.body(dto).asString().getBody();
		return res;

	}

	public String TransactionStatus(TransferStatusReq dto, String merchantid) {
		String res =  Unirest.post(payoutUrl+"transactionStatus/"+merchantid)
				.header("Content-Type", "application/json")
				.body(dto).asString().getBody();
		return res;
	}
}
