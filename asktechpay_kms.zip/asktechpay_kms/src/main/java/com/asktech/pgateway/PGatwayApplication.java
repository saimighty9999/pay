package com.asktech.pgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PGatwayApplication {

	public static void main(String[] args) {
		SpringApplication.run(PGatwayApplication.class, args);
	}

}
