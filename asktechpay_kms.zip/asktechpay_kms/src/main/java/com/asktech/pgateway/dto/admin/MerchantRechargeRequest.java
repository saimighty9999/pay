package com.asktech.pgateway.dto.admin;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)

public class MerchantRechargeRequest implements Serializable {
    private static final long serialVersionUID = -8114443377343980087L;
	
	private String amount;
	private String notes;
	private String utr;
	private String bankName;
	private String bankId;
}
