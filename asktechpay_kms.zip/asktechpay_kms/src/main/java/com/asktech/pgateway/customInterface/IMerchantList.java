package com.asktech.pgateway.customInterface;

public interface IMerchantList {
	String getMerchantEMail();
	String getMerchantId();
	String getMerchant_name();
	String getPhone_number();
	String getUser_status();
	String getKyc_status();
}
