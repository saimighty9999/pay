package com.asktech.pgateway.constants.nonseamless;

public interface NetBankingFields extends Fields{
	String NB_PAYMENT_CODE = "paymentCode";
}
