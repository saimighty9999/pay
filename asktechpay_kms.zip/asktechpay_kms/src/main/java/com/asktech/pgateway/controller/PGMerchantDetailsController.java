package com.asktech.pgateway.controller;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.asktech.pgateway.constants.ErrorValues;
import com.asktech.pgateway.dto.admin.MerchantCreateResponse;
import com.asktech.pgateway.dto.merchant.DashBoardDetails;
import com.asktech.pgateway.dto.merchant.MerchantDashBoardBalance;
import com.asktech.pgateway.dto.merchant.MerchantResponse;
import com.asktech.pgateway.dto.merchant.MerchantSettlement;
import com.asktech.pgateway.dto.merchant.TransactionDetailsDto;
import com.asktech.pgateway.dto.utility.SuccessResponseDto;
import com.asktech.pgateway.enums.FormValidationExceptionEnums;
import com.asktech.pgateway.enums.SuccessCode;
import com.asktech.pgateway.exception.JWTException;
import com.asktech.pgateway.exception.SessionExpiredException;
import com.asktech.pgateway.exception.UserException;
import com.asktech.pgateway.exception.ValidationExceptions;
import com.asktech.pgateway.model.CommissionStructure;
import com.asktech.pgateway.model.MerchantBalanceSheet;
import com.asktech.pgateway.model.MerchantBankDetails;
import com.asktech.pgateway.model.MerchantDetails;
import com.asktech.pgateway.model.UserDetails;
import com.asktech.pgateway.service.PGGatewayAdminService;
import com.asktech.pgateway.service.PaymentMerchantService;
import com.asktech.pgateway.service.UserLoginService;
import com.asktech.pgateway.util.JwtUserValidator;
import com.asktech.pgateway.util.Validator;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;

@RestController
@RequestMapping("/api")
public class PGMerchantDetailsController implements ErrorValues{
	
	static Logger logger = LoggerFactory.getLogger(PGGatewayAdminController.class);
	
	@Autowired
	PGGatewayAdminService pgGatewayAdminService;
	@Autowired
	PaymentMerchantService paymentMerchantService;
	@Autowired
	UserLoginService userLoginService;
	@Autowired
	JwtUserValidator jwtValidator;

	
	@PutMapping(value = "user/passwordChange")
	@ApiOperation(value = "User can resend OTP, if OTP is not received. ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> initialPasswordChange(@RequestParam("userNameOrEmailId") String userNameOrEmailId ,@RequestParam("password") String password)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions {
		
		SuccessResponseDto sdto = new SuccessResponseDto();
		if (userNameOrEmailId == null) {

			throw new ValidationExceptions(ALL_FIELDS_MANDATORY, FormValidationExceptionEnums.ALL_FIELDS_MANDATORY);
		}
		 userLoginService.passwordChange(userNameOrEmailId, password);
		
		sdto.getMsg().add("Password change successsfully done for userId :: "+userNameOrEmailId);
		sdto.setSuccessCode(SuccessCode.RESET_PASSWORD_SUCCESS);
		return ResponseEntity.ok().body(sdto);
	}

	
	
	@PutMapping("/updateMerchantKey")
	public ResponseEntity<?> updateMerchantKey(@RequestParam("uuid") String uuid) throws IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions, 
	UserException, JWTException, SessionExpiredException{
		
		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		
		MerchantCreateResponse merchantCreateResponse = pgGatewayAdminService.refreshSecretKey(uuid);
		
		return ResponseEntity.ok().body(merchantCreateResponse);
	}
	
	@GetMapping("/getMerchantDetails")
	@ApiOperation(value = "Get erchant details from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getMerchant(@RequestParam("uuid") String uuid) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		MerchantResponse merchantResponse = paymentMerchantService.merchantView(uuid);
		
		return ResponseEntity.ok().body(merchantResponse);
	}
	
	@GetMapping("/getTransactionDetails")
	@ApiOperation(value = "Get erchant details from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getMerchanttrDetails(@RequestParam("uuid") String uuid) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		List<TransactionDetailsDto> transactionDetails = paymentMerchantService.getTransactionDetails(uuid);
		
		return ResponseEntity.ok().body(transactionDetails);
	}
	
	@GetMapping("/getLast3DaysTransaction")
	@ApiOperation(value = "Get erchant details from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getLast3DaysTransaction(@RequestParam("uuid") String uuid) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		List<TransactionDetailsDto> transactionDetails = paymentMerchantService.getLast3DaysTransaction(uuid);
		
		return ResponseEntity.ok().body(transactionDetails);
	}
	
	@GetMapping("/getSettleDetailsLat7Days")
	@ApiOperation(value = "Get erchant details from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getSettleDetailsLat7Days(@RequestParam("uuid") String uuid) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		List<MerchantBalanceSheet> merchantBalanceSheet = paymentMerchantService.getSettleDetailsLat7Days(uuid);
		
		return ResponseEntity.ok().body(merchantBalanceSheet);
	}
	
	@GetMapping("/getUnSettleDetails")
	@ApiOperation(value = "Get erchant details from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getUnSettleDetails(@RequestParam("uuid") String uuid) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		List<MerchantSettlement> transactionDetails = paymentMerchantService.getUnSettleDetails(uuid);
	
		return ResponseEntity.ok().body(transactionDetails);
	}
	@GetMapping("/getSettleDetails")
	@ApiOperation(value = "Get erchant details from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getSettleDetails(@RequestParam("uuid") String uuid) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		List<MerchantSettlement> transactionDetails = paymentMerchantService.getSettleDetails(uuid);
	
		return ResponseEntity.ok().body(transactionDetails);
	}
	@GetMapping("/dashBoardBalance")
	@ApiOperation(value = "Get Merchant details from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getDashBoardBalance(@RequestParam("uuid") String uuid) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		DashBoardDetails merchantDashBoardBalance = paymentMerchantService.getDashBoardBalance(uuid);
		
		return ResponseEntity.ok().body(merchantDashBoardBalance);
	}
	
	@PostMapping("/createBankDetails")
	@ApiOperation(value = "Get Merchant details from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> createbankDetails(@RequestParam("uuid") String uuid, MerchantBankDetails merchantBankDetails ) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		merchantBankDetails = paymentMerchantService.createBankDetails(merchantBankDetails,uuid);
		
		return ResponseEntity.ok().body(merchantBankDetails);
	}
	
	/*
	@PostMapping("/createCommissionStructure4Merchant")
	@ApiOperation(value = "Post Merchant Services from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> createCommStrucForMerchant(@RequestParam("uuid") String uuid, 
			@RequestParam("merchantPGNme") String merchantPGNme,
			@RequestParam("merchantService") String merchantService,
			@RequestParam("pgCommissionType") String pgCommissionType,
			@RequestParam("pgAmount") int pgAmount,
			@RequestParam("askCommissionType") String asCommissionType,
			@RequestParam("askAmount") int askAmount
			) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		CommissionStructure commissionStructure= pgGatewayAdminService.createCommissionstructure(merchantPGNme,merchantService,pgAmount,pgCommissionType,askAmount,asCommissionType,uuid);
		
		return ResponseEntity.ok().body(commissionStructure);
	}
	
	@PostMapping("/createCommissionStructure4Asktech")
	@ApiOperation(value = "Post Merchant Services from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> createCommissionstructureAskTech(
			@RequestParam("merchantPGNme") String merchantPGNme,
			@RequestParam("merchantService") String merchantService,		
			@RequestParam("pgCommissionType") String pgCommissionType,
			@RequestParam("pgAmount") int pgAmount,
			@RequestParam("askCommissionType") String asCommissionType,
			@RequestParam("askAmount") int askAmount
			) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		CommissionStructure commissionStructure= pgGatewayAdminService.createCommissionstructureAskTech(merchantPGNme,merchantService,pgAmount,pgCommissionType,askAmount,asCommissionType);
		
		return ResponseEntity.ok().body(commissionStructure);
	}
	*/
	@GetMapping("/getBankdetails")
	@ApiOperation(value = "Get Merchant details from Merchant Credentials.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getBankDetails(@RequestParam("uuid") String uuid) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		MerchantBankDetails merchantBankDetails = paymentMerchantService.getBankDetails(uuid);
		
		return ResponseEntity.ok().body(merchantBankDetails);
	}
	
	@PutMapping("/updateBankdetails")
	@ApiOperation(value = "Update Merchant Bank Details as per Merchant Request.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> updateBankDetails(@RequestParam("uuid") String uuid, @RequestBody MerchantBankDetails merchantBankDetails) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		merchantBankDetails = paymentMerchantService.updateBankDetails(uuid,merchantBankDetails);
		
		return ResponseEntity.ok().body(merchantBankDetails);
	}
	
	@GetMapping("/getCustomer")
	@ApiOperation(value = "Update Merchant Bank Details as per Merchant Request.", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getCustomerkDetails(@RequestParam("emailIdOrPhone") String custEmailorPhone) throws UserException, JWTException, SessionExpiredException, JsonProcessingException,IllegalAccessException, NoSuchAlgorithmException, ValidationExceptions{
		
		logger.info("In the controller");
		List<UserDetails> userDetails = pgGatewayAdminService.getUserDetails(custEmailorPhone);
		
		return ResponseEntity.ok().body(userDetails);
	}
	
	@GetMapping(value = "/merchant/transactionDetailsDateFilter")
	@ApiOperation(value = "Admin User with Date wise transaction ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> adminTransactionDetailsDateWise(@RequestParam("uuid") String uuid,
			@RequestParam("dateFrom") String dateFrom,
			@RequestParam("dateTo") String dateTo)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		if (!Validator.isValidateDateFormat(dateFrom) || dateFrom == null) {
			logger.info("Date validation error 1 ... "+ dateTo);
			throw new ValidationExceptions(DATE_FORMAT_VALIDATION, FormValidationExceptionEnums.DATE_FORMAT_VALIDATION);
		}
		if (dateTo.length()!=0) {
			if (!Validator.isValidateDateFormat(dateTo)) {
				logger.info("Date validation error ... "+ dateTo);
				throw new ValidationExceptions(DATE_FORMAT_VALIDATION,
						FormValidationExceptionEnums.DATE_FORMAT_VALIDATION);
			}
		}

		return ResponseEntity.ok().body(pgGatewayAdminService.getTransactiilteronDetailsWithDateF(user.getMerchantID(),
				dateFrom, dateTo));
	}
	
	
	
	@GetMapping(value = "/merchant/lastDaySettleMent")
	@ApiOperation(value = "Merchant User with Date wise transaction ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> merchantSettleMentLastDay(@RequestParam("uuid") String uuid
			)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		
		return ResponseEntity.ok().body(paymentMerchantService.getMerchantLastDaySettlement(user.getMerchantID()));
	}
	
	@GetMapping(value = "/merchant/currDaySettleMent")
	@ApiOperation(value = "Merchant User with Date wise transaction ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> merchantSettleMentCurrDay(@RequestParam("uuid") String uuid
			)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		
		return ResponseEntity.ok().body(paymentMerchantService.getMerchantCurrDaySettlement(user.getMerchantID()));
	}
	
	@GetMapping(value = "/merchant/last7DaysSettleMent")
	@ApiOperation(value = "Merchant User with Date wise transaction ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> merchantSettleMentLast7Days(@RequestParam("uuid") String uuid
			)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		
		return ResponseEntity.ok().body(paymentMerchantService.getMerchantLast7DaySettlement(user.getMerchantID()));
	}
	@GetMapping(value = "/merchant/currMonthSettleMent")
	@ApiOperation(value = "Merchant User with Date wise transaction ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> merchantSettleMentCurrMonth(@RequestParam("uuid") String uuid
			)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		
		return ResponseEntity.ok().body(paymentMerchantService.getMerchantCurrMonthSettlement(user.getMerchantID()));
	}
	@GetMapping(value = "/merchant/lastMonthSettleMent")
	@ApiOperation(value = "Merchant User with Date wise transaction ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> merchantSettleMentlastMonth(@RequestParam("uuid") String uuid
			)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		
		return ResponseEntity.ok().body(paymentMerchantService.getMerchantLastMonthSettlement(user.getMerchantID()));
	}
	
	@GetMapping(value = "/merchant/last90DaysSettleMent")
	@ApiOperation(value = "Merchant User with Date wise transaction ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> merchantSettleMentLast90Days(@RequestParam("uuid") String uuid
			)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		
		return ResponseEntity.ok().body(paymentMerchantService.getMerchantLast90DaySettlement(user.getMerchantID()));
	}
	
	@GetMapping(value = "/merchant/detailsMerchantDetailsReport")
	@ApiOperation(value = "Merchant User with Date wise transaction ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getMerchantDetailsReport(@RequestParam("uuid") String uuid
			)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		
		return ResponseEntity.ok().body(paymentMerchantService.getMerchantDetailsReport(user.getMerchantID()));
	}

	@GetMapping(value = "/merchant/merchantTransactionLastDay")
	@ApiOperation(value = "User can logout. ", authorizations = { @Authorization(value = "apiKey") })
	public ResponseEntity<?> adminMerchantTransactionYesterday(@RequestParam("uuid") String uuid)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		return ResponseEntity.ok().body(paymentMerchantService.merchantStatusTransactionLastDay(user));
	}

	@GetMapping(value = "/merchant/merchantTransactionToday")
	@ApiOperation(value = "User can logout. ", authorizations = { @Authorization(value = "apiKey") })
	public ResponseEntity<?> adminMerchantTransactionToday(@RequestParam("uuid") String uuid, HttpServletRequest request)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);
		
		return ResponseEntity.ok().body(paymentMerchantService.merchantStatusTransactionToday(user));
	}

	@GetMapping(value = "/merchant/merchantTransactionCurrMonth")
	@ApiOperation(value = "User can logout. ", authorizations = { @Authorization(value = "apiKey") })
	public ResponseEntity<?> adminMerchantTransactionCurrMonth(@RequestParam("uuid") String uuid)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		return ResponseEntity.ok().body(paymentMerchantService.merchantStatusTransactionCurrMonth(user));
	}

	@GetMapping(value = "/merchant/merchantTransactionLastMonth")
	@ApiOperation(value = "User can logout. ", authorizations = { @Authorization(value = "apiKey") })
	public ResponseEntity<?> adminMerchantTransactionLastMonth(@RequestParam("uuid") String uuid)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		return ResponseEntity.ok().body(paymentMerchantService.merchantStatusTransactionLastMonth(user));
	}
	
	@PostMapping(value = "/merchant/merchantCreateApiForCustomer")
	@ApiOperation(value = "User can logout. ", authorizations = { @Authorization(value = "apiKey") })
	public ResponseEntity<?> merchantCreateApiForCustomer(
			@RequestParam("uuid") String uuid,
			@RequestParam("custName") String custName,
			@RequestParam("custPhone") String custPhone,
			@RequestParam("custEmail") String custEmail,
			@RequestParam("custAmount") String custAmount,
			@RequestParam("linkExpiry") int linkExpiry)
			throws UserException, JWTException, SessionExpiredException, ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException, ParseException, UnsupportedEncodingException {

		MerchantDetails user = jwtValidator.validatebyJwtMerchantDetails(uuid);

		return ResponseEntity.ok().body(paymentMerchantService.merchantCreateApiForCustomer(uuid,user, custName,custPhone,custEmail,custAmount,linkExpiry));
	}
	
	
}
