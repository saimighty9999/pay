package com.asktech.pgateway.constants;

public interface NetBankingFields extends Fields{
	String NB_PAYMENT_CODE = "paymentcode";
}
