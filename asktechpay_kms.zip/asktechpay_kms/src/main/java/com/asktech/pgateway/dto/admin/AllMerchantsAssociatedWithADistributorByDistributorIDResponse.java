package com.asktech.pgateway.dto.admin;

import java.io.Serializable;
import java.util.List;

import com.asktech.pgateway.model.MerchantDetails;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class AllMerchantsAssociatedWithADistributorByDistributorIDResponse implements Serializable {

	/**@author abhimanyu-kumar*/
	private static final long serialVersionUID = 2942476814492696784L;
	private int status;
	private String message;
	private List<MerchantDetails> listOfMerchantDetails;
	
	

}
