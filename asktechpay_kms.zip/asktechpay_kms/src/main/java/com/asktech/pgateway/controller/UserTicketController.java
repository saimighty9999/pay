package com.asktech.pgateway.controller;

import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.asktech.pgateway.constants.ErrorValues;
import com.asktech.pgateway.dto.ticket.TicketCreateRequest;
import com.asktech.pgateway.dto.ticket.TicketUpdateRequest;
import com.asktech.pgateway.exception.JWTException;
import com.asktech.pgateway.exception.SessionExpiredException;
import com.asktech.pgateway.exception.UserException;
import com.asktech.pgateway.exception.ValidationExceptions;
import com.asktech.pgateway.model.MerchantDetails;
import com.asktech.pgateway.model.UserAdminDetails;
import com.asktech.pgateway.security.JwtGenerator;
import com.asktech.pgateway.service.TicketingService;
import com.asktech.pgateway.util.CommissionCalculator;
import com.asktech.pgateway.util.JwtUserValidator;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.Authorization;

@RestController
public class UserTicketController implements ErrorValues {

	@Autowired
	JwtUserValidator jwtValidator;

	@Autowired
	TicketingService ticketingService;
	@Autowired
	private JwtGenerator jwtGenerator;
	@Autowired
	private JwtUserValidator jwtUserValidator;
	@Autowired
	CommissionCalculator commissionCalculator;

	public UserTicketController(JwtGenerator jwtGenerator) {
		this.jwtGenerator = jwtGenerator;
	}

	static Logger logger = LoggerFactory.getLogger(UserTicketController.class);

	@PostMapping(value = "/api/admin/createComplaintType")
	@ApiOperation(value = "Create API for Complaint Type ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> createComplaintType(@RequestParam("uuid") String uuid,
			@RequestParam("complaintType") String complaintType) throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions {

		UserAdminDetails userAdminDetails = jwtUserValidator.validatebyJwtAdminDetails(uuid);
		logger.info("User Validation done :: "+userAdminDetails.getEmailId());

		return ResponseEntity.ok().body(ticketingService.createComplaintType(uuid, complaintType));
	}
	
	@PostMapping(value = "/api/admin/createComplaintSubType")
	@ApiOperation(value = "Create API for Complaint Type ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> createComplaintSubType(@RequestParam("uuid") String uuid,
			@RequestParam("complaintType") String complaintType,
			@RequestParam("complaintSubType") String complaintSubType) throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions {

		UserAdminDetails userAdminDetails = jwtUserValidator.validatebyJwtAdminDetails(uuid);
		logger.info("User Validation done :: "+userAdminDetails.getEmailId());

		return ResponseEntity.ok().body(ticketingService.createComplaintSubType(uuid, complaintType, complaintSubType));
	}
	
	@PutMapping(value = "/api/admin/updateComplaintType")
	@ApiOperation(value = "Create API for Complaint Type ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> updateComplaintType(@RequestParam("uuid") String uuid,
			@RequestParam("complaintType") String complaintType,
			@RequestParam("status") String status) throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions {

		UserAdminDetails userAdminDetails = jwtUserValidator.validatebyJwtAdminDetails(uuid);
		logger.info("User Validation done :: "+userAdminDetails.getEmailId());

		return ResponseEntity.ok().body(ticketingService.updateComplaintType(uuid, complaintType,status));
	}
	
	@PutMapping(value = "/api/admin/updateComplaintSubType")
	@ApiOperation(value = "Create API for Complaint Type ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> updateComplaintSubType(@RequestParam("uuid") String uuid,
			@RequestParam("complaintType") String complaintType,
			@RequestParam("subType") String subType,
			@RequestParam("status") String status) throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions {

		UserAdminDetails userAdminDetails = jwtUserValidator.validatebyJwtAdminDetails(uuid);
		logger.info("User Validation done :: "+userAdminDetails.getEmailId());

		return ResponseEntity.ok().body(ticketingService.updateComplaintSubType(uuid, complaintType,subType,status));
	}
	
	@PostMapping(value = "/api/merchant/createComplaint")
	@ApiOperation(value = "Create API for Complaint Type ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> createComplaint(@RequestParam("uuid") String uuid,
			@RequestBody TicketCreateRequest ticketCreateRequest
			) throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails merchantDetails = jwtUserValidator.validatebyJwtMerchantDetails(uuid);
		logger.info("User Validation done :: "+merchantDetails.getMerchantEMail());

		return ResponseEntity.ok().body(ticketingService.createTicket(uuid, ticketCreateRequest, merchantDetails));
	}
	
	@PutMapping(value = "/api/merchant/updateTicket")
	@ApiOperation(value = "Create API for Complaint Type ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> updateTicketMerchant(@RequestParam("uuid") String uuid,
			@RequestBody TicketUpdateRequest ticketUpdateRequest
			) throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails merchantDetails = jwtUserValidator.validatebyJwtMerchantDetails(uuid);
		logger.info("User Validation done :: "+merchantDetails.getMerchantEMail());

		return ResponseEntity.ok().body(ticketingService.updateTicketMerchant(uuid, ticketUpdateRequest, merchantDetails));
	}
	
	@PutMapping(value = "/api/admin/updateTicket")
	@ApiOperation(value = "Create API for Complaint Type ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> updateTicketAdmin(@RequestParam("uuid") String uuid,
			@RequestBody TicketUpdateRequest ticketUpdateRequest
			) throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions, ParseException {

		UserAdminDetails userAdminDetails = jwtUserValidator.validatebyJwtAdminDetails(uuid);
		logger.info("User Validation done :: "+userAdminDetails.getEmailId());

		return ResponseEntity.ok().body(ticketingService.updateTicketAdmin(uuid, ticketUpdateRequest));
	}
	
	@PutMapping(value = "/api/merchant/reopenTicket")
	@ApiOperation(value = "Create API for Complaint Type ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> reopenTicketMerchant(
			@RequestParam("uuid") String uuid,
			@RequestParam("complaintId") String complaintId,
			@RequestParam("complantTest") String complantTest
			) throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails merchantDetails = jwtUserValidator.validatebyJwtMerchantDetails(uuid);
		logger.info("User Validation done :: "+merchantDetails.getMerchantEMail());

		return ResponseEntity.ok().body(ticketingService.reopenTicket(uuid, complaintId, complantTest));
	}
	
	@GetMapping(value = "/api/merchant/complaintDetails")
	@ApiOperation(value = "Create API for Complaint Type ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getComplaintDetails(
			@RequestParam("uuid") String uuid
			) throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions, ParseException {

		MerchantDetails merchantDetails = jwtUserValidator.validatebyJwtMerchantDetails(uuid);
		logger.info("User Validation done :: "+merchantDetails.getMerchantEMail());

		return ResponseEntity.ok().body(ticketingService.getTicketDetails(uuid));
	}
	
	@GetMapping(value = "/api/admin/complaintDetails")
	@ApiOperation(value = "Create API for Complaint Type ", authorizations = {
			@Authorization(value = "apiKey") })
	public ResponseEntity<?> getComplaintDetailsAdmin(
			@RequestParam("uuid") String uuid
			) throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions, ParseException {

		UserAdminDetails userAdminDetails = jwtUserValidator.validatebyJwtAdminDetails(uuid);
		logger.info("User Validation done :: "+userAdminDetails.getEmailId());

		return ResponseEntity.ok().body(ticketingService.getTicketDetailsAdmin(uuid));
	}
	
	@PostMapping(value="/testCommission")
	public ResponseEntity<?> reopenTicketMerchant() throws UserException, JWTException, 
	SessionExpiredException, ValidationExceptions, ParseException, JsonProcessingException {		

		return ResponseEntity.ok().body(null);
	}
}
