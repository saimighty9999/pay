package com.asktech.pgateway.constants;

public interface WalletFields extends Fields{
	String PAYMENT_CODE = "paymentcode";
}
