package com.asktech.pgateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.pgateway.model.MerchantRequest4Customer;

public interface MerchantRequest4CustomerRepository extends JpaRepository<MerchantRequest4Customer, String> {

}
