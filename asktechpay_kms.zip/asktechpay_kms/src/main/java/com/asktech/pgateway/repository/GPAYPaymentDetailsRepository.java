package com.asktech.pgateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.pgateway.model.GPAYPaymentDetails;

public interface GPAYPaymentDetailsRepository extends JpaRepository<GPAYPaymentDetails, String>{

}
