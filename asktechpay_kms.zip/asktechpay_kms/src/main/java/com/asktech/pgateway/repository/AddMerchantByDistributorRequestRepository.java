package com.asktech.pgateway.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.asktech.pgateway.model.AddMerchantByDistributorRequest;

@Repository
public interface AddMerchantByDistributorRequestRepository extends JpaRepository<AddMerchantByDistributorRequest, Long>{

	
	
	List<AddMerchantByDistributorRequest> findByDistributorID(String distributorID);
	//AddMerchantByDistributorRequest findByDistributorID(String distributorID);

	AddMerchantByDistributorRequest findByDistributorIDAndUuid(String distributorID, String addMerchantRequestUuid);


}
