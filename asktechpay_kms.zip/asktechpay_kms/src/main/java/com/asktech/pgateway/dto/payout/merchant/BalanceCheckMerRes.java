package com.asktech.pgateway.dto.payout.merchant;

public class BalanceCheckMerRes {

}
