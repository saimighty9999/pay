package com.asktech.pgateway.dto.admin;

import java.io.Serializable;

import com.asktech.pgateway.model.DistributorMerchantDetails;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class DistributorMerchantDetailsResponse implements Serializable{
	/**@author abhimanyu-kumar*/

	private static final long serialVersionUID = 7155350301436831056L;
	private int status;
	private String message;
	private DistributorMerchantDetails distributorMerchantDetails;

}
