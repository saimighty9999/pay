package com.asktech.pgateway.customInterface;

public interface IMerchantStatus {

	String getStatus();
	String getAdminUUid();
	String getMerchantCount();
	
}
