package com.asktech.pgateway.enums;

public enum TransactionMethods {

	CARD, WALLET, NETBANKING, UPI;
	TransactionMethods(){
		
	}
}
