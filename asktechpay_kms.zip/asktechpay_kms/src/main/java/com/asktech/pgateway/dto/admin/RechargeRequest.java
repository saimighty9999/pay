package com.asktech.pgateway.dto.admin;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;
/**@author abhimanyu-kumar*/
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class RechargeRequest implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8114443377343980087L;
	
	private String amount;
	private String notes;// you can use clob
	private String utr;
}
