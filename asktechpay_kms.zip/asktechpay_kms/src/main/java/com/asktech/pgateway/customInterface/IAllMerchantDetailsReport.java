package com.asktech.pgateway.customInterface;

public interface IAllMerchantDetailsReport {

	String getMerchantEMail();
	String getMerchantId();
	String getMerchantName();
	String getPhoneNumber();	
	String getkycStatus();
	String getServiceType();
	String getServiceStatus();
	String getPGName();
	String getPGStatus();
}
