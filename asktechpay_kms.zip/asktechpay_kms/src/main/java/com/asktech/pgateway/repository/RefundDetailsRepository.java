package com.asktech.pgateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.pgateway.model.RefundDetails;

public interface RefundDetailsRepository extends JpaRepository<RefundDetails, String> {

	RefundDetails findByMerchantIdAndMerchantOrderIdAndStatus(String merchantId, String orderId, String string);

}
