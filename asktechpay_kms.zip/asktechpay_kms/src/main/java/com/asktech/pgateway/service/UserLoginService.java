package com.asktech.pgateway.service;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.asktech.pgateway.constants.ErrorValues;
import com.asktech.pgateway.constants.cashfree.CashFreeFields;
import com.asktech.pgateway.dto.login.LoginRequestDto;
import com.asktech.pgateway.dto.login.LoginResponseDto;
import com.asktech.pgateway.dto.login.LogoutRequestDto;
import com.asktech.pgateway.dto.merchant.OTPConfirmation;
import com.asktech.pgateway.enums.FormValidationExceptionEnums;
import com.asktech.pgateway.enums.UserStatus;
import com.asktech.pgateway.exception.ValidationExceptions;
import com.asktech.pgateway.mail.MailIntegration;
import com.asktech.pgateway.model.MerchantDetails;
import com.asktech.pgateway.model.MobileOtp;
import com.asktech.pgateway.model.UserOTPDetails;
import com.asktech.pgateway.model.UserSession;
import com.asktech.pgateway.repository.MerchantDetailsRepository;
import com.asktech.pgateway.repository.MobileOtpRepository;
import com.asktech.pgateway.repository.UserOTPDetailsRepository;
import com.asktech.pgateway.security.Encryption;
import com.asktech.pgateway.util.SmsCallTemplate;
import com.asktech.pgateway.util.Validator;

import jdk.jshell.spi.ExecutionControl.UserException;

@Service
public class UserLoginService implements CashFreeFields, ErrorValues {

	@Autowired
	MerchantDetailsRepository repo;
	@Autowired
	UserOTPDetailsRepository userOTPDetailsRepository;
	@Autowired
	MobileOtpRepository mobileOtpRepository;

	@Value("${idealSessionTimeOut}")
	long IDEAL_EXPIRATION_TIME;
	
	@Value("${otpExpiryTime}")
	long otpExpiryTime;
	@Value("${otpCount}")
	long otpCount;
	@Value("smsSenderId")
	String smsSenderId;

	long EXPIRATION_TIME = 60 * 24;
	
	@Autowired
	MailIntegration sendMail;
	@Autowired
	SmsCallTemplate smsCallTemplate;

	static Logger logger = LoggerFactory.getLogger(UserLoginService.class);

	public OTPConfirmation getUserLogin(LoginRequestDto dto)
			throws UserException, NoSuchAlgorithmException, IOException, ValidationExceptions {
		
		
		if (dto.getPassword().isEmpty()) {
			throw new ValidationExceptions(EMAIL_ID_NOT_FOUND, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}

		MerchantDetails user = repo.findByMerchantEMail(dto.getUserNameOrEmail());
		if (user == null) {

			throw new ValidationExceptions(EMAIL_ID_NOT_FOUND, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);

		}if (user.getPassword() != null) {
			if (dto.getPassword() == null) {
				throw new ValidationExceptions(PASSWORD_CANT_BE_BLANK,
						FormValidationExceptionEnums.PASSWORD_VALIDATION_ERROR);

			} //else if (!user.getPassword().equals(Encryption.getEncryptedPassword(dto.getPassword()))) {
			else if (!dto.getPassword().equals(Encryption.getDecryptedPassword(user.getPassword()))) {
				throw new ValidationExceptions(PASSWORD_MISMATCH,
						FormValidationExceptionEnums.PASSWORD_VALIDATION_ERROR);
			}
		} else {
			throw new ValidationExceptions(PASSWORD_MISMATCH, FormValidationExceptionEnums.PASSWORD_VALIDATION_ERROR);
		}

		
		if(user.getInitialPwdChange()==null) {
			throw new ValidationExceptions(INITIAL_PASSWORD_CHANGE_REQUEST,
					FormValidationExceptionEnums.INITIAL_PASSWORD_CHANGE_REQUIRED);
		}
		
		if (user.getUserStatus().equals(UserStatus.BLOCKED.toString())) {
			throw new ValidationExceptions(USER_STATUS_BLOCKED, FormValidationExceptionEnums.USER_STATUS_BLOCKED);

		}
		if (user.getUserStatus().equals(UserStatus.DELETE.toString())) {

			throw new ValidationExceptions(USER_STATUS_REMOVED, FormValidationExceptionEnums.USER_STATUS_REMOVED);
		}
		
		sendMobileOtp(user);
		OTPConfirmation otpConfirmation = new OTPConfirmation();
		otpConfirmation.setResponseCode("200");
		otpConfirmation.setResponseText("Login OPT has been send to register Mobile Number and Email Id . Valid for 2 Mins");
		otpConfirmation.setUserId(dto.getUserNameOrEmail());
		
		return otpConfirmation;
	}
	
	public void userResenOtp(String emailorphone) throws UserException, ValidationExceptions {
		MerchantDetails user = repo.findByMerchantEMail(emailorphone);
		if (user == null) {
			throw new ValidationExceptions(EMAIL_ID_NOT_FOUND, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);			
		}
		sendMobileOtp(user);
	}
	public LoginResponseDto verifyOtp(int otp, LoginRequestDto dto) throws UserException, ValidationExceptions {
		
		long EXPIRATION_TIME = 60 * 24;
		MobileOtp motp = mobileOtpRepository.findByOtpAndUserName(otp, dto.getUserNameOrEmail());
		if (motp == null) {
			logger.info("Invalid otp==> ");
			throw new ValidationExceptions(OPT_EXPIRED, FormValidationExceptionEnums.OPT_EXPIRED);
		}
		Calendar cal = Calendar.getInstance();
		Date dat = cal.getTime();
		if ((motp.getExpDate()).before(dat)) {
			mobileOtpRepository.delete(motp);			
			throw new ValidationExceptions(OPT_EXPIRED, FormValidationExceptionEnums.OPT_EXPIRED);
		}
		
		MerchantDetails user = repo.findByMerchantEMail(dto.getUserNameOrEmail());
		if (user == null) {
			throw new ValidationExceptions(EMAIL_ID_NOT_FOUND, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}
		
		if (user.getUserStatus().equals(UserStatus.BLOCKED.toString())) {
			throw new ValidationExceptions(USER_STATUS_BLOCKED, FormValidationExceptionEnums.USER_STATUS_BLOCKED);

		}
		if (user.getUserStatus().equals(UserStatus.DELETE.toString())) {

			throw new ValidationExceptions(USER_STATUS_REMOVED, FormValidationExceptionEnums.USER_STATUS_REMOVED);
		}
		
		if (user.getUserSession() != null) {
			user.getUserSession().setSessionStatus(0);
		}

		UserSession session = new UserSession();
		if (user.getUserSession() != null) {
			session = user.getUserSession();
		}
		session.setSessionStatus(1);
		session.setUserAgent(dto.getUserAgent());
		session.setIpAddress(dto.getIpAddress());
		session.setUser(user);
		String hash = Encryption.getSHA256Hash(UUID.randomUUID().toString() + user.getMerchantEMail());
		session.setSessionToken(hash);
		ZonedDateTime expirationTime = ZonedDateTime.now(ZoneOffset.UTC).plus(EXPIRATION_TIME, ChronoUnit.MINUTES);
		Date date = Date.from(expirationTime.toInstant());
		session.setSessionExpiryDate(date);
		ZonedDateTime idealExpirationTime = ZonedDateTime.now(ZoneOffset.UTC).plus(IDEAL_EXPIRATION_TIME,
				ChronoUnit.MINUTES);
		Date idealDate = Date.from(idealExpirationTime.toInstant());
		session.setIdealSessionExpiry(idealDate);
		user.setUserSession(session);
		repo.save(user);
		
		mobileOtpRepository.delete(motp);

		LoginResponseDto loginResponseDto = new LoginResponseDto();

		loginResponseDto.setUuid(user.getUuid());
		loginResponseDto.setEmail(user.getMerchantEMail());
		loginResponseDto.setPhoneNumber(user.getPhoneNumber());
		loginResponseDto.setSessionStatus(user.getUserSession().getSessionStatus());
		loginResponseDto.setSessionToken(user.getUserSession().getSessionToken());
		loginResponseDto.setSessionExpiryDate(user.getUserSession().getSessionExpiryDate());

		return loginResponseDto;
	}
	
	private void sendMobileOtp(MerchantDetails user) throws UserException, ValidationExceptions {
		try {
			int otp = new Random().nextInt(900000) + 100000;
			String message = "Hi " + user.getMerchantName() + " Welcome to IMobile, Your OTP for login is " + otp;
			String mobileNo = "91" + user.getPhoneNumber();
			sendSMSMessage(user.getPhoneNumber(),user.getMerchantEMail(), otp);
			smsCallTemplate.smsSendbyApi(message, mobileNo, smsSenderId);	
			sendMail.sendLoginOtpMail(user.getMerchantName(), user.getMerchantEMail(), user.getPhoneNumber(), String.valueOf(otp));
		} catch (Exception e) {			
			throw new ValidationExceptions(SMS_SEND_ERROR, FormValidationExceptionEnums.SMS_SEND_ERROR);
		}
	}
	
	private void sendSMSMessage(String phoneNumber, String userName,int otp) throws UserException, ValidationExceptions {
		MobileOtp motp = null;
		motp = mobileOtpRepository.findBymobileNo(phoneNumber);
		if (motp == null) {
			motp = new MobileOtp();
			ZonedDateTime expirationTime = ZonedDateTime.now(ZoneOffset.UTC).plus(otpExpiryTime, ChronoUnit.MINUTES);
			Date date = Date.from(expirationTime.toInstant());
			motp.setCount(1);
			motp.setExpDate(date);
			motp.setUserName(userName);
			motp.setMobileNo(phoneNumber);
			motp.setOtp(otp);
		} else {
			Calendar cal = Calendar.getInstance();
			Date dat = cal.getTime();
			if ((motp.getExpDate()).after(dat) && motp.getCount() >= otpCount) {			
				
				throw new ValidationExceptions(SMS_OTP_COUNTER_REACHED, FormValidationExceptionEnums.TRY_AFTER_5_MINUTES);
			}
			if (motp.getCount() == otpCount) {
				motp.setCount(1);
			} else {
				motp.setCount(motp.getCount() + 1);
			}
			motp.setOtp(otp);
		}
		mobileOtpRepository.save(motp);
	}

	public void userLogout(LogoutRequestDto dto) throws UserException, ValidationExceptions {

		MerchantDetails user = repo.findByuuid(dto.getUuid());

		if (!(user.getUserSession().getSessionToken()).equals(dto.getSessionToken())) {
			logger.error("Session Token does not Exist");

			throw new ValidationExceptions(SESSION_NOT_FOUND, FormValidationExceptionEnums.SESSION_NOT_FOUND);
		}
		user.getUserSession().setSessionStatus(0);
		repo.save(user);
	}
	
	public void initiatlPasswordChange(String userNameOrEmailId, String password) throws ValidationExceptions {

		if(!Validator.isValidatePassword(password)) {
			throw new ValidationExceptions(PASSWORD_VALIDATION, FormValidationExceptionEnums.PASSWORD_VALIDATION);
		}
		
		MerchantDetails user = repo.findByMerchantEMail(userNameOrEmailId);

		if (user==null) {
			logger.error("User ot found ..." + userNameOrEmailId);

			throw new ValidationExceptions(USER_NOT_EXISTS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}
		user.setPassword(Encryption.getEncryptedPassword(password));
		user.setInitialPwdChange("Y");
		user.setUserStatus(UserStatus.ACTIVE.toString());
		
		repo.save(user);
		
	}

	public void passwordChange(String userNameOrEmailId, String password) throws ValidationExceptions {
		
		if(!Validator.isValidatePassword(password)) {
			throw new ValidationExceptions(PASSWORD_VALIDATION, FormValidationExceptionEnums.PASSWORD_VALIDATION);
		}
		
		MerchantDetails user = repo.findByMerchantEMail(userNameOrEmailId);

		if (user==null) {
			logger.error("User ot found ..." + userNameOrEmailId);

			throw new ValidationExceptions(USER_NOT_EXISTS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}
		user.setPassword(Encryption.getEncryptedPassword(password));
		
		
		repo.save(user);
		
	}
	
	public void forgotPassword(String userNameOrEmailId) throws ValidationExceptions {
		MerchantDetails user = repo.findByMerchantEMail(userNameOrEmailId);
		if (user == null) {
			logger.error("User not found ..." + userNameOrEmailId);

			throw new ValidationExceptions(USER_NOT_EXISTS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}

		int otp = (new Random()).nextInt(90000000) + 10000000;

		String message = "Hi " + user.getMerchantName() + " Your forgot password OTP for change the password is " + otp;

		UserOTPDetails userOTPDetails = userOTPDetailsRepository.findByUuid(user.getUuid());
		ZonedDateTime expirationTime = ZonedDateTime.now(ZoneOffset.UTC).plus(otpExpiryTime, ChronoUnit.MINUTES);
		Date date = Date.from(expirationTime.toInstant());
		if (userOTPDetails == null) {
			userOTPDetails = new UserOTPDetails();
			userOTPDetails.setEmailId(user.getMerchantEMail());
			userOTPDetails.setExpDate(date);
			userOTPDetails.setMobileNo(user.getPhoneNumber());
			userOTPDetails.setModeOfTr("MAIL");
			userOTPDetails.setOptCount(0);
			userOTPDetails.setUuid(user.getUuid());
			userOTPDetails.setOtpValue(String.valueOf(otp));

		} else {
			userOTPDetails.setExpDate(date);
			userOTPDetails.setModeOfTr("MAIL");
			userOTPDetails.setOptCount(userOTPDetails.getOptCount() + 1);
			userOTPDetails.setOtpValue(String.valueOf(otp));

		}
		userOTPDetailsRepository.save(userOTPDetails);

		sendMail.sendMailForgotPassword(user.getMerchantEMail(), message, "Forget Password : " + user.getMerchantName());
	}

	public void forgotPasswordChange(String userNameOrEmailId, String password, String otp)
			throws ValidationExceptions {

		if (!Validator.isValidatePassword(password)) {
			throw new ValidationExceptions(PASSWORD_VALIDATION, FormValidationExceptionEnums.PASSWORD_VALIDATION);
		}

		MerchantDetails user = repo.findByMerchantEMail(userNameOrEmailId);
		if (user == null) {
			logger.error("User not found ..." + userNameOrEmailId);
			throw new ValidationExceptions(USER_NOT_EXISTS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}
		UserOTPDetails userOTPDetails = userOTPDetailsRepository.findByUuid(user.getUuid());
		if (!userOTPDetails.getOtpValue().equalsIgnoreCase(otp)) {
			throw new ValidationExceptions(OTP_MISMATCH, FormValidationExceptionEnums.OTP_MISMATCH);
		}

		Calendar cal = Calendar.getInstance();
		Date dat = cal.getTime();
		if ((userOTPDetails.getExpDate()).before(dat)) {
			userOTPDetailsRepository.delete(userOTPDetails);
			throw new ValidationExceptions(OTP_EXPIRED, FormValidationExceptionEnums.OTP_EXPIRED);
		}
		
		user.setPassword(Encryption.getEncryptedPassword(password));
		userOTPDetailsRepository.delete(userOTPDetails);
		repo.save(user);
	}

}
