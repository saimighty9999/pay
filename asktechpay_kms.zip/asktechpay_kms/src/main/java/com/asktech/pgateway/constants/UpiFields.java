package com.asktech.pgateway.constants;

public interface UpiFields extends Fields{
	String UPI_VPA = "upi_vpa";
}
