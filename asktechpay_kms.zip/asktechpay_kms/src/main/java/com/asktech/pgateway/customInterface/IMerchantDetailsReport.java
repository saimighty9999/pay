package com.asktech.pgateway.customInterface;

public interface IMerchantDetailsReport {

	String getMerchantEMail();
	String getMerchantId();
	String getMerchantName();
	String getPhoneNumber();	
	String getkycStatus();
	String getService();
	String getStatus();
}
