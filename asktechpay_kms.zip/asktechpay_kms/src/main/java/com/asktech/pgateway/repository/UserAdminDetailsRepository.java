package com.asktech.pgateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.asktech.pgateway.model.UserAdminDetails;
@Repository
public interface UserAdminDetailsRepository extends JpaRepository<UserAdminDetails, Long>{

	UserAdminDetails findByUserId(String userNameOrEmail);

	UserAdminDetails findByEmailId(String email);

	//UserAdminDetails findByuuid(String uuid);

	@Query(value= "SELECT * FROM user_admin_details WHERE uuid =:uuid", nativeQuery = true)
	UserAdminDetails findByUuid(@Param("uuid") String uuid);

	//UserAdminDetails findByUuid(String uuid);


}
