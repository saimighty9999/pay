package com.asktech.pgateway.dto.admin;

import java.io.Serializable;

import com.asktech.pgateway.model.DistributorDetails;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;
/**@author abhimanyu-kumar*/
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class DistributorFromDistributorMerchantDetailsResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4002103971545943628L;
	private int status;
	private String message;
	private DistributorDetails distributorDetails;

}
