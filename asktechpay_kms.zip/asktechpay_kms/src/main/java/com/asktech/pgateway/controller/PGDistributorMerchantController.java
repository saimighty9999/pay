package com.asktech.pgateway.controller;

import org.springframework.web.bind.annotation.RestController;
/**@author abhimanyu-kumar*/
@RestController
public class PGDistributorMerchantController {
	
	
	
	
	
	



}
