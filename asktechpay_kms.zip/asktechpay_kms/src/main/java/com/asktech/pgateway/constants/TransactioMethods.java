package com.asktech.pgateway.constants;

public interface TransactioMethods {
	String CARD = "card"; 
	String WALLET = "wallet"; 
	String NETBANKING = "nb";
	String UPI = "upi";
}
