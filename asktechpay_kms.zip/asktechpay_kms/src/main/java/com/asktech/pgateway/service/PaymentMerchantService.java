package com.asktech.pgateway.service;

import java.util.ArrayList;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.asktech.pgateway.constants.ErrorValues;
import com.asktech.pgateway.customInterface.IMerchantDetailsReport;
import com.asktech.pgateway.customInterface.IMerchantSettlement;
import com.asktech.pgateway.customInterface.IMerchantTransaction;
import com.asktech.pgateway.customInterface.ISettlementBalanceReport;
import com.asktech.pgateway.dto.merchant.DashBoardDetails;
import com.asktech.pgateway.dto.merchant.MerchantResponse;
import com.asktech.pgateway.customInterface.IMerchantTransaction;
import com.asktech.pgateway.dto.merchant.MerchantDashBoardBalance;
import com.asktech.pgateway.dto.merchant.MerchantSettlement;
import com.asktech.pgateway.dto.merchant.TransactionDetailsDto;
import com.asktech.pgateway.enums.FormValidationExceptionEnums;
import com.asktech.pgateway.dto.merchant.MerchantResponse;
import com.asktech.pgateway.enums.UserStatus;
import com.asktech.pgateway.exception.ValidationExceptions;
import com.asktech.pgateway.mail.MailIntegration;
import com.asktech.pgateway.model.MerchantBalanceSheet;
import com.asktech.pgateway.model.MerchantBankDetails;
import com.asktech.pgateway.model.MerchantDetails;
import com.asktech.pgateway.model.MerchantRequest4Customer;
import com.asktech.pgateway.model.TransactionDetails;
import com.asktech.pgateway.repository.CommissionStructureRepository;
import com.asktech.pgateway.repository.MerchantBalanceSheetRepository;
import com.asktech.pgateway.repository.MerchantBankDetailsRepository;
import com.asktech.pgateway.repository.MerchantDashBoardBalanceRepository;
import com.asktech.pgateway.repository.MerchantDetailsRepository;
import com.asktech.pgateway.repository.MerchantPGDetailsRepository;
import com.asktech.pgateway.repository.MerchantPGServicesRepository;
import com.asktech.pgateway.repository.MerchantRequest4CustomerRepository;
import com.asktech.pgateway.repository.TransactionDetailsRepository;
import com.asktech.pgateway.repository.UserDetailsRepository;
import com.asktech.pgateway.security.Encryption;
import com.asktech.pgateway.util.EncryptSignature;
import com.asktech.pgateway.util.Utility;
import com.asktech.pgateway.util.Validator;
import com.asktech.pgateway.util.SecurityUtils;
import com.asktech.pgateway.util.Utility;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class PaymentMerchantService implements ErrorValues {

	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	MerchantBalanceSheetRepository merchantBalanceSheetRepository;
	@Autowired
	MerchantDashBoardBalanceRepository merchantDashBoardBalanceRepository;
	@Autowired
	MerchantBankDetailsRepository merchantBankDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	MerchantPGServicesRepository merchantPGServicesRepository;
	@Autowired
	CommissionStructureRepository commissionStructureRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantRequest4CustomerRepository merchantRequest4CustomerRepository;
	@Autowired
	MailIntegration sendMail;

	ObjectMapper mapper = new ObjectMapper();

	static Logger logger = LoggerFactory.getLogger(PaymentMerchantService.class);
	@Value("${apiEndPoint}")
	String apiEndPoint;
	@Value("${apiCustomerNotifyUrl}")
	String apiCustomerNotifyUrl;

	public MerchantResponse merchantView(String uuid) throws ValidationExceptions {
		logger.info("merchantView In this Method.");
		MerchantDetails merchantDetails = merchantDetailsRepository.findByuuid(uuid);

		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}

		MerchantResponse merchantResponse = new MerchantResponse();

		merchantResponse.setMerchantAppId(Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getAppID()));
		merchantResponse.setMerchantEmail(merchantDetails.getMerchantEMail());
		merchantResponse.setMerchantKyc(merchantDetails.getKycStatus());
		merchantResponse.setMerchantName(merchantDetails.getMerchantName());
		merchantResponse.setMerchantPhone(merchantDetails.getPhoneNumber());
		merchantResponse.setMerchantSecret(Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getSecretId()));

		return merchantResponse;
	}

	public List<TransactionDetailsDto> getTransactionDetails(String uuid) throws ValidationExceptions {

		logger.info("merchantView In this Method.");

		MerchantDetails merchantDetails = merchantDetailsRepository.findByuuid(uuid);

		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}
		logger.info("Merchantid" + merchantDetails);
		List<TransactionDetails> listTransactionDetails = transactionDetailsRepository
				.findAllTopByMerchantId(merchantDetails.getMerchantID());
		List<TransactionDetailsDto> trdetails = new ArrayList<TransactionDetailsDto>();
		for (TransactionDetails tr : listTransactionDetails) {
			TransactionDetailsDto trd = new TransactionDetailsDto();
			trd.setMerchantId(tr.getMerchantId());
			trd.setAmount(Float.toString(((float) tr.getAmount() / 100)));
			trd.setPaymentOption(tr.getPaymentOption());
			trd.setOrderID(tr.getOrderID());
			trd.setStatus(tr.getStatus());
			trd.setPaymentMode(tr.getPaymentMode());
			trd.setTxtMsg(tr.getTxtMsg());
			trd.setTransactionTime(tr.getCreated().toString());
			trd.setMerchantOrderId(tr.getMerchantOrderId());
			trd.setMerchantReturnURL(tr.getMerchantReturnURL());
			if (tr.getVpaUPI() != null) {
				trd.setVpaUPI(SecurityUtils.decryptSaveData(tr.getVpaUPI()).replace("\u0000", ""));
			}
			if (tr.getPaymentCode() != null) {
				//trd.setWalletOrBankCode(SecurityUtils.decryptSaveData(tr.getPaymentCode()).replace("\u0000", ""));
				trd.setWalletOrBankCode(tr.getPaymentCode());
			}
			if (tr.getCardNumber() != null) {
				trd.setCardNumber(Utility.maskCardNumber(SecurityUtils.decryptSaveData(tr.getCardNumber()))
						.replace("\u0000", ""));
			}
			trdetails.add(trd);
		}
		return trdetails;
	}

	public List<MerchantSettlement> getSettleDetails(String uuid) throws ValidationExceptions {
		logger.info("getUnSettleDetails In this Method.");

		MerchantDetails merchantDetails = merchantDetailsRepository.findByuuid(uuid);

		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}
		List<ISettlementBalanceReport> merchantBalanceSheet = merchantBalanceSheetRepository
				.getSettlementBalanceSheet("SETTLED", merchantDetails.getMerchantID());
		List<MerchantSettlement> merchantBalSheet = new ArrayList<MerchantSettlement>();
		for (ISettlementBalanceReport mer : merchantBalanceSheet) {
			MerchantSettlement m = new MerchantSettlement();
			m.setAmount(mer.getAmount());
			m.setCreated(mer.getCreated());
			m.setMerchant_id(mer.getMerchant_id());
			m.setMerchant_order_id(mer.getMerchant_order_id());
			m.setSettlement_status(mer.getSettlement_status());
			m.setTr_type(mer.getTr_type());
			m.setSettledAmount(mer.getSettle_amount_to_merchant());
			if (mer.getVpaupi() != null) {
				m.setVpaupi(SecurityUtils.decryptSaveData(mer.getVpaupi()).replace("\u0000", ""));
			}
			if (mer.getPayment_code() != null) {
				m.setWalletOrBankCode(mer.getPayment_code());
			}
			if (mer.getCard_number() != null) {
				m.setCard_number(Utility.maskCardNumber(SecurityUtils.decryptSaveData(mer.getCard_number()))
						.replace("\u0000", ""));
			}

			merchantBalSheet.add(m);

		}
		return merchantBalSheet;
	}

	public List<TransactionDetailsDto> getLast3DaysTransaction(String uuid) throws ValidationExceptions {
		logger.info("getLast3DaysTransaction In this Method.");

		MerchantDetails merchantDetails = merchantDetailsRepository.findByuuid(uuid);

		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}
		List<TransactionDetails> transactionDetails = transactionDetailsRepository
				.findLast3DaysTransaction(merchantDetails.getMerchantID());
		List<TransactionDetailsDto> trdetails = new ArrayList<TransactionDetailsDto>();
		for (TransactionDetails tr : transactionDetails) {
			TransactionDetailsDto trd = new TransactionDetailsDto();
			trd.setMerchantId(tr.getMerchantId());
			trd.setAmount(Float.toString(((float) tr.getAmount() / 100)));
			trd.setPaymentOption(tr.getPaymentOption());
			trd.setOrderID(tr.getOrderID());
			trd.setStatus(tr.getStatus());
			trd.setPaymentMode(tr.getPaymentMode());
			trd.setTxtMsg(tr.getTxtMsg());
			trd.setTransactionTime(tr.getCreated().toString());
			trd.setMerchantOrderId(tr.getMerchantOrderId());
			trd.setMerchantReturnURL(tr.getMerchantReturnURL());
			if (tr.getVpaUPI() != null) {
				trd.setVpaUPI(SecurityUtils.decryptSaveData(tr.getVpaUPI()).replace("\u0000", ""));
			}
			if (tr.getPaymentCode() != null) {
				trd.setWalletOrBankCode(tr.getPaymentCode());
			}
			if (tr.getCardNumber() != null) {
				trd.setCardNumber(Utility.maskCardNumber(SecurityUtils.decryptSaveData(tr.getCardNumber()))
						.replace("\u0000", ""));
			}
			trdetails.add(trd);
		}
		return trdetails;
	}

	public List<MerchantBalanceSheet> getSettleDetailsLat7Days(String uuid) throws ValidationExceptions {
		logger.info("getLast3DaysTransaction In this Method.");

		MerchantDetails merchantDetails = merchantDetailsRepository.findByuuid(uuid);

		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}
		List<MerchantBalanceSheet> merchantBalanceSheet = merchantBalanceSheetRepository
				.findLast7DaysSettleTransaction(merchantDetails.getMerchantID());

		return merchantBalanceSheet;
	}

	public List<MerchantSettlement> getUnSettleDetails(String uuid) throws ValidationExceptions {
		logger.info("getUnSettleDetails In this Method.");

		MerchantDetails merchantDetails = merchantDetailsRepository.findByuuid(uuid);

		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}
		List<ISettlementBalanceReport> merchantBalanceSheet = merchantBalanceSheetRepository
				.getSettlementBalanceSheet("PENDING", merchantDetails.getMerchantID());
		List<MerchantSettlement> merchantBalSheet = new ArrayList<MerchantSettlement>();
		for (ISettlementBalanceReport mer : merchantBalanceSheet) {
			MerchantSettlement m = new MerchantSettlement();
			m.setAmount(mer.getAmount());
			m.setCreated(mer.getCreated());
			m.setMerchant_id(mer.getMerchant_id());
			m.setMerchant_order_id(mer.getMerchant_order_id());
			m.setSettlement_status(mer.getSettlement_status());
			m.setTr_type(mer.getTr_type());

			if (mer.getVpaupi() != null) {
				m.setVpaupi(SecurityUtils.decryptSaveData(mer.getVpaupi()).replace("\u0000", ""));
			}
			if (mer.getPayment_code() != null) {
				m.setWalletOrBankCode(mer.getPayment_code());
			}
			if (mer.getCard_number() != null) {
				m.setCard_number(Utility.maskCardNumber(SecurityUtils.decryptSaveData(mer.getCard_number()))
						.replace("\u0000", ""));
			}

			merchantBalSheet.add(m);

		}
		return merchantBalSheet;
	}

	public DashBoardDetails getDashBoardBalance(String uuid) throws ValidationExceptions {
		logger.info("getDashBoardBalance In this Method.");

		MerchantDetails merchantDetails = merchantDetailsRepository.findByuuid(uuid);

		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}

		DashBoardDetails dashBoardDetails = new DashBoardDetails();

		String amt = "0";
		String unsettledamt = "0";
		String settled = "0";
		List<IMerchantTransaction> tda = transactionDetailsRepository
				.getTodayTrDetails(merchantDetails.getMerchantID());
		float a = 0;
		if (tda.isEmpty()) {
			a = 0;
		} else {
			a = (float) tda.get(0).getAmount() / 100;
		}
		amt = String.valueOf(a);
		logger.info("Todays Amount for dashboard :: " + amt);
		dashBoardDetails.setTodaysTransactions(amt);

		unsettledamt = merchantBalanceSheetRepository.getPendingSettlementTotal(merchantDetails.getMerchantID());

		logger.info("Unsettled Amount for dashboard :: " + unsettledamt);

		dashBoardDetails.setUnsettledAmount(unsettledamt);

		settled = merchantBalanceSheetRepository.getSettledTotal(merchantDetails.getMerchantID());
		logger.info("Settled Amount for dashboard :: " + settled);
		if (settled == null) {
			dashBoardDetails.setLastSettlements("0");
		} else {
			dashBoardDetails.setLastSettlements(settled);
		}
		return dashBoardDetails;
	}

	public MerchantBankDetails createBankDetails(MerchantBankDetails merchantBankDetails, String uuid)
			throws ValidationExceptions {

		logger.info("getDashBoardBalance In this Method.");

		MerchantDetails merchantDetails = merchantDetailsRepository.findByuuid(uuid);

		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}

		MerchantBankDetails merchantBankDetails2 = merchantBankDetailsRepository
				.findByMerchantID(merchantDetails.getMerchantID());
		if (merchantBankDetails2 != null) {
			throw new ValidationExceptions(MERCHANT_BANK_DETAIL_PRESENT,
					FormValidationExceptionEnums.MERCHANT_BANK_DETAILS_EXISTS);
		}

		merchantBankDetails.setMerchantID(merchantDetails.getMerchantID());
		merchantBankDetails.setAccountNo(merchantBankDetails.getAccountNo());
		merchantBankDetails.setBankIFSCCode(merchantBankDetails.getBankIFSCCode());
		merchantBankDetails.setBankName(merchantBankDetails.getBankName());
		merchantBankDetails.setCity(merchantBankDetails.getCity());
		merchantBankDetails.setMicrCode(merchantBankDetails.getMicrCode());
		merchantBankDetailsRepository.save(merchantBankDetails);

		return merchantBankDetails;
	}

	public MerchantBankDetails getBankDetails(String uuid) throws ValidationExceptions {

		MerchantDetails merchantDetails = merchantDetailsRepository.findByuuid(uuid);

		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}

		MerchantBankDetails merchantBankDetails = merchantBankDetailsRepository
				.findByMerchantID(merchantDetails.getMerchantID());
		if (merchantBankDetails == null) {
			throw new ValidationExceptions(BANK_DETAILS_NOT_FOUND,
					FormValidationExceptionEnums.MERCHANT_BANK_DETILS_NOT_FOUND);
		}
		return merchantBankDetails;

	}

	public MerchantBankDetails updateBankDetails(String uuid, MerchantBankDetails merchantBankDetails)
			throws ValidationExceptions {
		MerchantDetails merchantDetails = merchantDetailsRepository.findByuuid(uuid);

		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.EMAIL_ID_NOT_FOUND);
		}

		MerchantBankDetails merchantBankDetails2 = merchantBankDetailsRepository
				.findByMerchantID(merchantDetails.getMerchantID());

		merchantBankDetails2.setAccountNo(merchantBankDetails.getAccountNo());
		merchantBankDetails2.setBankIFSCCode(merchantBankDetails.getBankIFSCCode());
		merchantBankDetails2.setBankName(merchantBankDetails.getBankName());
		merchantBankDetails2.setCity(merchantBankDetails.getCity());
		merchantBankDetails2.setMicrCode(merchantBankDetails.getMicrCode());

		merchantBankDetailsRepository.save(merchantBankDetails2);

		return merchantBankDetails2;
	}

	public List<IMerchantSettlement> getMerchantLastDaySettlement(String merchantID) {

		return merchantBalanceSheetRepository.getLastDaySettlement(merchantID);
	}

	public Object getMerchantCurrDaySettlement(String merchantID) {
		return merchantBalanceSheetRepository.getCurrDaySettlement(merchantID);
	}

	public Object getMerchantLast7DaySettlement(String merchantID) {
		return merchantBalanceSheetRepository.getLast7DaySettlement(merchantID);
	}

	public Object getMerchantCurrMonthSettlement(String merchantID) {
		return merchantBalanceSheetRepository.getCurrMonthSettlement(merchantID);
	}

	public Object getMerchantLastMonthSettlement(String merchantID) {
		return merchantBalanceSheetRepository.getLastMonthSettlement(merchantID);
	}

	public Object getMerchantLast90DaySettlement(String merchantID) {
		return merchantBalanceSheetRepository.getLast90DaySettlement(merchantID);
	}

	public List<IMerchantDetailsReport> getMerchantDetailsReport(String merchantId) {

		List<IMerchantDetailsReport> getMerchantDetailsReport = merchantPGServicesRepository
				.getMerchantDetailsReport(merchantId, UserStatus.ACTIVE.toString());

		return getMerchantDetailsReport;
	}

	public List<IMerchantTransaction> merchantStatusTransactionLastDay(MerchantDetails user) {

		return transactionDetailsRepository.getYesterdayTrDetails(user.getMerchantID());
	}

	public List<IMerchantTransaction> merchantStatusTransactionToday(MerchantDetails user) {
		return transactionDetailsRepository.getTodayTrDetails(user.getMerchantID());
	}

	public List<IMerchantTransaction> merchantStatusTransactionCurrMonth(MerchantDetails user) {
		return transactionDetailsRepository.getCurrMonthTrDetails(user.getMerchantID());
	}

	public List<IMerchantTransaction> merchantStatusTransactionLastMonth(MerchantDetails user) {
		return transactionDetailsRepository.getLastMonthTrDetails(user.getMerchantID());
	}

	public MerchantRequest4Customer merchantCreateApiForCustomer(String uuid, MerchantDetails merchantDetails,
			String custName, String custPhone, String custEmail, String custAmount, int linkExpiry)
			throws ValidationExceptions, ParseException, InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {

		Map<String, String> parameters = new LinkedHashMap<String, String>();
		ZonedDateTime expirationTime = ZonedDateTime.now().plus(60, ChronoUnit.MINUTES);
		Date date = Date.from(expirationTime.toInstant());

		String orderId = String.valueOf(Utility.getEpochTIme());

		if (!Validator.isValidCardUserName(custName)) {
			throw new ValidationExceptions(NAME_VALIDATION_FAILED, FormValidationExceptionEnums.FORM_VALIDATION_FAILED);
		}

		if (!Validator.isValidPhoneNumber(custPhone)) {
			throw new ValidationExceptions(NAME_VALIDATION_FAILED, FormValidationExceptionEnums.FORM_VALIDATION_FAILED);
		}

		if (!Validator.isValidEmail(custEmail)) {
			throw new ValidationExceptions(NAME_VALIDATION_FAILED, FormValidationExceptionEnums.FORM_VALIDATION_FAILED);
		}
		if (!Validator.validDouble(custAmount)) {
			throw new ValidationExceptions(AMOUNT_VALIDATION_ERROR,
					FormValidationExceptionEnums.AMOUNT_VALIDATION_ERROR);
		}

		MerchantRequest4Customer merchantRequest4Customer = new MerchantRequest4Customer();
		merchantRequest4Customer.setAmount(custAmount);
		merchantRequest4Customer.setCreatedBy(uuid);
		merchantRequest4Customer.setCustEmail(custEmail);
		merchantRequest4Customer.setCustName(custName);
		merchantRequest4Customer.setCustPhone(custPhone);
		merchantRequest4Customer.setLinkCustomer(apiEndPoint+"customerRequest/"+Utility.randomStringGenerator(10));
		merchantRequest4Customer.setLinkExpiry(linkExpiry);
		merchantRequest4Customer.setLinkExpiryTime(date);
		merchantRequest4Customer.setStatus(UserStatus.PENDING.toString());
		merchantRequest4Customer.setMerchantId(merchantDetails.getMerchantID());
		merchantRequest4Customer.setOrderCurrency("INR");
		merchantRequest4Customer.setOrderId(orderId);
		merchantRequest4Customer.setOrderNote("From Merchant Portal");
		merchantRequest4Customer.setReturnUrl(apiCustomerNotifyUrl);
		merchantRequest4Customer.setAppId(Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getAppID()));
		
		parameters.put("customerEmail", custEmail);
		parameters.put("customerName", custName);
		parameters.put("customerPhone", custPhone);
		parameters.put("customerid", merchantRequest4Customer.getAppId());
		parameters.put("notifyUrl", apiCustomerNotifyUrl);
		parameters.put("orderAmount", custAmount);
		parameters.put("orderCurrency", "INR");
		parameters.put("orderid", orderId);
		parameters.put("orderNote", "From Merchant Portal");
		
		String data = EncryptSignature.encryptSignature(Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getSecretId()),parameters);
		merchantRequest4Customer.setSignature(data.trim());
		
		sendMail.sendGeneratedMailToCustomer(custName, custEmail, custPhone , merchantRequest4Customer.getLinkCustomer());
		
		return merchantRequest4CustomerRepository.save(merchantRequest4Customer);

	}
}
