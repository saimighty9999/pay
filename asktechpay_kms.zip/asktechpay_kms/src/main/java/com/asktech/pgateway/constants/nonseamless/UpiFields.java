package com.asktech.pgateway.constants.nonseamless;

public interface UpiFields extends Fields{
	String UPI_VPA = "upi_vpa";
}
