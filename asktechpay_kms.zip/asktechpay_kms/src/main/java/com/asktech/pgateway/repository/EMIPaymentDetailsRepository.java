package com.asktech.pgateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.pgateway.model.EMIPaymentDetails;

public interface EMIPaymentDetailsRepository extends JpaRepository<EMIPaymentDetails, String>{

}
