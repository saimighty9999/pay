package com.asktech.pgateway.enums;

public enum ValidationExceptions {
FATAL_EXCEPTION, ALL_FIELDS_MANDATORY;
	
	ValidationExceptions(){
		
	}
}
