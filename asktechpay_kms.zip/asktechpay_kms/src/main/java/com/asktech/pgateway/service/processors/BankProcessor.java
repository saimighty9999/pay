package com.asktech.pgateway.service.processors;

public class BankProcessor {

}
