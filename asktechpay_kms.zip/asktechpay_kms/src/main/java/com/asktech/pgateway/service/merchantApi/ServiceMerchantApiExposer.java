package com.asktech.pgateway.service.merchantApi;

import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.asktech.pgateway.constants.ErrorValues;
import com.asktech.pgateway.dto.merchant.MerchantRefundResponse;
import com.asktech.pgateway.dto.merchant.MerchantTransaction;
import com.asktech.pgateway.dto.merchant.MerchantTransactionResponse;
import com.asktech.pgateway.enums.FormValidationExceptionEnums;
import com.asktech.pgateway.enums.UserStatus;
import com.asktech.pgateway.exception.ValidationExceptions;
import com.asktech.pgateway.model.MerchantBalanceSheet;
import com.asktech.pgateway.model.MerchantDetails;
import com.asktech.pgateway.model.RefundDetails;
import com.asktech.pgateway.model.TransactionDetails;
import com.asktech.pgateway.repository.MerchantBalanceSheetRepository;
import com.asktech.pgateway.repository.MerchantDetailsRepository;
import com.asktech.pgateway.repository.RefundDetailsRepository;
import com.asktech.pgateway.repository.TransactionDetailsRepository;
import com.asktech.pgateway.security.Encryption;
import com.asktech.pgateway.security.SecurityExposerFunction;
import com.asktech.pgateway.util.GeneralUtils;
import com.asktech.pgateway.util.SecurityUtils;
import com.asktech.pgateway.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.jsonwebtoken.Claims;

@Service
public class ServiceMerchantApiExposer implements ErrorValues {

	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	MerchantBalanceSheetRepository merchantBalanceSheetRepository;
	@Autowired
	RefundDetailsRepository refundDetailsRepository;

	static Logger logger = LoggerFactory.getLogger(ServiceMerchantApiExposer.class);

	public MerchantTransaction transactionStatus(String tokenInfo, MultiValueMap<String, String> formData)
			throws ValidationExceptions, NoSuchAlgorithmException, JsonProcessingException {
		logger.info("MerchantAPIService transactionStatus In this Method.");
		logger.info("transactionStatus ::"+GeneralUtils.MultiValueMaptoJson(formData));
		SecurityExposerFunction securityExposerFunction = new SecurityExposerFunction();
		MerchantTransaction merchantTransaction = new MerchantTransaction();

		logger.info("tokenInfo :: " + tokenInfo);
		logger.info("strBody :: " + formData);

		Claims claimBody = securityExposerFunction.decodeJWT(tokenInfo);
		MerchantDetails merchantDetails = merchantDetailsRepository
				.findByAppID(Encryption.encryptCardNumberOrExpOrCvv(claimBody.get("appId").toString()));

		logger.info(Utility.convertDTO2JsonString(claimBody));
		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.MERCHANT_NOT_FOUND);
		}

		logger.info("Before Verify the Token with Secrect key and Signature");
		String SECRET = Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getSecretId()).trim().strip().replace("\u0000", "");
		logger.info("SECRET::"+SECRET);
		securityExposerFunction.decodeJWTwithSignature(tokenInfo,
				SECRET);		
		logger.info("Verification done from Signature with JWT");
		logger.info("claimBody.checkSum :: " + claimBody.get("checkSum"));
		logger.info("Generate the CheckSum :: "
				+ SecurityExposerFunction.generateCheckSum(populatedMultiPleMapToMap(formData),SECRET)
				+ populatedMultiPleMapToMap(formData));

		if (!validateCheckSum(claimBody.get("checkSum").toString(),
				SecurityExposerFunction.generateCheckSum(populatedMultiPleMapToMap(formData),SECRET))) {
			throw new ValidationExceptions(CHECKSUM_MISMATCH, FormValidationExceptionEnums.CHECKSUM_MISMATCH);
		}

		logger.info("CheckSum Validation done ...." + merchantDetails.getMerchantID() + "|"
				+ formData.get("orderId").get(0));

		List<TransactionDetails> listTransactionDetails = transactionDetailsRepository
				.findAllByMerchantOrderIdAndMerchantId(formData.get("orderId").get(0), merchantDetails.getMerchantID());

		List<MerchantTransactionResponse> listMerchantTransactionResponse = populateTransactionDetails(
				listTransactionDetails);

		merchantTransaction.setListMerchantTransactionResponse(listMerchantTransactionResponse);
		merchantTransaction.setHeader(createdHeader(listMerchantTransactionResponse.toString(),SECRET));

		return merchantTransaction;
	}
	
	public MerchantRefundResponse generateRefundRequest(String tokenInfo, MultiValueMap<String, String> formData) throws JsonProcessingException, ValidationExceptions, NoSuchAlgorithmException {		
		
		logger.info("MerchantAPIService generateRefundRequest In this Method.");

		SecurityExposerFunction securityExposerFunction = new SecurityExposerFunction();		

		logger.info("tokenInfo :: " + tokenInfo);
		logger.info("strBody :: " + formData);

		Claims claimBody = securityExposerFunction.decodeJWT(tokenInfo);		
		MerchantDetails merchantDetails = merchantDetailsRepository.findByAppID(claimBody.get("appId").toString());
		logger.info(Utility.convertDTO2JsonString(claimBody));
		if (merchantDetails == null) {
			throw new ValidationExceptions(MERCHNT_NOT_EXISTIS, FormValidationExceptionEnums.MERCHANT_NOT_FOUND);
		}		

		logger.info("Before Verify the Token with Secrect key and Signature");

		securityExposerFunction.decodeJWTwithSignature(tokenInfo,Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getSecretId()));

		logger.info("Verification done from Signature with JWT");
		logger.info("claimBody.checkSum :: " + claimBody.get("checkSum"));
		logger.info("Generate the CheckSum :: "
				+ SecurityExposerFunction.generateCheckSum(populatedMultiPleMapToMap(formData),
						Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getSecretId()))+populatedMultiPleMapToMap(formData));

		if (!validateCheckSum(claimBody.get("checkSum").toString(),
				SecurityExposerFunction.generateCheckSum(populatedMultiPleMapToMap(formData),
						Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getSecretId())))) {
			throw new ValidationExceptions(CHECKSUM_MISMATCH, FormValidationExceptionEnums.CHECKSUM_MISMATCH);
		}
		
		logger.info("Check sum validation success ...");
		MerchantBalanceSheet merchantBalanceSheet = merchantBalanceSheetRepository.findAllByMerchantIdAndMerchantOrderIdAndSettlementStatus(
				merchantDetails.getMerchantID(),
				formData.get("orderId").get(0),
				UserStatus.PENDING.toString());
		
		if(merchantBalanceSheet == null) {
			throw new ValidationExceptions(REFUND_INITIATE_FAILED, FormValidationExceptionEnums.REFUND_INITIATE_FAILED);
		}
		
		RefundDetails refundDetails = new RefundDetails();
		refundDetails.setAmount(String.valueOf(merchantBalanceSheet.getAmount()));
		refundDetails.setCardNumber(merchantBalanceSheet.getCardNumber());
		refundDetails.setInitiatedBy(merchantDetails.getUuid());
		refundDetails.setMerchantId(merchantDetails.getMerchantID());
		refundDetails.setMerchantOrderId(merchantBalanceSheet.getMerchantOrderId());
		refundDetails.setPaymentCode(merchantBalanceSheet.getPaymentCode());
		refundDetails.setPaymentMode(merchantBalanceSheet.getPaymentMode());
		refundDetails.setPaymentOption(merchantBalanceSheet.getTrType());
		refundDetails.setPgOrderId(merchantBalanceSheet.getPgOrderId());
		refundDetails.setPgStatus(merchantBalanceSheet.getPgStatus());		
		refundDetails.setRefOrderId(merchantBalanceSheet.getMerchantOrderId());
		refundDetails.setStatus(UserStatus.INITIATED.toString());
		refundDetails.setVpaUpi(merchantBalanceSheet.getVpaUPI());
		refundDetails.setUserId(merchantBalanceSheet.getUserId());
		
		RefundDetails refundDetailsUpd = refundDetailsRepository.save(refundDetails);
		MerchantRefundResponse merchantRefundResponse = new MerchantRefundResponse();
		merchantRefundResponse.setRefundDetails(refundDetailsUpd);
		merchantRefundResponse.setHeader(createdHeader(refundDetailsUpd.toString(),
				Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getSecretId())));
		
		return merchantRefundResponse;
	}

	public Map<String, String> populatedMultiPleMapToMap(MultiValueMap<String, String> formData) {

		Map<String, String> parameters = new LinkedHashMap<String, String>();
		parameters.put("orderId", formData.get("orderId").get(0));

		return parameters;
	}

	public boolean validateCheckSum(String inputCheckSum, String generatedCheckSum) {

		if (inputCheckSum.equals(generatedCheckSum)) {
			return true;
		}

		return false;
	}

	public List<MerchantTransactionResponse> populateTransactionDetails(
			List<TransactionDetails> listTransactionDetails) {

		MerchantTransactionResponse merchantTransactionResponse = new MerchantTransactionResponse();
		List<MerchantTransactionResponse> listMerchantTransactionResponse = new ArrayList<MerchantTransactionResponse>();

		for (TransactionDetails transactionDetails : listTransactionDetails) {
			merchantTransactionResponse
					.setAmount(Utility.getAmountConversion(String.valueOf(transactionDetails.getAmount())));
			merchantTransactionResponse.setMerchantId(transactionDetails.getMerchantId());
			merchantTransactionResponse.setMerchantOrderId(transactionDetails.getMerchantOrderId());
			merchantTransactionResponse.setOrderID(transactionDetails.getOrderID());
			merchantTransactionResponse.setPaymentOption(transactionDetails.getPaymentOption());
			merchantTransactionResponse.setStatus(transactionDetails.getStatus());
			merchantTransactionResponse.setTxtMsg(transactionDetails.getTxtMsg());
			merchantTransactionResponse.setTxtPGTime(transactionDetails.getTxtPGTime());
			merchantTransactionResponse.setPaymentMode(transactionDetails.getPaymentMode());
			if (transactionDetails.getVpaUPI() != null) {
				merchantTransactionResponse.setVpaUPI(
						SecurityUtils.decryptSaveData(transactionDetails.getVpaUPI()).replace("\u0000", ""));
			}
			if (transactionDetails.getPaymentCode() != null) {
				//merchantTransactionResponse.setPaymentCode(SecurityUtils.decryptSaveData(transactionDetails.getPaymentCode()).replace("\u0000", ""));
				merchantTransactionResponse.setPaymentCode(transactionDetails.getPaymentCode());
			}
			if (transactionDetails.getCardNumber() != null) {
				merchantTransactionResponse.setCardNumber(
						Utility.maskCardNumber(SecurityUtils.decryptSaveData(transactionDetails.getCardNumber())).replace("\u0000", ""));
			}
			listMerchantTransactionResponse.add(merchantTransactionResponse);
		}
		return listMerchantTransactionResponse;
	}

	public String createdHeader(String strJson, String secretKey) throws NoSuchAlgorithmException {

		return SecurityExposerFunction.generateCheckSum(strJson, secretKey);
	}

	
}
