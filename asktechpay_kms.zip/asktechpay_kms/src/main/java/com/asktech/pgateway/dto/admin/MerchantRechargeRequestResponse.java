package com.asktech.pgateway.dto.admin;


import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantRechargeRequestResponse implements Serializable{

	
	private static final long serialVersionUID = -8044211800234325064L;
	private String message;
	private int status;
	private long id;
	private String createdBy;
	private String updatedBy;
	private String merchantID;
	private String distributorID;
	private String bankName;
	private String bankId;
	private String uuid;
	private long amount;
	private String notes;// you can use clob
	private String UTR;
	//private String created;
	//private String updated;
	private String requestedStatus;
	private String approval;
	private String info1;
	private String info2;
	private String info3;
	private String info4;
	private String info5;
}