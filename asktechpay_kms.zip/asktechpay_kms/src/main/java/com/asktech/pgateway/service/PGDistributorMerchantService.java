package com.asktech.pgateway.service;

import org.springframework.stereotype.Service;
/**@author abhimanyu-kumar*/
@Service
public class PGDistributorMerchantService {

}
