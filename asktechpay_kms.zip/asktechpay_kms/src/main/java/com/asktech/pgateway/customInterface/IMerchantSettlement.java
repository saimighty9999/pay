package com.asktech.pgateway.customInterface;

public interface IMerchantSettlement {

	String getMerchantId();
	String getAmount();
	String getStatus();
}
