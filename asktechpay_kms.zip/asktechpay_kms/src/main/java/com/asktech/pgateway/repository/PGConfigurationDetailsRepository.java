package com.asktech.pgateway.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.pgateway.model.PGConfigurationDetails;

public interface PGConfigurationDetailsRepository  extends JpaRepository<PGConfigurationDetails, String>{

	List<PGConfigurationDetails> findAllByPgUuid(String pgUuid);

	PGConfigurationDetails findByPgUuid(String pgUuid);

	PGConfigurationDetails findByPgName(String pgName);

}
