package com.asktech.pgateway.constants;

public interface ErrorValues {
	String SQL_ERROR = "SQL Error:";
	String SQL_DUPLICATE_ID = "SQL Exception, Duplicate Order ID";
	String SAVE_SUCCESS = "Saved Success";
	String ALL_FIELDS_MANDATORY = "All Fields Mandatory";
	String FORM_VALIDATION_FAILED = "Form Validation Failed:";
	String SIGNATURE_MISMATCH = "Signature Mismatch";
	String JSON_PARSE_ISSUE_MERCHANT_REQUEST = "Merchant Request is not in Proper Format";
	String INPUT_BLANK_VALUE = "Input should not content blank value";
	String MERCHANT_EXITS = "Provided Merchant Name already Present in System";
	String MERCHANT_NOT_FOUND = "Merchant not found / Mapped with provided AppID - ";
	String MERCHNT_NOT_EXISTIS = "Merchant not found / Mapped with provided emailid";
	String MERCHANT_PG_SERVICE_NO_MAPPED = "Merchant not mapped with provided PG Service ";
	String MERCHANT_PG_CONFIG_NOT_FOUND = "Merchant mapped with PG Service but not mapped with PG Details like (Appid and Secret Keys).";
	String MERCHANT_PG_APP_ID_NOT_FOUND = "Merchant PG APP id not found in request .";
	String MERCHANT_PG_SECRET_NOT_FOUND = "Merchant PG Secret id not found in request .";
	String MERCHANT_PG_NAME_NOT_FOUND = "Merchant Name id not found in request .";
	String PG_NOT_PRESENT = "Provided PG name not found in system.";
	String BANK_DETAILS_NOT_FOUND = "Merchnat Bank Details not found in system.";
	String EMAIL_ID_ALREADY_EXISTS_IN_SYSTEM ="EMAIL ID already exists in system as ADMIN , Admin can't be a Merchant , Please contact Administrator";
	String PHONE_VAIDATION_FAILED = "Input Mobile format is not valid";
	String INVALID_URL = "URL is invalid";
	String MERCHANT_PHONE_NUMBER_ALREADY_EXISTS_IN_SYSTEM ="PHONE NUMBER already exists in system ";
	String MERCHANT_EMAIL_ID_ALREADY_EXISTS_IN_SYSTEM ="EMAIL ID already exists in system ";
	String MOBILE_VALIDATION_FAILED = "Input Mobile Number is not proper as per Mobile Number Validator. Proceed with proper Mobile Number.";
	String EMAIL_VALIDATION_FAILED = "Input EMAIL is not proper as per Email Validator. Proceed with proper Email id.";
	String NAME_VALIDATION_FAILED = "Input Customer Name / Name validation failed .";
	String PHONE_VAIDATION_FILED = "Input Mobile not format is not valid";
	String EMAIL_ID_NOT_FOUND = "Input Email Id not Exists in System , please login with proper EMAIL id / Register as a merchant.";
	String USER_STATUS_BLOCKED = "User Status is Blocked in system , Contact Admistrator.";
	String USER_STATUS_REMOVED = "User is Removed from system , Contact Admistrator.";
	String PASSWORD_CANT_BE_BLANK = "User Input password can't be NULL";
	String PASSWORD_MISMATCH = "Input password is not correct as per system Information.";
	String SESSION_NOT_FOUND = "User Session not active / found .";
	String USER_NOT_EXISTS = "User does not exist";
	String INITIAL_PASSWORD_CHANGE_REQUEST = "Initial password change required , please check the password . ";
	String PASSWORD_VALIDATION = "Password not validate as per Rules .\n a. start-of-string \n b.a digit must occur at least once \n c.a lower case letter must occur at least once \n d. an upper case letter must occur at least once \n e. a special character must occur at least once \n f. no whitespace allowed in the entire string \n g. anything, at least eight places though \n h. end-of-string";
	String AMOUNT_VALIDATION_ERROR = "Input Amount value is not correct.";
	String SMS_SEND_ERROR = "The SMS process has exception , Please contact administrator.";
	String SMS_OTP_COUNTER_REACHED = "You can try only 3 atempts within 5 minutus Please try after 5 minutes !!";
	String OPT_EXPIRED = "otp is expired please login again !!";
	
	String MERCHANT_BANK_DETAIL_PRESENT = "Merchant Bank details already exists , client can be update the bank details from Update option.";
	String MERCHANT_SERVICE_TYPE = "Service Type blank will not acceptable in system.";
	String MERCHANT_COMMISSION_TYPE = "CommissionType blank will not acceptable in system.";
	String MERCHANT_COMM_AMOUNT = "Commission strucure Fixed / Floating amount can't be blank .";
	String MERCHANT_COMMISSION_EXISTS = "Comission structure is avalable for the merchant with service ID and PG Details..";
	
	String ADMIN_USER_EXISTS = "The EMAIL ID alread registered with user ...";
	String SUPER_USER_ROLE = "This user does not have supur user role , only super user can perform the Acivity.";
	
	String PG_ALREADY_CREATED = "PG details already created as per Input provided , please crosscheck the sensitive information." ;
	String PG_SERVICES = "nput PG services not defined in system , contact Administrator.";
	String PG_DEFAULT_SERVICE_SCOPE= "Only one service will be default for all PG associated serviceType";
	
	String MERCHANT_PG_ASSOCIATION_EXISTS = "The Association Between Merchant and PG already present.";
	String MERCHANT_PG_ASSOCIATION_NON_EXISTS = "The Association Between Merchant and PG not Found.";
	String PG_NOT_CREATED = "The Input PG detals not found in System.";
	String PG_NOT_ACTIVE = "The Input PG detals not ACTIVE in System.";
	String PG_SEVICE_CREATED = "The Mentioned service already associated with PG.";
	String PG_SERVICE_ASSOCIATION_NOT_FOUND = "PG and Provided services association not found.";
	String PG_SERVICE_NOT_FOUND = "No PG service avaiable with inut services.";
	String MERCHANT_PG_SERVICE_NOT_ASSOCIATED = "Merchnats associated with service , but service not found.";
	String MERCHANT_PG_SERVICE_NOT_FOUND = "The service either not active with PG and Merchants / not not associated";
	String MERCHANT_SERVICE_PRESENT_AS_ACTIVE = "Merchant service As active or another same Service active with another PG , please check and update accordingly , as per rule , only one Service should ACTIVE status irrespective of PG association with Merchant.";
	
	String USER_STATUS = "The input user status is not defined in system.";
	String OTP_MISMATCH = "The provided OTP is not valid for the user.";
	String OTP_EXPIRED = "The otp is expired please login again !!";
	
	String COMPLAINT_TYPE_EXISTS = "The mentioned complaint type already present in system.";
	String COMPLAINT_TYPE_NOT_EXISTS = "The mentioned complaint type not present in system.";
	String COMPLAINT_TYPE_SUBTYPE_EXISTS = "The mentioned complaint type and Subtype already present in system.";
	String COMPLAINT_TYPE_SUBTYPE_NOT_EXISTS = "The mentioned complaint type and Subtype not present in system.";
	String COMPLAINT_ID_BLANK = "Input complaint ID should provided during complaint update operation.";
	String COMPLAINT_NOT_FOUND = "Provided Complaint id not found .";
	String COMPLAINT_ALREADY_CLOSED = "The provided Ticket already in closed state , please reopen the ticket/ create another new Ticket.";
	String COMPLAINT_NOT_CLOSED = "The provided Ticket not in closed status.";
	String COMPLAINT_TYPE_SUB_TYPE_STATUS = "The input Complaint type and Sub Type is not found as Active in system.";
	
	String DUPLICATE_ORDERID = "Order Id Already used";
	String INVALID_COOKIE = "Invalid Cookie Exception";
	String UNKNOWN_OPTION = "Invalid Option";

	
	String DATE_FORMAT_VALIDATION = "Date fied validaton failed , Date Format should be [DD-MM-YYYY] like [23-09-2021]";

	String DATA_INVALID = "Invalid data in input field";
	String  BANK_ERROR = "BANK Not Found";
	String CREATE_REQUEST_FAILED = "Create request failed";
	
	String DECRYPTION_ERROR = "Decription issue found , please contact admistrator.";
	
	String VALIDATION_ERROR_ORDER_AMOUNT = "Input Order Amount can't be negetive or 0";
	String VALIDATION_ERROR_PAYMENT_OPTION = "Input payment Option is not valid.";
	String VALIDATION_ERROR_CARD_NUMBER = "Input card number is not valid.";
	String VALIDATION_ERROR_CARD_HOLDER_NAME = "Input Card Holder name is not valid";
	
	String EXCEPTION_IN_SMS_SENDING = "SMS URL is not working" ;
	
	String MERCHANT_ASSO_WITH_BUSI_ASSO = "Merchant is already associated with one of Business Associate ";
	String BUSINESS_ASSOCIATED_NOT_FOUND = "The Business Associate Information is not found for uuid";
	String COMMISSION_WITH_MERCHANT_ALREADY_PRESENT = "The Commission Structure already present for the Merchant";
	String COMMISSION_UPDATE = "Only Active Commission can be blocked from UI";
	String COMMISSION_NOT_FOUND = "Commission Details not found/ not Active for provided and Commission Id and Business Associate";
	String TRANSACTION_NOT_FOUND = "Transaction details not found / not eligible for Commission update";
	String AMOUNT_NOT_MATCHED_WITH_EDITED_COMM = "Edited commission is not performed due to calculation not correct , please check the values once.";
	
	String REFUND_INITIATE_FAILED = "The order id either not found in system / not eligible to initiate the refund.";
	String REFUND_UPDATE_FAILED = "The order id either not found in system / not eligible to update the refund status";
	
	String  CHECKSUM_MISMATCH = "CheckSum mismatch happened during selection journey.";
	String USER_NOT_FOUND = "User not found in db";
	String MERCHANT_DISTRIBUTOR_ASSOCIATION_ALREADY_EXIST = "Merchant is already associated with this Distributor";
	String DISTRIBUTOR_NOT_EXIST = "Distributor do not exist in db";
	String MERCHNT_NOT_EXIST = "Merchant do not exist in db";
}
