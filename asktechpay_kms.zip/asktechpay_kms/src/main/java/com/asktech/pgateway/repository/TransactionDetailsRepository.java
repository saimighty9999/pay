package com.asktech.pgateway.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.asktech.pgateway.customInterface.IMerchantDetailsReport;
import com.asktech.pgateway.customInterface.IMerchantSettlement;
import com.asktech.pgateway.customInterface.IMerchantTransaction;
import com.asktech.pgateway.model.TransactionDetails;

public interface TransactionDetailsRepository extends JpaRepository<TransactionDetails, String>{

	TransactionDetails findByOrderIDAndStatus(String string, String string2);
	
	List<TransactionDetails> findAllByMerchantId(String id);
	
	@Query(value = "select tr.id, tr.created, tr.updated, tr.amount, tr.card_number, tr.cust_order_id, tr.merchant_id, tr.merchant_order_id, tr.merchant_returnurl, tr.orderid, tr.payment_code, tr.payment_mode, tr.payment_option, tr.pg_id, tr.pg_orderid, tr.pg_type, tr.status, tr.txt_msg, tr.txtpgtime, tr.userid, tr.vpaupi"
			+ " from transaction_details tr where merchant_id= :merchant_id order by tr.id desc limit 100",
			nativeQuery = true)
	List<TransactionDetails> findAllTopByMerchantId(@Param("merchant_id") String merchant_id);

	@Query(value = "select tr.id, tr.created, tr.updated, tr.amount, tr.card_number, tr.cust_order_id, tr.merchant_id, tr.merchant_order_id, tr.merchant_returnurl, tr.orderid, tr.payment_code, tr.payment_mode, tr.payment_option, tr.pg_id, tr.pg_orderid, tr.pg_type, tr.status, tr.txt_msg, tr.txtpgtime, tr.userid, tr.vpaupi"
			+ " from transaction_details tr where merchant_id= :merchant_id and created >=DATE_ADD(CURDATE(), INTERVAL -3 DAY)",
			nativeQuery = true)
	public List<TransactionDetails> findLast3DaysTransaction(@Param("merchant_id") String merchant_id);
	
	
	@Query(value = "select tr.* "
			+ "from transaction_details tr "
			+ "where tr.merchant_id= :merchant_id "
			+ "and date(tr.created) between :dateFrom and :dateTo ",
			nativeQuery = true)
	public List<TransactionDetails> getTransactionDateRange(@Param("merchant_id") String merchant_id , @Param("dateFrom") String dateFrom ,@Param("dateTo") String dateTo );
	
	@Query(value = "select tr.* "
			+ "from transaction_details tr "
			+ "where tr.merchant_id= :merchant_id "
			+ "and date(tr.created) = :dateFrom  ",
			nativeQuery = true)
	public List<TransactionDetails> getTransactionDate(@Param("merchant_id") String merchant_id , @Param("dateFrom") String dateFrom  );
	TransactionDetails findByOrderID(String string);
	
	
	@Query(value = "select a.merchant_id as merchantId,a.pg_type as pgType ,status as status,sum(a.amount) as amount "
			+ "from transaction_details a, merchant_details b "
			+ "where b.merchantid = a.merchant_id "
			+ "and date(a.created) = curdate()-1 "
			+ "and b.merchantid= :merchant_id "
			+ "group by a.merchant_id,a.pg_type,a.status", nativeQuery = true)
	List<IMerchantTransaction> getYesterdayTrDetails(@Param("merchant_id") String merchant_id  );
	
	@Query(value = "select a.merchant_id as merchantId, status as status,sum(a.amount) as amount "
			+ "from transaction_details a, merchant_details b "
			+ "where b.merchantid = a.merchant_id "
			+ "and date(a.created) = curdate() "
			+ "and b.merchantid= :merchant_id "
			+ "group by a.merchant_id, a.status", nativeQuery = true)
	List<IMerchantTransaction> getTodayTrDetails(@Param("merchant_id") String merchant_id  );
	
	@Query(value = "select a.merchant_id as merchantId,a.pg_type as pgType ,status as status,sum(a.amount) as amount  "
			+ "from transaction_details a, merchant_details b "
			+ "where b.merchantid = a.merchant_id "
			+ "and MONTH(a.created) = MONTH(CURRENT_DATE - INTERVAL 1 MONTH) "
			+ "and YEAR(a.created) = YEAR(CURRENT_DATE - INTERVAL 1 MONTH) "
			+ "and b.merchantid= :merchant_id "
			+ "group by a.merchant_id,a.pg_type,a.status", nativeQuery = true)
	List<IMerchantTransaction> getLastMonthTrDetails(@Param("merchant_id") String merchant_id  );
	
	@Query(value = "select a.merchant_id as merchantId,a.pg_type as pgType ,status as status,sum(a.amount) as amount "
			+ "from transaction_details a, merchant_details b "
			+ "where b.merchantid = a.merchant_id "
			+ "and MONTH(a.created) = MONTH(CURRENT_DATE()) "
			+ "and YEAR(a.created) = YEAR(CURRENT_DATE()) "
			+ "and b.merchantid= :merchant_id "
			+ "group by a.merchant_id,a.pg_type,a.status", nativeQuery = true)
	List<IMerchantTransaction> getCurrMonthTrDetails(@Param("merchant_id") String merchant_id  );
	List<TransactionDetails> findAllByMerchantOrderId(String string);
	List<TransactionDetails> findAllByMerchantOrderIdAndMerchantId(String string, String merchantID);
}	
