package com.asktech.pgateway.controller.payout;

public class VanController {

}
