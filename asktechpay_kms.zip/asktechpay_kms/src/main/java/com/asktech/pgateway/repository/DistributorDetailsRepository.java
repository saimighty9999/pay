package com.asktech.pgateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.asktech.pgateway.model.DistributorDetails;
import com.asktech.pgateway.model.DistributorMerchantDetails;

/**@author abhimanyu-kumar*/
@Repository
public interface DistributorDetailsRepository extends JpaRepository<DistributorDetails, Long>{

	//DistributorDetails  findByDistributorID(Long distributorID);

	DistributorDetails findByDistributorID(String distributorID);

	

}
