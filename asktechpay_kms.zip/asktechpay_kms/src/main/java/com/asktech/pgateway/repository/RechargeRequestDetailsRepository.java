package com.asktech.pgateway.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.asktech.pgateway.model.RechargeRequestDetails;
/**@author abhimanyu-kumar*/
@Repository
public interface RechargeRequestDetailsRepository extends JpaRepository<RechargeRequestDetails, Long>{


	List<RechargeRequestDetails> findByDistributorID(String distributorID);

}
