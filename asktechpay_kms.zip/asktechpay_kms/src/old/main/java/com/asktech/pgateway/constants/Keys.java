package com.asktech.pgateway.constants;

public abstract class Keys {
	protected static final String  FrontKey = "StSqWAlh1QqcT7GObxZKUrJYf4hcQRdv";
	protected static final String  FrontSalt = "7F598785B49A8E5C";
	protected static final String  BackKey = "StSqWAlh1QqcT7GObxZKUrJYf4hcQRdv";
	protected static final String  BackSalt = "7F598785B49A8E5C";

	public static final String askTechSecret = "superAdmins7905093601SuperAdmins";
	public static final String askTechSalt = "superAdmin!!!!!!!!SuperAdmin";
	
	public static final String askTechFTSecret = "asktech123wallet";
	public static final String askTechFTSalt = "ashtech123wallet";
	
	public static final String serviceFactoryInstance = "PBKDF2WithHmacSHA256";
	public static final String cipherInstance = "AES/CBC/PKCS5Padding";
	public static final String secretKeyType = "AES";
	
	public static final String utfType = "UTF-8";
}
