package com.asktech.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class InputFromPgTransactionUpdate  extends AbstractTimeStampAndId{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name="merchant_id")
	private String merchantId;
	@Column(name="order_id")
	private String orderId;
	@Column(name="merchant_order_id")
	private String merchantOrderId;
	@Column(name="input_from_pg" , columnDefinition = "LONGTEXT")
	private String inputFromPg;
	@Column(name="source")
	private String source;
}
