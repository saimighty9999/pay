package com.asktech.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(indexes = {
        @Index(columnList = "orderId"),
        @Index(columnList = "upiId"),
})
public class NeoCredTransactionDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(length = 50)
    private String merchantId;
    @Column(length = 50, unique = true)
    private String orderId;
    @Column(length = 100)
    private String upiId;
    @Column(name = "TransactionStatus", length = 80)
    private String transactionStatus;
    @Column(name = "updateFlag")
    private String updateFlag;
    @Column(name = "source")
    private String source;
    @Column(name = "responseText", columnDefinition = "LONGTEXT")
    private String responseText;
    @Column(columnDefinition = "LONGTEXT")
    private String reqText;
    @Column(columnDefinition = "TEXT")
    private String upiText;
    private String gatewayReferenceId;
    private String gatewayResponseMessage;
    private String gatewayTransactionId;
    private String merchantRequestId;
    private String payeeVpa;
    private String payerName;
    private String payerVpa;
    private String transactionTimestamp;
    @Column(columnDefinition = "TEXT")
    private String statusText;
}
