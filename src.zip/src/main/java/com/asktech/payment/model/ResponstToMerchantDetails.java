package com.asktech.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class ResponstToMerchantDetails extends AbstractTimeStampAndId {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name="merchant_id")
	private String merchantId;
	@Column(name="order_id")
	private String orderId;
	@Column(name="merchant_order_id")
	private String merchantOrderId;
	@Column(name="input_for_merchant" , columnDefinition = "TEXT")
	private String inputForMerchant;
}
