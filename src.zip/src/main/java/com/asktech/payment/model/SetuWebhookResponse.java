package com.asktech.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
public class SetuWebhookResponse extends AbstractTimeStampAndId{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "appId")	
	private String appId;
	@Column(name = "productInstanceId")	
	private String productInstanceId;
	@Column(name = "currencyCode")	
	private String currencyCode;
	@Column(name = "value")	
	private String value;
	@Column(name = "billerBillId")	
	private String billerBillId;
	@Column(name = "payerVpa")	
	private String payerVpa;
	@Column(name = "platformBillId")	
	private String platformBillId;
	@Column(name = "status")	
	private String status;
	@Column(name = "transactionId")	
	private String transactionId;
	@Column(name = "timeStamp")	
	private String timeStamp;
	@Column(name = "type")	
	private String type;
	@Column(name = "idSetu")	
	private String idSetu;

}
