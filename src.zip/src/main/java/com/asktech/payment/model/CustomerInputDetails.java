package com.asktech.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(indexes = {
	@Index(columnList = "paymentInfo"),
	@Index(columnList = "trxType"),
})
public class CustomerInputDetails extends AbstractTimeStampAndId{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(columnDefinition = "TEXT")  
	private String inputEncData;
	@Column(columnDefinition = "TEXT")
	private String inputDecrptData;
	private String merchantId;
	private String ipAddress;
	private String status;
	private String errorMessage;
	private String errorCode;
	@Column(length = 100)
	private String trxType;
	@Column(length = 100)
	private String paymentInfo;
}
