package com.asktech.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
public class SetuLinkGeneration extends AbstractTimeStampAndId{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "status")	
	private String status;
	@Column(name = "name")
	private String name;
	@Column(name = "shortURL")
	private String shortUrl;
	@Column(columnDefinition = "TEXT", name="upiID")  
	private String upiId;
	@Column(columnDefinition = "TEXT", name="upiLink") 
	private String upiLink;
	@Column(columnDefinition = "TEXT", name="platformBillID") 
	private String platformBillId;
	@Column(name = "orderid")
	private String orderId;
	@Column(name = "merchant_order_id")
	private String merchantOrderId;
	
	
}
