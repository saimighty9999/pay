package com.asktech.payment.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class TransactionDetailsLog extends AbstractTimeStampAndId{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private long oldUserID;
	private String oldmerchantId;
	private String oldpgId;
	private int oldAmount;
	private String oldPaymentOption;
	private String oldOrderID;
	private String oldPgOrderID;
	private String oldPgType;
	private String oldStatus;
	private String oldPaymentMode;
	private String oldTxtMsg;
	private String oldTxtPGTime;
	private String oldMerchantOrderId;
	private String oldCustOrderId;
	private String oldMerchantReturnURL;
	private String oldCardNumber;
	private String oldPaymentCode;
	private String oldVpaUPI;
	private String oldReconStatus;
	private String oldSource;
    private long newUserID;
	private String newmerchantId;
	private String newpgId;
	private int newAmount;
	private String newPaymentOption;
	private String newOrderID;
	private String newPgOrderID;
	private String newPgType;
	private String newStatus;
	private String newPaymentMode;
	private String newTxtMsg;
	private String newTxtPGTime;
	private String newMerchantOrderId;
	private String newCustOrderId;
	private String newMerchantReturnURL;
	private String newCardNumber;
	private String newPaymentCode;
	private String newVpaUPI;
	private String newReconStatus;
	private String newSource;
}
