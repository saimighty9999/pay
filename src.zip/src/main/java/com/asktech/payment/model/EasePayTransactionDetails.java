package com.asktech.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(indexes = {
	@Index(columnList = "orderId")	
})
public class EasePayTransactionDetails extends AbstractTimeStampAndId{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "txStatus")	
	private String txStatus;
	@Column(name = "orderAmount")	
    private String orderAmount;
	@Column(name = "orderId", length = 30)
    private String orderId;
	@Column(name = "paymentMode")	
    private String paymentMode;
	@Column(name = "txTime")	
    private String txTime;
	@Column(name = "txMsg")	
    private String txMsg;
	@Column(name = "referenceId")	
    private String referenceId;
	@Column(name = "merchantOderId")
	private String merchantOrderId;
	@Column(name = "updateFlag")
	private String updateFlag;
	@Column(name = "source")
	private String source;
	@Column(name = "email")
	private String email;
	@Column(name = "phoneNo")
	private String phoneNo;
	@Column(name="responseCode")
	private String responseCode;
	@Column(name="rrn")
	private String rrn;
	@Column(name="MerchantId")
	private String merchantId;
	@Column(name="pgid")
	private String pgid;
	@Column(name="callbackRes", columnDefinition="TEXT")
	private String callbackRes;
}
