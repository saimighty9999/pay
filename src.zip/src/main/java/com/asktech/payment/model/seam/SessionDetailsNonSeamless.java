package com.asktech.payment.model.seam;

import com.asktech.payment.model.AbstractTimeStampAndId;

public class SessionDetailsNonSeamless  extends AbstractTimeStampAndId{

}
