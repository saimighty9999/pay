package com.asktech.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaytmTransactionDetails extends AbstractTimeStampAndId{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "bank_name")	
	private String bankName;
	@Column(name = "bank_txt_id")	
    private String bankTxtId;
	@Column(name = "checksum_hash")	
    private String checkSumHash;
	@Column(name = "currency")	
    private String currency;
	@Column(name = "gateway_name")	
    private String gatewayName;	
	@Column(name = "mid")
	private String mid;
	@Column(name="order_id")
	private String orderId;
	@Column(name="payment_code")
	private String paymentCode;
	@Column(name="resp_code")
	private String respCode;
	@Column(name="resp_msg")
	private String respMsg;
	@Column(name="status")
	private String status;
	@Column(name="txn_amount")
	private String txnAmount;
	@Column(name="txn_date")
	private String txnDate;
	@Column(name="txn_id")
	private String txnId;
}
