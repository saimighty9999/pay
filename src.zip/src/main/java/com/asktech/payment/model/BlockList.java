package com.asktech.payment.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(indexes = {
        @Index(columnList = "vpaid"),
        @Index(columnList = "cardno"),
        @Index(columnList = "ipaddress"),
        @Index(columnList = "phonenumber"),
        @Index(columnList = "email"),
})
public class BlockList {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(length = 100)
    private String vpaid;
    @Column(length = 80)
    private String cardno;
    @Column(length = 80)
    private String ipaddress;
    @Column(length = 80)
    private String phonenumber;
    @Column(length = 100)
    private String email;
    @Column(length = 100)
    private String urlstring;
    @Column(length = 80)
    private String merchantid;
    @Column(length = 100)
    private String appid;
}
