package com.asktech.payment.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class ZavionTransactionDetails extends AbstractTimeStampAndId {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String responseDateTime;
	private String responseCode;
	private String authCode;
	private String custPhone;
	private String moptype;	
	private String currencyCode;
	private String status;
	private String amount;
	private String responseMessage;
	private String custEmail;
	private String appId;
	private String txnId;
	private String txnKey;
	private String txtType;
	private String duplicateYn;
	private String hash;
	private String paymentType;
	private String returnUrl;
	private String orderId;
	
}
