package com.asktech.payment.config;

public final class CashfreeConfig {
	public static final String appId = "";

	//public static final String returnUrl= "https://pgapi.eazypaymentz.com/pg/returnurl";
	//public static final String notifyUrl = "https://pgapi.eazypaymentz.com/pg/notifyurl";
	

	//public static final String returnUrl= "http://localhost:8080/returnurl";
	//public static final String notifyUrl = "http://localhost:8080/notifyurl";

	public static final String secretKey = "";
	public static final String currency = "INR";
	public static final String publickey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCCGVdLunh1Kj0tBIw7XQYd70fwyzr4MUEOUwVEfGXq2BY1bteq0gAri3d808WnuVO36lBNZ2C9L/8+fgvNjqvehWHgN9pEaXMc1w12l3pjFB7OetPCE68T08qDtsChMJZDdR/9aqJk1BRomThKtp9gaNYgvciCrQJG5s57JYgMRQIDAQAB";
	public static final String privatekey = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAIIZV0u6eHUqPS0EjDtdBh3vR/DLOvgxQQ5TBUR8ZerYFjVu16rSACuLd3zTxae5U7fqUE1nYL0v/z5+C82Oq96FYeA32kRpcxzXDXaXemMUHs5608ITrxPTyoO2wKEwlkN1H/1qomTUFGiZOEq2n2Bo1iC9yIKtAkbmznsliAxFAgMBAAECgYB+2/j8lgLZtOtcV1/qjuXlEKtkyLdixpx6PEgZpPe4jSbyyXexUP7rdx53cQT+bL+OygOtxo1VTVUl+cDGm0VIzIUHIAH9iW64r7K0yXqZqG3LpEtFLXA1/Dbd+Ul8UCWwvsjmnNmsC68Jt0HzX9wAA8MZKRUq89Yj9JLp6RZYYQJBAPg2DzkAby6gp7vXS1Xt90gO4+rLCw3a5/JBRTLokH9u9CZjoSme4IGJ3vSQ0wPLAm7EKQCF069oZkxMCfW3LP0CQQCGLnUt2B2/avq4DQORgnlI9zw/Xd0KVXxUqeFAgJCejtT2zHVrmY1QeUhPG8gdW7JMiDpC5cT9w9QWC6HAOKLpAkAYogTQu2JNVlRPKAap+HvaAuBLpOrr7RWnzSJ48uukOfaw+KI95y6QrIYb72OBtNwA8ia/joh7l/jPCZzTbeJhAkBCWTqL/q9G9Ykf9R9slg2O7OGXm7wu3fJqks3U7T2ViZ74okT1faoIvs/ofh5Hlg3mFf5pEeCEco6uj/XdbKPxAkAUYuPrBcH9P6zUK8R29+cP61CAuOoAhzqY1BgsN37Aa2i1gQvluGxt30MHTaDUdxrf3+cVPBlCWVi95a80X82l";
	public static final String pglink ="https://www.cashfree.com/checkout/post/submit";
	
}