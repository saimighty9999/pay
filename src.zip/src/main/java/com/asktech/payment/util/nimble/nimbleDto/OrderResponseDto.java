package com.asktech.payment.util.nimble.nimbleDto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderResponseDto {
    @JsonProperty("message")
    private String message;
    // @JsonProperty("order")
    // private List<OrderResponseSubDto> order;
    @JsonProperty("order_id")
    private String order_id;
    @JsonProperty("user")
    private UserCreateOrderResponseDto user;
}
