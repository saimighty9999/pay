package com.asktech.payment.util.nimble.nimbleDto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class StatusApiNimbblRes {
    @JsonProperty("vpa_id")
    private String vpa_id;
    @JsonProperty("vpa_app_name")
    private String vpa_app_name;
    @JsonProperty("retry_allowed")
    private String retry_allowed;
    @JsonProperty("merchant_id")
    private String merchant_id;
    @JsonProperty("issuer")
    private String issuer;
    @JsonProperty("network")
    private String network;
    @JsonProperty("sub_merchant_id")
    private String sub_merchant_id;
    @JsonProperty("psp_generated_txn_id")
    private String psp_generated_txn_id;
    @JsonProperty("nimbbl_merchant_message")
    private String nimbbl_merchant_message;
    @JsonProperty("refund_done")
    private String refund_done;
    @JsonProperty("nimbbl_error_code")
    private String nimbbl_error_code;
    @JsonProperty("additional_charges")
    private String additional_charges;
    @JsonProperty("webhook_sent")
    private String webhook_sent;
    @JsonProperty("psp_generated_redirect")
    private String psp_generated_redirect;
    @JsonProperty("vpa_holder")
    private String vpa_holder;
    @JsonProperty("bank_name")
    private String bank_name;
    @JsonProperty("expiry")
    private String expiry;
    @JsonProperty("merchant_callback_url")
    private String merchant_callback_url;
    @JsonProperty("holder_name")
    private String holder_name;
    @JsonProperty("transaction_id")
    private String transaction_id;
    @JsonProperty("paytm_payment_mode")
    private String paytm_payment_mode;
    @JsonProperty("payment_mode")
    private String payment_mode;
    @JsonProperty("wallet_name")
    private String wallet_name;
    @JsonProperty("grand_total_amount")
    private String grand_total_amount;
    @JsonProperty("transaction_type")
    private String transaction_type;
    @JsonProperty("masked_card")
    private String masked_card;
    @JsonProperty("nimbbl_consumer_message")
    private String nimbbl_consumer_message;
    @JsonProperty("psp_generated_redirect_type")
    private String psp_generated_redirect_type;
    @JsonProperty("payment_partner")
    private String payment_partner;
    @JsonProperty("status")
    private String status;
}