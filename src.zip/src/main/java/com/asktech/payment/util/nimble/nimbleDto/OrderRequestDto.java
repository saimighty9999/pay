package com.asktech.payment.util.nimble.nimbleDto;

import java.util.List;
import lombok.AllArgsConstructor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OrderRequestDto {
    private String amount_before_tax;
    private String callback_mode;
    private String callback_url;
    private String currency;
    private String invoice_id;
    private String device_user_agent;
    private String order_from_ip;
    private int tax;
    private UserDto user;
    private ShippingAddressDto shipping_address;
    private String total_amount;
    private List<OrderLineItemDto> order_line_items;
    private CustomAttributesDto custom_attributes;



    
}

