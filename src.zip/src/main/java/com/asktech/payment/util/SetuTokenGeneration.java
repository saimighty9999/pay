package com.asktech.payment.util;

import java.util.Date;
import java.util.UUID;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;

public class SetuTokenGeneration {


	    private static String schemedId="b4ad6b0b-3990-4df6-b1b9-0ca47ae90566";
	    private static String secret="ab6b9c19-8327-4c9e-96a6-4c7cf0044563";
	   


	    
	    public static String yieldBearerToken(String schemedId ,String secret ) {

	        Algorithm algorithm = Algorithm.HMAC256(secret);
	        String token = JWT.create()
	                .withAudience(schemedId)
	                .withIssuedAt(new Date())
	                .withClaim("jti",  UUID.randomUUID().toString())
	                .sign(algorithm);
	        System.out.println("Bearer " + token);
	        return "Bearer " + token;
	    }
	    public void verifyBearerToken (String bearerToken, String schemedId ,String secret) throws JWTVerificationException {
	        bearerToken = bearerToken.replace("Bearer ", "");
	        Algorithm algorithm = Algorithm.HMAC256(secret);
	        JWTVerifier verifier = JWT.require(algorithm)
	                .acceptLeeway(10)
	                .withAudience(schemedId)
	                .build(); //Reusable verifier instance
	        DecodedJWT jwt = verifier.verify(bearerToken);
	    }
}
