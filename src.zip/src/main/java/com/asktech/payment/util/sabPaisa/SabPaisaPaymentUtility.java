package com.asktech.payment.util.sabPaisa;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constant.sabPaisa.SabPaisaConstants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.sabPaisa.SabPaisaResponse;
import com.asktech.payment.dto.sabPaisa.SabPaisaStatusRequest;
import com.asktech.payment.dto.sabPaisa.SabPaisaTransactionStatus;
import com.asktech.payment.dto.setu.SetuErrorResponse;
import com.asktech.payment.enums.FormValidationExceptionEnums;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.PGConfigurationDetails;
import com.asktech.payment.model.SabPaisaTransactionDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.SabPaisaTransactionDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sabpaisa.requestprocessing.Encryptor;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class SabPaisaPaymentUtility implements CashFreeFields, SabPaisaConstants {

	static Logger logger = LoggerFactory.getLogger(SabPaisaPaymentUtility.class);

	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	SabPaisaTransactionDetailsRepository sabPaisaTransactionDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletListRepository walletListRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	PGConfigurationDetailsRepository pgConfigurationDetailsRepository;

	ObjectMapper mapper = new ObjectMapper();

	@Value("${pgEndPoints.sabPaisaReturnUrl}")
	String sabPaisaReturnUrl;
	@Value("${pgEndPoints.sabPaisaEndPoint}")
	String sabPaisaEndPoint;
	@Value("${pgEndPoints.asanpayStatusAPI}")
	String AsanpayStatusAPI;
	@Value("${pgEndPoints.sabPaisaUpiLimit}")
	int sabPaisaUpiLimit;

	public Model processSabPaisaRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId, String ipAddress)
			throws IOException, ParseException, NoSuchAlgorithmException, InvalidKeyException,
			IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException, NoSuchPaddingException,
			ValidationExceptions {
		sabPaisaReturnUrl = pgGatewayUtilService.getReturnUrl(sabPaisaReturnUrl,
				merchantPGDetails.getMerchantID(), formData.get(PAYMENT_OPTION).get(0));
		String spURL = "?" + SabPaisaConstants.CLIENTNAME + "=" + merchantPGDetails.getMerchantPGAppId() + "&"
				+ SabPaisaConstants.USERN + "=" + merchantPGDetails.getMerchantPGAdd1() + "&" + SabPaisaConstants.PASS
				+ "=" + merchantPGDetails.getMerchantPGAdd2() + "&" + SabPaisaConstants.AMT + "="
				+ Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)) + "&" + SabPaisaConstants.TXNID + "="
				+ orderId + "&" + SabPaisaConstants.FIRSTNAME + "=" + formData.get(CUSOMERNAME).get(0) + "&"
				+ SabPaisaConstants.LASTNAME + "=" + formData.get(CUSOMERNAME).get(0) + "&"
				+ SabPaisaConstants.CONTACTNO + "=" + formData.get(CUSTOMERPHONE).get(0) + "&" + SabPaisaConstants.EMAIL
				+ "=" + formData.get(CUSTOMEREMAIL).get(0) + "&" + SabPaisaConstants.ADD + "=" + "Kolkata" + "&"
				+ SabPaisaConstants.RU + "=" + sabPaisaReturnUrl + "&" + SabPaisaConstants.FAILUREURL + "="
				+ sabPaisaReturnUrl + "&" + SabPaisaConstants.BYPASSFLAG + "=true";

		// model = generateGenericModel(model, merchantPGDetails, formData, orderId);
		logger.info("spUrl:: " + spURL);
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {
			spURL = setUPIDetailsSabPaisa(orderId, spURL, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.NETBANKING)) {
			spURL = setNBDetailsSabPaisa(orderId, spURL, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.WALLET)) {
			spURL = setWalletDetailsSabPaisa(orderId, spURL, formData, merchantPGDetails);
		}

		logger.info("Request Params::" + spURL);

		spURL = Encryptor.encrypt(Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()),
				merchantPGDetails.getMerchantPGSaltKey(), spURL);
		spURL = spURL.replace("+", "%2B");
		spURL = "?query=" + spURL + "&clientName=" + merchantPGDetails.getMerchantPGAppId();
		spURL = sabPaisaEndPoint + spURL;

		logger.info("Before Execute Params::" + spURL);
		model.addAttribute("paymentUrl", spURL);

		return model;

	}

	public String setWalletDetailsSabPaisa(String orderId, String spURL, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) throws ValidationExceptions {

		populateSabPaisaTransactionDetails(formData, orderId, merchantPGDetails);

		WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		spURL = spURL + "&" + MODETRANSFER + "=" + WALLET_MODE_TRANSFER + "&" + UDF19 + "="
				+ walletList.getPaymentcodepg();

		WalletPaymentDetails walletPaymentDetails = new WalletPaymentDetails();

		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		walletPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		walletPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		walletPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		walletPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		walletPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		walletPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		walletPaymentDetailsRepository.save(walletPaymentDetails);

		return spURL;
	}

	public String setUPIDetailsSabPaisa(String orderId, String spURL, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) throws ValidationExceptions {

		populateSabPaisaTransactionDetails(formData, orderId, merchantPGDetails);

		spURL = spURL + "&" + MODETRANSFER + "=" + UPI_MODE_TRANSFER + "&" + UDF19 + "=" + formData.get(UPI_VPI).get(0);

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();
		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(formData.get(UPI_VPI).get(0));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return spURL;
	}

	private String setNBDetailsSabPaisa(String orderId, String spURL, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) throws ValidationExceptions {

		populateSabPaisaTransactionDetails(formData, orderId, merchantPGDetails);
		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		spURL = spURL + "&" + MODETRANSFER + "=" + NB_MODE_TRANSFER + "&" + UDF19 + "=" + bankList.getPgBankCode();

		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return spURL;
	}

	private void populateSabPaisaTransactionDetails(MultiValueMap<String, String> formData, String orderId,
			MerchantPGDetails merchantPGDetails) throws ValidationExceptions {

		SabPaisaTransactionDetails sabPaisaTransactionDetails = new SabPaisaTransactionDetails();
		sabPaisaTransactionDetails.setAmt(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		sabPaisaTransactionDetails.setClientName(merchantPGDetails.getMerchantPGAppId());
		sabPaisaTransactionDetails.setContactNo(formData.get(CUSTOMERPHONE).get(0));
		sabPaisaTransactionDetails.setEmail(formData.get(CUSTOMEREMAIL).get(0));
		sabPaisaTransactionDetails.setFirstName(formData.get(CUSOMERNAME).get(0));
		sabPaisaTransactionDetails.setModeTransfer(formData.get(PAYMENT_OPTION).get(0));
		sabPaisaTransactionDetails.setPass(merchantPGDetails.getMerchantPGAdd2());
		sabPaisaTransactionDetails.setTxnId(orderId);
		sabPaisaTransactionDetails.setTxStatus("TRInitiate");
		sabPaisaTransactionDetails.setUpdateFlag("N");
		sabPaisaTransactionDetails.setUsern(merchantPGDetails.getMerchantPGAdd1());
		sabPaisaTransactionDetailsRepository.save(sabPaisaTransactionDetails);
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {
			sabPaisaTransactionDetails.setUpiId(formData.get(UPI_VPI).get(0));
			int upiCount = upiVpaCount(formData.get(UPI_VPI).get(0));
			if (upiCount >= sabPaisaUpiLimit) {
				sabPaisaTransactionDetails.setTxStatus("FAILED");
				sabPaisaTransactionDetails.setResponseText("UPI LIMIT ERROR");
				sabPaisaTransactionDetailsRepository.save(sabPaisaTransactionDetails);
				throw new ValidationExceptions("UPI EXCEPTION", FormValidationExceptionEnums.E0011);
			}
		}
		// sabPaisaTransactionDetailsRepository.save(sabPaisaTransactionDetails);
	}

	private int upiVpaCount(String vpa) {
		List<SabPaisaTransactionDetails> sabPaisaTransactionDetails = sabPaisaTransactionDetailsRepository
				.getByUpiIdAndDate(vpa);
		return sabPaisaTransactionDetails.size();
	}

	public TransactionDetails updateTransactionStatus(String encyptionData, String clientCode)
			throws ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {

		// SabPaisaTransactionStatus sabPaisaTransactionStatus = new
		// SabPaisaTransactionStatus();
		PGConfigurationDetails pgConfigurationDetails = pgConfigurationDetailsRepository.findByPgAppId(clientCode);

		String decText = Encryptor.decrypt(Encryption.decryptCardNumberOrExpOrCvv(pgConfigurationDetails.getPgSecret()),
				pgConfigurationDetails.getPgSaltKey(), encyptionData);

		logger.info("decText :: " + decText);

		logger.info("Convert Multivalue Map :: "
				+ GeneralUtils.MultiValueMaptoJson(GeneralUtils.convertStringToMultiValueMap(decText)));

		SabPaisaResponse sabPaisaResponse = mapper.readValue(
				GeneralUtils.MultiValueMaptoJson(GeneralUtils.convertStringToMultiValueMap(decText)),
				SabPaisaResponse.class);

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(sabPaisaResponse.getClientTxnId());

		SabPaisaTransactionDetails sabPaisaTransactionDetails = sabPaisaTransactionDetailsRepository
				.findByTxnId(sabPaisaResponse.getClientTxnId());

		if (transactionDetails != null) {

			SabPaisaStatusRequest sabPaisaStatusRequest = new SabPaisaStatusRequest();
			sabPaisaStatusRequest.setClientCode(sabPaisaTransactionDetails.getClientName());
			sabPaisaStatusRequest.setClientxnId(sabPaisaTransactionDetails.getTxnId());

			// sabPaisaTransactionStatus = callSabPaisaStatusapi(sabPaisaStatusRequest);

			// transactionDetails.setStatus(sabPaisaTransactionStatus.getTxnStatus());
			// transactionDetails.setTxtMsg(sabPaisaTransactionStatus.getSabPaisaRespCode());
			// transactionDetails.setPgOrderID(sabPaisaTransactionStatus.getSpTxnId());
			// transactionDetails.setTxtPGTime(sabPaisaTransactionStatus.getTransCompleteDate());

			transactionDetails.setPaymentMode(sabPaisaResponse.getPayMode());
			transactionDetails.setStatus(sabPaisaResponse.getSpRespStatus());
			transactionDetails.setTxtMsg(sabPaisaResponse.getReMsg());
			transactionDetails.setPgOrderID(sabPaisaResponse.getSabPaisaTxId());
			transactionDetails.setTxtPGTime(Utility.populateDbTime());

			transactionDetails.setSource("ReturnURL");
			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsRepository.save(transactionDetails);
		}
		logger.info("Transaction Update");

		logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(Utility.convertDTO2JsonString(sabPaisaResponse), transactionDetails,
				"ReturnURL");

		try {

			sabPaisaTransactionDetails.setPgTxnNo(sabPaisaResponse.getPGTxnNo());
			sabPaisaTransactionDetails.setSabPaisaTxId(sabPaisaResponse.getSabPaisaTxId());
			sabPaisaTransactionDetails.setResponseText(Utility.convertDTO2JsonString(sabPaisaResponse));
			sabPaisaTransactionDetails.setUpdateFlag("N");
			sabPaisaTransactionDetails.setSource("ReturnURL");

			sabPaisaTransactionDetailsRepository.save(sabPaisaTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in SabPaisaPayTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");

		return transactionDetails;
	}

	public Model getResponseProcess(TransactionDetails transactionDetails, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	public SabPaisaTransactionStatus callSabPaisaStatusapi(SabPaisaStatusRequest sabPaisaStatusRequest)
			throws JsonProcessingException {

		HttpResponse<SabPaisaTransactionStatus> SabPaisaTransactionDetails = Unirest.post(AsanpayStatusAPI)
				.body(Utility.convertDTO2JsonString(sabPaisaStatusRequest)).asObject(SabPaisaTransactionStatus.class)
				.ifFailure(SetuErrorResponse.class, r -> {
					SetuErrorResponse e = r.getBody();
					try {
						logger.info("SabPaisa Status Request Response Error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});

		logger.info("Response :: " + Utility.convertDTO2JsonString(SabPaisaTransactionDetails.getBody()));

		return SabPaisaTransactionDetails.getBody();

	}

}
