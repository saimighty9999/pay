package com.asktech.payment.util.grezpay;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constant.grezpay.GrezPayContants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.grezpay.GrezPayTransactionStatus;
import com.asktech.payment.dto.setu.SetuErrorResponse;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.GrezPayTransactionDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.GrezPayTransactionDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class GrezPayPaymentUtility implements CashFreeFields, GrezPayContants {

	static Logger logger = LoggerFactory.getLogger(GrezPayPaymentUtility.class);

	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	GrezPayTransactionDetailsRepository grezPayTransactionDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletListRepository walletListRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;

	@Value("${pgEndPoints.grezpaySeamLess}")
	String payuSeamLess;
	@Value("${pgEndPoints.grezpayReturnURL}")
	String payuReturnURL;

	public Model processGrezPayRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId)
			throws IOException, ParseException, NoSuchAlgorithmException {
		logger.info("GrezPay Form" + GeneralUtils.MultiValueMaptoJson(formData));
		Map<String, String> params = new HashMap<String, String>();
		params.put(APP_ID, merchantPGDetails.getMerchantPGAppId());
		params.put(AMOUNT, formData.get(ORDERAMOUNT).get(0));
		params.put(CURRENCY_CODE, CURRENCY_VALUE);
		params.put(CUST_EMAIL, formData.get(CUSTOMEREMAIL).get(0));
		params.put(CUST_NAME, formData.get(CUSOMERNAME).get(0));
		params.put(CUST_PHONE, formData.get(CUSTOMERPHONE).get(0));
		params.put(ORDER_ID, orderId);
		params.put(PRODUCT_DESC, PRODUCTDESC_VALUE);
		params.put(RETURN_URL, payuReturnURL);
		params.put(TXNTYPE, TXTTYPE_VALUE);

		String hash = ChecksumUtils.generateCheckSum(params,
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));

		// model = generateGenericModel(model, merchantPGDetails, hash, formData,
		// orderId);

		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {
			// model = setUPIDetailsGrezPay(orderId, model, formData, merchantPGDetails,
			// hash);
			params = setUPIDetailsGrezPay(orderId, params, formData, merchantPGDetails, hash);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.NETBANKING)) {
			// model = setNBDetailsGrezPay(orderId, model, params, formData,
			// merchantPGDetails);
			params = setNBDetailsGrezPay(orderId, params, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.WALLET)) {
			params = setWalletDetailsGrezPay(orderId, params, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.CARD)) {
			params = setCardDetailsGrezPay(orderId, params, formData, merchantPGDetails);

			logger.info("GrezPay Params:: " + params.toString());
		} else {
			logger.error("GrezPay Invalid:: " + formData.get(PAYMENT_OPTION).get(0));
		}
		hash = ChecksumUtils.generateCheckSum(params,
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
		model.addAllAttributes(params);
		model.addAttribute(HASH, hash);
		return model;

	}

	private Model generateGenericModel(Model model, MerchantPGDetails merchantPGDetails,
			String hashValue, MultiValueMap<String, String> formData, String orderId) {

		model.addAttribute(APP_ID, merchantPGDetails.getMerchantPGAppId());
		model.addAttribute(ORDER_ID, orderId);
		model.addAttribute(AMOUNT, formData.get(ORDERAMOUNT).get(0));
		model.addAttribute(TXNTYPE, TXTTYPE_VALUE);
		model.addAttribute(CUST_NAME, formData.get(CUSOMERNAME).get(0));
		model.addAttribute(CUST_PHONE, formData.get(CUSTOMERPHONE).get(0));
		model.addAttribute(CUST_EMAIL, formData.get(CUSTOMEREMAIL).get(0));
		model.addAttribute(PRODUCT_DESC, PRODUCTDESC_VALUE);
		model.addAttribute(CURRENCY_CODE, CURRENCY_VALUE);
		model.addAttribute(RETURN_URL, payuReturnURL);
		model.addAttribute(HASH, hashValue);

		return model;
	}

	public Map<String, String> setWalletDetailsGrezPay(String orderId, Map<String, String> params,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails) {
		populateGrezPayTransactionDetails(formData, orderId, merchantPGDetails.getMerchantPGAppId());

		WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		// model.addAttribute(PAYMENT_TYPE, PAYMENT_TYPE_WL);
		// model.addAttribute(MOP_TYPE, walletList.getPaymentcodepg());
		params.put(PAYMENT_TYPE, PAYMENT_TYPE_WL);
		params.put(MOP_TYPE, walletList.getPaymentcodepg());

		WalletPaymentDetails walletPaymentDetails = new WalletPaymentDetails();

		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		walletPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		walletPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		walletPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		walletPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		walletPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		walletPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		walletPaymentDetailsRepository.save(walletPaymentDetails);

		return params;
	}

	public Map<String, String> setUPIDetailsGrezPay(String orderId, Map<String, String> params,
			MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String hashValue) {

		populateGrezPayTransactionDetails(formData, orderId, merchantPGDetails.getMerchantPGAppId());
		// model.addAttribute(PAYMENT_TYPE, PAYMENT_TYPE_UPI_VALUE);
		// model.addAttribute(MOP_TYPE, MOP_TYPE_UPI_VALUE);
		// model.addAttribute(PAYMENT_TYPE_UPI_VPA, formData.get(UPI_VPI).get(0));
		params.put(PAYMENT_TYPE, PAYMENT_TYPE_UPI_VALUE);
		params.put(MOP_TYPE, MOP_TYPE_UPI_VALUE);
		params.put(PAYMENT_TYPE_UPI_VPA, formData.get(UPI_VPI).get(0));

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return params;
	}

	private Map<String, String> setNBDetailsGrezPay(String orderId, Map<String, String> params,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails) {
		populateGrezPayTransactionDetails(formData, orderId, merchantPGDetails.getMerchantPGAppId());
		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(),
				UserStatus.ACTIVE.toString(), merchantPGDetails.getMerchantPGName());

		// model.addAttribute(PAYMENT_TYPE, PAYMENT_TYPE_NB);
		// model.addAttribute(MOP_TYPE, bankList.getPgBankCode());
		params.put(PAYMENT_TYPE, PAYMENT_TYPE_NB);
		params.put(MOP_TYPE, bankList.getPgBankCode());
		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return params;
	}

	private Map<String, String> setCardDetailsGrezPay(String orderId, Map<String, String> params,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails) {

		populateGrezPayTransactionDetails(formData, orderId, merchantPGDetails.getMerchantPGAppId());

		// model.addAttribute(PAYMENT_TYPE, PAYMENT_TYPE_DC);
		// model.addAttribute(MOP_TYPE,cardTypeMapping(pgGatewayUtilService.getCardDeterminator(formData.get(CARD_NUMBER).get(0).substring(0,
		// 6)).getCards().getScheme()) );
		// model.addAttribute(PAYMENT_CARD_NUMBER, formData.get(CARD_NUMBER).get(0));
		// model.addAttribute(PAYMENT_CARD_EXP_DT,
		// formData.get(CARD_EXPMONTH).get(0)+formData.get(CARD_EXPYEAR).get(0));
		// model.addAttribute(PAYMENT_CVV, formData.get(CARD_CVV).get(0));
		params.put(PAYMENT_TYPE, PAYMENT_TYPE_DC);
		try {
			params.put(MOP_TYPE, cardTypeMapping(pgGatewayUtilService
					.getCardDeterminator(formData.get(CARD_NUMBER).get(0).substring(0, 6)).getCards().getScheme()));
		} catch (Exception e) {
			logger.error(e.getMessage());
			params.put(MOP_TYPE, "DC");
		}
		params.put(PAYMENT_CARD_NUMBER, formData.get(CARD_NUMBER).get(0));
		params.put(PAYMENT_CARD_EXP_DT, formData.get(CARD_EXPMONTH).get(0) + formData.get(CARD_EXPYEAR).get(0));
		params.put(PAYMENT_CVV, formData.get(CARD_CVV).get(0));
		return params;
	}

	private void populateGrezPayTransactionDetails(MultiValueMap<String, String> formData, String orderId,
			String appid) {

		GrezPayTransactionDetails grezPayTransactionDetails = new GrezPayTransactionDetails();
		grezPayTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		grezPayTransactionDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		grezPayTransactionDetails.setOrderId(orderId);
		grezPayTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		grezPayTransactionDetails.setTxStatus(UserStatus.PENDING.toString());
		grezPayTransactionDetails.setUpdateFlag("N");
		grezPayTransactionDetails.setSource("TRInitiate");
		grezPayTransactionDetails.setAppId(appid);
		grezPayTransactionDetailsRepository.save(grezPayTransactionDetails);
	}

	public GrezPayTransactionDetails updateTransactionStatus(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException, ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException {

		logger.info("Inside method updateTransactionStatus()");
		logger.info("Response Form Data" + GeneralUtils.MultiValueMaptoJson(responseFormData));

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDER_ID));

		String returnHash = pgGatewayUtilService.checkResponseData(responseFormData, RESP_HASH);

		GrezPayTransactionDetails grezPayTransactionDetails = grezPayTransactionDetailsRepository
				.findByOrderId(transactionDetails.getOrderID());

		if (transactionDetails != null) {

			if (validateReturnSignature(transactionDetails, responseFormData, returnHash)) {
				logger.info("The return signature has been verified ...");

				transactionDetails.setStatus(
						checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE),
								pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));

			} else {
				logger.info("The return signature not verified ...");
				transactionDetails.setStatus(UserStatus.FAILED.toString());
			}

			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetails.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXNID));
			transactionDetails
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENT_TYPE));
			transactionDetails.setTxtMsg(
					getErrorMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE)) + "|"
							+ pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_MESSAGE));
			transactionDetails
					.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_DATE_TIME));

			transactionDetails.setSource("ReturnURL");
			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsRepository.save(transactionDetails);
		}
		logger.info("Transaction Update");

		logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");

		try {

			if (grezPayTransactionDetails == null) {
				grezPayTransactionDetails = new GrezPayTransactionDetails();
				grezPayTransactionDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
				grezPayTransactionDetails
						.setOrderAmount(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERAMOUNT));
				grezPayTransactionDetails
						.setOrderId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDER_ID));
				grezPayTransactionDetails
						.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENT_TYPE));
				grezPayTransactionDetails.setSignature(returnHash);
				grezPayTransactionDetails
						.setTxMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE));
				grezPayTransactionDetails
						.setTxStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
				grezPayTransactionDetails
						.setTxTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_DATE_TIME));
				grezPayTransactionDetails.setUpdateFlag("N");
				grezPayTransactionDetails.setSource("ReturnURL");
			} else {
				grezPayTransactionDetails.setSignature(returnHash);
				grezPayTransactionDetails
						.setTxMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE));
				grezPayTransactionDetails
						.setTxStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
				grezPayTransactionDetails
						.setTxTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_DATE_TIME));
				grezPayTransactionDetails.setUpdateFlag("N");
				grezPayTransactionDetails.setSource("ReturnURL");
				grezPayTransactionDetails
						.setResponseText(Encryption.encryptCardNumberOrExpOrCvv(responseFormData.toString()));
			}
			grezPayTransactionDetailsRepository.save(grezPayTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in CashfreeTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");

		return grezPayTransactionDetails;
	}

	public Model getResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDER_ID));

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	public boolean validateReturnSignature(TransactionDetails transactionDetails,
			MultiValueMap<String, String> responseFormData, String returnHash) throws NoSuchAlgorithmException {

		MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository
				.findByMerchantIDAndMerchantPGId(transactionDetails.getMerchantId(), transactionDetails.getPgId());

		responseFormData.remove(RESP_HASH);
		Map<String, String> params = GeneralUtils.convertMultiToRegularMap(responseFormData);
		String hash = ChecksumUtils.generateCheckSum(params,
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));

		if (hash.equalsIgnoreCase(returnHash)) {
			return true;
		}

		return false;
	}

	public String getErrorMsg(String subcode) {
		Map<String, String> map = new HashMap<>();
		map.put("000", "SUCCESS");
		map.put("004", "Declined");
		map.put("001", "Acquirer Error");
		map.put("002", "Denied");
		map.put("003", "Timeout");
		map.put("005", "Authenncation not available");
		map.put("006", "Transaction Processing");
		map.put("007", "Rejected by Acquirer");
		map.put("008", "Duplicate");
		map.put("009", "Response signature did not match");
		map.put("010", "Cancelled by user");
		map.put("011", "Authorization success but error processing");
		map.put("012", "Denied due to fraud detection");
		map.put("013", "Invalid request not available");
		map.put("014", "Refund amount you requested is greater than");
		map.put("007", "Failed/Failed by acquirer");
		map.put("015", "Status is yet to be received from Bank/Customer has led the transaction in middle");
		map.put("016", "Auto Reversal");
		map.put("300", "Invalid Request");
		map.put("113", "Payment option not supported");
		try {
			return map.get(subcode);
		} catch (Exception e) {
			return subcode;
		}

	}

	public String checkStatus(String errorCode, String errorMsg) {
		String[] successarr = { "000|success" };
		String[] pendingarr = { "006|PROCESSING", "015|SENT_TO_BANK" };
		String[] failedarr = { "004|DECLINED", "001|ACQUIRER_ERROR", "002|DENIED", "003|TIMEOUT",
				"005|AUTHENTICATION_UNAVAILABLE", "007|REJECTED", "008|DUPLICATE", "009|SIGNATURE_MISMATCH",
				"010|CANCELLED", "011|RECURRING_PAYMENT_UNSUCCESSFULL", "013|INVALID_REQUEST",
				"014|REFUND_INSUFFICIENT_BALANCE", "007|TXN_FAILED", "016|AUTO_REVERSAL", "007|FAILED_AT_ACQUIRER",
				"300|VALIDATION_FAILED", "113|PAYMENT_OPTION_NOT_SUPPORTED" };
		String[] flaggedarr = { "012|DENIED_BY_RISK" };

		String msg = errorCode + "|" + errorMsg;

		logger.info("MSG::" + msg);
		if (errorCode.equals("000") && errorMsg.equalsIgnoreCase("Captured")) {
			return UserStatus.SUCCESS.toString();
		} else if ((errorCode.equals("006")) || (errorCode.equals("015"))) {
			return UserStatus.PENDING.toString();
		} else if (errorCode.equals("012")) {
			return UserStatus.FLAGGED.toString();
		} else {
			return UserStatus.FAILED.toString();
		}

	}

	public String cardTypeMapping(String cardType) {

		if (cardType.equalsIgnoreCase("visa")) {
			return "VI";
		} else if (cardType.equalsIgnoreCase("mastercard")) {
			return "MC";
		} else if (cardType.equalsIgnoreCase("rupay")) {
			return "RU";
		} else if (cardType.equalsIgnoreCase("amex")) {
			return "AX";
		} else if (cardType.equalsIgnoreCase("DISCOVER")) {
			return "DI";
		} else if (cardType.equalsIgnoreCase("JCB")) {
			return "JC";
		} else if (cardType.equalsIgnoreCase("MAESTRO")) {
			return "MS";
		} else if (cardType.equalsIgnoreCase("DINERS")) {
			return "DN";
		}

		return null;
	}

}
