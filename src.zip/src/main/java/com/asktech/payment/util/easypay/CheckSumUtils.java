package com.asktech.payment.util.easypay;

import org.springframework.stereotype.Component;
import java.io.ByteArrayOutputStream;
import java.util.Base64;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

@Component
public class CheckSumUtils {
	


//    Long currentTime = Calendar.getInstance().getTimeInMillis();

	/*
	 * public static void main(String[] args) {
	 * 
	 * 
	 * 
	 * 
	 * //https://uat5yesmoney.easypay.co.in:5043/epyesbc/easypaygateway/v1?checksum=
	 * YXxs9Le7hy9VAJr1CgKNvx67/M/E0wJYK8vsKpuSJIXVXUG9GfnnppS/
	 * A8QgM7JvolQUlbJ9xNqxSg0cB8S/lw==&cpcode=AKAPR4216&sscode=1659371676000&amount
	 * =500.00&mobile=8328840320&txnid=MAB153837846000037
	 * 
	 * // Long currentTime = Calendar.getInstance().getTimeInMillis(); // //
	 * System.out.println(currentTime);
	 * 
	 * // String text = "AKAPR4216|"+currentTime+"|500.00|NA|MAB153837846000089";
	 * String text = "AKAPR4216|1659526268000|500.00|8328840320|MAB153837846000057";
	 * String secureHashText=generateSecureHash(text);
	 * System.out.println("Secure hash Output : "+secureHashText);
	 * 
	 * }
	 */
	static final String SECURE_SECRET = "aefc05467d";
    static final char[] HEX_TABLE = new char[]{
            '0', '1', '2', '3', '4', '5', '6', '7',
            '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
    private static byte[] decodeHexArray = new byte[103];

    static {
        int i = 0;
        for (byte b : new byte[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'}) {
            decodeHexArray[b] = (byte) i++;
        }
        decodeHexArray['a'] = decodeHexArray['A'];
        decodeHexArray['b'] = decodeHexArray['B'];
        decodeHexArray['c'] = decodeHexArray['C'];
        decodeHexArray['d'] = decodeHexArray['D'];
        decodeHexArray['e'] = decodeHexArray['E'];
        decodeHexArray['f'] = decodeHexArray['F'];
    }

	public static byte[] decodeHexa(byte[] data) throws Exception {
		if (data == null) {
			return null;
		}
		if (data.length % 2 != 0) {
			throw new Exception("Invalid data length:" + data.length);
		}
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		byte b1, b2;
		int i = 0;
		while (i < data.length) {
			b1 = decodeHexArray[data[i++]];
			b2 = decodeHexArray[data[i++]];
			out.write((b1 << 4) | b2);
		}
		out.flush();
		out.close();
		return out.toByteArray();
	}
	 public String generateSecureHash(String text, String secret) {
	        byte[] mac = null;
	        try {
	            byte[] b = decodeHexa(secret.getBytes());
	            SecretKey key = new SecretKeySpec(b, "HMACSHA512");
	            Mac m = Mac.getInstance("HMACSHA512");
	            m.init(key);
	            m.update(text.getBytes("UTF-8"));
	            mac = m.doFinal();
	        } catch (Exception e) {

	        }
	     
	        return Base64.getEncoder().encodeToString(mac);

	    }

}
