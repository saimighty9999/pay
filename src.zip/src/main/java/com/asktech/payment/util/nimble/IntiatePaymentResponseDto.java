package com.asktech.payment.util.nimble;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class IntiatePaymentResponseDto {
    @JsonProperty("status")
    private String status;
    @JsonProperty("vpa")
    private String vpa;
    @JsonProperty("isVPAValid")
    private String isVPAValid;
    @JsonProperty("payerAccountName")
    private String payerAccountName;
    @JsonProperty("error")
    private ErrorDto error;
    @JsonProperty("error_msg")
    private ErrorDto error_msg;
    @JsonProperty("status_code")
    private ErrorDto status_code;

}
