package com.asktech.payment.util.paytm;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.TreeMap;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.ErrorValues;
import com.asktech.payment.constant.MerchantResponseContants;
import com.asktech.payment.constant.paytm.PaytmConstants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.paytm.Paytmpopulate;
import com.asktech.payment.enums.FormValidationExceptionEnums;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.PaytmTransactionDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.TransactionDetailsAll;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.PaytmTransactionDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.paytm.pg.merchant.PaytmChecksum;

@Service
public class PaytmPgUtility implements CashFreeFields, ErrorValues, PaytmConstants, MerchantResponseContants {

	static Logger logger = LoggerFactory.getLogger(PaytmPgUtility.class);

	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;
	@Autowired
	PaytmTransactionDetailsRepository paytmTransactionDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;

	@Value("${pgEndPoints.paytmCreateLink}")
	String paytmCreateLink;
	@Value("${pgEndPoints.paytmCallBackAPI}")
	String paytmCallBackAPI;
	@Value("${pgEndPoints.paytmSubmitJs}")
	String paytmSubmitJs;

	public JSONObject generateTxnToken(String merchantKey, String merchantMID, MultiValueMap<String, String> formData,
			String orderId, MerchantPGDetails merchantPGDetails) throws Exception {

		JSONObject outPutDetails = new JSONObject();

		JSONObject paytmParams = new JSONObject();

		JSONObject body = new JSONObject();
		paytmCallBackAPI = pgGatewayUtilService.getReturnUrl(paytmCallBackAPI,
				merchantPGDetails.getMerchantID(), formData.get(PAYMENT_OPTION).get(0));
		body.put(REQUESTTYPE, REQUESTTYPE_VALUE);
		body.put(MID, merchantMID);
		body.put(WEBSITENAME, WEBSITENAME_VALUE);
		body.put(ORDERID, orderId);
		body.put(CALLBACKURL, paytmCallBackAPI);

		JSONObject txnAmount = new JSONObject();
		txnAmount.put(VALUE, Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		txnAmount.put(CURRENCY, CURRENCY_VALUE);

		JSONObject userInfo = new JSONObject();
		userInfo.put(CUSTID, "CUST_" + orderId);
		body.put(TXTAMOUNT, txnAmount);
		body.put(USERINFO, userInfo);

		String checksum = PaytmChecksum.generateSignature(body.toString(), merchantKey);

		JSONObject head = new JSONObject();
		head.put(PaytmConstants.SIGNATURE, checksum);
		paytmParams.put(BODY, body);
		paytmParams.put(HEAD, head);

		String post_data = paytmParams.toString();
		logger.info("post_data :: " + post_data);

		logger.info("Paytm URL :: " + paytmCreateLink.replace("[merchantMID]", merchantMID) + orderId);

		/* for Staging */
		URL url = new URL(paytmCreateLink.replace("[merchantMID]", merchantMID) + orderId);
		try {
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "application/json");
			connection.setDoOutput(true);

			DataOutputStream requestWriter = new DataOutputStream(connection.getOutputStream());
			requestWriter.writeBytes(post_data);
			requestWriter.close();
			String responseData = "";
			InputStream is = connection.getInputStream();
			BufferedReader responseReader = new BufferedReader(new InputStreamReader(is));
			if ((responseData = responseReader.readLine()) != null) {
				logger.info("Response: " + responseData);
				outPutDetails = new JSONObject(responseData);
			}
			responseReader.close();
		} catch (Exception exception) {
			exception.printStackTrace();
			throw new ValidationExceptions(PAYTM_EXCEPTION, FormValidationExceptionEnums.E0085,
					formData.get(RETURNURL).get(0), formData);
		}

		return outPutDetails;
	}

	public Model processPaytmRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) throws Exception {

		logger.info("Inside populateModelInfo() Paytm");

		WalletPaymentDetails walletPaymentDetails = new WalletPaymentDetails();

		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		walletPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		walletPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		walletPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		walletPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		walletPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		walletPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		walletPaymentDetailsRepository.save(walletPaymentDetails);

		Paytmpopulate paytmpopulate = new Paytmpopulate();
		paytmpopulate.setOrderId(orderId);
		paytmpopulate.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		paytmpopulate.setStatus("PENDING");
		paytmpopulate.setTxnamount(formData.get(ORDERAMOUNT).get(0));
		populatePatmTransactions(paytmpopulate);

		JSONObject jsonObjectPaytm = generateTxnToken(
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()),
				merchantPGDetails.getMerchantPGAppId(),
				formData, orderId, merchantPGDetails);

		logger.info("jsonObjectPaytm values :: " + jsonObjectPaytm.toString());
		if (!jsonObjectPaytm.isEmpty()) {
			logger.info("Token Value :: " + jsonObjectPaytm.getJSONObject("body").get("txnToken"));
			model.addAttribute(PaytmConstants.AMOUNT, Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
			model.addAttribute(ORDERID, orderId);
			model.addAttribute(PaytmConstants.TOKENTYPE, TOKENTYPE_VALUE);
			model.addAttribute(PaytmConstants.TOKEN, jsonObjectPaytm.getJSONObject("body").get("txnToken"));
			model.addAttribute("Host", paytmSubmitJs + merchantPGDetails.getMerchantPGAppId() + ".js");
			model.addAttribute(MID, merchantPGDetails.getMerchantPGAppId());
		} else {
			// throw exception
		}

		logger.info("Ended populateModelInfo()");
		return model;
	}

	public void updateTransactionStatusPaytm(MultiValueMap<String, String> responseFormData) throws Exception {
		logger.info("Inside method updateTransactionStatus()");
		logger.info("Response Form Data" + GeneralUtils.MultiValueMaptoJson(responseFormData));

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
		if (transactionDetails != null) {

			if (payTMCheckSUMVerifier(responseFormData, transactionDetails.getMerchantId(),
					transactionDetails.getPgId())) {
				transactionDetails
						.setStatus(checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));
				logger.info("The return signature verified ...");
			} else {
				logger.info("The return signature not verified ...");
				transactionDetails.setStatus(UserStatus.FAILED.toString());
			}

			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));
			// transactionDetails.setStatus(pgGatewayUtilService.checkResponseData(responseFormData,
			// RESP_STATUS));
			transactionDetails.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXNID));
			transactionDetails
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
			transactionDetails.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPMSG));
			transactionDetails.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXNDATE));
			transactionDetails.setSource("ReturnURL");
			transactionDetailsRepository.save(transactionDetails);
		} else {
			TransactionDetailsAll transactionDetailsAll = new TransactionDetailsAll();
			logger.info("Transaction Details Null");
			logger.info("Insert All Transaction Details");
			transactionDetails = transactionDetailsRepository
					.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

			logger.info("Insert Transaction Details by orderId:: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsAll.setOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
			transactionDetailsAll
					.setStatus(checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));
			transactionDetailsAll.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXNID));
			transactionDetailsAll
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
			transactionDetailsAll.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPMSG));
			transactionDetailsAll.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXNDATE));

			transactionDetailsAllRepository.save(transactionDetailsAll);
		}
		logger.info("Transaction Update");
		logger.info("GetUser Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");
		PaytmTransactionDetails paytmTransactionDetails = null;
		// PaytmTransactionDetails paytmTransactionDetails = new
		// PaytmTransactionDetails();
		paytmTransactionDetails = paytmTransactionDetailsRepository
				.findByOrderId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
		// paytmTransactionDetails.setBankName(responseFormData.get(RESP_BANKNAME).get(0));
		if (paytmTransactionDetails == null) {
			paytmTransactionDetails = new PaytmTransactionDetails();
		}
		paytmTransactionDetails.setBankTxtId(responseFormData.get(RESP_BANKTXNID).get(0));
		paytmTransactionDetails.setCheckSumHash(responseFormData.get(RESP_CHECKSUMHASH).get(0));
		paytmTransactionDetails.setCurrency(responseFormData.get(RESP_CURRENCY).get(0));
		paytmTransactionDetails.setGatewayName(responseFormData.get(RESP_GATEWAYNAME).get(0));
		paytmTransactionDetails.setMid(responseFormData.get(RESP_MID).get(0));
		paytmTransactionDetails.setOrderId(responseFormData.get(RESP_ORDERID).get(0));
		paytmTransactionDetails.setPaymentCode(responseFormData.get(RESP_PAYMENTMODE).get(0));
		paytmTransactionDetails.setRespCode(responseFormData.get(RESP_RESPCODE).get(0));
		paytmTransactionDetails.setRespMsg(responseFormData.get(RESP_RESPMSG).get(0));
		paytmTransactionDetails.setStatus(responseFormData.get(RESP_STATUS).get(0));
		paytmTransactionDetails.setTxnAmount(responseFormData.get(RESP_TXNAMOUNT).get(0));
		paytmTransactionDetails.setTxnDate(responseFormData.get(RESP_TXNDATE).get(0));
		paytmTransactionDetails.setTxnId(responseFormData.get(RESP_TXNID).get(0));

		paytmTransactionDetailsRepository.save(paytmTransactionDetails);

	}

	public Model getResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {
		logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

		String status = "";
		status = checkStatus(transactionDetails.getStatus());
		logger.info("Return URL :: " + URLEncoder.encode(transactionDetails.getMerchantReturnURL(), "UTF-8"));
		logger.info("Transaction Amt:" + String.valueOf(transactionDetails.getAmount()));
		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);

		return pgGatewayUtilService.populateReturnModel(model, amt, status, transactionDetails);
	}

	private boolean payTMCheckSUMVerifier(MultiValueMap<String, String> responseFormData, String merchantId,
			String pgUUid) throws Exception {

		MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository.findByMerchantIDAndMerchantPGId(merchantId,
				pgUUid);
		String secretKey = Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret());
		logger.info("Secret Key :: " + secretKey);
		String paytmChecksumdt = null;
		TreeMap<String, String> paytmParams = new TreeMap<String, String>();

		for (Object requestParamsEntry : responseFormData.keySet()) {
			if ("CHECKSUMHASH".equalsIgnoreCase((String) requestParamsEntry)) {
				paytmChecksumdt = responseFormData.get(requestParamsEntry).get(0);
			} else {
				paytmParams.put((String) requestParamsEntry, responseFormData.get(requestParamsEntry).get(0));
			}
		}
		return PaytmChecksum.verifySignature(paytmParams, secretKey, paytmChecksumdt);

		// return false;
	}

	public void populatePatmTransactions(Paytmpopulate paytmpopulate) {
		PaytmTransactionDetails paytmTransactionDetails = null;
		paytmTransactionDetails = paytmTransactionDetailsRepository.findByOrderId(paytmpopulate.getOrderId());
		if (paytmTransactionDetails == null) {
			paytmTransactionDetails = new PaytmTransactionDetails();
		}
		paytmTransactionDetails.setOrderId(paytmpopulate.getOrderId());
		paytmTransactionDetails.setPaymentCode(paytmpopulate.getPaymentMode());
		paytmTransactionDetails.setStatus(paytmpopulate.getStatus());
		paytmTransactionDetails.setTxnAmount(Utility.getAmountConversion(paytmpopulate.getTxnamount()));
		paytmTransactionDetailsRepository.save(paytmTransactionDetails);
	}

	public String checkStatus(String paytm) {
		if (paytm.equalsIgnoreCase("TXN_SUCCESS")) {
			return UserStatus.SUCCESS.toString();
		}
		if (paytm.equalsIgnoreCase("TXN_FAILURE")) {
			return UserStatus.FAILED.toString();
		}

		return paytm;
	}

}
