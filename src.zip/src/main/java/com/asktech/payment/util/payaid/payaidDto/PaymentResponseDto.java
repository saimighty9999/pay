package com.asktech.payment.util.payaid.payaidDto;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentResponseDto {
    @JsonProperty("transaction_id")
    private String transaction_id;
    @JsonProperty("payment_mode")
    private String payment_mode;
    @JsonProperty("Payment_channel")
    private String Payment_channel;
    @JsonProperty("payment_datetime")
    private String payment_datetime;
    @JsonProperty("response_code")
    private String response_code;
    @JsonProperty("response_message")
    private String response_message;
    @JsonProperty("error_desc")
    private String error_desc;
    @JsonProperty("order_id")
    private String order_id;
    @JsonProperty("amount")
    private String amount;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("description")
    private String description;
    @JsonProperty("name")
    private String name;
    @JsonProperty("email")
    private String email;
    @JsonProperty("phone")
    private String phone;
    @JsonProperty("address_line_1")
    private String address_line_1;
    @JsonProperty("address_line_2")
    private String address_line_2;
    @JsonProperty("city")
    private String city;
    @JsonProperty("state")
    private String state;
    @JsonProperty("country")
    private String country;
    @JsonProperty("zip_code")
    private String zip_code;
    @JsonProperty("udf1")
    private String udf1;
    @JsonProperty("udf2")
    private String udf2;
    @JsonProperty("udf3")
    private String udf3;
    @JsonProperty("udf4")
    private String udf4;
    @JsonProperty("udf5")
    private String udf5;
    @JsonProperty("cardmasked")
    private String cardmasked;
    @JsonProperty("hash")
    private String hash;

}
