package com.asktech.payment.util.nimble.nimbleDto;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class NimbllStatusApiRes { 

   private String vpa_id;
   private String vpa_app_name;
   private String offer_discount;
   private String retry_allowed;
   private String merchant_id;
   private String issuer;
   private String network;
   private String sub_merchant_id;
   private String offer;
   private String psp_generated_txn_id;
   private String nimbbl_merchant_message;
   private String refund_done;
   private String nimbbl_error_code;
   private String additional_charges;
   private String webhook_sent;
   private String psp_generated_redirect;
   private String vpa_holder;
   private String bank_name;
   private String expiry;
   private String merchant_callback_url;
   private String holder_name;
   private String transaction_id;
   private String paytm_payment_mode;
   private String payment_mode;
   private String upi_flow;
   private String wallet_name;
   private String grand_total_amount;
   private String transaction_type;
   private String card_type;
   private String masked_card;
   private String freecharge_payment_mode;
   private String nimbbl_consumer_message;
   private String psp_generated_redirect_type;
   private String payment_partner;
   private String status;

}



