package com.asktech.payment.util.nimble.nimbleDto.returnData;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Order {
    private String convenience_fee;
    private String amount_before_tax;
    private String shopfront_domain;
    private String referrer_platform_version;
    private String description;
    private String tax;
    private String device_user_agent;
    private String cancellation_reason;
    private String order_date;
    private String total_amount;
    private String referrer_platform;
    private String invoice_id;
    private String currency;
    private String grand_total;
    private Device device;
    private String attempts;
    private String status;
}
