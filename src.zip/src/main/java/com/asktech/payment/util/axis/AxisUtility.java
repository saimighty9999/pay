package com.asktech.payment.util.axis;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.zip.Checksum;

import org.springframework.stereotype.Component;

import com.asktech.payment.util.axis.dto.AxisTransactionResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.asktech.payment.constants.cashfree.CashFreeFields;

@Component
public class AxisUtility implements CashFreeFields{
    
    static Logger logger = LoggerFactory.getLogger(AxisUtility.class);

    public static void main(String args[]){
        
        // String checkSumString  = "ANALYTIQDEMOCORP261ACC03362311651471.0VEND01264215Sangeetha MobilesPvtltd5230330001915HDFC000052310HDFCBankBhuvaneshwari@sangeethamobiles.com7719871404";
        String checkSumString = "ANALYTIQDEMOCORP261ACC03362311651471.0VEND01264215Arpit Shivsagar Mishra67334688874SBIN002053910SBIchetanyaagrawal@gmail.com9763493161";
        String checkSum = encodeCheckSumWithSHA256(checkSumString);
        // System.out.println("\n\n\n");
        // System.out.println(checkSum);
        // String requesString = "{\"channelId\":\"ANALYTIQ\",\"corpCode\":\"DEMOCORP261\",\"userId\":\"ACC0336231165147\",\"beneinsert\":[{\"apiVersion\":\"1.0\",\"beneLEI\":\"\",\"beneCode\":\"VEND01264215\",\"beneName\":\"Arpit Shivsagar Mishra\",\"beneAccNum\":\"67334688874\",\"beneIfscCode\":\"SBIN0020539\",\"beneAcType\":\"10\",\"beneBankName\":\"SBI\",\"beneAddr1\":\"\",\"beneAddr2\":\"\",\"beneAddr3\":\"\",\"beneCity\":\"\",\"beneState\":\"\",\"benePincode\":\"\",\"beneEmailAddr1\":\"chetanyaagrawal@gmail.com\",\"beneMobileNo\":\"9763493161\"}],\"checksum\":\""+ checkSum+"\"}";
        String requesString = "{'channelId':'ANALYTIQ','corpCode':'DEMOCORP261','corpAccNum':'241010107618844','checksum':'"+checkSum+"'}";

        // System.out.println("\n\n\n");

        // System.out.println(requesString);
        String encryptedRequest = encryptCallBack("1F4DC4B07AA34418A15ED37C56B64B64", requesString);
        // System.out.println("\n\n\n");
        // System.out.println(encryptedRequest);
        // nDsljP6ErzBZjojYHw8ebQFZxLq3YMivX/0OfrxoQEUq+/ezWPi8LLm4jjBEan8s9fKe0AjvPd4XMdegViukKMWvhLmClq6mXkW2YKA77SLBUsgp7V4ZhvSX0+JgeS8B
        // String decrypt = decryptCallBack("1F4DC4B07AA34418A15ED37C56B64B64", "6kmy2cOShsth61pEJzWZAdbo8lGg3DOoFihaIx3TAxXss56BDpzirfa74G20MFyr6gmhqN1CF9lq9qJCrNtFG85HgZt2bKHTtmjQyas8yAOWutOXQ9fE8s2/kRD9QR35WICAUeOfzDnGTB+TRpok4aCVpXxDG9oirE7LmUpNnpZs9CQv2EnHZ5epO2p16dC7SYCAeG1L2oVx3AezhrGq3u5zbxtkPMLBUyMYjnLlwAwAj7QdV26ko331LM5CxmCYbvEmpx/TxgOwT5vuGbopaZgWWd+GpQ0HqBTec/4o0mL619BV1f2uhTJNhbv0GoqinEOk5oRiZMdpGvqBRxd5dkP+r1r8E2L0NoFsfFaPUrhBK4KaNTYpnWVp8dUUMoK3RBQX1ShxYyODuoV8CfChGO9MzCoi3q3OYnxETkFmvfTRu8pqHKZwJ76s5m+WLXVwJqbJfstwYME9Psd70lH6f0G/gt5NtYEL5Y9AY2XXmjiVg+zqAusOWtmAzPHgTujGKluknk6FXkky5uOFs6byRg==");
        // System.out.println("\n\n\n");
        // System.out.println(decrypt);
        // nT8Tigjk3akscqtdme+UpTBHnbEUmwh268OcBHzFKfE/OqcISSXesrXw269CcDNrI63nz8gB66zR7mTJlV9dfU8o0g6T32SYOZ+yXZJEdAleNAPnPoJCPLKvNxtWXKV0



        checkSumString  = "ANALYTIQDEMOCORP261241010107618844";
        checkSum = encodeCheckSumWithSHA256(checkSumString);
        // System.out.println("\n\n\n");
        // System.out.println(checkSum);
        // requesString = "{\"channelId\":\"ANALYTIQ\",\"corpCode\":\"DEMOCORP261\",\"corpAccNum\":\"241010107618844\",\"checksum\":"+checkSum+"}";
        requesString ="{\"channelId\":\"ANALYTIQ\",\"corpCode\":\"DEMOCORP261\",\"corpAccNum\":\"241010107618844\",\"checksum\":"+checkSum+"}";
        
        

        // System.out.println("\n\n\n");
        // System.out.println(requesString);
        encryptedRequest = encryptCallBack("1F4DC4B07AA34418A15ED37C56B64B64", requesString);
        System.out.println("\n\n\n");
        System.out.println(encryptedRequest);
        // decrypt = decryptCallBack("1F4DC4B07AA34418A15ED37C56B64B64", "VklnYpdpoV/mZH/Lxf13CKcu1CXJt5U7+5776oQ0fr1cVVEgyrH1TjuvnbXcJllxfV/xaeSoG+E0LXfn48UKNg==");
        // System.out.println("\n\n\n");
        // System.out.println(decrypt);


        checkSumString  = "ANALYTIQDEMOCORP261241010107618844";
        checkSum = encodeCheckSumWithSHA256(checkSumString);
        // System.out.println("\n\n\n");
        // System.out.println(checkSum);
        requesString = "{\"data\":{\"CUR_TXN_ENQ\":[{\"transaction_id\":\"CN0006204254\",\"chequeNo\":null,\"statusDescription\":\"Creditetobeneficiaryon07-05-202018:40:22\",\"batchNo\":\"6r8wkrcQbzu7RpSnxSt54S4XRq7r9S\",\"utrNo\":\"815812301659\",\"transactionStatus\":\"PROCESSED\",\"processingDate\":\"06-07-202018:40:22\",\"corpCode\":\"DEMOCORP11\",\"crn\":\"338200641748800\",\"responseCode\":\"AC02\",\"paymentMode\":\"R\",\"vendorCode\":\"\",\"amount\":\"\",\"corporateAccountNumber\":\"\",\"debitCreditIndicator\":\"\",\"beneficiaryAccountNumber\":\"\",\"extra1\":\"\",\"extra2\":\"\",\"extra3\":\"\",\"extra4\":\"\",\"extra5\":\"\"}],\"checksum\":\"6423c04adb6f5370ead0797b457c65cd\"},\"message\":\"Success\",\"status\":\"S\"}";
        // System.out.println("\n\n\n");
        // System.out.println(requesString);
         encryptedRequest = encryptCallBack("1F4DC4B07AA34418A15ED37C56B64B64", requesString);
        // System.out.println("\n\n\n");
        // System.out.println(encryptedRequest);
        // decrypt = decryptCallBack("1F4DC4B07AA34418A15ED37C56B64B64", "VklnYpdpoV/mZH/Lxf13CKcu1CXJt5U7+5776oQ0fr1cVVEgyrH1TjuvnbXcJllxfV/xaeSoG+E0LXfn48UKNg==");
        // System.out.println("\n\n\n");
        // System.out.println(decrypt);


    }


    // string creator 
    public static String encryptCallBack(String key, String str_resp)
	{
			    
			ByteArrayOutputStream baos = new ByteArrayOutputStream(key.length() / 2);
				
		    for (int i = 0; i < key.length(); i += 2) {
		        String output = key.substring(i, i + 2);	       
		        int decimal = Integer.parseInt(output, 16);	        
		        baos.write(decimal);
		    }
			    
				
		    try {
				SecretKeySpec skeySpec = new SecretKeySpec(baos.toByteArray(), "AES");
			      
			    byte [] iv1 = new byte [] {(byte) 0x8E, 0x12, 0x39, (byte) 0x9C, 0x07, 0x72, 0x6F, 0x5A, (byte) 0x8E, 0x12, 0x39, (byte) 0x9C, 0x07,0x72, 0x6F, 0x5A};
				AlgorithmParameterSpec paramSpec = new IvParameterSpec(iv1);

			    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			    cipher.init(1, skeySpec,paramSpec);
			     

			    byte[] encrypted = cipher.doFinal(str_resp.getBytes("UTF-8"));
			    
			    ByteArrayOutputStream os = new ByteArrayOutputStream();
			    os.write(iv1);
			    os.write(encrypted);
			   byte[] encryptedWithIV = os.toByteArray();
			 
			    //return new String(Base64.encode(os.toByteArray()));
			    String encryptedResult = Base64.getEncoder().encodeToString(encryptedWithIV);
			    return encryptedResult;
			} 
		    catch (Exception ex) 
		    {
			   ex.printStackTrace();
			}

			return null;
	}

    public  String decryptCallBack(String key, String encrypted)
	{
			    
			ByteArrayOutputStream baos = new ByteArrayOutputStream(key.length() / 2);
					
			for (int i = 0; i < key.length(); i += 2) 
			{
				String output = key.substring(i, i + 2);	       
				int decimal = Integer.parseInt(output, 16);	        
				baos.write(decimal);
			}
				    
			try
			{
			    SecretKeySpec skeySpec = new SecretKeySpec(baos.toByteArray(), "AES");
			    
			    //byte[] encryptedIVandTextAsBytes = Base64.decode(encrypted);
			    byte[] encryptedIVandTextAsBytes = Base64.getDecoder().decode(encrypted);
			    byte[] iv = Arrays.copyOf(encryptedIVandTextAsBytes, 16);
			    byte[] ciphertextByte = Arrays.copyOfRange(encryptedIVandTextAsBytes, 16, encryptedIVandTextAsBytes.length);
			    
			    
			    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
			    cipher.init(2, skeySpec, new IvParameterSpec(iv));
			    byte[] decryptedTextBytes = cipher.doFinal(ciphertextByte);	
			    
			    String original = new String(decryptedTextBytes, "UTF-8");

			    return original;
			}
			catch (Exception ex) 
			{
			     ex.printStackTrace();
			}

			return null;
	}

    // CHECKSUM LOGIC


    // CHECKSUM HASING LOGIC
    public static String encodeCheckSumWithSHA256(String data) {
        MessageDigest md;
        StringBuilder sb = new StringBuilder();
        String response = null;
        try {
        md = MessageDigest.getInstance("MD5");
        md.update(data.getBytes(StandardCharsets.UTF_8));
        // Get the hashbytes 
        byte[]hashBytes = md.digest(); 
        // Converthash bytes to hex format 
        for (byte b : hashBytes) {
        sb.append(String.format("%02x", b));
        }
        response = sb.toString();
        }catch (Exception e) {
        throw new RuntimeException("Internal server error");
        }
        return response;

    }


    public void callBackTransactionStatus(String requestData)throws JsonMappingException, JsonProcessingException{
        ObjectMapper objectMapper = new ObjectMapper();

        AxisTransactionResponse transactionResponse = objectMapper.readValue(requestData,
        AxisTransactionResponse.class);

        String decrypString = decryptCallBack("1F4DC4B07AA34418A15ED37C56B64B64", transactionResponse.getGetStatusResponseBodyEncrypted());
        // System.out.println(decrypString);
        logger.info("Axis bank call back deycrpted: " +  decrypString);

    }

}
