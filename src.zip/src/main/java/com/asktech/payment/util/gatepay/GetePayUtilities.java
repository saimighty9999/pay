package com.asktech.payment.util.gatepay;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.asktech.payment.constant.gatepay.GatePayContants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.gatepay.GatePayPaymentResponse;
import com.asktech.payment.dto.gatepay.GetepayPaymentRequest;
import com.asktech.payment.enums.PGServices;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.GetePayTransactionDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.GetePayTransactionDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.pgcomponent.security.SecureCardData;
import com.pgcomponent.security.SignatureGenerator;

@Service
public class GetePayUtilities implements CashFreeFields, GatePayContants{
	
	static Logger logger = LoggerFactory.getLogger(GetePayUtilities.class);

	@Value("${pgEndPoints.getePayReturnURL}")
	String getePayReturnURL;
	@Value("${pgEndPoints.getePayPaymentURL}")
	String getePayPaymentURL;

	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	GetePayTransactionDetailsRepository getePayTransactionDetailsRepository;
	

	public Model processGatePayRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) throws Exception {

		GetepayPaymentRequest getepayPaymentRequest = new GetepayPaymentRequest();

		getepayPaymentRequest.setAmt(BigDecimal.valueOf(Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100));
		getepayPaymentRequest.setDate(LocalDateTime.now().toString());
		getepayPaymentRequest.setLogin(merchantPGDetails.getMerchantPGAdd1());
		getepayPaymentRequest.setMEmail(formData.get(CUSTOMEREMAIL).get(0));
		getepayPaymentRequest.setMerchantId(Long.parseLong(merchantPGDetails.getMerchantPGAppId()));
		getepayPaymentRequest.setMerchantTxnId(orderId);
		getepayPaymentRequest.setMNumber(formData.get(CUSTOMERPHONE).get(0));
		getepayPaymentRequest.setMobile(formData.get(CUSTOMERPHONE).get(0));
		getepayPaymentRequest.setOd("SeamLess Analytics TR");
		getepayPaymentRequest.setPass(Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));		
		getepayPaymentRequest.setPaymentType(PAYMENTTYPE);
		getepayPaymentRequest.setProductType(PRODUCTTYPE);
		getepayPaymentRequest.setTxncurr(CURRENCY);
		getepayPaymentRequest.setTxnType(TXNTYPE);
		getepayPaymentRequest.setUdf1(formData.get(CUSOMERNAME).get(0));
		getepayPaymentRequest.setUdf2(formData.get(CUSTOMERPHONE).get(0));
		getepayPaymentRequest.setUdf3(formData.get(CUSTOMEREMAIL).get(0));
		getepayPaymentRequest.setRequestType(REQUESTTYPE);
		getepayPaymentRequest.setRu(getePayReturnURL);
		getepayPaymentRequest.setTransactionId(Long.parseLong("0"));
		getepayPaymentRequest.setProductDetails("");
		getepayPaymentRequest.setBankid("");
		getepayPaymentRequest.setVan("");
		getepayPaymentRequest.setUdf4("");
		getepayPaymentRequest.setUdf5("");
		populateGetePayTransaction(formData, orderId);
		String signature = SignatureGenerator.signatureGeneration(
				new String[] { getepayPaymentRequest.getAmt().toString(), getepayPaymentRequest.getTxncurr(),
						getepayPaymentRequest.getLogin(), getepayPaymentRequest.getMerchantTxnId() },
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
				logger.info("getepayPaymentRequest::"+Utility.convertDTO2JsonString(getepayPaymentRequest));
		getepayPaymentRequest.setSignature(signature);
		
		
		if(formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.UPI.toString())) {
			getepayPaymentRequest = createGatePayRequestUPI(getepayPaymentRequest, formData, merchantPGDetails);
		}
		logger.info("getepayPaymentRequest:: Payment"+Utility.convertDTO2JsonString(getepayPaymentRequest));
		return generateModelInfo(getepayPaymentRequest, model);
	}
	
	private void populateGetePayTransaction(MultiValueMap<String, String> formData, String orderId) {
		
		GetePayTransactionDetails getePayTransactionDetails = new GetePayTransactionDetails();
		getePayTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		getePayTransactionDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		getePayTransactionDetails.setOrderId(orderId);
		getePayTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));					
		getePayTransactionDetails.setTxStatus(UserStatus.INITIATED.toString());		
		
		getePayTransactionDetailsRepository.save(getePayTransactionDetails);
	}

	/*
	public GatepayPaymentRequest createGatePayRequestNB(GatepayPaymentRequest gatepayPaymentRequest,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails, Model model)
			throws JsonProcessingException {

		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(gatepayPaymentRequest.getMerchantTxnId());
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return gatepayPaymentRequest;

	}
	*/

	public GetepayPaymentRequest createGatePayRequestUPI(GetepayPaymentRequest gatepayPaymentRequest,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails)
			throws Exception {

		SecureCardData secureCardData = new SecureCardData();
		String encData = secureCardData.encryptData(formData.get(UPI_VPI).get(0),UPI_CODE);
	
		gatepayPaymentRequest.setCarddata(encData);
		gatepayPaymentRequest.setPaymentMode("UPI");
		
		
		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(gatepayPaymentRequest.getMerchantTxnId());
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return gatepayPaymentRequest;

	}
	
	private Model generateModelInfo(GetepayPaymentRequest gatepayPaymentRequest,  Model model) throws JsonProcessingException {
	
		RestTemplate restTemplate = new RestTemplate();
		MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter();
		
		logger.info("Input request :: "+Utility.convertDTO2JsonString(gatepayPaymentRequest));
		logger.info("Input gatePayPaymentURL :: "+getePayPaymentURL);
		
		mappingJackson2HttpMessageConverter.setSupportedMediaTypes(Arrays.asList(MediaType.APPLICATION_JSON, MediaType.APPLICATION_OCTET_STREAM));
		restTemplate.getMessageConverters().add(mappingJackson2HttpMessageConverter);
		ResponseEntity<GatePayPaymentResponse> responseEntity = restTemplate.postForEntity(
				getePayPaymentURL, gatepayPaymentRequest, GatePayPaymentResponse.class);
		logger.info("Generated Request For the Processor :: " + Utility.convertDTO2JsonString(responseEntity.getBody()));


		GatePayPaymentResponse response = responseEntity.getBody();

		//Redirect user to 3dsecure page for verification
		String redirectUrl = response.getThreeDSecureUrl();
		
		logger.info("redirectUrl :: "+redirectUrl);
		
		model.addAttribute("redirect_url", redirectUrl);
		
		return model;
	}
	
	public GetePayTransactionDetails updateTransactionStatus(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException, ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException {

		//logger.info("Inside method updateTransactionStatus()");
		//logger.info("Response Form Data" + GeneralUtils.MultiValueMaptoJson(responseFormData));

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

		String returnHash = pgGatewayUtilService.checkResponseData(responseFormData, RESP_SIGNATURE);

		GetePayTransactionDetails getePayTransactionDetails = getePayTransactionDetailsRepository.findByOrderId(transactionDetails.getOrderID());

		if (transactionDetails != null) {

			if (validateReturnSignature( responseFormData, returnHash)) {
				logger.info("The return signature has been verified ...");

				transactionDetails.setStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));

			} else {
				logger.info("The return signature not verified ...");
				transactionDetails.setStatus(UserStatus.FAILED.toString());
			}

			//logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetails.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PGORDERID));
			transactionDetails.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTTYPE));			
			transactionDetails.setTxtPGTime(Utility.populateDbTime());
			transactionDetails.setSource("ReturnURL");
			//logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsRepository.save(transactionDetails);
		}
		logger.info("Transaction Update");

		//logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			//logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			//logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				//logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					//logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		//logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");

		try {

			if (getePayTransactionDetails == null) {
				getePayTransactionDetails = new GetePayTransactionDetails();
				getePayTransactionDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
				getePayTransactionDetails.setOrderAmount(pgGatewayUtilService.checkResponseData(responseFormData, RESP_AMOUNT));
				getePayTransactionDetails.setOrderId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
				getePayTransactionDetails.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTTYPE));
				getePayTransactionDetails.setSignature(returnHash);				
				getePayTransactionDetails.setTxStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
				getePayTransactionDetails.setTxTime(Utility.populateDbTime());
				getePayTransactionDetails.setUpdateFlag("N");
				getePayTransactionDetails.setSource("ReturnURL");
			} else {
				getePayTransactionDetails.setSignature(returnHash);
				getePayTransactionDetails.setTxStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
				getePayTransactionDetails.setTxTime(Utility.populateDbTime());
				getePayTransactionDetails.setUpdateFlag("N");
				getePayTransactionDetails.setSource("ReturnURL");
				getePayTransactionDetails.setResponseText(Encryption.encryptCardNumberOrExpOrCvv(responseFormData.toString()));
			}
			getePayTransactionDetailsRepository.save(getePayTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in CashfreeTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");

		return getePayTransactionDetails;
	}

	public Model getResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		//logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}
	
	private boolean validateReturnSignature(MultiValueMap<String, String> responseFormData, String returnHash) {
		String signature = SignatureGenerator.signatureGeneration(
				new String[] { 	pgGatewayUtilService.checkResponseData(responseFormData, RESP_MID),
								pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID),
								pgGatewayUtilService.checkResponseData(responseFormData, RESP_AMOUNT),
								pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS) },
				pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
		
		if(signature.equals(returnHash)) {
			return true;
		}
		
		return false;
	}
}
