package com.asktech.payment.util.axis.dto;

public class AxisTransactionDecryptedResponse {
    
}
