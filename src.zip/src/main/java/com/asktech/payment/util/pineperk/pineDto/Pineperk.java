package com.asktech.payment.util.pineperk.pineDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Pineperk { 
   private Merchant_data merchant_data;
   private Payment_info_data payment_info_data;
   private Customer_data customer_data;
   private Billing_address_data billing_address_data;
   private Shipping_address_data shipping_address_data;
   private Product_info_data product_info_data;
   private Additional_info_data additional_info_data;
   
}

