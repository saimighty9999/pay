package com.asktech.payment.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.asktech.payment.model.EasyPayLogs;
import com.asktech.payment.repository.PaymentGatewayLogsReporsitory;

@Service
public class PaymentLogs {
    @Autowired
    PaymentGatewayLogsReporsitory paymentGatewayLogsReporsitory;
    
    @Async
    public void saveLogs(String merchantId, String orderId, String reqType, String reqres, String pgid, String pgname){
        EasyPayLogs easyPayLogs = new EasyPayLogs();
        easyPayLogs.setMerchantid(merchantId);
        easyPayLogs.setOrderId(orderId);
        easyPayLogs.setRequestType(reqType);
        easyPayLogs.setReqresLog(reqres);
        easyPayLogs.setPgid(pgid);
        easyPayLogs.setPgname(pgname);
        paymentGatewayLogsReporsitory.save(easyPayLogs);
    }
}
