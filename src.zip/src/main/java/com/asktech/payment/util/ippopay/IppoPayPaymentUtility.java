package com.asktech.payment.util.ippopay;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constant.ippopay.IppoPayConstants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.ippoPay.Customer;
import com.asktech.payment.dto.ippoPay.IppoPayOrderCreateRequest;
import com.asktech.payment.dto.ippoPay.IppoPayOrderResponse;
import com.asktech.payment.dto.ippoPay.Phone;
import com.asktech.payment.dto.setu.SetuErrorResponse;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.model.IppoPayTransactionDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.repository.IppoPayTransactionDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class IppoPayPaymentUtility implements CashFreeFields, IppoPayConstants {

	static Logger logger = LoggerFactory.getLogger(IppoPayPaymentUtility.class);

	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	IppoPayTransactionDetailsRepository ippoPayTransactionDetailsRepository;

	@Value("${pgEndPoints.ippopayReturnURL}")
	String ippopayReturnURL;
	@Value("${pgEndPoints.ippopayPaymentURL}")
	String ippopayPaymentURL;

	public Model processIppoPayRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) throws IOException {

		

		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {

			model = setUPIDetailsIppoPay(orderId, model, orderId, formData, merchantPGDetails);
		}

		populateIppoPayTransDetails(formData, merchantPGDetails, orderId);

		return model;
	}

	public void populateIppoPayTransDetails(MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails,
			String orderId) {

		IppoPayTransactionDetails ippoPayTransactionDetails = new IppoPayTransactionDetails();

		ippoPayTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		ippoPayTransactionDetails.setOrderAmount(
				String.format("%.2f", Double.parseDouble(String.valueOf(formData.get(ORDERAMOUNT).get(0))) / 100));
		ippoPayTransactionDetails.setOrderId(orderId);
		ippoPayTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		ippoPayTransactionDetails.setTxStatus(UserStatus.PENDING.toString());
		ippoPayTransactionDetails.setUpdateFlag("N");
		ippoPayTransactionDetails.setSource("Initiated");
		ippoPayTransactionDetails.setEmail(formData.get(CUSTOMEREMAIL).get(0));
		ippoPayTransactionDetails.setPhoneNo(formData.get(CUSTOMERPHONE).get(0));

		ippoPayTransactionDetailsRepository.save(ippoPayTransactionDetails);
	}

	private Model setUPIDetailsIppoPay(String orderId, Model model, String data, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) throws IOException {

		IppoPayOrderResponse ippoPayOrderResponse = generateCreateRequest(formData);

		model = generateModel( model, ippoPayOrderResponse);

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return model;
	}

	private Model generateModel( Model model,
			IppoPayOrderResponse ippoPayOrderResponse) {

		
		model.addAttribute("orderId", ippoPayOrderResponse.getData().getOrder().getOrderId());
		model.addAttribute("publicKey", ippoPayOrderResponse.getData().getOrder().getPublicKey());
		

		return model;
	}

	private IppoPayOrderResponse generateCreateRequest(MultiValueMap<String, String> formData) throws IOException {

		IppoPayOrderCreateRequest ippoPayOrderCreateRequest = new IppoPayOrderCreateRequest();
		
		Customer customer = new Customer();
		Phone phone = new Phone(); 
		
		phone.setCountryCode("91");
		phone.setNationalNumber("9051093937");
		
		customer.setEmail(formData.get(CUSTOMEREMAIL).get(0));
		customer.setName(formData.get(CUSOMERNAME).get(0));
		customer.setPhone(phone);
		
		ippoPayOrderCreateRequest.setAmount(String.format("%.2f", Double.parseDouble(String.valueOf(formData.get(ORDERAMOUNT).get(0))) / 100));
		ippoPayOrderCreateRequest.setCurrency(IN_CURRENCY);
		ippoPayOrderCreateRequest.setCustomer(customer);
		ippoPayOrderCreateRequest.setNotifyUrl(ippopayReturnURL);
		ippoPayOrderCreateRequest.setPaymentModes(IN_PAYMENT_MODES);
		//ippoPayOrderCreateRequest.setReturnUrl(ippopayReturnURL);
		
		
		logger.info("ippoPayOrderCreateRequest :: "+Utility.convertDTO2JsonString(ippoPayOrderCreateRequest));
		
		
		HttpResponse<String> ippoPayOrderResponse = Unirest
				.post(ippopayPaymentURL)
				.basicAuth("pk_live_fZplArKZg25N", "sk_live_2gSHfRsPd38mjgr4jzlEIqKys8EfTljwY1UeooAk")
				.header("Content-Type", "application/json")
				.body(ippoPayOrderCreateRequest)
				.asString().ifFailure(SetuErrorResponse.class, r -> {
					SetuErrorResponse e = r.getBody();
					try {
						logger.info("IPPOPAY Response Error ::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});
				logger.info("ippopayPaymentURL :: "+ Utility.convertDTO2JsonString(ippoPayOrderResponse.getBody()));
				
				ObjectMapper objectMapper = new ObjectMapper();
				System.out.println("Output :: "+Utility.convertDTO2JsonString(objectMapper.readValue(ippoPayOrderResponse.getBody(), IppoPayOrderResponse.class)));
				
		return objectMapper.readValue(ippoPayOrderResponse.getBody(), IppoPayOrderResponse.class);
	}

}
