package com.asktech.payment.util.cashfree;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Set;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.ReturnMerchantAttributes;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.constants.cashfree.CashFreeResponseFormData;
import com.asktech.payment.constants.cashfree.CashFreeSubmitFields;
import com.asktech.payment.dto.utility.SignatureRequestAll;
import com.asktech.payment.enums.PGServices;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.CashfreeTransactionDetails;
import com.asktech.payment.model.GPAYPaymentDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.TransactionDetailsAll;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.CardPaymentDetailsRepository;
import com.asktech.payment.repository.CashfreeTransactionDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.service.PaymentVerification;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class CashFreeUtilityClass
		implements CashFreeFields, CashFreeSubmitFields, CashFreeResponseFormData, ReturnMerchantAttributes {

	@Autowired
	PaymentVerification service;
	@Autowired
	CardPaymentDetailsRepository cardPaymentDetailsRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;

	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	WalletListRepository walletListRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	CashfreeTransactionDetailsRepository cashfreeTransactionDetailsRepository;

	@Autowired
	PGGatewayUtilService pgGatewayUtilService;

	@Value("${pgEndPoints.cashfree}")
	String cashfreeURL;
	@Value("${pgEndPoints.cashfreeReturnURL}")
	String cashfreeReturnURL;
	@Value("${pgEndPoints.cashfreeNotifyURL}")
	String cashfreeNotifyURL;

	static Logger logger = LoggerFactory.getLogger(CashFreeUtilityClass.class);

	public Model processCashFreeRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId)
			throws InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException {

		logger.info("Inside processCashFreeRequest()");

		String sign = null;
		logger.info("Before  Encryption :: " + merchantPGDetails.getMerchantPGSecret());
		String merchantSecret = Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret());
		logger.info("After Encryption :: " + merchantSecret);
		SignatureRequestAll signatureRequest = new SignatureRequestAll();

		signatureRequest.setAppId(merchantPGDetails.getMerchantPGAppId());
		signatureRequest.setOrderId(orderId);
		signatureRequest.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		signatureRequest.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		signatureRequest.setOrderNote(formData.get(ORDERNOTE).get(0));
		signatureRequest.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		signatureRequest.setCustomerName(formData.get(CUSOMERNAME).get(0));
		signatureRequest.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		signatureRequest.setReturnUrl(pgGatewayUtilService.getReturnUrl(cashfreeReturnURL,
				merchantPGDetails.getMerchantID(), formData.get(PAYMENT_OPTION).get(0)));
		signatureRequest.setNotifyUrl(pgGatewayUtilService.getWebhookUrl(cashfreeNotifyURL,
				merchantPGDetails.getMerchantID(), formData.get(PAYMENT_OPTION).get(0)));
		signatureRequest.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));

		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.CARD.toString())) {
			signatureRequest.setCard_number(formData.get(CARD_NUMBER).get(0));
			signatureRequest.setCard_holder(formData.get(CARD_HOLDER).get(0));
			signatureRequest.setCard_expiryMonth(formData.get(CARD_EXPMONTH).get(0));
			signatureRequest.setCard_cvv(formData.get(CARD_CVV).get(0));
			signatureRequest.setCard_expiryYear(formData.get(CARD_EXPYEAR).get(0));

			sign = service.createSignature(signatureRequest, merchantSecret);
			model = setCardDetailsCashFree(signatureRequest, orderId, model, sign);

		}

		else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.NB.toString())) {
			logger.info("Inside processCashFreeRequest() into NB process");

			BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
					formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
					merchantPGDetails.getMerchantPGName());

			signatureRequest.setPaymentCode(bankList.getPgBankCode());
			logger.info("SignatureRequest NB ::  " + Utility.convertDTO2JsonString(signatureRequest));
			sign = service.createSignature(signatureRequest, merchantSecret);
			model = setNBDetailsCashFree(signatureRequest, orderId, model, sign);
		}

		else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.WALLET.toString())) {

			WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
					formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
					merchantPGDetails.getMerchantPGName());
			signatureRequest.setPaymentCode(walletList.getPaymentcodepg());
			logger.info("SignatureRequest WALLET ::  " + Utility.convertDTO2JsonString(signatureRequest));
			sign = service.createSignature(signatureRequest, merchantSecret);
			model = setWalletDetailsCashFree(signatureRequest, orderId, model, sign);

		}

		else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.UPI.toString())) {
			if (formData.get(UPI_VPI) != null) {
				logger.info("Inside UPI_VPI");
				logger.info("CashFree Signature :: " + merchantSecret);
				signatureRequest.setUpi_vpa(formData.get(UPI_VPI).get(0));

				logger.info("SignatureRequest UPI ::  " + Utility.convertDTO2JsonString(signatureRequest));
				sign = service.createSignature(signatureRequest, merchantSecret);
				model = setUPIDetailsCashFree(signatureRequest, orderId, model, sign);

			} else if (formData.get(UPIMODE).get(0).equalsIgnoreCase("gpay")) {
				logger.info("Inside UPIMODE");
				signatureRequest.setUpiMode(formData.get(UPIMODE).get(0));
				sign = service.createSignature(signatureRequest, merchantSecret);
				model = setGPAYDetailsCashFree(signatureRequest, orderId, model, sign);
			}
		}

		else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("emi")) {

		}

		else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("paylater")) {

		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("paypal")) {

		}

		model.addAttribute("postPage", cashfreeURL);

		return model;
	}

	public Model setGPAYDetailsCashFree(SignatureRequestAll signatureRequest, String orderId, Model model,
			String sign) {

		GPAYPaymentDetails gpayPaymentDetails = new GPAYPaymentDetails();

		gpayPaymentDetails.setOrderId(orderId);
		gpayPaymentDetails.setOrderAmount(signatureRequest.getOrderAmount());
		gpayPaymentDetails.setOrderNote(signatureRequest.getOrderNote());
		gpayPaymentDetails.setOrderCurrency(signatureRequest.getOrderCurrency());
		gpayPaymentDetails.setCustomerName(signatureRequest.getCustomerName());
		gpayPaymentDetails.setCustomerEmail(signatureRequest.getCustomerEmail());
		gpayPaymentDetails.setCustomerPhone(signatureRequest.getCustomerPhone());
		gpayPaymentDetails.setPaymentOption(signatureRequest.getPaymentOption());
		gpayPaymentDetails.setUpiMode(SecurityUtils.encryptSaveData(signatureRequest.getUpiMode()));

		model.addAttribute(CUSTDETAILS, gpayPaymentDetails);
		model.addAttribute(SUBMIT_SIGNATURE, sign);
		model.addAttribute(SUBMIT_RETURNURL, cashfreeReturnURL);
		model.addAttribute(SUBMIT_NOTIFYURL, cashfreeNotifyURL);
		model.addAttribute(SUBMIT_APPID, signatureRequest.getAppId());

		return model;
	}

	public Model setUPIDetailsCashFree(SignatureRequestAll signatureRequest, String orderId, Model model, String sign) {

		model = populateGenericAttribute(model, signatureRequest, orderId, sign);
		model.addAttribute(SUBMIT_UPI_VPA, signatureRequest.getUpi_vpa());
		pgGatewayUtilService.populateUPIInputRepo(orderId, signatureRequest);

		return model;
	}

	public Model setCardDetailsCashFree(SignatureRequestAll signatureRequest, String orderId, Model model,
			String sign) {

		logger.info("Inside setCardDetailsCashFree()");
		model = populateGenericAttribute(model, signatureRequest, orderId, sign);
		model.addAttribute(SUBMIT_CARDHOLDER, signatureRequest.getCard_holder());
		model.addAttribute(SUBMIT_CARDEXPIRYMONTH, signatureRequest.getCard_expiryMonth());
		model.addAttribute(SUBMIT_CARDEXPIRYYEAR, signatureRequest.getCard_expiryYear());
		model.addAttribute(SUBMIT_CARDCVV, signatureRequest.getCard_cvv());
		model.addAttribute(SUBMIT_CARDNUMBER, signatureRequest.getCard_number());
		// pgGatewayUtilService.populateCardInputRepo(orderId, signatureRequest);
		return model;
	}

	public Model setNBDetailsCashFree(SignatureRequestAll signatureRequest, String orderId, Model model, String sign) {

		logger.info("Inside setNBDetailsCashFree()");
		model = populateGenericAttribute(model, signatureRequest, orderId, sign);
		model.addAttribute(SUBMIT_PAYMENTCODE, signatureRequest.getPaymentCode());
		pgGatewayUtilService.populateNBInputRepo(orderId, signatureRequest);
		logger.info("End of setNBDetailsCashFree()");
		return model;
	}

	public Model setWalletDetailsCashFree(SignatureRequestAll signatureRequest, String orderId, Model model,
			String sign) {
		model = populateGenericAttribute(model, signatureRequest, orderId, sign);
		model.addAttribute(SUBMIT_PAYMENTCODE, signatureRequest.getPaymentCode());
		pgGatewayUtilService.populateWalletInputRepo(orderId, signatureRequest);

		return model;
	}

	public Model populateGenericAttribute(Model model, SignatureRequestAll signatureRequest, String orderId,
			String sign) {

		model.addAttribute(SUBMIT_ORDERNOTE, signatureRequest.getOrderNote());
		model.addAttribute(SUBMIT_ORDERCURRENCY, signatureRequest.getOrderCurrency());
		model.addAttribute(SUBMIT_CUSTOMERNAME, signatureRequest.getCustomerName());
		model.addAttribute(SUBMIT_CUSTOMEREMAIL, signatureRequest.getCustomerEmail());
		model.addAttribute(SUBMIT_CUSTOMERPHONE, signatureRequest.getCustomerPhone());
		model.addAttribute(SUBMIT_ORDERAMOUNT, signatureRequest.getOrderAmount());
		model.addAttribute(SUBMIT_ORDERID, orderId);
		model.addAttribute(SUBMIT_PAYMENTOPTION, signatureRequest.getPaymentOption());
		model.addAttribute(SUBMIT_SIGNATURE, sign);
		model.addAttribute(SUBMIT_RETURNURL, signatureRequest.getReturnUrl());
		model.addAttribute(SUBMIT_NOTIFYURL, signatureRequest.getNotifyUrl());
		model.addAttribute(SUBMIT_APPID, signatureRequest.getAppId());

		return model;
	}

	public boolean validateReturnSignature(MultiValueMap<String, String> responseFormData, String merchantId,
			String pgUUid) throws InvalidKeyException, NoSuchAlgorithmException {

		MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository.findByMerchantIDAndMerchantPGId(merchantId,
				pgUUid);

		logger.info("Coming from CashFree :: " + responseFormData.get(SIGNATURE).get(0));

		LinkedHashMap<String, String> postData = new LinkedHashMap<String, String>();
		postData.put(ORDERID, responseFormData.get(ORDERID).get(0));
		postData.put(ORDERAMOUNT, responseFormData.get(ORDERAMOUNT).get(0));
		postData.put(REFERENCEID, responseFormData.get(REFERENCEID).get(0));
		postData.put(TXSTATUS, responseFormData.get(TXSTATUS).get(0));
		postData.put(PAYMENTMODE, responseFormData.get(PAYMENTMODE).get(0));
		try {
			postData.put(TXMSG, responseFormData.get(TXMSG).get(0));
		} catch (Exception e) {
			postData.put(TXMSG, "");
		}
		postData.put(TXTIME, responseFormData.get(TXTIME).get(0));

		String data = "";
		Set<String> keys = postData.keySet();

		for (String key : keys) {
			data = data + postData.get(key);
		}

		String secretKey = Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret());
		Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
		SecretKeySpec secret_key_spec = new SecretKeySpec(secretKey.getBytes(), "HmacSHA256");
		sha256_HMAC.init(secret_key_spec);

		String signature = Base64.getEncoder().encodeToString(sha256_HMAC.doFinal(data.getBytes()));
		logger.info("Signature from mycode :: " + signature);
		if (responseFormData.get(SIGNATURE).get(0).equals(signature)) {
			return true;
		}
		return false;
	}

	public void updateTransactionStatus(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException, ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException {

		logger.info("Inside method updateTransactionStatus()");
		logger.info("Response Form Data" + GeneralUtils.MultiValueMaptoJson(responseFormData));

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

		if (transactionDetails != null) {

			if (validateReturnSignature(responseFormData, transactionDetails.getMerchantId(),
					transactionDetails.getPgId())) {
				logger.info("The return signature has been verified ...");
				String trxMsg = pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG);
				String pmode = pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE);
				transactionDetails.setStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXSTATUS));
				if (pmode.contains("UPI")) {
					if (!trxMsg.contains("00:")) {
						transactionDetails.setStatus(UserStatus.FAILED.toString());

					}
				}
			} else {
				logger.info("The return signature not verified ...");
				transactionDetails.setStatus(UserStatus.FAILED.toString());
			}

			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetails.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_REFERENCEID));
			transactionDetails
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
			transactionDetails.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG));
			transactionDetails.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));

			transactionDetails.setSource("ReturnURL");
			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsRepository.save(transactionDetails);
		} else {
			TransactionDetailsAll transactionDetailsAll = new TransactionDetailsAll();
			logger.info("Transaction Details Null");
			logger.info("Insert All Transaction Details");
			transactionDetails = transactionDetailsRepository
					.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

			logger.info("Insert Transaction Details by orderId:: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsAll.setOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
			transactionDetailsAll.setStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXSTATUS));
			transactionDetailsAll
					.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_REFERENCEID));
			transactionDetailsAll
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
			transactionDetails.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG));
			transactionDetails.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));

			transactionDetailsAllRepository.save(transactionDetailsAll);
		}
		logger.info("Transaction Update");

		logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			// logger.info("merchantDetails " +
			// Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");

		try {
			CashfreeTransactionDetails cashfreeTransactionDetails = new CashfreeTransactionDetails();

			cashfreeTransactionDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
			cashfreeTransactionDetails
					.setOrderAmount(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERAMOUNT));
			cashfreeTransactionDetails
					.setOrderId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
			cashfreeTransactionDetails
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
			cashfreeTransactionDetails
					.setReferenceId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_REFERENCEID));
			cashfreeTransactionDetails
					.setSignature(pgGatewayUtilService.checkResponseData(responseFormData, RESP_SIGNATURE));
			cashfreeTransactionDetails.setTxMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG));
			cashfreeTransactionDetails
					.setTxStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXSTATUS));
			cashfreeTransactionDetails.setTxTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));
			cashfreeTransactionDetails.setUpdateFlag("N");
			cashfreeTransactionDetails.setSource("ReturnURL");
			cashfreeTransactionDetailsRepository.save(cashfreeTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in CashfreeTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");
	}

	public Model getResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

		String status = "";

		if (transactionDetails.getStatus().equalsIgnoreCase(STATUS_PAYMENT_SUCCESSFUL)) {

			status = UserStatus.SUCCESS.toString();
		} else {
			status = transactionDetails.getStatus();
		}
		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);

		String trxMsg = pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG);
		String pmode = pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE);
		if (pmode.contains("UPI")) {
			if (!trxMsg.contains("00:")) {
				status = UserStatus.FAILED.toString();
			}
		}
		if (!validateReturnSignature(responseFormData, transactionDetails.getMerchantId(),
				transactionDetails.getPgId())) {
			status = UserStatus.FAILED.toString();
		}
		return pgGatewayUtilService.populateReturnModel(model, amt, status, transactionDetails);
	}

	public Model getCustResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, "VendorOrderId"));

		String status = "";
		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);


		if (!validateReturnSignature(responseFormData, transactionDetails.getMerchantId(),
				transactionDetails.getPgId())) {
			status = UserStatus.FAILED.toString();
		}
		return pgGatewayUtilService.populateReturnModelFinal(model, amt, status, transactionDetails);
	}

	public void updateTransactionWithNotifyCashfree(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException {

		logger.info("Inside method updateTransactionStatus()");
		logger.info("Response Form Data" + GeneralUtils.MultiValueMaptoJson(responseFormData));
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
		if (transactionDetails != null) {
			logger.info("Update Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));
			transactionDetails.setStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXSTATUS));
			transactionDetails.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_REFERENCEID));
			transactionDetails
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
			transactionDetails.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG));
			transactionDetails.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));
			transactionDetails.setSource("NotifyURL");
			transactionDetailsRepository.save(transactionDetails);

			pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "NotifyURL");

			CashfreeTransactionDetails cashfreeTransactionDetails = cashfreeTransactionDetailsRepository
					.findByOrderId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

			try {
				if (cashfreeTransactionDetails == null) {
					cashfreeTransactionDetails = new CashfreeTransactionDetails();

				}
				cashfreeTransactionDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
				cashfreeTransactionDetails
						.setOrderAmount(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERAMOUNT));
				cashfreeTransactionDetails
						.setOrderId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
				cashfreeTransactionDetails
						.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
				cashfreeTransactionDetails
						.setReferenceId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_REFERENCEID));
				cashfreeTransactionDetails
						.setSignature(pgGatewayUtilService.checkResponseData(responseFormData, RESP_SIGNATURE));
				cashfreeTransactionDetails
						.setTxMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG));
				cashfreeTransactionDetails
						.setTxStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXSTATUS));
				cashfreeTransactionDetails
						.setTxTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));
				cashfreeTransactionDetails.setUpdateFlag("N");
				cashfreeTransactionDetails.setSource("NotifyURL");
				cashfreeTransactionDetailsRepository.save(cashfreeTransactionDetails);

			} catch (Exception e) {
				logger.error("Exception in CashfreeTransactionDetails population ...");
			}
			logger.info("End method updateTransactionStatus()");

		}
	}

}
