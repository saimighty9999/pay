package com.asktech.payment.util.nimble.nimbleDto;

import lombok.AllArgsConstructor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UserDto {
    private String mobile_number;
    private String email;
    private String first_name;
    private String last_name;

}
