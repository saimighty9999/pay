package com.asktech.payment.util.pineperk.pineDto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Customer_data {
    
   private String email_id;
   private String country_code;
   private String mobile_number;
}
