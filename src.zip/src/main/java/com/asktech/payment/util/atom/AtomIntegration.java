package com.asktech.payment.util.atom;

public class AtomIntegration {

	// public static void main(String[] args) {

	// 	 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");  
	// 	 LocalDateTime now = LocalDateTime.now();  
	// 	 System.out.println(dtf.format(now));  
		
	// 	String Vendor_ID = "9132";
	// 	String Password = "Test@123";
	// 	String Product_ID = "NSE";
	// 	String ReqHashKey = "KEY123657234";
	// 	String RespHashKey = "KEYRESP123657234";
	// 	String Request_Salt = "A4476C2062FFA58980DC8F79EB6A799E";
	// 	String Response_Salt = "75AEF0FA1B94B3C10D4F5B268F757F11";
	// 	String AESEncryption_Request_Key = "A4476C2062FFA58980DC8F79EB6A799E";
	// 	String AESEncryption_Response_Key = "75AEF0FA1B94B3C10D4F5B268F757F11";
	// 	String clientcode = "007";

	// 	String custName = "BobTheBuilder";
	// 	String ru = "https://paynetzuat.atomtech.in/paynetzclient/ResponseParam.jsp";
	// 	String ttype = "NBFundTransfer";
	// 	String txnid = "Mer762345780";
	// 	String amt = "100.00";
	// 	String txncurr = "INR";
	// 	String custacc = "100000036600";
	// 	String phn = "9051093937";
		
		

	// 	String mid = Vendor_ID;
	// 	// String mid = "6755";
	// 	// String key = "8E41C78439831010F81F61C344B7BFC7";

	// 	// String decKey = "8E41C78439831010F81F61C344B7BFC7";

	// 	String signature = SignatureGenerate.getEncodedValueWithSha2(ReqHashKey, Vendor_ID, Password, ttype, Product_ID,
	// 			txnid, amt, txncurr);
	// 	String str = "login=" + Vendor_ID + "&pass=" + Password + "&ttype=" + ttype + "&prodid=" + Product_ID + "&amt="
	// 			+ amt + "&txncurr=" + txncurr
	// 			+ "&txnscamt=0&clientcode=" + clientcode + "&txnid=" + txnid
	// 			+ "&date="+dtf.format(now).replace(" ", "%20")
	// 			+ "&custacc=" + custacc
	// 			+ "&bankid=2001&ru=" + ru 
	// 			+ "&signature="+ signature
	// 			+ "&udf1=" + custName 
	// 			+ "&udf2=test@gmail.com&udf3=" + phn ;
		
	// 	System.out.println("Request Enc :: "+str);
		
	// 	String enc = null;
	// 	String dec = null;
	// 	try {
			
	// 		str = "merchantid=9132&merchanttxnid=165660721886614752962883&amt=100.00&tdate=2022-06-30";
	// 		enc = new AtomAES().encrypt(str, AESEncryption_Request_Key, Request_Salt);
	// 		System.out.println("Encrypted String is :: " + enc);

	// 		enc = "C05AED44531A61C12454AC83E2D48EA16A780A0A0F35FF24075A80FAAACAE3E430557E0FA2968E35C4FF2ECB37402443C1BE16094B2E6D7E93B0934FB16F45324F406580A3A54B497148FA3CD939812FB92E16A72B82E46911E81B92444F8BD48BBC014C7955D062881BFDEA1C557761065918731626EBF1B9630DD5A7B9E2412E76E0AEA10E08E22993B62FD81D76A491FD96D69851E6B029118965822982AB1809978FF0EE4F773F858AA7C56B7755D2025F4C0B316C41B9EFB46A30B7B6C3E4D00656DB72164C7899C2724C365D62D04EFCF4BBB111E3D41276D7717976044EC38DA8177FDC432B5BFC8260E3DBBA84CB3568DCAF50A6E07256FDAEDD071A942DCC5AD4A9638791DC222A7DCD3F22F10DE70E254869F9AD35E59E68F54AC8982FF6DDB5B611C3A9D55FBB39A5B2BD";
	// 		dec = new AtomAES().decrypt(enc, AESEncryption_Response_Key, Response_Salt);
	// 		System.out.println("Decrypted String is :: " + dec);

	// 	} catch (Exception e) {
	// 		e.printStackTrace();
	// 	}
	// 	//System.out.println("Encrypted String :: https://caller.atomtech.in/ots/payment/txn?merchId=197&encData=" + enc);
	// 	System.out.println("Encrypted String ::  https://paynetzuat.atomtech.in/paynetz/vftsv2?login="+Vendor_ID+"&encdata=" + enc);

	// }
}
