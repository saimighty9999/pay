package com.asktech.payment.util.pineperk.pineDto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderDataResponseDto {
    @JsonProperty("order_status")
    private String order_status;
    @JsonProperty("plural_order_id")
    private String plural_order_id;
    @JsonProperty("amount")
    private String amount;
    @JsonProperty("order_desc")
    private String order_desc;
    @JsonProperty("refund_amount")
    private String refund_amount;

    
}
