package com.asktech.payment.util.airPay.dto.failedRes;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
// @JsonInclude(Include.NON_NULL)
// @JsonIgnoreProperties(ignoreUnknown = true)
public class TRANSACTION { 
	public String TRANSACTIONPAYMENTSTATUS;
	public String MERCID;
	public String TRANSACTIONID;
	public String APTRANSACTIONID;
	public String TXN_MODE;
	public String CHMOD;
	public String AMOUNT;
	public String CURRENCYCODE;
	public String TRANSACTIONSTATUS;
	public String MESSAGE;
	public String CUSTOMER;
	public String CUSTOMERPHONE;
	public String CUSTOMEREMAIL;
	public String TRANSACTIONTYPE;
	public String TRANSACTIONTIME;
	public String UID;
	public String BILLEDAMOUNT;
	public String MERCHANT_NAME;
	public String CUSTOMERVPA;
	public String ap_SecureHash;
}

