package com.asktech.payment.util.payaid.payaidDto;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class PaymentRequestDto {
    private String api_key;
    private String address_line_1;
    private String address_line_2;
    private String amount;
    private String city;
    private String country;
    private String currency;
    private String description;
    private String email;
    private String mode;   
    private String name;
    private String order_id;
    private String phone;
    private String return_url;
    private String return_url_failure;  
    private String return_url_cancel;
    private String state;
    private String udf1;
    private String udf2;
    private String udf3;
    private String udf4;
    private String udf5;
    private String zip_code;
    private String hash;
    private String bank_code;

    public String createStringToHash(){

        String stringToHash = address_line_1+"|"+address_line_2+"|"+amount+"|"+api_key+"|"+bank_code+"|"+city+"|"+country+"|"+currency+"|"+description+"|"+email+"|"+mode+"|"+name+"|"+order_id+"|"+phone+"|"+return_url+"|"+state+"|"/*+udf1+"|"+udf2+"|"+udf3+"|"+udf4+"|"+udf5+"|"*/+zip_code; 
        return stringToHash;
    }    
}



