package com.asktech.payment.util.pineperk.pineDto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentInfoDataResponse {
    @JsonProperty("acquirer_name")
    private String acquirer_name;
    @JsonProperty("auth_code")
    private String auth_code;
    @JsonProperty("captured_amount_in_paisa")
    private String captured_amount_in_paisa;
    @JsonProperty("card_holder_name")
    private String card_holder_name;
    @JsonProperty("masked_card_number")
    private String masked_card_number;
    @JsonProperty("merchant_return_url")
    private String merchant_return_url;
    @JsonProperty("mobile_no")
    private String mobile_no;
    @JsonProperty("payment_completion_date_time")
    private String payment_completion_date_time;
    @JsonProperty("payment_id")
    private String payment_id;
    @JsonProperty("payment_status")
    private String payment_status;
    @JsonProperty("payment_response_code")
    private String payment_response_code;
    @JsonProperty("payment_response_message")
    private String payment_response_message;
    @JsonProperty("product_code")
    private String product_code;
    @JsonProperty("rrn")
    private String rrn;
    @JsonProperty("refund_amount_in_paisa")
    private String refund_amount_in_paisa;
    @JsonProperty("salted_card_hash")
    private String salted_card_hash;
    @JsonProperty("udf_field_1")
    private String udf_field_1;
    @JsonProperty("udf_field_2")
    private String udf_field_2;
    @JsonProperty("udf_field_3")
    private String udf_field_3;
    @JsonProperty("udf_field_4")
    private String udf_field_4;
    @JsonProperty("payment_mode")
    private String payment_mode;
    @JsonProperty("issuer_name")
    private String issuer_name;
    @JsonProperty("gateway_payment_id")
    private String gateway_payment_id;
    
    
}
