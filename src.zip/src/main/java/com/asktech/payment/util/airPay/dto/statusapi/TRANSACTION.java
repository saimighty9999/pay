package com.asktech.payment.util.airPay.dto.statusapi;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class TRANSACTION { 
	public String TRANSACTIONSTATUS;
	public String MESSAGE;
	public String APTRANSACTIONID;
	public String TRANSACTIONID;
	public String AMOUNT;
	public String ap_SecureHash;
	public String AP_SECUREHASH;
	public String CARDCOUNTRY;
	public String CHMOD;
	public String CONVERSIONRATE;
	public String BANKNAME;
	public String CARDISSUER;
	public String CARDTYPE;
	public String CUSTOMER;
	public String CUSTOMEREMAIL;
	public String CUSTOMERPHONE;
	public String CURRENCYCODE;
	public String RISK;
	public String TRANSACTIONTYPE;
	public String TRANSACTIONTIME;
	public String TRANSACTIONPAYMENTSTATUS;
	public String MERCHANT_NAME;
	public String WALLETBALANCE;
	public String SURCHARGE;
	public String SETTLEMENT_DATE;
	public String BILLEDAMOUNT;
	public String CUSTOMERVPA;
	public String TRANSACTIONREASON;
	public String RRN;
}
