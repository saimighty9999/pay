package com.asktech.payment.util.freecharge;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.ErrorValues;
import com.asktech.payment.constant.ReturnMerchantAttributes;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.constants.freecharge.FreeChargeResponseFormData;
import com.asktech.payment.constants.freecharge.Freechagre;
import com.asktech.payment.dto.freeCharge.FreeChargeRequest;
import com.asktech.payment.dto.freeCharge.FreeChargeResponse;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.model.FreeChargeTransactionDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.TransactionDetailsAll;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.FreeChargeTransactionDetailsRepo;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class FreeChargeUtility implements CashFreeFields, ErrorValues , Freechagre,FreeChargeResponseFormData,ReturnMerchantAttributes {
	
	@Value("${pgEndPoints.freeChargePaymentLink}")
	String freeChargePaymentLink;
	@Value("${pgEndPoints.freeChargefurlLink}")
	String freeChargefurlLink;
	@Value("${pgEndPoints.freeChargesurlLink}")
	String freeChargesurlLink;
	
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	FreeChargeTransactionDetailsRepo freeChargeTransactionDetailsRepo;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;
	
	static Logger logger = LoggerFactory.getLogger(FreeChargeUtility.class);
	
	public String generateChecksum(String jsonString, String merchantKey) throws Exception {
		MessageDigest md;
		String plainText = jsonString.concat(merchantKey);
		try {
			md = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e) {
			throw new Exception(); //
		}
		md.update(plainText.getBytes(Charset.defaultCharset()));
		byte[] mdbytes = md.digest();
		
		StringBuffer checksum = new StringBuffer();
		for (int i = 0; i < mdbytes.length; i++) {
			checksum.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16).substring(1));
		}
		return checksum.toString();
	}
	
	public Model populateModelInfo( Model model,MerchantPGDetails merchantPGDetails,MultiValueMap<String, String> formData, String orderId) throws JsonProcessingException, Exception {

		logger.info("Inside populateModelInfo() FreeCharge");
		
		WalletPaymentDetails  walletPaymentDetails = new WalletPaymentDetails();

		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		walletPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		walletPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		walletPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		walletPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		walletPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		//walletPaymentDetails.setPaymentCode(SecurityUtils.encryptSaveData(formData.get(PAYMENTCODE).get(0)));
		walletPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		
		walletPaymentDetailsRepository.save(walletPaymentDetails);		
		model.addAttribute(Freechagre.AMOUNT,walletPaymentDetails.getOrderAmount() );
		model.addAttribute(Freechagre.CHANNEL, Freechagre.CHANNEL_WEB);
		model.addAttribute(Freechagre.FURL, freeChargefurlLink);
		model.addAttribute(Freechagre.MERCHANTID,merchantPGDetails.getMerchantPGAppId() );
		model.addAttribute(Freechagre.SURL, freeChargesurlLink);		
		model.addAttribute(Freechagre.MERCHANTTXNID,orderId );
		model.addAttribute(Freechagre.CHECKSUM, populateCheckSum(walletPaymentDetails.getOrderAmount(),merchantPGDetails,orderId));
		
		logger.info("Ended populateModelInfo()");
		return model;
	}
	
	public String populateCheckSum(String amount ,MerchantPGDetails merchantPGDetails , String orderId) throws JsonProcessingException, Exception {
		FreeChargeRequest freeChargeRequest = new FreeChargeRequest();
		freeChargeRequest.setAmount(amount);
		freeChargeRequest.setChannel(Freechagre.CHANNEL_WEB);
		freeChargeRequest.setFurl(freeChargefurlLink);
		freeChargeRequest.setMerchantId(merchantPGDetails.getMerchantPGAppId());
		freeChargeRequest.setSurl(freeChargesurlLink);
		freeChargeRequest.setMerchantTxnId(orderId);
		
		logger.info("Before CheckSome :: "+Utility.convertDTO2JsonString(freeChargeRequest));
		logger.info("Before CheckSome with Secret  :: "+Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
				
		String checkSum = generateChecksum(Utility.convertDTO2JsonString(freeChargeRequest),
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
		return checkSum;
	}
	
	public void updateTransactionStatusFreeCharge(MultiValueMap<String, String> responseFormData)
			throws Exception {

		logger.info("Inside method updateTransactionStatus()" + responseFormData.toString());

		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderIDAndStatus(
				pgGatewayUtilService.checkResponseData(responseFormData, RESP_MERCHANTTXNID), UserStatus.PENDING.toString());
		
		//freeChargeUtility.validateSignature(responseFormData, transactionDetails);
		
		
		if (transactionDetails != null) {

			transactionDetails.setStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
			transactionDetails.setTxtPGTime(Utility.populateDbTime());
			transactionDetails.setSource("ReturnURL");			
			transactionDetails.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXNID));			
			transactionDetailsRepository.save(transactionDetails);
			
		} else {
			TransactionDetailsAll transactionDetailsAll = new TransactionDetailsAll();
			transactionDetailsAll.setOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_MERCHANTTXNID));
			transactionDetailsAll.setStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
			transactionDetailsAll.setTxtPGTime(Utility.populateDbTime());
			transactionDetailsAll.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXNID));

			transactionDetailsAllRepository.save(transactionDetailsAll);
		}
		logger.info("Transaction Update");
		logger.info("GetUser Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails), userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");

		try {
			FreeChargeTransactionDetails freeChargeTransactionDetails = new FreeChargeTransactionDetails();

			freeChargeTransactionDetails.setStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
			freeChargeTransactionDetails.setAmount(pgGatewayUtilService.checkResponseData(responseFormData, RESP_AMOUNT));
			freeChargeTransactionDetails.setChecksum(pgGatewayUtilService.checkResponseData(responseFormData, RESP_CHECKSUM));
			freeChargeTransactionDetails.setMerchantTxnId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_MERCHANTTXNID));
			freeChargeTransactionDetails.setUpdateFlag("N");
			freeChargeTransactionDetails.setTxnId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXNID));
			
			if (freeChargeTransactionDetails.getStatus().equalsIgnoreCase("FAILED")) {
				freeChargeTransactionDetails.setErrorCode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ERRORCODE));
				freeChargeTransactionDetails.setErrorDetails(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ERRORMESSAGE));
			}

			freeChargeTransactionDetailsRepo.save(freeChargeTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in CashfreeTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");
	}
	
	public Model getResponseProcessFreeCharge(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException {

		logger.info("Inside Method getResponseProcessFreeCharge()");
		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_MERCHANTTXNID));

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		
		/*
		String tr_time = Utility.populateDbTime();
		String signature = pgGatewayUtilService.populateReturnSignature(transactionDetails.getStatus(),
				transactionDetails.getPaymentOption(), transactionDetails.getMerchantOrderId(),
				String.valueOf(transactionDetails.getAmount()), transactionDetails.getOrderID(), tr_time,
				transactionDetails.getMerchantId(), "", "");

		model.addAttribute(RET_RETURNURL, transactionDetails.getMerchantReturnURL().replaceAll("\\p{C}", ""));
		model.addAttribute(RET_STATUS, transactionDetails.getStatus().replace("COMPLETED", "SUCCESS"));
		model.addAttribute(RET_PAYMENTOPTION, transactionDetails.getPaymentOption());
		model.addAttribute(RET_MERCHANTORDERID, transactionDetails.getMerchantOrderId());
		model.addAttribute(RET_ORDERAMOUNT, Utility.getAmountConversion(String.valueOf(transactionDetails.getAmount())));
		model.addAttribute(RET_VENDORORDERID, transactionDetails.getOrderID());
		model.addAttribute(RET_TXTDATE, tr_time);
		model.addAttribute(RET_SIGNATURE, signature);
		logger.info("End Method getResponseProcessLetsPay()");		

		if (transactionDetails.getMerchantAlertURL() != null) {

			logger.info("Merchant Notify URL :: " + transactionDetails.getMerchantAlertURL());			
			notiFyURLService2Merchant.sendNotifyDetails2Merchant(
					transactionDetails.getStatus().replace("COMPLETED", "SUCCESS"),
					transactionDetails.getPaymentOption(), transactionDetails.getMerchantOrderId(), amt,
					transactionDetails.getOrderID(), tr_time, signature, transactionDetails.getMerchantAlertURL());
		}
		pgGatewayUtilService.populateResponseToMerchant(transactionDetails, model.toString());

		return model;
		*/
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}
	
	public boolean validateSignature(MultiValueMap<String, String> responseFormData , TransactionDetails transactionDetails) throws JsonProcessingException, Exception {
		FreeChargeResponse freeChargeResponse = new FreeChargeResponse();
		
		MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository.findByMerchantIDAndMerchantPGId(
				transactionDetails.getMerchantId(),transactionDetails.getPgId());
		
		freeChargeResponse.setAmount(responseFormData.get("amount").get(0));
		
		if(Objects.isNull(responseFormData.get("authCode").get(0))) {
			freeChargeResponse.setAuthCode("");
		}else {
			freeChargeResponse.setAuthCode(responseFormData.get("authCode").get(0));
		}
		if(Objects.isNull(responseFormData.get("merchantLogo").get(0))) {
			freeChargeResponse.setMerchantLogo("");
		}else {
			freeChargeResponse.setMerchantLogo(responseFormData.get("merchantLogo").get(0));
		}
		if(Objects.isNull(responseFormData.get("merchantName").get(0))) {
			freeChargeResponse.setMerchantName("");
		}else {
			freeChargeResponse.setMerchantName(responseFormData.get("merchantName").get(0));
		}
		if(Objects.isNull(responseFormData.get("metadata").get(0))) {
			freeChargeResponse.setMetadata(responseFormData.get("metadata").get(0));
		}else {
			freeChargeResponse.setMerchantName(responseFormData.get("metadata").get(0));
		}		
		freeChargeResponse.setMerchantTxnId(responseFormData.get("merchantTxnId").get(0));		
		freeChargeResponse.setStatus(responseFormData.get("status").get(0));
		freeChargeResponse.setTxnId(responseFormData.get("txnId").get(0));
		
		String checkSum = generateChecksum(Utility.convertDTO2JsonString(freeChargeResponse),
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
		
		logger.info("Getting checkSum as output from Free :: "+responseFormData.get("checksum").get(0));
		logger.info("Generate Checksum after received the Data from FreeCharge :: "+checkSum);
		
		return true;
	}
	
	
	/*
	public SetuResponsePayment processPayment(SetuPaymentLinkCreation setuPaymentLinkCreation, MerchantPGDetails merchantPGDetails)
			throws JsonProcessingException {

		try {
			HttpResponse<SetuResponsePayment> setuResponsePayment = Unirest.post(freeChargePaymentLink)					
					.header(Freechagre.CONTENTTYPE, Freechagre.CONTENTVALUE)					
					.field("amount", "")
					.field("channel", "")
					.field("furl", "")
					.field("merchantId", "")
					.field("surl", "")
					.field("checksum", "")
					.field("merchantTxnId", "")
					.asObject(SetuResponsePayment.class)
					.ifFailure(SetuErrorResponse.class, r -> {
						SetuErrorResponse e = r.getBody();

					});
			logger.info(
					"FreeCharge.getBody() :: " + Utility.convertDTO2JsonString(setuResponsePayment.getBody()));
			return setuResponsePayment.getBody();
		} catch (Exception e) {
			logger.error("Exception");
			e.printStackTrace();
		}

		return null;
	}
	*/
}
