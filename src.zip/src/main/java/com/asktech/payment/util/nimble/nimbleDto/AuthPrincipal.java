package com.asktech.payment.util.nimble.nimbleDto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuthPrincipal {
    @JsonProperty("id")
    private String id;
    @JsonProperty("access_key")
    private String access_key;
    @JsonProperty("active")
    private boolean active;
    @JsonProperty("type")
    private String type;
    @JsonProperty("sub_merchant_id")
    private String sub_merchant_id;
    @JsonProperty("number_of_token_per_minute")
    private String number_of_token_per_minute;
    @JsonProperty("skip_device_verification")
    private boolean skip_device_verification;
    
}
