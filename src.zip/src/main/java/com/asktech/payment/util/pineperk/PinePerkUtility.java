package com.asktech.payment.util.pineperk;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.sabPaisa.SabPaisaTransactionStatus;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.Utility;
import com.asktech.payment.util.pineperk.pineDto.Additional_info_data;
import com.asktech.payment.util.pineperk.pineDto.Billing_address_data;
import com.asktech.payment.util.pineperk.pineDto.Customer_data;
import com.asktech.payment.util.pineperk.pineDto.Merchant_data;
import com.asktech.payment.util.pineperk.pineDto.Payment_info_data;
import com.asktech.payment.util.pineperk.pineDto.PineTokenResponseDto;
import com.asktech.payment.util.pineperk.pineDto.Pinebase;
import com.asktech.payment.util.pineperk.pineDto.Pineperk;
import com.asktech.payment.util.pineperk.pineDto.Product_details;
import com.asktech.payment.util.pineperk.pineDto.Product_info_data;
import com.asktech.payment.util.pineperk.pineDto.Shipping_address_data;
import com.fasterxml.jackson.core.JsonProcessingException;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Component
public class PinePerkUtility implements CashFreeFields {

    static Logger logger = LoggerFactory.getLogger(PinePerkUtility.class);
    @Autowired
    PGConfigurationDetailsRepository pgConfigurationDetailsRepository;
    @Autowired
    UPIPaymentDetailsRepository upiPaymentDetailsRepository;
    @Autowired
    TransactionDetailsRepository transactionDetailsRepository;
    @Autowired
    PGGatewayUtilService pgGatewayUtilService;
    @Autowired
    MerchantPGDetailsRepository merchantPGDetailsRepository;
    @Autowired
    TransactionDetailsAllRepository transactionDetailsAllRepository;
    @Autowired
    UserDetailsRepository userDetailsRepository;
    @Autowired
    MerchantDetailsRepository merchantDetailsRepository;

    @Value("${pgEndPoints.pineperkReturn}")
    String pineperkReturn;

    public Model processRequest(MultiValueMap<String, String> formData, Model model,
            MerchantPGDetails merchantPGDetails, String orderId, String return_url)
            throws JsonProcessingException, ValidationExceptions, NoSuchAlgorithmException,
            UnsupportedEncodingException {

        PineTokenResponseDto pineTokenResponseDto = createOrder(orderId, formData, merchantPGDetails);
        model.addAttribute("redirect_url","https://checkout.pluralonline.com/?orderToken="+pineTokenResponseDto.getToken()+"&paymentMode=ALL");

        return model;

    }

    public PineTokenResponseDto createOrder(String orderId, MultiValueMap<String, String> formData,
            MerchantPGDetails merchantPGDetails) throws JsonProcessingException {
        Pineperk pineperk = new Pineperk();

        // System.out.println("\n\n\nHello\n\n\n\n");

        Merchant_data merchant_data = new Merchant_data();
        Customer_data customer_data = new Customer_data();
        Payment_info_data payment = new Payment_info_data();
        Billing_address_data billaddress = new Billing_address_data();
        Additional_info_data additional = new Additional_info_data();
        // Product_details product = new Product_details();
        Product_info_data productinfo = new Product_info_data();
        Shipping_address_data shipping = new Shipping_address_data();
        Product_details details = new Product_details();

        merchant_data.setMerchant_access_code(merchantPGDetails.getMerchantPGAppId());
        merchant_data.setMerchant_id(merchantPGDetails.getMerchantPGAdd1());
        merchant_data.setMerchant_return_url("https://penny-pay.co.in");
        merchant_data.setMerchant_order_id(formData.get(ORDERID).get(0));

        pineperkReturn = pgGatewayUtilService.getReturnUrl(pineperkReturn, merchantPGDetails.getMerchantID(),
                formData.get(PAYMENT_OPTION).get(0));

        pineperk.setMerchant_data(merchant_data);
        customer_data.setEmail_id(formData.get(CUSTOMEREMAIL).get(0));
        customer_data.setCountry_code("91");
        customer_data.setMobile_number(formData.get(CUSTOMERPHONE).get(0));

        payment.setAmount(Float.parseFloat(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0))));
        payment.setOrder_desc("Description");
        payment.setCurrency_code("INR");
        billaddress.setFirst_name(formData.get(CUSOMERNAME).get(0));
        billaddress.setLast_name(formData.get(CUSOMERNAME).get(0));

        billaddress.setAddress1("Pritampura");
        billaddress.setAddress2("sector 5");
        billaddress.setAddress3("NOIDA");
        billaddress.setCity("Nagpur");
        billaddress.setPin_code("440008");
        billaddress.setCountry("INDIA");
        billaddress.setState("UP");
        shipping.setFirst_name(formData.get(CUSOMERNAME).get(0));
        shipping.setLast_name(formData.get(CUSOMERNAME).get(0));
        shipping.setAddress1("Pritampura");
        shipping.setAddress2("sector 5");
        shipping.setAddress3("NOIDA");
        shipping.setCity("Nagpur");
        shipping.setPin_code("440008");
        shipping.setCountry("INDIA");
        shipping.setState("Maharashtra");

        details.setProduct_amount(Float.parseFloat(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0))));
        details.setProduct_code("40");

        List detail_lists = new ArrayList<>();
        detail_lists.add(details);
        productinfo.setProduct_details(detail_lists);
        additional.setRfu1("1");

        // ## ADDING DATA TO PINEPARK DTO

        pineperk.setMerchant_data(merchant_data);
        pineperk.setPayment_info_data(payment);
        pineperk.setCustomer_data(customer_data);
        pineperk.setBilling_address_data(billaddress);
        pineperk.setShipping_address_data(shipping);
        pineperk.setProduct_info_data(productinfo);
        pineperk.setAdditional_info_data(additional);

        String pineJson = Utility.convertDTO2JsonString(pineperk);
        String pinebase6 = Utility.encodeBase64(pineJson);

        String strsecretkey = Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret());
        String hashkey = HashingAlgorithm.GenerateHash(pinebase6, strsecretkey);

        System.out.println("\n\n\n");
        System.out.println(hashkey);
        System.out.println("\n\n\n");
        System.out.println("\n\n\n");
        System.out.println("\n\n\n");

        System.out.println(pinebase6);
        System.out.println("\n\n\n");

        Pinebase pinebase = new Pinebase();
        pinebase.setRequest(pinebase6);

        PineTokenResponseDto pineTokenResponseDto = sendPinePerkRequest(pinebase, hashkey);
        if (pineTokenResponseDto == null) {
            return null;
        }
        logger.info(Utility.convertDTO2JsonString(pineTokenResponseDto));
        return pineTokenResponseDto;
        // return null;

    }

    public PineTokenResponseDto sendPinePerkRequest(Pinebase pinebase, String hash)
            throws JsonProcessingException {

        logger.info(Utility.convertDTO2JsonString(pinebase));
        HttpResponse<PineTokenResponseDto> PineperkDetails = Unirest
                .post("https://api.pluralonline.com/api/v1/order/create").header("x-verify", hash)
                .header("Content-Type", "application/json")
                .body(Utility.convertDTO2JsonString(pinebase)).asObject(PineTokenResponseDto.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("Error Response :: " + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });

        logger.info("Response :: " + Utility.convertDTO2JsonString(PineperkDetails.getBody()));
        return PineperkDetails.getBody();

    }

    public void sendPinePerkPaymentRequest(Pineperk pineperk, PineTokenResponseDto pineTokenResponseDto)
            throws JsonProcessingException {
        HttpResponse<SabPaisaTransactionStatus> SabPaisaTransactionDetails = Unirest
                .post("https://checkout.pluralonline.com?orderToken=" + pineTokenResponseDto.getToken()
                        + "&paymentMode=ALL")
                .body(Utility.convertDTO2JsonString(pineperk)).asObject(SabPaisaTransactionStatus.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();

                    try {
                        logger.info("PinePerk Status Request Response Error::" + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });

        logger.info("Response :: " + Utility.convertDTO2JsonString(SabPaisaTransactionDetails.getBody()));

    }

}
