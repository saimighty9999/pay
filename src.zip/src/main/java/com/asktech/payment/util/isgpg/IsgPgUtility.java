package com.asktech.payment.util.isgpg;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.nsdl.NSDLAuthenticationEncRequest;
import com.asktech.payment.dto.nsdl.NSDLAuthenticationRequest;
import com.asktech.payment.dto.nsdl.NSDLAuthenticationResponse;
import com.asktech.payment.dto.nsdl.NSDLStatusEncRequest;
import com.asktech.payment.dto.nsdl.NSDLStatusRequest;
import com.asktech.payment.dto.nsdl.NSDLStatusResponse;
import com.asktech.payment.dto.nsdl.NSDLStatusResponseDecode;
import com.asktech.payment.dto.setu.SetuErrorResponse;
import com.asktech.payment.model.IsgPgTransactionDetail;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NSDLTransactionDetails;
import com.asktech.payment.model.PGConfigurationDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.repository.IsgPgTransactionDetailRepo;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.PaymentLogs;
import com.asktech.payment.util.Utility;
import com.asktech.payment.util.nsdl.DataEncryptionDecryption;
import com.asktech.payment.util.nsdl.DataHashing;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class IsgPgUtility implements CashFreeFields {

	static Logger logger = LoggerFactory.getLogger(IsgPgUtility.class);

	// @Autowired
	// Environment env;

	@Autowired
	IsgPgChecksum isgPgChecksum;
	@Autowired
	private TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	private UserDetailsRepository userDetailsRepository;
	@Autowired
	private MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	private PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	private PaymentLogs paymentLogs;
	@Autowired
	IsgPgTransactionDetailRepo isgPgTransactionDetailRepo;

	@Value("${pgEndPoints.isgAuthenticationEndPoint}")
	String isgAuthenticationEndPoint;
	@Value("${pgEndPoints.isgAuthorizationEndPoint}")
	String isgAuthorizationEndPoint;
	@Value("${pgEndPoints.isgUPIEndPoint}")
	String isgUPIEndPoint;
	@Value("${pgEndPoints.isgStatusEndPoint}")
	String isgStatusEndPoint;

	@Value("${apiEndPoint}")
	String apiurl;

	ObjectMapper objectMapper = new ObjectMapper();

	public Model processIsgUPIRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId, String ipAddress, String returnURL) throws Exception {

		NSDLAuthenticationEncRequest nsdlAuthenticationEncRequest = new NSDLAuthenticationEncRequest();
		nsdlAuthenticationEncRequest.setBankId("000004");
		nsdlAuthenticationEncRequest.setMerchantId(merchantPGDetails.getMerchantPGAppId());
		nsdlAuthenticationEncRequest.setOrderId(orderId);
		nsdlAuthenticationEncRequest.setTerminalId(merchantPGDetails.getMerchantPGAdd1());
		nsdlAuthenticationEncRequest.setMCC(merchantPGDetails.getMerchantPGAdd2());
		nsdlAuthenticationEncRequest.setCommand("Pay");
		nsdlAuthenticationEncRequest.setCurrency(356);
		nsdlAuthenticationEncRequest.setAmount(Integer.parseInt(formData.get(ORDERAMOUNT).get(0)));
		nsdlAuthenticationEncRequest.setPaymentOption("upi");
		nsdlAuthenticationEncRequest.setAccessCode(merchantPGDetails.getMerchantPGAdd3());
		nsdlAuthenticationEncRequest.setVpa(formData.get(UPI_VPI).get(0));
		logger.info("REQ::" + Utility.convertDTO2JsonString(nsdlAuthenticationEncRequest));
		Map<Object, Object> fields = new LinkedHashMap<>();
		fields.put("MerchantId", nsdlAuthenticationEncRequest.getMerchantId());
		fields.put("OrderId", nsdlAuthenticationEncRequest.getOrderId());
		fields.put("Amount", nsdlAuthenticationEncRequest.getAmount());
		fields.put("BankId", nsdlAuthenticationEncRequest.getBankId());
		fields.put("TerminalId", nsdlAuthenticationEncRequest.getTerminalId());
		fields.put("MCC", nsdlAuthenticationEncRequest.getMCC());
		fields.put("AccessCode", nsdlAuthenticationEncRequest.getAccessCode());
		fields.put("Command", nsdlAuthenticationEncRequest.getCommand());
		fields.put("Currency", nsdlAuthenticationEncRequest.getCurrency());
		fields.put("PaymentOption", nsdlAuthenticationEncRequest.getPaymentOption());
		fields.put("VPA", nsdlAuthenticationEncRequest.getVpa());

		logger.info("MerchantPGDetails :: " + Utility.convertDTO2JsonString(merchantPGDetails));
		logger.info("SaltKey :: " + merchantPGDetails.getMerchantPGSaltKey());
		logger.info("Hash Fields :: " + fields.toString());
		String secureHash = DataHashing.getHashValue(fields, merchantPGDetails.getMerchantPGSaltKey());
		nsdlAuthenticationEncRequest.setSecureHash(secureHash);

		logger.info("Secret :: " + Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
		logger.info("Decryption Request  :: " + Utility.convertDTO2JsonString(nsdlAuthenticationEncRequest));
		String encData = DataEncryptionDecryption.encrypt(Utility.convertDTO2JsonString(nsdlAuthenticationEncRequest),
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
		logger.info("Encryption Data :: " + encData);

		NSDLAuthenticationRequest nsdlAuthenticationRequest = setNSDLAuthenticationRequest(
				nsdlAuthenticationEncRequest.getBankId(), nsdlAuthenticationEncRequest.getMerchantId(), orderId,
				nsdlAuthenticationEncRequest.getTerminalId());

		NSDLAuthenticationResponse nsdlAuthenticationResponse = populateAuthenticationResponse(
				nsdlAuthenticationRequest, encData, isgUPIEndPoint, orderId);
		if (nsdlAuthenticationResponse.getEncData() != null) {
			String decData = DataEncryptionDecryption.decrypt(nsdlAuthenticationResponse.getEncData(),
					Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
			logger.info("Decryption Data :: " + decData);

			String respmsg = convertJsonStrTOJsonObject(decData).getString("ResponseMessage");
			logger.error("Response Message :: " + respmsg);
			model.addAttribute("orderId", orderId);
			model.addAttribute("apiurl", apiurl);
		} else {
			model.addAttribute("errorMsg", nsdlAuthenticationResponse.getErrorMessage());
		}

		return model;
	}

	public JSONObject convertJsonStrTOJsonObject(String stringToParse) throws org.json.simple.parser.ParseException {
		JSONObject jsonObj = new JSONObject(stringToParse.toString());

		return jsonObj;
	}

	private  NSDLAuthenticationRequest setNSDLAuthenticationRequest(String bankId, String merchantId,
			String orderId,
			String terminalId) {

		NSDLAuthenticationRequest nsdlAuthenticationRequest = new NSDLAuthenticationRequest();
		nsdlAuthenticationRequest.setBankId(bankId);
		nsdlAuthenticationRequest.setMerchantId(merchantId);
		nsdlAuthenticationRequest.setOrderId(orderId);
		nsdlAuthenticationRequest.setTerminalId(terminalId);

		return nsdlAuthenticationRequest;
	}

	public  NSDLAuthenticationResponse populateAuthenticationResponse(
			NSDLAuthenticationRequest nsdlAuthenticationRequest, String encData, String endPoint, String orderId)
			throws JsonProcessingException {

		nsdlAuthenticationRequest.setEncData(encData);

		logger.info("Request JSON :: " + Utility.convertDTO2JsonString(nsdlAuthenticationRequest));

		HttpResponse<NSDLAuthenticationResponse> nsdlAuthenticationResponse = Unirest.post(endPoint)
				.header("Content-Type", "application/json").body(nsdlAuthenticationRequest)
				.asObject(NSDLAuthenticationResponse.class).ifFailure(SetuErrorResponse.class, r -> {
					SetuErrorResponse e = r.getBody();
					try {
						logger.info("NSDL Authentication Request Response Error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});

		logger.info(
				"Authentication Response :: " + Utility.convertDTO2JsonString(nsdlAuthenticationResponse.getBody()));

		populateISGTransaction(nsdlAuthenticationRequest, nsdlAuthenticationResponse.getBody(), orderId);

		return nsdlAuthenticationResponse.getBody();
	}

	public NSDLStatusResponseDecode getUPIStatus(String orderId, IsgPgTransactionDetail isgPgTransactionDetail,
			TransactionDetails transactionDetails, PGConfigurationDetails pgConfigurationDetails) throws Exception {

		NSDLStatusResponseDecode nsdlStatusResponseDecode = new NSDLStatusResponseDecode();

		logger.info("transactionDetails :: " + Utility.convertDTO2JsonString(transactionDetails));
		Map<Object, Object> nsdlParams = new LinkedHashMap<>();
		nsdlParams.put("BankId", isgPgTransactionDetail.getBankId());
		nsdlParams.put("MerchantId", isgPgTransactionDetail.getMerchantId());
		nsdlParams.put("TerminalId", isgPgTransactionDetail.getAuthTerminalId());
		nsdlParams.put("OrderId", orderId);
		nsdlParams.put("AccessCode", pgConfigurationDetails.getPgAddInfo3());
		nsdlParams.put("TxnType", "Status");

		String secureHash = DataHashing.getHashValue(nsdlParams, pgConfigurationDetails.getPgSaltKey());

		NSDLStatusEncRequest nsdlStatusEncRequest = new NSDLStatusEncRequest();
		nsdlStatusEncRequest.setSecureHash(secureHash);
		nsdlStatusEncRequest.setAccessCode(pgConfigurationDetails.getPgAddInfo3());
		nsdlStatusEncRequest.setBankId(isgPgTransactionDetail.getBankId());
		nsdlStatusEncRequest.setMerchantId(isgPgTransactionDetail.getMerchantId());
		nsdlStatusEncRequest.setOrderId(orderId);
		nsdlStatusEncRequest.setTerminalId(isgPgTransactionDetail.getAuthTerminalId());
		nsdlStatusEncRequest.setTxnType("Status");
		nsdlStatusEncRequest.setVpa(transactionDetails.getVpaUPI());

		String encData = DataEncryptionDecryption.encrypt(Utility.convertDTO2JsonString(nsdlStatusEncRequest),
				Encryption.decryptCardNumberOrExpOrCvv(pgConfigurationDetails.getPgSecret()));

		NSDLStatusRequest nsdlStatusRequest = new NSDLStatusRequest();
		nsdlStatusRequest.setBankId(isgPgTransactionDetail.getBankId());
		nsdlStatusRequest.setEncData(encData);
		nsdlStatusRequest.setMerchantId(isgPgTransactionDetail.getMerchantId());
		nsdlStatusRequest.setOrderId(orderId);
		nsdlStatusRequest.setTerminalId(isgPgTransactionDetail.getAuthTerminalId());

		// logger.info("Enc Request ::
		// "+Utility.convertDTO2JsonString(nsdlStatusRequest));
		nsdlStatusResponseDecode = populateStatusResponse(nsdlStatusRequest, pgConfigurationDetails);

		// logger.info(Utility.convertDTO2JsonString(nsdlStatusResponseDecode));

		return nsdlStatusResponseDecode;
	}

	private NSDLStatusResponseDecode populateStatusResponse(NSDLStatusRequest nsdlStatusRequest,
			PGConfigurationDetails pgConfigurationDetails)
			throws JsonParseException, JsonMappingException, IOException {

		HttpResponse<NSDLStatusResponse> nsdlStatusResponse = Unirest.post(isgStatusEndPoint)
				.header("Content-Type", "application/json").body(nsdlStatusRequest).asObject(NSDLStatusResponse.class)
				.ifFailure(SetuErrorResponse.class, r -> {
					SetuErrorResponse e = r.getBody();
					try {
						logger.info("ISG Authentication Request Response Error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});

		// logger.info("Response :: " + nsdlStatusResponse.getBody());

		String decData = DataEncryptionDecryption.decrypt(nsdlStatusResponse.getBody().getEncData(),
				Encryption.decryptCardNumberOrExpOrCvv(pgConfigurationDetails.getPgSecret()));
		// logger.info("DecData :: " + decData);
		// logger.info("NSDLStatusResponseDecode ::
		// "+Utility.convertDTO2JsonString(nsdlStatusResponseDecode));
		return objectMapper.readValue(decData, NSDLStatusResponseDecode.class);
	}

	public Model updateTransactionStatus(IsgPgTransactionDetail isgPgTransactionDetail, String responseCode,
			String responseMessage, String paymentMode, String authResponse, Model model)
			throws JsonProcessingException, InvalidKeyException, NoSuchAlgorithmException {
		logger.info("Inside method updateTransactionStatus()");

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(isgPgTransactionDetail.getOrderId());

		transactionDetails.setStatus(responseCode);
		transactionDetails.setPgOrderID(isgPgTransactionDetail.getPgId());
		transactionDetails.setPaymentMode(paymentMode);
		transactionDetails.setTxtMsg(responseMessage);
		transactionDetails.setTxtPGTime(Utility.populateDbTime());

		transactionDetails.setSource("ReturnURL");

		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		// logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(authResponse, transactionDetails, "ReturnURL");

		try {

			isgPgTransactionDetail.setSource("ReturnURL");
			isgPgTransactionDetail.setAuthErrorMessage(responseMessage);
			isgPgTransactionDetail.setTransactionStatus(responseCode);
			isgPgTransactionDetail.setAuthErrorCode(responseCode);
			isgPgTransactionDetail.setAuthRes(authResponse);

			isgPgTransactionDetailRepo.save(isgPgTransactionDetail);

		} catch (Exception e) {
			logger.error("Exception in isgTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");

		transactionDetailsRepository.save(transactionDetails);

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	private void populateISGTransaction(NSDLAuthenticationRequest nsdlAuthenticationRequest,
			NSDLAuthenticationResponse nsdlAuthenticationResponse, String orderId) {

		IsgPgTransactionDetail sgPgTransactionDetail = isgPgTransactionDetailRepo
				.findByOrderId(nsdlAuthenticationRequest.getOrderId());
		if (sgPgTransactionDetail == null) {
			sgPgTransactionDetail = new IsgPgTransactionDetail();
			sgPgTransactionDetail.setAuthEncData(nsdlAuthenticationResponse.getEncData());
			sgPgTransactionDetail.setAuthErrorCode(nsdlAuthenticationResponse.getErrorCode());
			sgPgTransactionDetail.setAuthErrorMessage(nsdlAuthenticationResponse.getErrorMessage());
			sgPgTransactionDetail.setAuthTerminalId(nsdlAuthenticationResponse.getTerminalId());
			sgPgTransactionDetail.setBankId(nsdlAuthenticationResponse.getBankId());
			sgPgTransactionDetail.setMerchantId(nsdlAuthenticationResponse.getMerchantId());
			sgPgTransactionDetail.setOrderId(nsdlAuthenticationResponse.getOrderId());
			sgPgTransactionDetail.setPgId(nsdlAuthenticationResponse.getPgId());

		} else {

		}
		isgPgTransactionDetailRepo.save(sgPgTransactionDetail);

	}

	public Model ISGreturnUrlUPI(String orderId, Model model) throws Exception {

		NSDLStatusResponseDecode nsdlStatusResponseDecode = getUPIDBStatusDetails(orderId, true);

		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(orderId);

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);

		logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			// logger.info("merchantDetails " +
			// Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(Utility.convertDTO2JsonString(nsdlStatusResponseDecode),
				transactionDetails, "ReturnURL");

		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	@Autowired
	PGConfigurationDetailsRepository pgConfigurationDetailsRepository;

	public NSDLStatusResponseDecode getUPIDBStatusDetails(String orderId, boolean statusUpd) throws Exception {

		IsgPgTransactionDetail isgPgTransactionDetail = isgPgTransactionDetailRepo.findByOrderId(orderId);
		PGConfigurationDetails pgConfigurationDetails = pgConfigurationDetailsRepository
				.findByPgAppId(isgPgTransactionDetail.getMerchantId());
		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(orderId);

		NSDLStatusResponseDecode nsdlStatusResponseDecode = getUPIStatus(orderId, isgPgTransactionDetail,
				transactionDetails, pgConfigurationDetails);
		logger.info("isgStatusResponseDecode" + Utility.convertDTO2JsonString(nsdlStatusResponseDecode));
		if (nsdlStatusResponseDecode.getResponseMessage().contains("Pending")) {
			nsdlStatusResponseDecode.setStatus("PENDING");
		} else {
			if (nsdlStatusResponseDecode.getResponseCode().equals("00")) {
				nsdlStatusResponseDecode.setStatus("SUCCESS");
			} else {
				nsdlStatusResponseDecode.setStatus("FAILED");
			}
		}
		if (statusUpd) {

			transactionDetails.setStatus(nsdlStatusResponseDecode.getStatus());
			transactionDetails.setPgOrderID(isgPgTransactionDetail.getPgId());
			transactionDetails.setTxtMsg(nsdlStatusResponseDecode.getResponseMessage());
			transactionDetails.setTxtPGTime(Utility.populateDbTime());

			isgPgTransactionDetail.setStatusApiRes(Utility.convertDTO2JsonString(nsdlStatusResponseDecode));
			isgPgTransactionDetail.setApprovalCode(nsdlStatusResponseDecode.getAccessCode());
			isgPgTransactionDetail.setResponceCode(nsdlStatusResponseDecode.getResponseCode());
			isgPgTransactionDetail.setRetailerOrderId(nsdlStatusResponseDecode.getRetRefNo());

			transactionDetailsRepository.save(transactionDetails);
			isgPgTransactionDetailRepo.save(isgPgTransactionDetail);

		}

		return nsdlStatusResponseDecode;
	}
}
// {
// "timestamp": 1660931735792,
// "status": 401,
// "error": "Unauthorized",
// "message": "PreparedStatementCallback; bad SQL grammar [SELECT emailAddress,
// SUBSTR(password_,9), 1 FROM User_ WHERE emailAddress = ?]; nested exception
// is com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException: Table
// 'epmoney.User_' doesn't exist",
// "path": "/epMoney/oauth/token"
// }