package com.asktech.payment.util;

import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.paytm.pg.merchant.PaytmChecksum;

@Service
public class PaytmUtilityFunction {

	static Logger logger = LoggerFactory.getLogger(PaytmUtilityFunction.class);
	public boolean paytmCheckSum(MultiValueMap<String, String> request) throws Exception {
		
		TreeMap<String, String> paytmParams = new TreeMap<String, String>();
		String paytmChecksum = "";
		for (Entry<String, List<String>> entry : request.entrySet()) {
		    if ("CHECKSUMHASH".equalsIgnoreCase(entry.getKey())){
		        paytmChecksum = entry.getValue().get(0);
		    } else {
		        paytmParams.put(entry.getKey(), entry.getValue().get(0));
		    }
		}
		logger.info("Return CheckSUmPaytm :: "+paytmChecksum);
		logger.info("Signature Generation String ::"+paytmParams.toString());
		logger.info("Signatur Generate :: "+ PaytmChecksum.generateSignature(paytmParams.toString(), "c8gqC5m4Jec2F4Ay"));
		return PaytmChecksum.verifySignature(paytmParams.toString(), "c8gqC5m4Jec2F4Ay",paytmChecksum);
	}
	
	public static void main(String args[]) throws Exception {
		
		String params = "{BANKNAME=[ICICI Bank], BANKTXNID=[11394719457], CURRENCY=[INR], GATEWAYNAME=[ICICI], MID=[ANALYT91650664782798], ORDERID=[16299879258699], PAYMENTMODE=[NB], RESPCODE=[01], RESPMSG=[Txn Success], STATUS=[TXN_SUCCESS], TXNAMOUNT=[1.00], TXNDATE=[2021-08-26 19:55:26.0], TXNID=[20210826111212800110168507602928535]}";
		String paramsArray = "{BANKNAME=[ICICI Bank], BANKTXNID=[11394719457], CURRENCY=[INR], GATEWAYNAME=[ICICI], MID=[ANALYT91650664782798], ORDERID=[16299879258699], PAYMENTMODE=[NB], RESPCODE=[01], RESPMSG=[Txn Success], STATUS=[TXN_SUCCESS], TXNAMOUNT=[1.00], TXNDATE=[2021-08-26 19:55:26.0], TXNID=[20210826111212800110168507602928535]}";
		
		logger.info("Signatur Generate :: "+ PaytmChecksum.generateSignature(params, "c8gqC5m4Jec2F4Ay"));
		logger.info("Signatur Generate Array :: "+ PaytmChecksum.generateSignature(paramsArray, "c8gqC5m4Jec2F4Ay"));
	}
}
