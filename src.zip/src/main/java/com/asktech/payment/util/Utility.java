package com.asktech.payment.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Utility {
	private final static String LOCALHOST_IPV4 = "127.0.0.1";
	private final static String LOCALHOST_IPV6 = "0:0:0:0:0:0:0:1";
	static Logger logger = LoggerFactory.getLogger(Utility.class);

	// public static void main(String args[]){
	// getRandomPhn();
	// getRandomPhn();
	// getRandomPhn();
	// getRandomPhn();
	// getRandomPhn();
	// getRandomPhn();
	// }

	public static String getRandomPhn() {
		Random random = new Random();
		String phoneNumber = String.format("%d%09d",
				random.nextInt(9 - 5) + 5, random.nextInt(1000000000));
		System.out.println("Phone Number =  " + phoneNumber);
		return phoneNumber;

	}
	public static boolean checkIfTimePassed(String val, long compareTime) {
		// logger.info("TIME::" + String.valueOf(val));
		long dt = (Long.parseLong(val) / 1000);
		long curtime = Instant.now().getEpochSecond();
		// logger.info("DT::" + String.valueOf(dt) + "|curtime::" + String.valueOf(curtime));
		if (curtime - dt > compareTime) {

			logger.info("TRUE:" + String.valueOf(curtime - dt));
			return true;
		}
		return false;
	}

	public static String encodeBase64(String originalInput) {
		return new String(Base64.encodeBase64(originalInput.getBytes()));
	}

	public static String decodeBase64(String originalInput) {
		return new String(Base64.decodeBase64(originalInput.getBytes()));
	}

	public static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	public static String exceptionToString(Exception e) {
		StringWriter errors = new StringWriter();
		e.printStackTrace(new PrintWriter(errors));
		return errors.toString();
	}

	public static Instant getTimestamp() {

		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		Instant instant = timestamp.toInstant();

		return instant;
	}

	public static String convertDTO2JsonString(Object json) throws JsonProcessingException {
		ObjectMapper Obj = new ObjectMapper();
		String jsonStr = Obj.writeValueAsString(json);
		return jsonStr;

	}

	public static boolean validateBalance(int fromBalabce, int toBalance) {

		if (fromBalabce >= toBalance) {
			return true;
		}

		return false;
	}

	public static Long getEpochTIme() throws ParseException {
		Date today = Calendar.getInstance().getTime();
		SimpleDateFormat crunchifyFormat = new SimpleDateFormat("MMM dd yyyy HH:mm:ss.SSS zzz");
		String currentTime = crunchifyFormat.format(today);
		Date date = crunchifyFormat.parse(currentTime);
		long epochTime = date.getTime();
		return epochTime;
	}

	public static String beautifyJson(String strJson) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		String prettyStaff1 = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(strJson);
		return null;
	}

	public static String getJsonFileCreate(JSONObject jsonObject, String requestType, String folderName)
			throws ParseException {

		// JSONObject jsonObject = new JSONObject(jsonStr);
		String fileName = requestType + "_" + getEpochTIme() + ".json";
		System.out.println("File Name :: " + fileName);
		try (FileWriter file = new FileWriter(folderName + fileName)) {

			file.write(jsonObject.toString());
			file.flush();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return fileName;
	}

	public static String createFlatFiles(String strValue, String folderName, String fileName) throws ParseException {
		try {
			fileName = fileName + "_" + getEpochTIme() + ".txt";

			Files.write(Paths.get(fileName), strValue.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;
	}

	private static int inc = 0;

	public static long getMerchantsID() {
		// 12 digits.

		long id = Long.parseLong(String.valueOf(System.currentTimeMillis()).substring(1, 13));
		inc = (inc + 1) % 10;
		return id;
	}

	public static String generateAppId() {

		UUID uuid = UUID.randomUUID();
		String uuidAsString = uuid.toString().replace("-", "");

		return uuidAsString;
	}

	public static String convertDatetoMySqlDateFormat(String dateIn) throws ParseException {

		DateFormat originalFormat = new SimpleDateFormat("dd-MM-yyyy");
		DateFormat targetFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = originalFormat.parse(dateIn);
		String formattedDate = targetFormat.format(date);

		return formattedDate;
	}

	public static Integer randomNumberForOtp(int sizeOfOtp) {

		int rand = (new Random()).nextInt(90000000) + 10000000;
		return rand;
	}

	public static String getAmountConversion(String amount) {

		return String.format("%.2f", Double.parseDouble(amount) / 100);

	}

	public static String populateSetuId() throws ParseException {
		return "AN-" + getEpochTIme();
	}

	public static String populateDbTime() {
		Date date = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String strDate = dateFormat.format(date);
		return strDate;
	}

	public static String populateDateFormat(String dtFormat) {
		Date date = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat(dtFormat);
		return dateFormat.format(date);
	}

	public static String updateTimeForResponse(String dateValue) {
		return dateValue.substring(0, dateValue.indexOf("."));
	}

	public static String maskCardNumber(String cardNumber) {
		// logger.info("maskCardNumber() :: "+cardNumber);
		if (cardNumber == null || StringUtils.isEmpty(cardNumber)) {
			// logger.info("Inside Null check Block maskCardNumber() :: "+cardNumber);
			return "";
		}
		StringBuilder maskedNumber = new StringBuilder();

		for (int i = 0; i < cardNumber.length(); i++) {
			if (i < cardNumber.length() - 4) {
				maskedNumber.append("X");
			} else {
				maskedNumber.append(cardNumber.charAt(i));
			}
		}

		return maskedNumber.toString();
	}

	public static String deviceType(String useragent) {
		if (useragent.matches(
				"(?i).*((android|bb\\d+|meego).+mobile|avantgo|bada\\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\\.(browser|link)|vodafone|wap|windows ce|xda|xiino).*")
				|| useragent.substring(0, 4).matches(
						"(?i)1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\\-(n|u)|c55\\/|capi|ccwa|cdm\\-|cell|chtm|cldc|cmd\\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\\-s|devi|dica|dmob|do(c|p)o|ds(12|\\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\\-|_)|g1 u|g560|gene|gf\\-5|g\\-mo|go(\\.w|od)|gr(ad|un)|haie|hcit|hd\\-(m|p|t)|hei\\-|hi(pt|ta)|hp( i|ip)|hs\\-c|ht(c(\\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\\-(20|go|ma)|i230|iac( |\\-|\\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\\/)|klon|kpt |kwc\\-|kyo(c|k)|le(no|xi)|lg( g|\\/(k|l|u)|50|54|\\-[a-w])|libw|lynx|m1\\-w|m3ga|m50\\/|ma(te|ui|xo)|mc(01|21|ca)|m\\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\\-2|po(ck|rt|se)|prox|psio|pt\\-g|qa\\-a|qc(07|12|21|32|60|\\-[2-7]|i\\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\\-|oo|p\\-)|sdk\\/|se(c(\\-|0|1)|47|mc|nd|ri)|sgh\\-|shar|sie(\\-|m)|sk\\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\\-|v\\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\\-|tdg\\-|tel(i|m)|tim\\-|t\\-mo|to(pl|sh)|ts(70|m\\-|m3|m5)|tx\\-9|up(\\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\\-|your|zeto|zte\\-")) {
			return "mobile";
		} else {
			return "desktop";
		}
	}

	public static String maskUpiCode(String upiCode) {
		if (upiCode == null || StringUtils.isEmpty(upiCode)) {
			return "";
		}
		return upiCode.substring(0, upiCode.lastIndexOf("@")).replaceAll("\\S", "*")
				+ upiCode.substring(upiCode.lastIndexOf("@"));
	}

	// public static void main(String args[]) throws ParseException {
	// HttpResponse<String> response = Unirest
	// .post("https://api.rmdigitalmarketing.co.in/adm/merchantApi/transactionStatusWithOrderId")
	// .multiPartContent()
	// .field("appId", "3d24456af6e34dda917e5c0094f9d059")
	// .field("secret",
	// "63eeb04e3e56c1ce287c393b4f284fef5218acaa7f31859d6baa79a14ea64aaf")
	// .field("orderId", "8195391776461814")
	// .asString();

	// System.out.println(response.getBody());
	// }
	public static String getUpiString(String vpa, String personName, String trxid, String providerTrxId,
			String transactionNote, String amount,
			String referenceUrl) {

		String upiUrl = "upi://pay?pa=" + vpa + "&pn=" + personName + "&mc=0000&tid=" + trxid + "&tr=" + providerTrxId
				+ "&tn=" + transactionNote
				+ "&am=" + amount
				+ "&mam=null&cu=INR";
		if (referenceUrl != null) {
			upiUrl = upiUrl + "&url=" + referenceUrl;
		}
		return upiUrl;
	}


	public static String getClientIp(HttpServletRequest request) {
		String ipAddress = request.getHeader("X-Forwarded-For");
		if (ipAddress == null) {
			ipAddress = request.getRemoteAddr();
		}
		if (!StringUtils.hasLength(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("Proxy-Client-IP");
		}

		if (!StringUtils.hasLength(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("WL-Proxy-Client-IP");
		}

		if (!StringUtils.hasLength(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getRemoteAddr();
			if (LOCALHOST_IPV4.equals(ipAddress) || LOCALHOST_IPV6.equals(ipAddress)) {
				try {
					InetAddress inetAddress = InetAddress.getLocalHost();
					ipAddress = inetAddress.getHostAddress();
				} catch (UnknownHostException e) {
					e.printStackTrace();
				}
			}
		}
		if (ipAddress != null) {
			if (!StringUtils.hasLength(ipAddress) && ipAddress.length() > 15 && ipAddress.indexOf(",") > 0) {
				ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
			}
		}

		return ipAddress;
	}

	public static JSONObject convertJsonStrTOJsonObject(String stringToParse)
			throws org.json.simple.parser.ParseException {
		JSONParser parser = new JSONParser();
		return (JSONObject) parser.parse(stringToParse);
	}

	public static boolean inArray(String[] arr, String val) {
		return Arrays.stream(arr).anyMatch(val::equals);

	}

}
