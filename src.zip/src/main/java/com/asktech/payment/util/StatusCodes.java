package com.asktech.payment.util;

import com.asktech.payment.model.PgErrorCodes;
import com.asktech.payment.repository.PgErrorCodeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StatusCodes {
    @Autowired
    PgErrorCodeRepository errorCodeRepository;

    public String checkStatus(String pg, String errorCode) {
        PgErrorCodes err = errorCodeRepository.findByPgNameAndPgStatusCode(pg, errorCode);
        if (err != null) {
            return err.getResponseStatus();
        }
        return null;
    }
}
