package com.asktech.payment.util.razorPay;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.util.Base64;

import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.razorPay.Card;
import com.asktech.payment.dto.razorPay.OrderCreateRequest;
import com.asktech.payment.dto.razorPay.OrderCreateResponse;
import com.asktech.payment.dto.razorPay.PaymentPageRequest;
import com.asktech.payment.dto.razorPay.RazorPayments;
import com.asktech.payment.dto.setu.SetuErrorResponse;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.RazorPayTransactionDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.PgErrorCodeRepository;
import com.asktech.payment.repository.RazorPayTransactionDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.StatusCodes;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class RazorPayPaymentUtility implements CashFreeFields {

	static Logger logger = LoggerFactory.getLogger(RazorPayPaymentUtility.class);

	@Value("${pgEndPoints.razorPayOrderCreate}")
	String razorPayOrderCreate;
	@Value("${pgEndPoints.razorPayPaymentPage}")
	String razorPayPaymentPage;
	@Value("${pgEndPoints.razorPayReturnURL}")
	String razorPayReturnURL;

	@Autowired
	RazorPayTransactionDetailsRepository razorPayTransactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletListRepository walletListRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;

	public Model processRazorPayRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId, String ipAddress) throws IOException, ParseException {

		String authenticationKey = populateRazorPayAuth(merchantPGDetails.getMerchantPGAppId(),
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));

		OrderCreateResponse orderCreateResponse = createOrder(formData.get(ORDERAMOUNT).get(0), orderId,
				authenticationKey);
		logger.info("orderCreateResponse.getStatus() :: " + orderCreateResponse.getStatus());

		if (orderCreateResponse.getStatus().equalsIgnoreCase("CREATED")) {
 
			PaymentPageRequest paymentPageRequest = new PaymentPageRequest();
			String paymentHtml = "";
			paymentPageRequest.setAmount(Integer.parseInt(formData.get(ORDERAMOUNT).get(0)));
			String returnUrl = pgGatewayUtilService.getReturnUrl(razorPayReturnURL,
					merchantPGDetails.getMerchantID(), formData.get(PAYMENT_OPTION).get(0));
			paymentPageRequest.setCallbackUrl(returnUrl);
			paymentPageRequest.setContact(formData.get(CUSTOMERPHONE).get(0));
			paymentPageRequest.setCurrency("INR");
			paymentPageRequest.setEmail(formData.get(CUSTOMEREMAIL).get(0));
			paymentPageRequest.setIp(ipAddress);
			paymentPageRequest.setOrder_id(orderCreateResponse.getId());
			paymentPageRequest.setCustomerName(formData.get(CUSOMERNAME).get(0));
			paymentPageRequest.setUserAgent(
					"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36");
			populateTransactionDetails(paymentPageRequest, paymentHtml, formData, orderId);
			return RazorPayNonSeamlessRequest(model, merchantPGDetails, orderId, paymentPageRequest);
			// if
			// (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI))
			// {
			// paymentHtml = generateUPIRequest(paymentPageRequest, formData,
			// merchantPGDetails, orderId);
			// } else if
			// (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.NETBANKING))
			// {
			// paymentHtml = generateNBRequest(paymentPageRequest, formData,
			// merchantPGDetails, orderId);
			// } else if
			// (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.WALLET))
			// {
			// paymentHtml = generateWalletRequest(paymentPageRequest, formData,
			// merchantPGDetails, orderId);
			// } else if
			// (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.CARD))
			// {
			// paymentHtml = generateCardRequest(paymentPageRequest, formData,
			// merchantPGDetails, orderId);
			// }

			// populateTransactionDetails(paymentPageRequest, paymentHtml, formData,
			// orderId);

			// logger.info("paymentHtml :: " + paymentHtml);
			// model.addAttribute("html", paymentHtml);

		}
		return model;
	}

	private Model RazorPayNonSeamlessRequest(Model model,
			MerchantPGDetails merchantPGDetails, String orderId, PaymentPageRequest paymentPageRequest) {
		model.addAttribute("pgkey", merchantPGDetails.getMerchantPGAppId());
		model.addAttribute("amt", paymentPageRequest.getAmount());
		model.addAttribute("name", "Comapany");
		model.addAttribute("orderid", paymentPageRequest.getOrder_id());
		model.addAttribute("callback", paymentPageRequest.getCallbackUrl());
		model.addAttribute("custname", paymentPageRequest.getCustomerName());
		model.addAttribute("custemail", paymentPageRequest.getEmail());
		model.addAttribute("custphn", paymentPageRequest.getContact());
		return model;

	}

	private RazorPayTransactionDetails getTransactionDetails(String razorPayOrderId) {

		return razorPayTransactionDetailsRepository.findByRazorPayOrderId(razorPayOrderId);
	}

	private void populateTransactionDetails(PaymentPageRequest paymentPageRequest, String generatedHtml,
			MultiValueMap<String, String> formData, String orderId) {
		RazorPayTransactionDetails razorPayTransactionDetails = new RazorPayTransactionDetails();

		razorPayTransactionDetails.setAmount(String.valueOf(paymentPageRequest.getAmount()));
		razorPayTransactionDetails.setGeneratedHtml(generatedHtml);
		razorPayTransactionDetails.setMerchantId(formData.get(ORDERID).get(0));
		razorPayTransactionDetails.setOrderId(orderId);
		razorPayTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		razorPayTransactionDetails.setRazorPayOrderId(paymentPageRequest.getOrder_id());
		razorPayTransactionDetails.setSource("TRInitiate");
		razorPayTransactionDetails.setStatus(UserStatus.PENDING.toString());
		razorPayTransactionDetailsRepository.save(razorPayTransactionDetails);
	}

	private String generateCardRequest(PaymentPageRequest paymentPageRequest, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) throws JsonProcessingException {

		Card card = new Card();
		card.setCvv(Integer.parseInt(formData.get(CARD_CVV).get(0)));
		card.setExpiry_month(Integer.parseInt(formData.get(CARD_EXPMONTH).get(0)));
		card.setExpiry_year(Integer.parseInt(formData.get(CARD_EXPYEAR).get(0)));
		card.setName(formData.get(CARD_HOLDER).get(0));
		card.setNumber(formData.get(CARD_NUMBER).get(0));

		paymentPageRequest.setCard(card);
		paymentPageRequest.setMethod("card");

		return generatePaymentPage(paymentPageRequest, merchantPGDetails);
	}

	private String generateWalletRequest(PaymentPageRequest paymentPageRequest, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) throws JsonProcessingException {

		WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		paymentPageRequest.setWallet(walletList.getPaymentcodepg());
		paymentPageRequest.setMethod("wallet");

		WalletPaymentDetails walletPaymentDetails = new WalletPaymentDetails();

		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		walletPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		walletPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		walletPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		walletPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		walletPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		walletPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		logger.info("Wallet walletPaymentDetails::" + Utility.convertDTO2JsonString(walletPaymentDetails));
		walletPaymentDetailsRepository.save(walletPaymentDetails);

		return generatePaymentPage(paymentPageRequest, merchantPGDetails);
	}

	private String generateUPIRequest(PaymentPageRequest paymentPageRequest, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) throws JsonProcessingException {

		paymentPageRequest.setVpa(formData.get(UPI_VPI).get(0));
		paymentPageRequest.setMethod("upi");

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return generatePaymentPage(paymentPageRequest, merchantPGDetails);
	}

	private String generateNBRequest(PaymentPageRequest paymentPageRequest, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) throws JsonProcessingException {

		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(),
				UserStatus.ACTIVE.toString(), merchantPGDetails.getMerchantPGName());

		paymentPageRequest.setBank(bankList.getPgBankCode());
		paymentPageRequest.setMethod("netbanking");

		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		logger.info("Bank nbPaymentDetails::" + Utility.convertDTO2JsonString(nbPaymentDetails));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return generatePaymentPage(paymentPageRequest, merchantPGDetails);
	}

	private OrderCreateResponse createOrder(String amount, String orderId, String authKey)
			throws JsonProcessingException {

		OrderCreateRequest orderCreateRequest = new OrderCreateRequest();
		orderCreateRequest.setAmount(Integer.parseInt(amount));
		orderCreateRequest.setCurrency("INR");
		orderCreateRequest.setPartial_payment(false);
		orderCreateRequest.setReceipt(orderId);

		HttpResponse<OrderCreateResponse> razorPayOrderResponse = Unirest.post(razorPayOrderCreate)
				.header("Content-Type", "application/json").header("Authorization", "Basic " + authKey)
				.header("Accept", "application/json").body(Utility.convertDTO2JsonString(orderCreateRequest))
				.asObject(OrderCreateResponse.class).ifFailure(SetuErrorResponse.class, r -> {
					SetuErrorResponse e = r.getBody();
					try {
						logger.info("RazorPay Order Create Response Error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});

		logger.debug("Order Response :: " + Utility.convertDTO2JsonString(razorPayOrderResponse.getBody()));

		return razorPayOrderResponse.getBody();
	}

	private String generatePaymentPage(PaymentPageRequest paymentPageRequest, MerchantPGDetails merchantPGDetails)
			throws JsonProcessingException {

		HttpResponse<String> razorPaymentPageResponse = Unirest.post(razorPayPaymentPage)
				.header("Content-Type", "application/json")
				.header("Authorization",
						"Basic " + populateRazorPayAuth(merchantPGDetails.getMerchantPGAppId(),
								Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret())))
				.header("Accept", "application/json").body(Utility.convertDTO2JsonString(paymentPageRequest)).asString()
				.ifFailure(SetuErrorResponse.class, r -> {
					SetuErrorResponse e = r.getBody();
					try {
						logger.info("RazorPay Order Create Response Error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});

		return razorPaymentPageResponse.getBody();
	}

	private String populateRazorPayAuth(String mid, String secretKey) {

		String authStr = mid + ":" + secretKey;
		byte[] bytesEncoded = Base64.getEncoder().encode(authStr.getBytes());
		String generatedAuth = new String(bytesEncoded);

		logger.debug("generatedAuth :: " + generatedAuth);
		return generatedAuth;

	}

	private boolean signatureValidation(String data, String secret, String razorPaySignature)
			throws SignatureException {

		String generated_signature = Signature.calculateRFC2104HMAC(data, secret);
		logger.info("generated_signature :: " + generated_signature);
		if (generated_signature.equalsIgnoreCase(generated_signature)) {
			return true;
		}

		return false;
	}

	@Autowired
	PgErrorCodeRepository pgErrorCodeRepository;

	public String updateTransactionStatus(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException, SignatureException {

		logger.info("Inside method updateTransactionStatus()");
		logger.info("Response Form Data::" + GeneralUtils.MultiValueMaptoJson(responseFormData));
		String razorPayOrderId = "";
		String razorPayPaymentId = "";
		// responseFormData.forEach(
		// (String key, List<String> list) -> {
		// list.forEach(item -> System.out.println(key + "::" + item));
		// });
		// System.out.println(responseFormData.get("error[code]").get(0));
		String txtdata = "Transaction Successful";
		String status = "SUCCESS";
		if (responseFormData.containsKey("error[code]")) {
			txtdata = responseFormData.get("error[description]").get(0);
			String reason = responseFormData.get("error[reason]").get(0);
			String resStatus = null;
			resStatus = checkRazorStatus("failed", reason);
			if (resStatus != null) {
				status = resStatus;
			}
			JSONObject meta = new JSONObject(responseFormData.get("error[metadata]").get(0));
			razorPayOrderId = meta.getString("order_id");
			razorPayPaymentId = meta.getString("payment_id");
			logger.info("RazorPay txtdata::" + txtdata + "|" + "status::" + status + "|" + "razorPayOrderId::"
					+ razorPayOrderId + "|razorPayPaymentId::" + razorPayPaymentId);
		} else {
			razorPayOrderId = pgGatewayUtilService.checkResponseData(responseFormData, "razorpay_order_id");
			razorPayPaymentId = pgGatewayUtilService.checkResponseData(responseFormData, "razorpay_payment_id");

		}
		RazorPayTransactionDetails razorPayTransactionDetails = getTransactionDetails(razorPayOrderId);
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(razorPayTransactionDetails.getOrderId());
		MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository
				.findByMerchantIDAndMerchantPGId(transactionDetails.getMerchantId(), transactionDetails.getPgId());

		if (razorPayTransactionDetails != null) {

			if (signatureValidation(razorPayOrderId + "|" + razorPayPaymentId,
					Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()),
					pgGatewayUtilService.checkResponseData(responseFormData, "razorpay_signature"))) {
				transactionDetails.setStatus(status);
				transactionDetails.setTxtMsg(txtdata);

			} else {
				logger.info("The return signature not verified ...");
				transactionDetails.setStatus(UserStatus.FAILED.toString());
				String rz = getOrderStatus(merchantPGDetails, razorPayTransactionDetails.getRazorPayOrderId());
				if (rz != null) {
					transactionDetails.setStatus(rz);
				}

			}

			transactionDetails.setPgOrderID(razorPayTransactionDetails.getRazorPayOrderId());
			transactionDetails.setPaymentMode(razorPayTransactionDetails.getPaymentMode());
			// transactionDetails.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData,
			// RESP_TXMSG));
			transactionDetails.setTxtPGTime(Utility.populateDbTime());

			transactionDetails.setSource("ReturnURL");
			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsRepository.save(transactionDetails);

			logger.info("Transaction Update");

			logger.info("Get User Details::" + transactionDetails.getUserID());
			UserDetails userDetails = null;
			try {
				userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
				logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
			} catch (Exception e) {
				logger.info("Unable to get Data" + e.getMessage());
				e.printStackTrace();
			}
			MerchantDetails merchantDetails = null;
			try {
				merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
				logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
			} catch (Exception e) {
				e.printStackTrace();
				logger.info("Unable to get Data" + e.getMessage());
			}
			if (merchantDetails != null) {
				if (!merchantDetails.getTr_mail_flag().isEmpty()) {
					logger.info("merchantDetails getTr_mail_flag not empty");
					if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
						logger.info("merchantDetails getTr_mail_flag Y");
						pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createMerchantEmail(userDetails,
								transactionDetails, merchantDetails), merchantDetails.getMerchantEMail(),
								"MerchantEmail");
						logger.info("createMailRepo Complete");
					}
				}
			}
			logger.info("createMailRepo 2");
			pgGatewayUtilService.createMailRepo(
					pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails), userDetails.getEmailId(),
					"CustomerEmail");
			logger.info("createMailRepo Email Complete");
			logger.info("Send SMS Start");
			pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
			logger.info("Send SMS End");

			pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");
			logger.info("populatePgResponseinDB");

			razorPayTransactionDetails
					.setSignature(pgGatewayUtilService.checkResponseData(responseFormData, "razorpay_signature"));
			razorPayTransactionDetails.setRazorPayPaymentId(razorPayPaymentId);
			razorPayTransactionDetails.setStatus(status);
			razorPayTransactionDetails.setSource("ReturnURL");

			razorPayTransactionDetailsRepository.save(razorPayTransactionDetails);

			logger.info("End method updateTransactionStatus()");

			return razorPayTransactionDetails.getOrderId();
		}

		return null;
	}

	public Model getResponseProcess(String orderid, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(orderid);

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	private String getOrderStatus(MerchantPGDetails pgConfigurationDetails, String orderId)
			throws JsonProcessingException {
		logger.info("Running getOrderStatus::" + orderId);
		// String razOrderId =
		// razorPayTransactionDetailsRepository.findByOrderId(orderId).getRazorPayOrderId();
		String razOrderId = orderId;
		logger.info("RazorPay ORDER ID::" + razOrderId);
		// getOrderStatusTest(pgConfigurationDetails, razOrderId);
		HttpResponse<RazorPayments> razorPayOrderResponse = Unirest
				.get("https://api.razorpay.com/v1/orders/" + razOrderId + "/payments")
				.header("Content-Type", "application/json")
				.header("Authorization",
						"Basic " + populateRazorPayAuth(pgConfigurationDetails.getMerchantPGAppId(),
								Encryption.decryptCardNumberOrExpOrCvv(pgConfigurationDetails.getMerchantPGSecret())))
				.header("Accept", "application/json").asObject(RazorPayments.class)
				.ifFailure(SetuErrorResponse.class, r -> {
					SetuErrorResponse e = r.getBody();
					try {
						logger.info("RazorPay Order Create Response Error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});

		logger.debug("Order Response :: " + Utility.convertDTO2JsonString(razorPayOrderResponse.getBody()));
		RazorPayments orders = razorPayOrderResponse.getBody();
		if (orders.getItems().size() > 0) {
			return checkRazorStatus(orders.getItems().get(0).getStatus(), orders.getItems().get(0).getError_reason());
		}
		return null;
	}

	@Autowired
	StatusCodes statusCodes;

	private String checkRazorStatus(String status, String reason) {
		if (status.equalsIgnoreCase("captured")) {
			return UserStatus.SUCCESS.toString();
		}
		if (status.equalsIgnoreCase("authorized") || status.equalsIgnoreCase("created")) {
			return UserStatus.PENDING.toString();
		}
		if (status.equalsIgnoreCase("failed")) {
			String sta = statusCodes.checkStatus("RAZORPAY", reason);
			if (sta != null) {
				return sta;
			} else {
				return UserStatus.FAILED.toString();
			}
		}
		if (status.equalsIgnoreCase("refunded")) {
			return UserStatus.REFUNDED.toString();
		}
		return status;
	}
	/*
	 * public static void main(String args[]) throws JsonProcessingException,
	 * SignatureException, RazorpayException {
	 * 
	 * getOrder("order_J53jLOKxNjl9M");
	 * 
	 * }
	 */

}
