package com.asktech.payment.util.isgpg;

import org.springframework.stereotype.Component;

@Component
public class IsgPgChecksum {
    
}
