package com.asktech.payment.util.neoCred.neoCredDto;

public class CreateVaResponse {
    
}
