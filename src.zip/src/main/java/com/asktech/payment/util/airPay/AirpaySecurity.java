package com.asktech.payment.util.airPay;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.asktech.payment.security.Encryption;

public class AirpaySecurity {

	public static String getPrivateKey(String secret, String userName, String password)
			throws NoSuchAlgorithmException {

		String sTemp = secret + "@" + userName + ":|:" + password;

		try {
			MessageDigest md1 = MessageDigest.getInstance("SHA-256");
			md1.update(sTemp.getBytes());
			byte byteData[] = md1.digest();
			StringBuffer sb1 = new StringBuffer();
			for (int i = 0; i < byteData.length; i++) {
				sb1.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
			}
			return sb1.toString();
		} catch (Exception e) {
			return null;
		}

	}

	public static String keySha256(String data) {

		try {
			MessageDigest md1 = MessageDigest.getInstance("SHA-256");
			md1.update(data.getBytes());
			byte byteData[] = md1.digest();
			StringBuffer sb1 = new StringBuffer();
			for (int i = 0; i < byteData.length; i++) {
				sb1.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
			}
			return sb1.toString();
		} catch (Exception e) {
			return null;
		}
	}

	public static String generateCheckSum(String sAllData, String keyValue) {

		String data = sAllData + "@" + keyValue;
		System.out.println("aAllData::" + data);
		return Encryption.getSHA256Hash(data);
		// try {
		// MessageDigest md1 = MessageDigest.getInstance("SHA-256");
		// md1.update(data.getBytes());
		// byte byteData[] = md1.digest();
		// StringBuffer sb1 = new StringBuffer();
		// for (int i = 0; i < byteData.length; i++) {
		// sb1.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
		// }
		// return sb1.toString();
		// } catch (Exception e) {
		// return null;
		// }
	}

	public static void main(String[] args){
		getChecksum("2117600","h89ZHxqw", "pankaj@gmail.com", "Pankaj", "Pankaj", "10.00", "1658233381113442B6149393", "11c8164f4780477111a7522cd9837950");
	}

	public static String getOrderChecksum(String username, String password, String mercid,String merchant_txnId, String airpayId){
		Date myDate = new Date();
		SimpleDateFormat sm = new SimpleDateFormat("YYYY-MM-d");
		String alldata = mercid+merchant_txnId+airpayId+sm.format(myDate);
		String salt = Encryption.getSHA256Hash((username+"~:~"+password)).toLowerCase();
		String dt = salt+"@"+alldata;
		return Encryption.getSHA256Hash(dt).toLowerCase();
	}
	public static String getChecksum(String username, String password, String buyerEmail,String buyerFirstName,String buyerLastName, String amount, String orderid, String uid) {
		String buyerAddress = "";

		String buyerCity = "";

		String buyerState = "";

		String buyerCountry = "";




		Date myDate = new Date();
		SimpleDateFormat sm = new SimpleDateFormat("YYYY-MM-d");
		String salt = Encryption.getSHA256Hash((username+"~:~"+password)).toLowerCase();
		System.out.println("ADT::"+salt);
		String alldata = buyerEmail+buyerFirstName+buyerLastName+buyerAddress+buyerCity+buyerState+buyerCountry+amount+orderid+uid+sm.format(myDate);
		System.out.println("ADT::"+alldata);
		String dt = salt+"@"+alldata;
		System.out.println("ADT::"+dt);
		String checksum = Encryption.getSHA256Hash(dt).toLowerCase();
		System.out.println("ADT::"+checksum);
	

		return checksum;
	}
}
/*
 * public static String generateCheckSum(String sAllData) {
 * try {
 * MessageDigest md = MessageDigest.getInstance("MD5");
 * byte[] array = md.digest(sAllData.getBytes());
 * StringBuffer sb = new StringBuffer();
 * for (int i = 0; i < array.length; ++i) {
 * sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
 * }
 * return sb.toString();
 * } catch (Exception e) {
 * return null;
 * }
 * 
 * }
 */
