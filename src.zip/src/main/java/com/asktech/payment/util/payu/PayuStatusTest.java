package com.asktech.payment.util.payu;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

public class PayuStatusTest {
	String COMMAND_VERIFY = "verify_payment";
	static String COMMAND = "";

	public static void main(String[] args) {
		try {
			callPayUStatusapi("uzPEZ8L1FglMugvowbyz2712eeSsvOa6", "cuo5bC", "1660985678318146CE677091");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String callPayUStatusapi(String saltKey, String secret, String orderId)
			throws IOException {

		String requestData = "key=" + secret
				+ "&command=" + "verify_payment" +
				"&var1=" + orderId + "&hash=" + getHashesResponse(orderId, saltKey, secret);

		HttpResponse<String> payUResponse = Unirest.post("https://info.payu.in/merchant/postservice.php?form=2")
				.header("Content-Type", "application/x-www-form-urlencoded")
				.body(requestData).asString();
		System.out.println(payUResponse.getBody());
		return payUResponse.getBody();
	}

	public static String getHashesResponse(String txnid, String salt, String key) {

		String ph = key + "|" + "verify_payment" + "|" + checkNull(txnid) + "|" + salt;
		System.out.println("Payment Hash " + ph);
		String statusHash = getSHA(ph);
		System.out.println("Payment Hash " + statusHash);

		return statusHash;
	}

	private static String checkNull(String value) {
		if (value == null) {
			return "";
		} else {
			return value;
		}
	}

	private static String getSHA(String str) {

		MessageDigest md;
		String out = "";
		try {
			md = MessageDigest.getInstance("SHA-512");
			md.update(str.getBytes());
			byte[] mb = md.digest();

			for (int i = 0; i < mb.length; i++) {
				byte temp = mb[i];
				String s = Integer.toHexString(new Byte(temp));
				while (s.length() < 2) {
					s = "0" + s;
				}
				s = s.substring(s.length() - 2);
				out += s;
			}

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return out;

	}
}
