package com.asktech.payment.util.payaid;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(indexes = {
        @Index(columnList = "orderId"),
        // @Index(columnList = "pgOrderId")
})
public class PayAidModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @Column(length = 50)
    private String merchantId;
    @Column(length = 50, unique = true)
    private String orderId;
    @Column(length = 100)
    private String pgOrderId;
    @Column(length = 100)
    private String pgTransId;
    @Column(length = 100)
    private String pgCustId;
    @Column(length = 100)
    private String accessKey;
    @Column(length = 300)
    private String accessSecret;
    @Column(length = 100)
    private String trxType;
    @Column(columnDefinition = "LONGTEXT")
    private String paymentResponse;
    @Column(columnDefinition = "LONGTEXT")
    private String statusResponse;

}
