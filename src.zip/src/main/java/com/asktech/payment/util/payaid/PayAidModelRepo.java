package com.asktech.payment.util.payaid;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PayAidModelRepo extends JpaRepository<PayAidModel, String> {
    PayAidModel findByOrderId(String orderId);
}
