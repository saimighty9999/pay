package com.asktech.payment.util.payu;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constant.payu.PayUConstants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.payu.CardValidateResponse;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.OnePayTransactionDetails;
import com.asktech.payment.model.PayUTransactionDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.TransactionDetailsAll;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.PayUTransactionDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class PayUPaymentUtility implements CashFreeFields, PayUConstants {

	@Value("${pgEndPoints.payuSeamLess}")
	String payuSeamLess;
	@Value("${pgEndPoints.payuReturnURL}")
	String payuReturnURL;
	@Value("${payu.productInfo}")
	String productInfo;
	@Value("${payu.commandCardValidate}")
	String commandCardValidate;

	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	PayUTransactionDetailsRepository payUTransactionDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletListRepository walletListRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;

	static Logger logger = LoggerFactory.getLogger(PayUPaymentUtility.class);

	/*
	 * public static void main(String args[]) {
	 * getHashes("12312312131212", "1.00", "iPhone", "antara",
	 * "antara4uonly@gmail.com", null, null, null, null, null,
	 * "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDQlra0TRRBOktHzpr+IIb6P231q+IIm73zFo7JcOQHusd7Ehksr5iU2kcfEEyQHba7k6uFPfq1LYMRhsNShjY8d3/uWvaz/mwBV27RE0ZaCl0XzfJ0ZGQQ5bnwfizX0+QqyFlTXCqzW7Pi2t7a/JvssJNXE6UUKyaafZljVj5RLEjjUzPHt6yziHXX3ItxRKZHmq8JkK2YIO0SLxFxUXqNm97vEi+OV2vUbn6481jB5Umm63Q4jnYmBijj+0w3mQc7d0Mz4pem7lzUQFLJPveaur4OH8Yyu3mYut2P2BcivklQBOdOzwGSTo1/OftXQb4v8DdsMIEfmhTXoIgMp/JXAgMBAAECggEAO4yrgHH49F5GG6v6R87VeiAdrmNx1m9QHVQ1U4EtOJ+0T4htM3q2HtjqMQ4gLYyuHIMeFp4JMyxZHOnSXX7/gOfE2DGT+PMLtp5Vfs736MDIrwEW1O/MOZ68JNKAzuUpYKVuCwRnFGl7w6oksXQot7v5dIShPk7LaJOu9NMsW1O7SZp1cnPw8YOmMBwNGZL75NfiAoKTeGtKDZRfFGeNMCt3utKWjPOnnIitHAPfgWJecPeKHKAJ1MqwpWspk91yOLtAQSUMMla+564mXoioGh5Ok8+/RShqkmFG0uZkiNeBcdqAoqtDLyqFaZQvPbFPDm37nPuK0HwcJuE3//9fQQKBgQDsNDl/gyO02/jvlBjjQG6aH+5Jmgx1IrC0Rm+AU188SyA7fVM8pNrJoam2pwuh2V1JcxHlLk0hK0uZlVz6KPCb1lRlNGq3O3g64Hjl+pjUHTc5P+MXREq6SeNeO3V1yR6eqZSG4cQDJb4aBMMNSQKGW3YkvYwQl9lvrCiMZUK60QKBgQDiEgBLh4VyD9CoSGK9pmwt7QF9Zup05P7Ji4tKZSQ3pCPMS95KWYQ7vbJzqqu1oeBdar6P4tj0lp7KvhQyDa+kh+WjWWY8NeUpt9XKfuuqHZ7714lmbdQ5Ek/4HdSBA9xwwSXh37szCov0jtRlzoiZ0+pS5Q48UUGNn1BDqXvUpwKBgQDlryL6S5s9E2pODcTltpHWbZZZG+NhRApwQs3KC0hgaO0+6+802VmnF/zgEC/Pgn6kHbEZGp0F1AP/pK5007qkzxXiE8ZxxvJyzjTB7Z0PJhm9IdLBnTbNT2w5BbiCgL+1qVE0l/Ty2pCw3FCPap955xZLQ8YfnIljfhUv8IejAQKBgE/EMj50Lu20DteR0uU/12PNAH2S1p8wPYY3qooxbboEPG1VR7XMKBA8Or79NWD9IQFVLK/wRsTmcFjxAIc4tQTEvo4IeT49dgJmTxUH+3cmxHXv8xclIYCRqY3OWLC9AAb437j3DEJSMle0HdVeLmy4jTF6iK9XrF2gHN4C6yJ5AoGAeKld3bLCAFyfzuhfbBnD9uI+mGU2nEXYTi0Fo7IUnL3xkBSL+pICnUUFZEfRQsyEyf+oGnrp7zChNQm1VrMdWjistNiyVWgWby0/j1FDPySSA0BhxgN/+MSvr0EakJnafHKT/qfmGYys7LnKDjSJ0fhYZzwgmC9fUUSnD0E+13c=",
	 * "cs4lak");
	 * }
	 */
	public String getHashes(String txnid, String amount, String productInfo, String firstname, String email,
			String udf1, String udf2, String udf3, String udf4, String udf5, String salt,
			String key) {

		String ph = checkNull(key) + "|" + checkNull(txnid) + "|" + checkNull(amount) + "|" + checkNull(productInfo)
				+ "|" + checkNull(firstname) + "|" + checkNull(email) + "|" + checkNull(udf1) + "|" + checkNull(udf2)
				+ "|" + checkNull(udf3) + "|" + checkNull(udf4) + "|" + checkNull(udf5) + "||||||" + salt;
		String paymentHash = getSHA(ph);
		System.out.println("Payment Hash " + paymentHash);

		return paymentHash;
	}

	private String checkNull(String value) {
		if (value == null) {
			return "";
		} else {
			return value;
		}
	}

	private String getSHA(String str) {

		MessageDigest md;
		String out = "";
		try {
			md = MessageDigest.getInstance("SHA-512");
			md.update(str.getBytes());
			byte[] mb = md.digest();

			for (int i = 0; i < mb.length; i++) {
				byte temp = mb[i];
				String s = Integer.toHexString(new Byte(temp));
				while (s.length() < 2) {
					s = "0" + s;
				}
				s = s.substring(s.length() - 2);
				out += s;
			}

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return out;

	}

	public Model processPayURequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) throws IOException, ParseException {
		populatePayUTransDetails(formData, merchantPGDetails, orderId);
		Map<String, String> params = new HashMap<String, String>();
		params.put(KEY, Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
		params.put(TXNID, orderId);
		params.put(PRODUCTINFO, productInfo);
		params.put(AMOUNT, String.valueOf((double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100));
		params.put(EMAIL, formData.get(CUSTOMEREMAIL).get(0));
		params.put(FIRSTNAME, formData.get(CUSOMERNAME).get(0));

		params.put(PHONE, formData.get(CUSTOMERPHONE).get(0));
		String returnUrl = pgGatewayUtilService.getReturnUrl(payuReturnURL,
				merchantPGDetails.getMerchantID(), formData.get(PAYMENT_OPTION).get(0));
		params.put(SURL, returnUrl);
		params.put(FURL, returnUrl);

		String hash = getHashes(orderId, params.get(AMOUNT), productInfo, formData.get(CUSOMERNAME).get(0),
				formData.get(CUSTOMEREMAIL).get(0), null, null, null, null, null,
				merchantPGDetails.getMerchantPGSaltKey(),
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
		logger.info("Hash :: " + hash);

		params.put(HASH, hash);
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {
			logger.info("Tr Method" + TransactioMethods.UPI);
			model = setUPIDetailsPayU(orderId, model, params, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.NETBANKING)) {
			logger.info("Tr Method" + TransactioMethods.NETBANKING);
			model = setNBDetailsPayU(orderId, model, params, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.WALLET)) {
			logger.info("Tr Method" + TransactioMethods.WALLET);
			model = setWalletDetailsPayU(orderId, model, params, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.CARD)) {
			logger.info("Tr Method" + TransactioMethods.CARD);
			model = setCardDetailsPayU(orderId, model, params, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI_QR)) {
			logger.info("Tr Method " + TransactioMethods.UPI_QR);
			model = setUPIQrDetailsPayU(orderId, model, params, formData, merchantPGDetails);
		}

		return model;

	}

	public Model setCardDetailsPayU(String orderId, Model model, Map<String, String> params,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails) throws IOException {

		CardValidateResponse cardValidateResponse = callPayUCardValidation(merchantPGDetails,
				formData.get(CARD_NUMBER).get(0).substring(0, 6));

		model.addAttribute(MODEL_KEY, params.get(KEY));
		model.addAttribute(MODEL_TXNID, params.get(TXNID));
		model.addAttribute(MODEL_PRODUCTINFO, params.get(PRODUCTINFO));
		model.addAttribute(MODEL_AMOUNT, params.get(AMOUNT));
		model.addAttribute(MODEL_EMAIL, params.get(EMAIL));
		model.addAttribute(MODEL_FIRSTNAME, params.get(FIRSTNAME));
		model.addAttribute(MODEL_PG, cardValidateResponse.getCardCategory());
		model.addAttribute(MODEL_BANKCODE, cardValidateResponse.getCardType());
		model.addAttribute(PAYMENT_CCNUM, formData.get(CARD_NUMBER).get(0));
		model.addAttribute(PAYMENT_CCNAME, formData.get(CARD_HOLDER).get(0));
		model.addAttribute(PAYMENT_CCVV, formData.get(CARD_CVV).get(0));
		model.addAttribute(PAYMENT_CCEXPMON, formData.get(CARD_EXPMONTH).get(0));
		model.addAttribute(PAYMENT_CCEXPYR, formData.get(CARD_EXPYEAR).get(0));
		model.addAttribute(MODEL_SURL, params.get(SURL));
		model.addAttribute(MODEL_FURL, params.get(FURL));
		model.addAttribute(MODEL_PHONE, params.get(PHONE));
		model.addAttribute(MODEL_HASH, params.get(HASH));

		return model;
	}

	public Model setWalletDetailsPayU(String orderId, Model model, Map<String, String> params,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails)
			throws JsonProcessingException {

		WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());
		logger.info("Wallet List::" + Utility.convertDTO2JsonString(walletList));
		model.addAttribute(MODEL_KEY, params.get(KEY));
		model.addAttribute(MODEL_TXNID, params.get(TXNID));
		model.addAttribute(MODEL_PRODUCTINFO, params.get(PRODUCTINFO));
		model.addAttribute(MODEL_AMOUNT, params.get(AMOUNT));
		model.addAttribute(MODEL_EMAIL, params.get(EMAIL));
		model.addAttribute(MODEL_FIRSTNAME, params.get(FIRSTNAME));
		model.addAttribute(MODEL_PG, PAYMENT_MODE_MW);
		model.addAttribute(MODEL_BANKCODE, walletList.getPaymentcodepg());
		model.addAttribute(MODEL_SURL, params.get(SURL));
		model.addAttribute(MODEL_FURL, params.get(FURL));
		model.addAttribute(MODEL_PHONE, params.get(PHONE));
		model.addAttribute(MODEL_HASH, params.get(HASH));
		logger.info("Model add Attribute");
		WalletPaymentDetails walletPaymentDetails = new WalletPaymentDetails();

		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		walletPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		walletPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		walletPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		walletPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		walletPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		walletPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		logger.info("Wallet walletPaymentDetails::" + Utility.convertDTO2JsonString(walletPaymentDetails));
		walletPaymentDetailsRepository.save(walletPaymentDetails);

		return model;
	}

	public Model setNBDetailsPayU(String orderId, Model model, Map<String, String> params,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails)
			throws JsonProcessingException {

		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(),
				UserStatus.ACTIVE.toString(), merchantPGDetails.getMerchantPGName());
		logger.info("Bank List::" + Utility.convertDTO2JsonString(bankList));
		model.addAttribute(MODEL_KEY, params.get(KEY));
		model.addAttribute(MODEL_TXNID, params.get(TXNID));
		model.addAttribute(MODEL_PRODUCTINFO, params.get(PRODUCTINFO));
		model.addAttribute(MODEL_AMOUNT, params.get(AMOUNT));
		model.addAttribute(MODEL_EMAIL, params.get(EMAIL));
		model.addAttribute(MODEL_FIRSTNAME, params.get(FIRSTNAME));
		model.addAttribute(MODEL_PG, PAYMENT_MODE_NB);
		model.addAttribute(MODEL_BANKCODE, bankList.getPgBankCode());
		model.addAttribute(MODEL_SURL, params.get(SURL));
		model.addAttribute(MODEL_FURL, params.get(FURL));
		model.addAttribute(MODEL_PHONE, params.get(PHONE));
		model.addAttribute(MODEL_HASH, params.get(HASH));
		logger.info("Model add Attribute");
		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		logger.info("Bank nbPaymentDetails::" + Utility.convertDTO2JsonString(nbPaymentDetails));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return model;
	}

	public Model setUPIDetailsPayU(String orderId, Model model, Map<String, String> params,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails) {

		model.addAttribute(MODEL_KEY, params.get(KEY));
		model.addAttribute(MODEL_TXNID, params.get(TXNID));
		model.addAttribute(MODEL_PRODUCTINFO, params.get(PRODUCTINFO));
		model.addAttribute(MODEL_AMOUNT, params.get(AMOUNT));
		model.addAttribute(MODEL_EMAIL, params.get(EMAIL));
		model.addAttribute(MODEL_FIRSTNAME, params.get(FIRSTNAME));
		model.addAttribute(MODEL_PG, PAYMENT_UPI);
		model.addAttribute(MODEL_BANKCODE, PAYMENT_BANKCODE_UPI);
		model.addAttribute(MODEL_VPA, formData.get(UPI_VPI).get(0));
		model.addAttribute(MODEL_SURL, params.get(SURL));
		model.addAttribute(MODEL_FURL, params.get(FURL));
		model.addAttribute(MODEL_PHONE, params.get(PHONE));
		model.addAttribute(MODEL_HASH, params.get(HASH));

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return model;
	}

	public Model setUPIQrDetailsPayU(String orderId, Model model, Map<String, String> params,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails) {
				logger.info("setUPIQrDetailsPayU");
				System.out.println(params);
				HttpResponse<String> response = Unirest.post("https://secure.payu.in/_payment")
				.multiPartContent()
				.field("key", params.get(KEY))
				.field("txnid", params.get(TXNID))
				.field("productinfo", params.get(PRODUCTINFO))
				.field("amount", params.get(AMOUNT))
				.field("email", params.get(EMAIL))
				.field("firstname", params.get(FIRSTNAME))
				.field("pg", PAYMENT_UPI)
				.field("bankcode", PAYMENT_BANKCODE_UPI)
				.field("vpa", formData.get(UPI_VPI).get(0))
				.field("surl", params.get(SURL))
				.field("furl", params.get(FURL))
				.field("phone",  params.get(PHONE))
				.field("hash", params.get(HASH))
				.asString();
		System.out.println(response.getBody());

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return model;
	}

	public String getHashesResponse(String txnid, String amount, String productInfo, String firstname, String email,
			String status,
			String udf1, String udf2, String udf3, String udf4, String udf5, String salt,
			String key) {

		String ph = salt + "|" + checkNull(status) + "||||||" + checkNull(udf5) + "|" + checkNull(udf4)
				+ "|" + checkNull(udf3) + "|" + checkNull(udf2) + "|" + checkNull(udf1) + "|" + checkNull(email) + "|"
				+ checkNull(firstname) + "|" + checkNull(productInfo) + "|"
				+ checkNull(amount) + "|" + checkNull(txnid) + "|" + key;
		logger.info("Payment Hash " + ph);
		String paymentHash = getSHA(ph);
		logger.info("Payment Hash " + paymentHash);

		return paymentHash;
	}

	public boolean validateReturnSignature(TransactionDetails transactionDetails,
			MultiValueMap<String, String> responseFormData) {

		MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository
				.findByMerchantIDAndMerchantPGId(transactionDetails.getMerchantId(), transactionDetails.getPgId());

		String hash = getHashesResponse(responseFormData.get(RESP_ORDERID).get(0),
				responseFormData.get(RESP_ORDERAMOUNT).get(0),
				responseFormData.get(RESP_PRODUCTINFO).get(0),
				responseFormData.get(RESP_FIRSTNAME).get(0),
				responseFormData.get(RESP_EMAIL).get(0),
				responseFormData.get(RESP_TXSTATUS).get(0),
				null, null, null, null, null,
				merchantPGDetails.getMerchantPGSaltKey(),
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));

		System.out.println("Generate Hash " + hash);
		System.out.println("Retrive Hash " + responseFormData.get(RESP_SIGNATURE).get(0));

		if (hash.equalsIgnoreCase(responseFormData.get(RESP_SIGNATURE).get(0))) {
			return true;
		}

		return false;
	}

	public void updateWebhookPayUResponse(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException {

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

		if (transactionDetails != null) {

			if (validateReturnSignature(transactionDetails, responseFormData)) {
				logger.info("The return signature has been verified ...");
				transactionDetails.setStatus(
						checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXSTATUS)));
			}
			transactionDetails.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_REFERENCEID));
			transactionDetails
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
			transactionDetails.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG));
			transactionDetails.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));

			transactionDetails.setSource("webhookPayU");
			transactionDetailsRepository.save(transactionDetails);

			try {
				notiFyURLService2Merchant.populateReturnDetails(transactionDetails);
			} catch (Exception e) {
				logger.error("Exception in notify to merchant :: " + e.toString());
			}
		}
	}

	public void updateTransactionStatus(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException, ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException {

		logger.info("Inside method updateTransactionStatus()");
		logger.info("Response Form Data" + GeneralUtils.MultiValueMaptoJson(responseFormData));

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

		if (transactionDetails != null) {

			if (validateReturnSignature(transactionDetails, responseFormData)) {
				logger.info("The return signature has been verified ...");
				String trxMsg = pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG);
				transactionDetails.setStatus(
						checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXSTATUS)));

			} else {
				logger.info("The return signature not verified ...");
				transactionDetails.setStatus(UserStatus.FAILED.toString());
			}

			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetails.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_REFERENCEID));
			transactionDetails
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
			transactionDetails.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG));
			transactionDetails.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));

			transactionDetails.setSource("ReturnURL");
			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsRepository.save(transactionDetails);
		} else {
			TransactionDetailsAll transactionDetailsAll = new TransactionDetailsAll();
			logger.info("Transaction Details Null");
			logger.info("Insert All Transaction Details");
			transactionDetails = transactionDetailsRepository
					.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

			logger.info("Insert Transaction Details by orderId:: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsAll.setOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
			transactionDetailsAll
					.setStatus(checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXSTATUS)));
			transactionDetailsAll
					.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_REFERENCEID));
			transactionDetailsAll
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
			transactionDetails.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG));
			transactionDetails.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));

			transactionDetailsAllRepository.save(transactionDetailsAll);
		}
		logger.info("Transaction Update");

		logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");
		logger.info("populatePgResponseinDB");
		try {
			PayUTransactionDetails payUTransactionDetails = payUTransactionDetailsRepository
					.findByMerchantOrderIdAndOrderId(transactionDetails.getMerchantOrderId(),
							transactionDetails.getOrderID());

			if (payUTransactionDetails == null) {
				logger.info("create payUTransactionDetails" + Utility.convertDTO2JsonString(payUTransactionDetails));
				logger.info("Inside payUTransactionDetails :: " + responseFormData.toString());
				payUTransactionDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
				payUTransactionDetails
						.setOrderAmount(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERAMOUNT));
				payUTransactionDetails
						.setOrderId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));
				payUTransactionDetails
						.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENTMODE));
				payUTransactionDetails
						.setSignature(pgGatewayUtilService.checkResponseData(responseFormData, RESP_SIGNATURE));
				payUTransactionDetails.setTxMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG));
				payUTransactionDetails.setTxStatus(
						checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXSTATUS)));
				payUTransactionDetails.setTxTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));
				payUTransactionDetails.setUpdateFlag("N");
				payUTransactionDetails.setSource("ReturnURL");
			} else {
				logger.info("PayUTransactionDetails::" + Utility.convertDTO2JsonString(payUTransactionDetails));
				payUTransactionDetails
						.setSignature(pgGatewayUtilService.checkResponseData(responseFormData, RESP_SIGNATURE));
				payUTransactionDetails.setTxMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXMSG));
				payUTransactionDetails.setTxStatus(
						checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXSTATUS)));
				payUTransactionDetails.setTxTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));
				payUTransactionDetails.setUpdateFlag("N");
				payUTransactionDetails.setSource("ReturnURL");
				payUTransactionDetails
						.setResponseText(Encryption.encryptCardNumberOrExpOrCvv(responseFormData.toString()));
			}

			payUTransactionDetailsRepository.save(payUTransactionDetails);

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Exception in CashfreeTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");
	}

	public Model getResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	public String getCardValidationHash(String cardBin, String salt, String key) {

		String ph = key + "|" + checkNull(commandCardValidate) + "|" + checkNull(cardBin) + "|" + salt;
		String statusHash = getSHA(ph);

		return statusHash;

	}

	public CardValidateResponse callPayUCardValidation(MerchantPGDetails merchantPGDetails, String cardBin)
			throws IOException {

		String requestData = "key=" + Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret())
				+ "&command=" + commandCardValidate +
				"&var1=" + cardBin + "&hash=" + getCardValidationHash(cardBin, merchantPGDetails.getMerchantPGSaltKey(),
						Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));

		HttpResponse<CardValidateResponse> payUCardResponse = Unirest
				.post("https://info.payu.in/merchant/postservice.php?form=2")
				.header("Content-Type", "application/x-www-form-urlencoded")
				.body(requestData).asObject(CardValidateResponse.class);

		return payUCardResponse.getBody();
	}

	public String checkStatus(String payuStatus) {
		if (payuStatus.equalsIgnoreCase(STATUS_SUCCESS)) {
			return UserStatus.SUCCESS.toString();
		}
		if (payuStatus.equalsIgnoreCase(STATUS_FAILED)) {
			return UserStatus.FAILED.toString();
		}
		if (payuStatus.equalsIgnoreCase(STATUS_DROPPED)) {
			return UserStatus.DROPPED.toString();
		}
		if (payuStatus.equalsIgnoreCase(STATUS_PENDING)) {
			return UserStatus.PENDING.toString();
		}
		if (payuStatus.equalsIgnoreCase(STATUS_failed_PENDING)) {
			return UserStatus.PENDING.toString();
		}
		return payuStatus;
	}

	public void populatePayUTransDetails(MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) throws JsonProcessingException {

		PayUTransactionDetails payUTransactionDetails = new PayUTransactionDetails();
		logger.info("populatePayUTransDetails start");
		payUTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		payUTransactionDetails
				.setOrderAmount(String.format("%.2f", Double.parseDouble(formData.get(ORDERAMOUNT).get(0)) / 100));
		payUTransactionDetails.setOrderId(orderId);
		payUTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		payUTransactionDetails.setTxStatus(UserStatus.PENDING.toString());
		payUTransactionDetails.setUpdateFlag("N");
		payUTransactionDetails.setSource("TRInitiate");
		logger.info(Utility.convertDTO2JsonString(payUTransactionDetails));
		logger.info("populatePayUTransDetails save");
		payUTransactionDetailsRepository.save(payUTransactionDetails);
	}

}
