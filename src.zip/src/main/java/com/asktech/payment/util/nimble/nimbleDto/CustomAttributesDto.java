package com.asktech.payment.util.nimble.nimbleDto;
import lombok.AllArgsConstructor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CustomAttributesDto {
    private String key_1;
    private String key_2;
}
