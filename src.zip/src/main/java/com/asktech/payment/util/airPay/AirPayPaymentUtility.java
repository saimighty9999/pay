package com.asktech.payment.util.airPay;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constant.airPay.AirPayConstants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.AirPayTransactionDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.PGConfigurationDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.repository.AirPayTransactionDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.asktech.payment.util.airPay.dto.Chkvaluest;
import com.asktech.payment.util.airPay.dto.ChkvaluestFinal;
import com.asktech.payment.util.airPay.dto.RESPONSE;
import com.asktech.payment.util.airPay.dto.failedRes.RESPONSEfail;
import com.asktech.payment.util.airPay.dto.statusapi.RESPONSEsta;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class AirPayPaymentUtility implements CashFreeFields, AirPayConstants {

	static Logger logger = LoggerFactory.getLogger(AirPayPaymentUtility.class);

	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	AirPayTransactionDetailsRepository airPayTransactionDetailsRepository;
	@Autowired
	PGConfigurationDetailsRepository pGConfigurationDetailsRepository;

	@Value("${pgEndPoints.airPayReturnURL}")
	String airPayReturnURL;
	@Value("${pgEndPoints.airPayPaymentURL}")
	String airPayPaymentURL;
	@Value("${pgEndPoints.airBaseURL}")
	String airBaseURL;
	@Value("${pgEndPoints.airOrdercheckURL}")
	String airOrdercheckURL;

	Date myDate = new Date();
	SimpleDateFormat sm = new SimpleDateFormat("YYYY-MM-d");

	public Model processAirPayRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) throws JsonProcessingException {
		populateAirPayTransDetails(formData, merchantPGDetails, orderId);
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {

			model = setUPIDetailsAirPay(orderId, model, orderId, formData, merchantPGDetails);
		}

		return model;
	}

	public void populateAirPayTransDetails(MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) {

		AirPayTransactionDetails airPayTransactionDetails = new AirPayTransactionDetails();
		airPayTransactionDetails.setMerchantId(merchantPGDetails.getMerchantID());
		airPayTransactionDetails.setPgid(merchantPGDetails.getMerchantPGId());
		airPayTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		airPayTransactionDetails.setOrderAmount(
				String.format("%.2f", Double.parseDouble(String.valueOf(formData.get(ORDERAMOUNT).get(0))) / 100));
		airPayTransactionDetails.setOrderId(orderId);
		airPayTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		airPayTransactionDetails.setTxStatus(UserStatus.PENDING.toString());
		airPayTransactionDetails.setUpdateFlag("N");
		airPayTransactionDetails.setSource("Initiated");
		airPayTransactionDetails.setEmail(formData.get(CUSTOMEREMAIL).get(0));
		airPayTransactionDetails.setPhoneNo(formData.get(CUSTOMERPHONE).get(0));

		airPayTransactionDetailsRepository.save(airPayTransactionDetails);
	}

	public void populateAirPayTransDetails(String orderId, String responseText, RESPONSE value,
			RESPONSEfail failvalue) {
		AirPayTransactionDetails airPayTransactionDetails = airPayTransactionDetailsRepository.findByOrderId(orderId);
		if (airPayTransactionDetails != null) {
			airPayTransactionDetails.setResponseText(responseText.trim());
			if (value != null) {
				airPayTransactionDetails.setStatusText(value.getTRANSACTION().MESSAGE);
				airPayTransactionDetails.setTxStatus(value.getTRANSACTION().TRANSACTIONSTATUS);
			}
			if (failvalue != null) {
				airPayTransactionDetails.setStatusText(failvalue.getTRANSACTION().MESSAGE);
				airPayTransactionDetails.setTxStatus(failvalue.getTRANSACTION().TRANSACTIONSTATUS);
			}
			airPayTransactionDetailsRepository.save(airPayTransactionDetails);
		}
	}

	public void populateAirPayTransDetails(String orderId, ChkvaluestFinal chkvaluestFinal) {
		AirPayTransactionDetails airPayTransactionDetails = airPayTransactionDetailsRepository.findByOrderId(orderId);
		if (airPayTransactionDetails != null) {
			if (chkvaluestFinal != null) {
				airPayTransactionDetails.setStatusText(chkvaluestFinal.getMESSAGE());
				airPayTransactionDetails.setTxStatus(chkvaluestFinal.getStatus());
				airPayTransactionDetails.setSource("ReturnUrl");
			}
			airPayTransactionDetailsRepository.save(airPayTransactionDetails);
		}
	}

	private Model setUPIDetailsAirPay(String orderId, Model model, String data, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) throws JsonProcessingException {

		String uuid = Utility.generateAppId();

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);
		String baseUrl = airBaseURL;
		String mer_dom = Utility.encodeBase64(baseUrl);
		String privateKey = "";
		try {
			privateKey = AirpaySecurity.getPrivateKey(merchantPGDetails.getMerchantPGSaltKey(),
					merchantPGDetails.getMerchantPGAdd1(), merchantPGDetails.getMerchantPGAdd2());
		} catch (NoSuchAlgorithmException e) {
			logger.error(e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// } catch (Exception e) {

		// }
		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(formData.get(ORDERAMOUNT).get(0))) / 100);

		String req = sendUPIRequest(
				merchantPGDetails.getMerchantPGAdd1(),
				merchantPGDetails.getMerchantPGAdd2(),
				formData.get(CUSTOMEREMAIL).get(0),
				formData.get(CUSOMERNAME).get(0),
				formData.get(CUSOMERNAME).get(0),
				amt,
				orderId,
				uuid,
				formData.get(CUSTOMERPHONE).get(0),
				formData.get(UPI_VPI).get(0),
				merchantPGDetails.getMerchantPGAppId(),
				mer_dom,
				privateKey);
		logger.info(req);
		XmlMapper xmlMapper = new XmlMapper();
		RESPONSE value;
		req = req.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
		try {
			value = xmlMapper.readValue(req, RESPONSE.class);
			populateAirPayTransDetails(orderId, req, value, null);
			try {
				logger.info(Utility.convertDTO2JsonString(value));
			} catch (JsonProcessingException ev) {
				// TODO Auto-generated catch block
				ev.printStackTrace();
			}
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			RESPONSEfail failvalue;
			try {
				failvalue = xmlMapper.readValue(req, RESPONSEfail.class);
				populateAirPayTransDetails(orderId, req, null, failvalue);
				try {
					logger.info(Utility.convertDTO2JsonString(failvalue));
				} catch (JsonProcessingException ex) {
					// TODO Auto-generated catch block
					ex.printStackTrace();
				}
			} catch (JsonProcessingException el) {
				populateAirPayTransDetails(orderId, req, null, null);
				// TODO Auto-generated catch block
				logger.info("AIRPAY REQ FAILED AGAIN::" + el.getMessage());
				e.printStackTrace();
			}
			logger.info("AIRPAY REQ FAILED::" + e.getMessage());
			e.printStackTrace();
		}
		checkStatus(orderId);
		model.addAttribute("orderId", orderId);
		return model;
	}

	public Model getResponseProcess(TransactionDetails transactionDetails, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	public TransactionDetails updateTransactionStatus(String orderId)
			throws ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(orderId);

		if (transactionDetails != null) {			
			ChkvaluestFinal chkvaluest = checkFinalStatus(orderId);
			transactionDetails.setStatus(chkvaluest.getStatus());
			transactionDetails.setTxtMsg(chkvaluest.getTRANSACTIONPAYMENTSTATUS() + "|" + chkvaluest.getMESSAGE());
			transactionDetails.setPgOrderID(chkvaluest.getAPTRANSACTIONID());
			transactionDetails.setTxtPGTime(Utility.populateDbTime());			
			transactionDetails.setSource("ReturnURL");
			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));
			transactionDetailsRepository.save(transactionDetails);
			populateAirPayTransDetails(orderId, chkvaluest);

		}
		logger.info("Transaction Update");

		logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		logger.info("End method updateTransactionStatus()");

		return transactionDetails;
	}

	// --------------------------------------------------------------------------
	private String sendUPIRequest(String username, String password, String buyerEmail, String buyerFirstName,
			String buyerLastName, String amount, String orderid, String uid, String phn, String vpa, String mercid,
			String mer_dom, String private_key) {
		String checksum = AirpaySecurity.getChecksum(username, password, buyerEmail, buyerFirstName, buyerLastName,
				amount, orderid, uid);
		HttpResponse<String> response = Unirest.post(airPayPaymentURL)
				.multiPartContent()
				.field("buyerEmail", buyerEmail)
				.field("buyerPhone", phn)
				.field("buyerFirstName", buyerFirstName)
				.field("buyerLastName", buyerFirstName)
				.field("orderid", orderid)
				.field("amount", amount)
				.field("UID", uid)
				.field("payerVPA", vpa)
				.field("privatekey", private_key)
				.field("mercid", mercid)
				.field("chmod", "upi")
				.field("checksum", checksum)
				.field("currency", "356")
				.field("isocurrency", "INR")
				.field("mode", "vpa")
				.field("channel", "upi")
				.field("mer_dom", mer_dom)
				.field("apiName", "collectVPA")
				.asString();
		return response.getBody();
	}

	private String checkTrStatus(String username, String password, String mercid, String merchant_txnId,
			String airpayId, String privatekey, String mer_dom) {
		String checksum = AirpaySecurity.getOrderChecksum(username, password, mercid, merchant_txnId, airpayId);
		HttpResponse<String> response = Unirest.post(airOrdercheckURL)
				.multiPartContent()
				.field("mercid", mercid)
				.field("merchant_txnId", merchant_txnId)
				.field("privatekey", privatekey)
				.field("checksum", checksum)
				.asString();
		return response.getBody();
	}

	public Chkvaluest checkStatus(String orderId) throws JsonProcessingException {
		String baseUrl = airBaseURL;
		String mer_dom = Utility.encodeBase64(baseUrl);
		String privateKey = "";
		Chkvaluest chkvaluest = new Chkvaluest();
		chkvaluest.setStatus("PENDING");
		AirPayTransactionDetails airPayTransactionDetails = airPayTransactionDetailsRepository.findByOrderId(orderId);
		logger.info(Utility.convertDTO2JsonString(airPayTransactionDetails));
		if (airPayTransactionDetails != null) {
			PGConfigurationDetails merchantPGDetails = pGConfigurationDetailsRepository
					.findByPgUuid(airPayTransactionDetails.getPgid());
			// MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository
			// .findByMerchantID(airPayTransactionDetails.getMerchantId());
			logger.info(Utility.convertDTO2JsonString(merchantPGDetails));
			try {
				privateKey = AirpaySecurity.getPrivateKey(merchantPGDetails.getPgSaltKey(),
						merchantPGDetails.getPgAddInfo1(), merchantPGDetails.getPgAddInfo2());
			} catch (NoSuchAlgorithmException e) {
				logger.error(e.getMessage());
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			logger.info("ORDERID::" + orderId);
			String chk = checkTrStatus(
					merchantPGDetails.getPgAddInfo1(),
					merchantPGDetails.getPgAddInfo2(), merchantPGDetails.getPgAppId(),
					orderId, "", privateKey, mer_dom);
			logger.info(chk);

			chk = chk.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
			RESPONSEsta chkvalue = new RESPONSEsta();
			XmlMapper xmlMapper = new XmlMapper();

			try {
				chkvalue = xmlMapper.readValue(chk, RESPONSEsta.class);
				String str = chkvalue.TRANSACTION.TRANSACTIONSTATUS;
				chkvaluest.setStatus(statusFlag(str));
				logger.info(Utility.convertDTO2JsonString(chkvalue));
			} catch (JsonProcessingException e) {
				logger.error("AIRPAY::CHECKSTATUS FAIL" + e.getMessage());
				// TODO Auto-generated catch block
				chkvaluest.setStatus("PENDING");
				e.printStackTrace();
			}
		}
		logger.info(Utility.convertDTO2JsonString(chkvaluest));
		return chkvaluest;
	}

	public ChkvaluestFinal checkFinalStatus(String orderId) throws JsonProcessingException {
		String baseUrl = airBaseURL;
		String mer_dom = Utility.encodeBase64(baseUrl);
		String privateKey = "";
		ChkvaluestFinal chkvaluest = new ChkvaluestFinal();
		chkvaluest.setStatus("PENDING");
		AirPayTransactionDetails airPayTransactionDetails = airPayTransactionDetailsRepository.findByOrderId(orderId);
		logger.info(Utility.convertDTO2JsonString(airPayTransactionDetails));
		if (airPayTransactionDetails != null) {
			PGConfigurationDetails merchantPGDetails = pGConfigurationDetailsRepository
					.findByPgUuid(airPayTransactionDetails.getPgid());
			// MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository
			// .findByMerchantID(airPayTransactionDetails.getMerchantId());
			logger.info(Utility.convertDTO2JsonString(merchantPGDetails));
			try {
				privateKey = AirpaySecurity.getPrivateKey(merchantPGDetails.getPgSaltKey(),
						merchantPGDetails.getPgAddInfo1(), merchantPGDetails.getPgAddInfo2());
			} catch (NoSuchAlgorithmException e) {
				logger.error(e.getMessage());
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			logger.info("ORDERID::" + orderId);
			String chk = checkTrStatus(
					merchantPGDetails.getPgAddInfo1(),
					merchantPGDetails.getPgAddInfo2(), merchantPGDetails.getPgAppId(),
					orderId, "", privateKey, mer_dom);
			logger.info(chk);
			airPayTransactionDetails.setStatusText(chk.trim());
            airPayTransactionDetails.setSource("StatusFinalCheck");
            airPayTransactionDetailsRepository.save(airPayTransactionDetails);
			chk = chk.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "");
			RESPONSEsta chkvalue = new RESPONSEsta();
			XmlMapper xmlMapper = new XmlMapper();

			try {
				chkvalue = xmlMapper.readValue(chk, RESPONSEsta.class);
				String str = chkvalue.TRANSACTION.TRANSACTIONSTATUS;
				chkvaluest.setStatus(statusFlag(str));
				chkvaluest.setAPTRANSACTIONID(chkvalue.TRANSACTION.APTRANSACTIONID);
				chkvaluest.setMESSAGE(chkvalue.TRANSACTION.MESSAGE);
				chkvaluest.setTRANSACTIONPAYMENTSTATUS(chkvalue.TRANSACTION.TRANSACTIONPAYMENTSTATUS);
				logger.info(Utility.convertDTO2JsonString(chkvalue));
			} catch (JsonProcessingException e) {
				logger.error("AIRPAY::CHECKSTATUS FAIL" + e.getMessage());
				// TODO Auto-generated catch block
				chkvaluest.setStatus("PENDING");
				e.printStackTrace();
			}
		}
		logger.info(Utility.convertDTO2JsonString(chkvaluest));
		return chkvaluest;
	}

	private String statusFlag(String code) {
		if (code.equals("200")) {
			return "SUCCESS";
		}
		if (code.equals("211")) {
			return "PENDING";
		}
		if (code.equals("400")) {
			return "FAILED";
		}
		if (code.equals("401")) {
			return "FAILED";
		}
		if (code.equals("402")) {
			return "FAILED";
		}
		if (code.equals("403")) {
			return "PENDING";
		}
		if (code.equals("405")) {
			return "FAILED";
		}
		if (code.equals("503")) {
			return "FAILED";
		}
		return "PENDING";
	}
}
