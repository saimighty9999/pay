package com.asktech.payment.util.nimble.nimbleDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentResUpiDto {
    @JsonProperty("transaction_id")
    private String transaction_id;
    @JsonProperty("status_code")
    private String status_code;
    @JsonProperty("completion_time")
    private String completion_time;
    @JsonProperty("extra_info")
    private Extra_info extra_info;
    @JsonProperty("message")
    private String message;
    @JsonProperty("order_id")
    private String order_id;
    @JsonProperty("status")
    private String status;
    @JsonProperty("info")
    private Info info;
}
