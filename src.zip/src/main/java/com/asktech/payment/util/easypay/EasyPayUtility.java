package com.asktech.payment.util.easypay;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;

import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.easePay.EasePayCallBackResp;
import com.asktech.payment.dto.easePay.EasePayCallBackResponse;
import com.asktech.payment.dto.easePay.StatusApiReqDto;
import com.asktech.payment.dto.easePay.StatusApiResDto;
import com.asktech.payment.dto.easePay.StatusAuthDto;
import com.asktech.payment.dto.easePay.StatusRes;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.EasePayTransactionDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.repository.EasePayTransactionDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.PaymentLogs;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class EasyPayUtility implements CashFreeFields {

	static Logger logger = LoggerFactory.getLogger(EasyPayUtility.class);

	// @Autowired
	// Environment env;
	@Autowired
	private CheckSumUtils checkSumUtils;
	@Autowired
	private EasePayTransactionDetailsRepository easePayTransactionDetailsRepository;
	@Autowired
	private TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	private UserDetailsRepository userDetailsRepository;
	@Autowired
	private MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	private PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	private PaymentLogs paymentLogs;
	@Value("${pgEndPoints.easypayRequestUrl}")
	String requestUrl;
	@Value("${pgEndPoints.easypayReturnUrl}")
	String returnUrl;

	public Model easypayment(Model model, MerchantPGDetails merchantPGDetails, MultiValueMap<String, String> formData,
			String orderId) {
		logger.info("easypayment Req");
		String uri = requestUrl;
		String cpcode = merchantPGDetails.getMerchantPGAppId();
		String secret = Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret());
		// String cpcode = "ANAPR9279";
		// String secret = "dacf786c2e";
		String amount = String.valueOf((float) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100.00f);
		String mobile = formData.get(CUSTOMERPHONE).get(0);
		String txnid = orderId;
		Long time = Instant.now().toEpochMilli();
		String sscode = time.toString();
		// String checksum = null;
		StringBuilder text = new StringBuilder();
		text.append(cpcode).append("|").append(sscode).append("|").append(amount).append("|").append(mobile).append("|")
				.append(txnid);
		// String secureHashText = checkSumUtils.generateSecureHash(text.toString(),
		// merchantPGDetails.getMerchantPGSecret());
		String secureHashText = checkSumUtils.generateSecureHash(text.toString(), secret);
		logger.info("Text: " + text.toString() + "\n Securehash:" + secureHashText);
		String urlTemplate = UriComponentsBuilder.fromHttpUrl(uri)
				.queryParam("checksum", secureHashText)
				.queryParam("cpcode", cpcode)
				.queryParam("sscode", sscode)
				.queryParam("amount", amount)
				.queryParam("mobile", mobile)
				.queryParam("txnid", txnid)
				.queryParam("returnUrl", returnUrl + "/" + txnid)
				.build().toUriString();
		paymentLogs.saveLogs(merchantPGDetails.getMerchantID(), orderId, "PAYMENTREQ", urlTemplate,
				merchantPGDetails.getMerchantPGId(), merchantPGDetails.getMerchantPGName());
		logger.info("urlTemplate::" + urlTemplate);
		model.addAttribute("redirect_url", urlTemplate);
		return model;
	}

	public Model processEasyPayRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) {

		// merchantPGDetails.getMerchantPGId();
		// easypayment(model, merchantPGDetails, formData);
		populateEasePayTransactionDetails(formData, merchantPGDetails, orderId);
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {

			model = easypayment(model, merchantPGDetails, formData, orderId);
		}
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.NETBANKING)) {

			model = easypayment(model, merchantPGDetails, formData, orderId);
		}
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.CARD)) {

			model = easypayment(model, merchantPGDetails, formData, orderId);
		}
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.WALLET)) {

			model = easypayment(model, merchantPGDetails, formData, orderId);
		}
		return model;
	}

	public void populateEasePayTransactionDetails(MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) {

		EasePayTransactionDetails easePayTransactionDetails = new EasePayTransactionDetails();
		easePayTransactionDetails.setMerchantId(merchantPGDetails.getMerchantID());
		easePayTransactionDetails.setPgid(merchantPGDetails.getMerchantPGId());
		easePayTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		easePayTransactionDetails.setOrderAmount(
				String.format("%.2f", Double.parseDouble(String.valueOf(formData.get(ORDERAMOUNT).get(0))) / 100));
		easePayTransactionDetails.setOrderId(orderId);
		easePayTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		easePayTransactionDetails.setTxStatus(UserStatus.PENDING.toString());
		easePayTransactionDetails.setUpdateFlag("N");
		easePayTransactionDetails.setSource("Initiated");
		easePayTransactionDetails.setEmail(formData.get(CUSTOMEREMAIL).get(0));
		easePayTransactionDetails.setPhoneNo(formData.get(CUSTOMERPHONE).get(0));

		easePayTransactionDetailsRepository.save(easePayTransactionDetails);
	}

	public TransactionDetails updateTransactionStatus(String orderId)
			throws ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {

		// ObjectMapper objectMapper = new ObjectMapper();
		// EasePayCallBackResponse easePayCallBackResponse =
		// objectMapper.readValue(jsonObject,
		// EasePayCallBackResponse.class);

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(orderId);
		// getEasyPayStatusApi(orderId, null, orderId);
		// if (transactionDetails != null) {

		// transactionDetails.setStatus(easePayCallBackResponse.getRespCode());
		// transactionDetails.setTxtMsg(easePayCallBackResponse.getRespMsg());
		// transactionDetails.setPgOrderID(easePayCallBackResponse.getRrn());
		// transactionDetails.setTxtPGTime(Utility.populateDbTime());
		// transactionDetails.setSource("ReturnURL");
		// logger.info("Insert Transaction Details :: " +
		// Utility.convertDTO2JsonString(transactionDetails));
		// transactionDetailsRepository.save(transactionDetails);
		// populateEasePayTransDetails(easePayCallBackResponse.getOrderId(),
		// easePayCallBackResponse);

		// }
		logger.info("Transaction Update::" + Utility.convertDTO2JsonString(transactionDetails));

		logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		logger.info("End method updateTransactionStatus()");

		return transactionDetails;
	}

	public void populateEasePayTransDetails(String orderId, EasePayCallBackResponse easePayCallBackResponse) {
		EasePayTransactionDetails easePayTransactionDetails = easePayTransactionDetailsRepository
				.findByOrderId(orderId);
		if (easePayTransactionDetails != null) {

			easePayTransactionDetails.setTxMsg(easePayTransactionDetails.getTxMsg());
			easePayTransactionDetails.setTxStatus(easePayCallBackResponse.getTxtStatus());
			easePayTransactionDetails.setSource("ReturnUrl");

			easePayTransactionDetailsRepository.save(easePayTransactionDetails);
		}
	}

	public EasePayCallBackResp callBackTransactionStatus(String jsonObject)
			throws JsonMappingException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		EasePayCallBackResponse easePayCallBackResponse = objectMapper.readValue(jsonObject,
				EasePayCallBackResponse.class);
		paymentLogs.saveLogs(null, easePayCallBackResponse.getOrderId(), "PAYMENTCALLBACK", jsonObject, null, null);

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(easePayCallBackResponse.getOrderId());

		if (transactionDetails != null) {
			if (easePayCallBackResponse.getRespCode().equals("00")) {
				transactionDetails.setStatus("SUCCESS");
			} else {
				transactionDetails.setStatus("FAILED");
			}
			transactionDetails.setTxtMsg(easePayCallBackResponse.getRespMsg());
			transactionDetails.setPgOrderID(easePayCallBackResponse.getRrn());
			transactionDetails.setTxtPGTime(Utility.populateDbTime());
			transactionDetails.setSource("CallBack");
			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));
			transactionDetailsRepository.save(transactionDetails);
			populateEasePayTransDetails(easePayCallBackResponse.getOrderId(), easePayCallBackResponse);

			return generateResponse("300", "Status Updated Successfully", "Success");
		}
		logger.info("Transaction Update");

		return generateResponse("302", "Transaction Failed", "Failed");
	}

	private EasePayCallBackResp generateResponse(String respCode, String response, String respMsg) {

		EasePayCallBackResp easePayCallBackResp = new EasePayCallBackResp();
		easePayCallBackResp.setRespCode(respCode);
		easePayCallBackResp.setRespMsg(respMsg);
		easePayCallBackResp.setResponse(response);

		return easePayCallBackResp;
	}

	public Model getResponseProcess(TransactionDetails transactionDetails, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	public StatusRes getEasyPayStatusApi(String orderId, MerchantPGDetails merchantPGDetails, String mobile) {
		StatusRes statusRes = new StatusRes();
		statusRes.setTRANSACTION_STATUS("ERROR");
		statusRes.setTRANSACTION_STATUSMESSAGE("Error in Response");
		statusRes.setREQUEST_REFERENCE_NO(orderId);
		HttpResponse<StatusAuthDto> statusAuthDtoRes = Unirest
				.post("https://yesmoneyapi.easypay.co.in/epMoney/oauth/token?grant_type=client_credentials")
				.basicAuth(merchantPGDetails.getMerchantPGAdd1(), merchantPGDetails.getMerchantPGAdd2())
				.asObject(StatusAuthDto.class)
				.ifFailure(Object.class, r -> {
					Object e = r.getBody();
					try {
						logger.error("Easy Status Response error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				});
		Unirest.shutDown();
		StatusAuthDto statusAuthDto = statusAuthDtoRes.getBody();
		if (statusAuthDto != null) {
			if (statusAuthDto.getAccess_token() != null && statusAuthDto.getAccess_token().length() > 10) {
				StatusApiReqDto statusApiReqDto = new StatusApiReqDto();
				statusApiReqDto.setCPCODE(merchantPGDetails.getMerchantPGAppId());
				statusApiReqDto.setCUSTOMER_MOBILE(mobile);
				statusApiReqDto.setREQUEST_REFERENCE_NO(orderId);
				HttpResponse<StatusApiResDto> statusApiResDto = Unirest
						.post("https://epmoney.easypay.co.in/epMoney/transaction-status/gateway/v1.0/")
						.header("Authorization", "Bearer " + statusAuthDto.getAccess_token()).body(statusApiReqDto)
						.asObject(StatusApiResDto.class)
						.ifFailure(Object.class, r -> {
							Object e = r.getBody();
							try {
								logger.error("Easy Status Response error::" + Utility.convertDTO2JsonString(e));
							} catch (JsonProcessingException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

						});
				Unirest.shutDown();
				StatusApiResDto statusApiResDtodt = statusApiResDto.getBody();
				if (statusApiResDtodt.getRESP_CODE().equals("200")) {
					statusRes.setBANK_REFERENCE_NO(statusApiResDtodt.getDATA().getBANK_REFERENCE_NO());
					statusRes.setREQUEST_REFERENCE_NO(statusApiResDtodt.getDATA().getREQUEST_REFERENCE_NO());
					statusRes.setTRANSACTION_STATUSMESSAGE(statusApiResDtodt.getDATA().getTRANSACTION_STATUSMESSAGE());
					statusRes.setTRANSACTION_STATUS(statusApiResDtodt.getDATA().getTRANSACTION_STATUS());
					return statusRes;
				} else {
					return statusRes;
				}
			} else {
				return statusRes;
			}
		} else {
			return statusRes;
		}

	}

}

// {
// "timestamp": 1660931735792,
// "status": 401,
// "error": "Unauthorized",
// "message": "PreparedStatementCallback; bad SQL grammar [SELECT emailAddress,
// SUBSTR(password_,9), 1 FROM User_ WHERE emailAddress = ?]; nested exception
// is com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException: Table
// 'epmoney.User_' doesn't exist",
// "path": "/epMoney/oauth/token"
// }