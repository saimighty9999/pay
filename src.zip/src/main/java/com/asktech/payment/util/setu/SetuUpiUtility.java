package com.asktech.payment.util.setu;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.ErrorValues;
import com.asktech.payment.constant.ReturnMerchantAttributes;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.constants.setu.Setu;
import com.asktech.payment.constants.setu.SetuResponseFormData;
import com.asktech.payment.dto.setu.Amount;
import com.asktech.payment.dto.setu.SetuErrorResponse;
import com.asktech.payment.dto.setu.SetuPaymentLinkCreation;
import com.asktech.payment.dto.setu.SetuResponsePayment;
import com.asktech.payment.enums.FormValidationExceptionEnums;
import com.asktech.payment.enums.PGServices;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.SetuLinkGeneration;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.SetuLinkGenerationRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.SetuTokenGeneration;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class SetuUpiUtility implements CashFreeFields, ErrorValues, Setu,ReturnMerchantAttributes,SetuResponseFormData {

	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	SetuLinkGenerationRepository setuLinkGenerationRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	
	
	
	@Value("${pgEndPoints.setuPaymentLinkCreate}")
	String setuPaymentLinkCreate;
	@Value("${pgEndPoints.setuTriggerPayment}")
	String setuTriggerPayment;
	@Value("${pgEndPoints.setuPaymentStatus}")
	String setuPaymentStatus;
	
	@Value("${apiEndPoint}")
	String apiurl;
	static Logger logger = LoggerFactory.getLogger(SetuUpiUtility.class);

	public Model processSetuRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId, String device)
			throws ParseException, JsonProcessingException, ValidationExceptions {

		logger.info("Inside processSetuRequest() ");
		SetuResponsePayment setuResponsePayment = new SetuResponsePayment();

		try {
			SetuPaymentLinkCreation setuPaymentLinkCreation = populateSetuPaymentLinkRequest(formData);
			logger.info("setuPaymentLinkCreation :: " + Utility.convertDTO2JsonString(setuPaymentLinkCreation));
			setuResponsePayment = processPayment(setuPaymentLinkCreation, merchantPGDetails);
			logger.info("setuResponsePayment :: " + Utility.convertDTO2JsonString(setuResponsePayment));

			SetuLinkGeneration setuLinkGeneration = new SetuLinkGeneration();
			setuLinkGeneration.setName(setuResponsePayment.getData().getName());
			setuLinkGeneration.setPlatformBillId(setuResponsePayment.getData().getPlatformBillID());
			setuLinkGeneration.setShortUrl(setuResponsePayment.getData().getPaymentLink().getShortURL());
			setuLinkGeneration.setStatus(String.valueOf(setuResponsePayment.getStatus()));
			setuLinkGeneration.setUpiId(setuResponsePayment.getData().getPaymentLink().getUpiID());
			setuLinkGeneration.setUpiLink(setuResponsePayment.getData().getPaymentLink().getUpiLink());
			setuLinkGeneration.setOrderId(orderId);
			setuLinkGeneration.setMerchantOrderId(formData.get("orderId").get(0));
			setuLinkGenerationRepository.save(setuLinkGeneration);

		} catch (Exception e) {
			e.getStackTrace();
			throw new ValidationExceptions(SETU_EXCEPTION, FormValidationExceptionEnums.E0077,formData.get(RETURNURL).get(0), formData);
		}

		return populateModelInfo(setuResponsePayment, model, formData, orderId, merchantPGDetails.getMerchantID(),device);
	}

	public Model populateModelInfo(SetuResponsePayment setuResponsePayment, Model model,
			MultiValueMap<String, String> formData, String orderId, String merchantId, String device) throws JsonProcessingException {

		logger.info("Inside setUPISetu()");
		//logger.info("URL RESPONSE:" + Utility.convertDTO2JsonString(setuResponsePayment));

		logger.info("Inside populateModelInfo()");

		logger.info("Short URL :: " + setuResponsePayment.getData().getPaymentLink().getShortURL());
		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		if (upiPaymentDetails.getPaymentOption().equalsIgnoreCase(PGServices.UPI.toString())) {
			upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));
		}
		upiPaymentDetailsRepository.save(upiPaymentDetails);
		model.addAttribute("returnUrl", setuResponsePayment.getData().getPaymentLink().getShortURL());
		model.addAttribute("orderId", orderId);
		model.addAttribute("merchantId", merchantId);
		model.addAttribute("apiurl", apiurl);
		model.addAttribute("device" , device);
		logger.info("Ended populateModelInfo()");
		return model;
	}

	public SetuResponsePayment processPayment(SetuPaymentLinkCreation setuPaymentLinkCreation,
			MerchantPGDetails merchantPGDetails) throws JsonProcessingException {
		logger.info("SETU Process Payment Request");
		try {
			String setutoken = SetuTokenGeneration.yieldBearerToken(merchantPGDetails.getMerchantPGAppId(), Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
			logger.info("SETU Token::" + setutoken);
			logger.info("SETU Data Send::" + Utility.convertDTO2JsonString(setuPaymentLinkCreation));
			HttpResponse<SetuResponsePayment> setuResponsePayment = Unirest.post(setuPaymentLinkCreate)					
					.header(Setu.AUTHORIZATION, SetuTokenGeneration.yieldBearerToken(merchantPGDetails.getMerchantPGAppId(), Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret())))
					.header(Setu.PRODUCTID, merchantPGDetails.getMerchantPGSaltKey())
					.header(Setu.CONTENTTYPE, Setu.CONTENTVALUE)
					.header(Setu.ACCEPT, Setu.ACCEPTVALUE)
					.body(setuPaymentLinkCreation).asObject(SetuResponsePayment.class)
					.ifFailure(SetuErrorResponse.class, r -> {
						SetuErrorResponse e = r.getBody();
						try {
							logger.info("SETU Link Generation Error::" + Utility.convertDTO2JsonString(e));
						} catch (JsonProcessingException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					});
			logger.info(
					"setuResponsePayment.getBody() :: " + Utility.convertDTO2JsonString(setuResponsePayment.getBody()));
			return setuResponsePayment.getBody();
		} catch (Exception e) {
			logger.error("Exception");
			e.printStackTrace();
		}

		return null;
	}

	public SetuPaymentLinkCreation populateSetuPaymentLinkRequest(MultiValueMap<String, String> formData)
			throws ParseException {

		SetuPaymentLinkCreation setuPaymentLinkCreation = new SetuPaymentLinkCreation();
		Amount amount = new Amount();
		amount.setCurrencyCode(SETU_CURRENCY);
		amount.setValue(Integer.parseInt(formData.get(ORDERAMOUNT).get(0)));
		setuPaymentLinkCreation.setAmount(amount);
		setuPaymentLinkCreation.setBillerBillID(Utility.populateSetuId());
		setuPaymentLinkCreation.setAmountExactness(Setu.SETU_EXACTNESS);
		return setuPaymentLinkCreation;
	}

	public Model getResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {
		
		logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID));

		String status = "";
		
		if (transactionDetails.getStatus().equalsIgnoreCase(STATUS_PAYMENT_SUCCESSFUL)) {
			status = UserStatus.SUCCESS.toString();
		} else {
			status = transactionDetails.getStatus();
		}
		logger.info("Return URL :: " + URLEncoder.encode(transactionDetails.getMerchantReturnURL(), "UTF-8"));
		logger.info("Transaction Amt:" + String.valueOf(transactionDetails.getAmount()));
		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);

		logger.info("Transaction Updated time ::" + transactionDetails.getUpdated().toString());

		/*
		String tr_time = Utility.populateDbTime();

		signature = pgGatewayUtilService.populateReturnSignature(status, transactionDetails.getPaymentOption(),
				transactionDetails.getMerchantOrderId(), String.valueOf(amt), transactionDetails.getOrderID(), tr_time,
				transactionDetails.getMerchantId(), "", "");

		logger.info("Transaction Amt final:" + amt);
		model.addAttribute(RET_RETURNURL, transactionDetails.getMerchantReturnURL().replaceAll("\\p{C}", ""));
		model.addAttribute(RET_STATUS, status);
		model.addAttribute(RET_PAYMENTOPTION, transactionDetails.getPaymentOption());
		model.addAttribute(RET_MERCHANTORDERID, transactionDetails.getMerchantOrderId());
		model.addAttribute(RET_MERCHANTORDERID, amt);
		model.addAttribute(RET_VENDORORDERID, transactionDetails.getOrderID());
		model.addAttribute(RET_TXTDATE, tr_time);
		model.addAttribute(RET_SIGNATURE, signature);

		if (transactionDetails.getMerchantAlertURL() != null) {

			logger.info("Merchant Notify URL :: " + transactionDetails.getMerchantAlertURL());
			
			notiFyURLService2Merchant.sendNotifyDetails2Merchant(status, transactionDetails.getPaymentOption(),
					transactionDetails.getMerchantOrderId(), amt, transactionDetails.getOrderID(), tr_time, signature,
					transactionDetails.getMerchantAlertURL());
		}
		pgGatewayUtilService.populateResponseToMerchant(transactionDetails, model.toString());
		logger.info("END Method getResponseProcess()");
		return model;
		*/
		
		return pgGatewayUtilService.populateReturnModel(model, amt, status, transactionDetails);
	}
	
	public void updateTransactionStatusSetu(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException, ValidationExceptions {

		logger.info("Inside method updateTransactionStatus()");

		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderIDAndAndMerchantId(
				pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERID), 
				pgGatewayUtilService.checkResponseData(responseFormData, RESP_MERCHANTDID));

		if (transactionDetails == null) {
			throw new ValidationExceptions(TRANSACTION_NOT_FOUND, FormValidationExceptionEnums.E0081);
		}

		logger.info("Transaction Update");

		if (transactionDetails.getStatus().equalsIgnoreCase(UserStatus.PENDING.toString())) {
			transactionDetails.setStatus(UserStatus.FAILED.toString());
			transactionDetails.setTxtMsg("Transaction TimeOut happened from API.");
			transactionDetails.setTxtPGTime(transactionDetails.getUpdatedAt().toString());
			transactionDetails.setSource("ReturnURL");
			transactionDetailsRepository.save(transactionDetails);
		}

		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		} else {
			throw new ValidationExceptions(MERCHANT_NOT_FOUND, FormValidationExceptionEnums.E0011);
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails), userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");

		logger.info("End method updateTransactionStatus()");
	}
	
}
