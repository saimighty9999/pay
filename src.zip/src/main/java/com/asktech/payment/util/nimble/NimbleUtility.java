package com.asktech.payment.util.nimble;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.Utility;
import com.asktech.payment.util.nimble.nimbleDto.CustomAttributesDto;
import com.asktech.payment.util.nimble.nimbleDto.IntiatePaymentRequestUpiDto;
import com.asktech.payment.util.nimble.nimbleDto.NetbankingRequestDto;
import com.asktech.payment.util.nimble.nimbleDto.NetbankingResponseDto;
import com.asktech.payment.util.nimble.nimbleDto.NimbllStatusApiRes;
import com.asktech.payment.util.nimble.nimbleDto.OrderLineItemDto;
import com.asktech.payment.util.nimble.nimbleDto.OrderRequestDto;
import com.asktech.payment.util.nimble.nimbleDto.OrderResponseDto;
import com.asktech.payment.util.nimble.nimbleDto.PaymentReqUpiDto;
import com.asktech.payment.util.nimble.nimbleDto.PaymentResUpiDto;
import com.asktech.payment.util.nimble.nimbleDto.PollingStatusApi;
import com.asktech.payment.util.nimble.nimbleDto.PollingStatusApiRes;
import com.asktech.payment.util.nimble.nimbleDto.ShippingAddressDto;
import com.asktech.payment.util.nimble.nimbleDto.TokenRequestDto;
import com.asktech.payment.util.nimble.nimbleDto.TokenResponseDto;
import com.asktech.payment.util.nimble.nimbleDto.UserDto;
import com.asktech.payment.util.nimble.nimbleDto.returnData.ReturnData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Component
public class NimbleUtility implements CashFreeFields {

    static Logger logger = LoggerFactory.getLogger(NimbleUtility.class);
    @Autowired
    PGConfigurationDetailsRepository pgConfigurationDetailsRepository;
    @Autowired
    UPIPaymentDetailsRepository upiPaymentDetailsRepository;
    @Autowired
    TransactionDetailsRepository transactionDetailsRepository;
    @Autowired
    PGGatewayUtilService pgGatewayUtilService;
    @Autowired
    MerchantPGDetailsRepository merchantPGDetailsRepository;
    @Autowired
    TransactionDetailsAllRepository transactionDetailsAllRepository;
    @Autowired
    UserDetailsRepository userDetailsRepository;
    @Autowired
    MerchantDetailsRepository merchantDetailsRepository;
    @Autowired
    NimbleModelRepo nimbleModelRepo;
    @Autowired
    NimbleSaveData nimbleSaveData;
    @Autowired
    BankListRepository bankListRepository;
    @Autowired
    WalletListRepository walletListRepository;
    @Autowired
    NotiFyURLService2Merchant notiFyURLService2Merchant;
    @Autowired
    WalletPaymentDetailsRepository walletPaymentDetailsRepository;
    @Autowired
    NBPaymentDetailsRepository nBPaymentDetailsRepository;

    @Value("${pgEndPoints.nimbblGenerateToken}")
    String nimbblGenerateToken;

    @Value("${pgEndPoints.nimbblCreateOrder}")
    String nimbblCreateOrder;

    @Value("${pgEndPoints.nimbblInitPayment}")
    String nimbblInitPayment;

    @Value("${pgEndPoints.nimbblCheckStatus}")
    String nimbblCheckStatus;

    @Value("${pgEndPoints.nimbblReturnUpiUrl}")
    String nimbblReturnUpiUrl;
    @Value("${pgEndPoints.nimbblMakePayment}")
    String nimbblMakePayment;
    @Value("${apiEndPoint}")
    String apiurl;

    public Model processRequest(MultiValueMap<String, String> formData, Model model,
            MerchantPGDetails merchantPGDetails, String orderId)
            throws JsonProcessingException, ValidationExceptions, NoSuchAlgorithmException {
        String returnURL = pgGatewayUtilService.getReturnUrl(nimbblReturnUpiUrl,
                merchantPGDetails.getMerchantID(), formData.get(PAYMENT_OPTION).get(0));

        NimbleModel nimbleModel = new NimbleModel();
        nimbleModel.setMerchantId(merchantPGDetails.getMerchantID());
        nimbleModel.setOrderId(orderId);
        nimbleModel.setAccessKey(merchantPGDetails.getMerchantPGAppId());
        nimbleModel.setAccessSecret(Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
        nimbleModelRepo.save(nimbleModel);
        // Get Token
        TokenResponseDto tokenResponse = createToken(merchantPGDetails);
        nimbleModel.setTokenResponse(Utility.convertDTO2JsonString(tokenResponse));
        nimbleModelRepo.save(nimbleModel);
        // Get Order
        String bearerToken = "Bearer " + tokenResponse.getToken();
        OrderResponseDto orderResponse = createOrder(formData, merchantPGDetails, orderId, returnURL,
                bearerToken);
        nimbleModel.setOrderCreationRes(Utility.convertDTO2JsonString(orderResponse));
        nimbleModelRepo.save(nimbleModel);
        // UPI Request
        logger.info("Form Data::" + GeneralUtils.MultiValueMaptoJson(formData));
        String xKey = tokenResponse.getAuth_principal().getSub_merchant_id() + "-"
                + createMd5(tokenResponse.getToken());
        String userToken = orderResponse.getUser().getToken();
        if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
            logger.info("UPI Request");

            PaymentResUpiDto paymentResUpiDto = collectUpiPaymentReq(orderResponse, bearerToken, userToken,
                    xKey, formData.get(UPI_VPI).get(0));
            if (paymentResUpiDto.getStatus().equalsIgnoreCase("PENDING")
                    && paymentResUpiDto.getStatus_code().equals("200")) {
                nimbleModel.setPaymentInitRes(Utility.convertDTO2JsonString(paymentResUpiDto));
                nimbleModel.setPgOrderId(paymentResUpiDto.getOrder_id());
                nimbleModel.setPgTransId((paymentResUpiDto.getTransaction_id()));
                nimbleModel.setTrxType(formData.get(PAYMENT_OPTION).get(0).toUpperCase());
                nimbleModelRepo.save(nimbleModel);
                model.addAttribute("orderId", orderId);
                model.addAttribute("amount", Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
                model.addAttribute("apiurl", pgGatewayUtilService.getReturnUrl(apiurl,
                        merchantPGDetails.getMerchantID(), formData.get(PAYMENT_OPTION).get(0)));
            } else {
                nimbleModel.setPaymentInitRes(Utility.convertDTO2JsonString(paymentResUpiDto));
                nimbleModel.setTrxType(formData.get(PAYMENT_OPTION).get(0).toUpperCase());
                nimbleModelRepo.save(nimbleModel);
                model.addAttribute("errorMsg", "Invalid Request");
                return model;
            }

        } else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
            BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
                    formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(),
                    UserStatus.ACTIVE.toString(), merchantPGDetails.getMerchantPGName());
            NetbankingResponseDto netbankingResponseDto = netBankingPaymentReq(orderResponse, bearerToken, userToken,
                    xKey, bankList.getPgBankCode(), returnURL);
            nimbleModel.setPaymentInitRes(Utility.convertDTO2JsonString(netbankingResponseDto));
            nimbleModel.setPgOrderId(netbankingResponseDto.getOrder_id());
            nimbleModel.setPgTransId((netbankingResponseDto.getTransaction_id()));
            nimbleModel.setTrxType(formData.get(PAYMENT_OPTION).get(0).toUpperCase());
            nimbleModelRepo.save(nimbleModel);
            if (netbankingResponseDto.getStatus().equalsIgnoreCase("PENDING")
                    && netbankingResponseDto.getStatus_code().equals("200")) {
                model.addAttribute("redirect_url", netbankingResponseDto.getExtra_info().getData().getRedirectUrl());
            } else {
                model.addAttribute("errorMsg", "Invalid Request");
                return model;
            }

        } else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")) {
            WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
                    formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
                    merchantPGDetails.getMerchantPGName());
            NetbankingResponseDto netbankingResponseDto = walletBankingPaymentReq(orderResponse, bearerToken, userToken,
                    xKey, walletList.getPaymentcodepg());
            nimbleModel.setPaymentInitRes(Utility.convertDTO2JsonString(netbankingResponseDto));
            nimbleModel.setPgOrderId(netbankingResponseDto.getOrder_id());
            nimbleModel.setPgTransId((netbankingResponseDto.getTransaction_id()));
            nimbleModel.setTrxType(formData.get(PAYMENT_OPTION).get(0).toUpperCase());
            nimbleModelRepo.save(nimbleModel);
            if (netbankingResponseDto.getStatus().equalsIgnoreCase("PENDING")
                    && netbankingResponseDto.getStatus_code().equals("200")) {
                model.addAttribute("redirect_url", netbankingResponseDto.getExtra_info().getData().getRedirectUrl());
            } else {
                model.addAttribute("errorMsg", "Invalid Request");
                return model;
            }
        } else {
            logger.info("INVALID Request::" + formData.get(PAYMENT_OPTION).get(0));
            model.addAttribute("errorMsg", "Invalid Request");
            return model;
        }
        return model;
    }

    public TokenResponseDto createToken(MerchantPGDetails merchantPGDetails) throws JsonProcessingException {
        TokenResponseDto tokenResponse = getToken(merchantPGDetails.getMerchantPGAppId(),
                Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
        logger.info("Token::" + Utility.convertDTO2JsonString(tokenResponse));
        String token = tokenResponse.getToken();
        tokenResponse.setToken(token);
        return tokenResponse;
    }

    public OrderResponseDto createOrder(MultiValueMap<String, String> formData,
            MerchantPGDetails merchantPGDetails, String orderId, String returnURL, String token)
            throws JsonProcessingException, NoSuchAlgorithmException {

        // GET THE TOKEN
        OrderRequestDto orderRequest = new OrderRequestDto();
        UserDto user = new UserDto();
        ShippingAddressDto shippingAddress = new ShippingAddressDto();
        OrderLineItemDto orderLineItem = new OrderLineItemDto();
        CustomAttributesDto customAttributes = new CustomAttributesDto();
        
        orderRequest.setAmount_before_tax(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
        if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
            orderRequest.setCallback_mode("callback_url_noredirect");
        } else {
            orderRequest.setCallback_mode("callback_url_redirect");
        }
        orderRequest.setCallback_url(returnURL);
        orderRequest.setCurrency("INR");
        orderRequest.setInvoice_id(orderId);
        orderRequest.setDevice_user_agent(
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.128 Safari/537.36");
        orderRequest.setOrder_from_ip("120.68.23.12");
        orderRequest.setTax(0);
        // ADD USER DATA
        user.setMobile_number(formData.get(CUSTOMERPHONE).get(0));
        user.setEmail(formData.get(CUSTOMEREMAIL).get(0));
        user.setFirst_name(formData.get(CUSOMERNAME).get(0));
        user.setLast_name(formData.get(CUSOMERNAME).get(0));
        orderRequest.setUser(user);
        // ADD SHIPPING ADDRESS
        shippingAddress.setAddress_1("NetaJi Shubhash CHandra bose");
        shippingAddress.setStreet("Pritampura");
        shippingAddress.setLandmark("No");
        shippingAddress.setArea("Delhi");
        shippingAddress.setCity("Delhi");
        shippingAddress.setState("Delhi");
        shippingAddress.setPincode("110001");
        shippingAddress.setAddress_type("Office");

        orderRequest.setShipping_address(shippingAddress);
        orderRequest.setTotal_amount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));

        // ADD ORDER LINE ITEMS
        orderLineItem.setReferrer_platform_sku_id("SKU" + orderId);
        orderLineItem.setTitle("Triangle");
        orderLineItem.setDescription("description");
        orderLineItem.setQuantity("1");
        orderLineItem.setRate("1");
        orderLineItem.setAmount_before_tax(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
        orderLineItem.setTotal_amount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
        orderLineItem.setImage_url("https://cdn.pixabay.com/photo/2021/02/15/15/25/rhomboid-6018215_960_720.jpg");
        orderLineItem.setTax("0");
        List orderLineItems = new ArrayList<>();
        orderLineItems.add(orderLineItem);

        orderRequest.setOrder_line_items(orderLineItems);

        // ADD CUSTOM ATTRIBUTES
        customAttributes.setKey_1(orderId);
        customAttributes.setKey_2("val_2");

        orderRequest.setCustom_attributes(customAttributes);

        OrderResponseDto orderResponse = createOrderRequest(orderRequest, token);
        logger.info("orderResponse::" + Utility.convertDTO2JsonString(orderResponse));

        // INTIATE PAYEMENT

        // System.out.println("\n\n\n");
        // System.out.println(Utility.convertDTO2JsonString(intiatePaymentResponse));
        // System.out.println("\n\n\n");
        return orderResponse;
    }

    public void initiateUpiPayment(OrderResponseDto orderResponse, TokenResponseDto tokenResponse,
            MultiValueMap<String, String> formData) throws JsonProcessingException, NoSuchAlgorithmException {
        IntiatePaymentRequestUpiDto intiatePaymentRequest = new IntiatePaymentRequestUpiDto();
        intiatePaymentRequest.setOrder_id(orderResponse.getOrder_id());
        intiatePaymentRequest.setPayment_mode("UPI");
        intiatePaymentRequest.setUpi_id(formData.get(UPI_VPI).get(0));

        String xKey = tokenResponse.getAuth_principal().getSub_merchant_id() + "-"
                + createMd5(tokenResponse.getToken());
        String userToken = orderResponse.getUser().getToken();
        // intiatePaymentReq(intiatePaymentRequest, token, userToken, xKey);
        String token = "Bearer " + tokenResponse.getToken();

        IntiatePaymentResponseDto intiatePaymentResponse = intiatePaymentReq(intiatePaymentRequest, token, userToken,
                xKey);
        intiatePaymentResponse.getStatus();
    }

    public TokenResponseDto getToken(String key, String keyScreat) throws JsonProcessingException {
        TokenRequestDto tokenRequest = new TokenRequestDto();
        tokenRequest.setAccess_key(key);
        tokenRequest.setAccess_secret(keyScreat);
        TokenResponseDto tokenResponse = GetTokenRequest(tokenRequest);
        return tokenResponse;
    }

    public TokenResponseDto GetTokenRequest(TokenRequestDto tokenRequest)
            throws JsonProcessingException {

        logger.info("TokenReq::" + Utility.convertDTO2JsonString(tokenRequest));
        HttpResponse<TokenResponseDto> tResponse = Unirest
                .post(nimbblGenerateToken)
                .body(Utility.convertDTO2JsonString(tokenRequest)).asObject(TokenResponseDto.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("NibleToken Status Request Response Error::" + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });

        // logger.info("Response :: " +
        // Utility.convertDTO2JsonString(tResponse.getBody()));
        return tResponse.getBody();

    }

    public OrderResponseDto createOrderRequest(OrderRequestDto orderRequest, String bearerToken)
            throws JsonProcessingException {

        logger.info("Create Order Req::" + Utility.convertDTO2JsonString(orderRequest));
        HttpResponse<OrderResponseDto> tResponse = Unirest.post(nimbblCreateOrder)
                .header("Authorization", bearerToken)
                .body(Utility.convertDTO2JsonString(orderRequest)).asObject(OrderResponseDto.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("NibleError " + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });

        logger.info("Response :: " + Utility.convertDTO2JsonString(tResponse.getBody()));
        return tResponse.getBody();

    }

    public IntiatePaymentResponseDto intiatePaymentReq(IntiatePaymentRequestUpiDto orderRequest, String bearerToken,
            String userToken, String xkey)
            throws JsonProcessingException {

        logger.info("nimbblInitPayment req::" + Utility.convertDTO2JsonString(orderRequest));
        HttpResponse<IntiatePaymentResponseDto> tResponse = Unirest
                .post(nimbblInitPayment).header("Authorization", bearerToken)
                .header("x-nimbbl-user-token", userToken).header("x-nimbbl-key", xkey)
                .body(Utility.convertDTO2JsonString(orderRequest)).asObject(IntiatePaymentResponseDto.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("Nibble status api " + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });
        logger.info("Response :: " + Utility.convertDTO2JsonString(tResponse.getBody()));
        return tResponse.getBody();

    }

    public String getStatusCheck(String orderId)
            throws JsonProcessingException, NoSuchAlgorithmException {

        NimbleModel nimbOrder = nimbleModelRepo.findByOrderId(orderId);
        TokenResponseDto tokenResponse = getToken(nimbOrder.getAccessKey(),
                nimbOrder.getAccessSecret());
        PollingStatusApi pollingStatusApi = new PollingStatusApi();
        pollingStatusApi.setOrder_id(nimbOrder.getPgOrderId());
        pollingStatusApi.setTransaction_id(nimbOrder.getPgTransId());
        pollingStatusApi.setPayment_mode(nimbOrder.getTrxType());
        logger.info(Utility.convertDTO2JsonString(tokenResponse));
        logger.info(Utility.convertDTO2JsonString(pollingStatusApi));
        String xKey = tokenResponse.getAuth_principal().getSub_merchant_id() + "-"
                + createMd5(tokenResponse.getToken());
        logger.info(xKey);
        
        HttpResponse<PollingStatusApiRes> tResponse = Unirest
                .post(nimbblCheckStatus).body(Utility.convertDTO2JsonString(pollingStatusApi))
                .header("Authorization", "Bearer " + tokenResponse.getToken())
                .header("x-nimbbl-key", xKey)
                .asObject(PollingStatusApiRes.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("Nibble status api " + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });
        logger.info(Utility.convertDTO2JsonString(tResponse.getBody()));
        // return tResponse.getBody();
        return "{\"status\":\"" + tResponse.getBody().getStatus().toUpperCase() +
                "\"}";
    }

    // public String getStatusCheck(String orderId)
    // throws JsonProcessingException, NoSuchAlgorithmException {

    // NimbleModel nimbOrder = nimbleModelRepo.findByOrderId(orderId);
    // TokenResponseDto tokenResponse = getToken(nimbOrder.getAccessKey(),
    // nimbOrder.getAccessSecret());
    // logger.info(Utility.convertDTO2JsonString(tokenResponse));
    // logger.info(nimbblCheckStatus + "/" + nimbOrder.getPgTransId());
    // HttpResponse<NimbllStatusApiRes> tResponse = Unirest
    // .get(nimbblCheckStatus + "/" + nimbOrder.getPgTransId())
    // .header("Authorization", "Bearer " + tokenResponse.getToken())
    // .asObject(NimbllStatusApiRes.class)
    // .ifFailure(Object.class, r -> {
    // Object e = r.getBody();
    // try {
    // logger.info("Nibble status api " + Utility.convertDTO2JsonString(e));
    // } catch (JsonProcessingException e1) {
    // TODO Auto-generated catch block
    // e1.printStackTrace();
    // }
    // });
    // logger.info(Utility.convertDTO2JsonString(tResponse.getBody()));
    // logger.info(Utility.convertDTO2JsonString(tResponse.getBody()));
    // return tResponse.getBody();
    // return "{\"status\":\"" + tResponse.getBody().getStatus().toUpperCase() +
    // "\"}";
    // }

    public PollingStatusApiRes getFinalStatus(String orderId)
            throws JsonProcessingException, NoSuchAlgorithmException {

        NimbleModel nimbOrder = nimbleModelRepo.findByOrderId(orderId);
        TokenResponseDto tokenResponse = getToken(nimbOrder.getAccessKey(), nimbOrder.getAccessSecret());
        PollingStatusApi pollingStatusApi = new PollingStatusApi();
        pollingStatusApi.setOrder_id(nimbOrder.getPgOrderId());
        pollingStatusApi.setTransaction_id(nimbOrder.getPgTransId());
        pollingStatusApi.setPayment_mode(nimbOrder.getTrxType().toUpperCase());
        if (nimbOrder.getTrxType().toUpperCase().equals("NB")) {
            pollingStatusApi.setPayment_mode("Netbanking");
        }
        if (nimbOrder.getTrxType().toUpperCase().equals("WALLET")) {
            pollingStatusApi.setPayment_mode("Wallet");
        }
        logger.info(Utility.convertDTO2JsonString(tokenResponse));
        logger.info(Utility.convertDTO2JsonString(pollingStatusApi));
        String xKey = tokenResponse.getAuth_principal().getSub_merchant_id() + "-"
                + createMd5(tokenResponse.getToken());
        logger.info(xKey);
        HttpResponse<PollingStatusApiRes> tResponse = Unirest
                .post(nimbblCheckStatus).body(Utility.convertDTO2JsonString(pollingStatusApi))
                .header("Authorization", "Bearer " + tokenResponse.getToken())
                .header("x-nimbbl-key", xKey)
                .asObject(PollingStatusApiRes.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("Nibble status api " + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });
        logger.info(Utility.convertDTO2JsonString(tResponse.getBody()));
        // return tResponse.getBody();
        nimbOrder.setPaymentStatusRes(Utility.convertDTO2JsonString(tResponse.getBody()));
        nimbleModelRepo.save(nimbOrder);
        return tResponse.getBody();
    }

    // public NimbllStatusApiRes checkFinalStatus(String orderId)
    // throws JsonProcessingException {
    // NimbleModel nimbOrder = nimbleModelRepo.findByOrderId(orderId);
    // TokenResponseDto tokenResponse = getToken(nimbOrder.getAccessKey(),
    // nimbOrder.getAccessSecret());
    // logger.info(Utility.convertDTO2JsonString(tokenResponse));
    // HttpResponse<NimbllStatusApiRes> tResponse = Unirest
    // .get(nimbblCheckStatus + "/" + nimbOrder.getPgTransId())
    // .header("Authorization", "Bearer " + tokenResponse.getToken())
    // .asObject(NimbllStatusApiRes.class)
    // .ifFailure(Object.class, r -> {
    // Object e = r.getBody();
    // try {
    // logger.info("Nibble status api " + Utility.convertDTO2JsonString(e));
    // } catch (JsonProcessingException e1) {
    // // TODO Auto-generated catch block
    // e1.printStackTrace();
    // }
    // });
    // logger.info(Utility.convertDTO2JsonString(tResponse.getBody()));
    // return tResponse.getBody();
    // }

    public PaymentResUpiDto collectUpiPaymentReq(OrderResponseDto orderResponse, String bearerToken,
            String userToken, String xkey, String upiid)
            throws JsonProcessingException {

        PaymentReqUpiDto orderRequest = new PaymentReqUpiDto();
        orderRequest.setFlow("collect");
        orderRequest.setPayment_mode("UPI");
        orderRequest.setUpi_id(upiid);
        orderRequest.setOrder_id(orderResponse.getOrder_id());
        logger.info("nimbblcollectUpiPayment req::" + Utility.convertDTO2JsonString(orderRequest));
        logger.info("nimbblcollectUpiPayment Token ::" + bearerToken);
        logger.info("nimbblcollectUpiPayment xkey ::" + xkey);
        logger.info("nimbblcollectUpiPayment userToken ::" + userToken);
        HttpResponse<PaymentResUpiDto> tResponse = Unirest
                .post(nimbblMakePayment).header("Authorization", bearerToken)
                .header("x-nimbbl-user-token", userToken).header("x-nimbbl-key", xkey)
                .body(Utility.convertDTO2JsonString(orderRequest)).asObject(PaymentResUpiDto.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("Nibble Collect Payment api " + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });
        logger.info("Response Upi Collect:: " + Utility.convertDTO2JsonString(tResponse.getBody()));
        return tResponse.getBody();

    }

    public Model getResponseProcess(TransactionDetails transactionDetails, Model model)
            throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
            UserException, ValidationExceptions {

        String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
        return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
    }

    public TransactionDetails updateTransactionStatus(String orderId, String type)
            throws ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
            InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException {
        TransactionDetails transactionDetails = null;
        if (type.equals("UPI")) {
            transactionDetails = transactionDetailsRepository
                    .findByOrderID(orderId);

            if (transactionDetails != null) {
                PollingStatusApiRes chkvaluest = getFinalStatus(orderId);
                transactionDetails.setStatus(chkvaluest.getStatus().toUpperCase());
                transactionDetails.setTxtMsg(chkvaluest.getMessage());
                transactionDetails.setPgOrderID(chkvaluest.getNimbbl_transaction_id());
                transactionDetails.setTxtPGTime(Utility.populateDbTime());
                transactionDetails.setSource("ReturnURL");
                logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));
                transactionDetailsRepository.save(transactionDetails);

            }
        } else {
            ObjectMapper objectMapper = new ObjectMapper();
            ReturnData returnData = objectMapper.readValue(orderId, ReturnData.class);
            if (returnData != null) {
                NimbleModel nimbleModel = nimbleModelRepo.findByPgOrderId(returnData.getNimbbl_order_id());
                transactionDetails = transactionDetailsRepository
                        .findByOrderID(nimbleModel.getOrderId());
                PollingStatusApiRes chkvaluest = getFinalStatus(nimbleModel.getOrderId());
                transactionDetails.setStatus(chkvaluest.getStatus().toUpperCase());
                transactionDetails.setTxtMsg(chkvaluest.getMessage());
                transactionDetails.setPgOrderID(chkvaluest.getNimbbl_transaction_id());
                transactionDetails.setTxtPGTime(Utility.populateDbTime());
                transactionDetails.setSource("ReturnURL");
                logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));
                transactionDetailsRepository.save(transactionDetails);
            }
        }
        logger.info("Transaction Update");

        logger.info("Get User Details::" + transactionDetails.getUserID());
        UserDetails userDetails = null;
        try {
            userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
            logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("Unable to get Data" + e.getMessage());
        }
        MerchantDetails merchantDetails = null;
        try {
            merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
            logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("Unable to get Data" + e.getMessage());
        }
        if (merchantDetails != null) {
            if (!merchantDetails.getTr_mail_flag().isEmpty()) {
                logger.info("merchantDetails getTr_mail_flag not empty");
                if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
                    logger.info("merchantDetails getTr_mail_flag Y");
                    pgGatewayUtilService.createMailRepo(
                            pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
                            merchantDetails.getMerchantEMail(), "MerchantEmail");
                    logger.info("createMailRepo Complete");
                }
            }
        }
        logger.info("createMailRepo 2");
        pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
                userDetails.getEmailId(), "CustomerEmail");
        logger.info("createMailRepo Email Complete");
        logger.info("Send SMS Start");
        pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
        logger.info("Send SMS End");

        logger.info("End method updateTransactionStatus()");

        return transactionDetails;
    }

    public NetbankingResponseDto netBankingPaymentReq(OrderResponseDto orderResponse, String bearerToken,
            String userToken, String xkey, String bank, String returnUrl)
            throws JsonProcessingException {
        NetbankingRequestDto netbankingRequestDto = new NetbankingRequestDto();
        netbankingRequestDto.setBank(bank);
        netbankingRequestDto.setOrder_id(orderResponse.getOrder_id());
        netbankingRequestDto.setOffer_id("");
        netbankingRequestDto.setPayment_mode("Netbanking");
        netbankingRequestDto.setCallback_url(returnUrl);
        logger.info("nimbblInitPayment req::" + Utility.convertDTO2JsonString(netbankingRequestDto));
        HttpResponse<NetbankingResponseDto> tResponse = Unirest
                .post(nimbblInitPayment).header("Authorization", bearerToken)
                .header("x-nimbbl-user-token", userToken).header("x-nimbbl-key", xkey)
                .body(Utility.convertDTO2JsonString(netbankingRequestDto)).asObject(NetbankingResponseDto.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("Nibble Netbanking Payment api " + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });
        logger.info("Response :: " + Utility.convertDTO2JsonString(tResponse.getBody()));
        return tResponse.getBody();

    }

    public NetbankingResponseDto walletBankingPaymentReq(OrderResponseDto orderResponse, String bearerToken,
            String userToken, String xkey, String bank)
            throws JsonProcessingException {
        NetbankingRequestDto netbankingRequestDto = new NetbankingRequestDto();
        netbankingRequestDto.setBank(bank);
        netbankingRequestDto.setOrder_id(orderResponse.getOrder_id());
        netbankingRequestDto.setPayment_mode("Wallet");
        logger.info("nimbblWalletPayment req::" + Utility.convertDTO2JsonString(netbankingRequestDto));
        HttpResponse<NetbankingResponseDto> tResponse = Unirest
                .post(nimbblInitPayment).header("Authorization", bearerToken)
                .header("x-nimbbl-user-token", userToken).header("x-nimbbl-key", xkey)
                .body(Utility.convertDTO2JsonString(netbankingRequestDto)).asObject(NetbankingResponseDto.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("Nibble Wallet Payment api " + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });
        logger.info("Response :: " + Utility.convertDTO2JsonString(tResponse.getBody()));
        return tResponse.getBody();

    }

    // FUNCTION TO PUT IN UTILITY
    public static String createMd5(String key) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] messageDigest = md.digest(key.getBytes());
        BigInteger no = new BigInteger(1, messageDigest);

        // Convert message digest into hex value
        String hashtext = no.toString(16);
        while (hashtext.length() < 32) {
            hashtext = "0" + hashtext;
        }
        return hashtext;
    }

}
