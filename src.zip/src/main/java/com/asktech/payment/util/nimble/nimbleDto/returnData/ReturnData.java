package com.asktech.payment.util.nimble.nimbleDto.returnData;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReturnData {
    private String nimbbl_transaction_id;
    private Boolean is_callback;
    private String nimbbl_order_id;
    private String message;
    private String nimbbl_signature;
    private User user;
    private Transaction transaction;
    private String status;
    private Order order;
 
}
