package com.asktech.payment.util.neoCred;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.easePay.EasePayCallBackResp;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.PaymentLogs;
import com.asktech.payment.util.Utility;
import com.asktech.payment.util.neoCred.neoCredDto.BankDetails;
import com.asktech.payment.util.neoCred.neoCredDto.CreateCustomerVa;
import com.asktech.payment.util.neoCred.neoCredDto.CreateVaResponse;
import com.asktech.payment.util.neoCred.neoCredDto.Customer;
import com.asktech.payment.util.neoCred.neoCredDto.CustomerAuthenticate;
import com.asktech.payment.util.neoCred.neoCredDto.CustomerAuthenticateResponse;
import com.asktech.payment.util.neoCred.neoCredDto.NeoStatusResponse;
import com.asktech.payment.util.neoCred.neoCredDto.PaymentDetails;
import com.asktech.payment.util.neoCred.neoCredDto.UpiDetails;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Component
public class NeoCredUtility implements CashFreeFields {
    static Logger logger = LoggerFactory.getLogger(NeoCredUtility.class);
    @Autowired
    PGConfigurationDetailsRepository pgConfigurationDetailsRepository;
    @Autowired
    UPIPaymentDetailsRepository upiPaymentDetailsRepository;
    @Autowired
    TransactionDetailsRepository transactionDetailsRepository;
    @Autowired
    PGGatewayUtilService pgGatewayUtilService;
    @Autowired
    MerchantPGDetailsRepository merchantPGDetailsRepository;
    @Autowired
    TransactionDetailsAllRepository transactionDetailsAllRepository;
    @Autowired
    UserDetailsRepository userDetailsRepository;
    @Autowired
    MerchantDetailsRepository merchantDetailsRepository;
    @Autowired
    private PaymentLogs paymentLogs;

    @Value("${pgEndPoints.neocredAuthRequest}")
    String neocredAuthRequest;
    @Value("${pgEndPoints.neocredPayRequest}")
    String neocredPayRequest;
    @Value("${pgEndPoints.neoCredReturnUrl}")
    String neoCredReturnUrl;
    @Value("${apiEndPoint}")
    String apiurl;

    private final String upiInitCode = "191203";
    private final String ifsccode = "RATN0000190";
    private final String accountnumber = "409910893733";

    @Autowired
    NeoCredSaveData neoCredSaveData;

    public Model processRequest(MultiValueMap<String, String> formData, Model model,
            MerchantPGDetails merchantPGDetails, String orderId, String returnURL)
            throws JsonProcessingException, ValidationExceptions {
        logger.info("Neo Process Request");
        String upiadd = getUpiAddress(formData, merchantPGDetails);
        logger.info("Neo Process::" + upiadd);
        if (upiadd == null) {
            model.addAttribute("errorMsg", "Invalid UPI");
            return model;
        }
        // String upiqr = Utility.getUpiString(upiadd, formData.get(CUSOMERNAME).get(0),
        // orderId, orderId,
        // "pay_" + orderId,
        // Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)), null);

        String upiqr = "upi://pay?pa=" + upiadd + "&pn=Merchant&am="
                + Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)) + "&tn=" + "pay_" + orderId + "&tid="
                + orderId;
        logger.info("Neo upiadd::" + upiqr);
        neoCredSaveData.saveNeoTransaction(orderId, merchantPGDetails.getMerchantID(), upiadd, null, upiqr);
        if (upiqr == null) {
            model.addAttribute("errorMsg", "Invalid UPI");
            return model;
        }
        model.addAttribute("upilink", upiqr);
        model.addAttribute("apiurl", apiurl);
        model.addAttribute("orderId", orderId);
        model.addAttribute("amount", Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
        model.addAttribute("apiurl", pgGatewayUtilService.getReturnUrl(apiurl,
                merchantPGDetails.getMerchantID(), formData.get(PAYMENT_OPTION).get(0)));
        return model;
    }

    public String getUpiAddress(MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails)
            throws JsonProcessingException {
        // Customer customer = new Customer();
        // customer.setFirstName(formData.get(ORDERCURRENCY).get(0));
        // String paymentId = upiInitCode + formData.get(CUSTOMERPHONE).get(0) +
        // "@yesbankltd";
        String paymentId = upiInitCode + formData.get(CUSTOMERPHONE).get(0) + "@yesbankltd";
        logger.info("Neo paymentId::" + paymentId);
        if (neoCredSaveData.checkUpiId(paymentId)) {
            return paymentId;
        }
        logger.info("Neo get AuthToken");
        String getAuthToken = getAutheticateToken(merchantPGDetails.getMerchantPGAppId(),
                Encryption.decryptCardNumberOrExpOrCvv((merchantPGDetails.getMerchantPGSecret())));
        logger.info("Neo AuthToken::" + getAuthToken);
        Customer customer = new Customer();
        BankDetails bank = new BankDetails();
        PaymentDetails paymentDetail = new PaymentDetails();
        UpiDetails upi = new UpiDetails();

        customer.setFirstName(formData.get(CUSOMERNAME).get(0));
        customer.setLastName(formData.get(CUSOMERNAME).get(0));
        customer.setMobileNumber(formData.get(CUSTOMERPHONE).get(0));

        bank.setIfscCode(ifsccode);
        bank.setAccountNumber(accountnumber);
        List<BankDetails> bankDetailsList = new ArrayList<>();
        bankDetailsList.add(bank);
        customer.setBankDetails(bankDetailsList);
        customer.setCloseByDate("");
        customer.setMobileNumber(formData.get(CUSTOMERPHONE).get(0));
        paymentDetail.setPaymentId(paymentId);
        paymentDetail.setPaymentMode("UPI");
        upi.setMerchantName("Merchant");
        upi.setBrandName("Collect Bot");
        upi.setMcc("6540");
        upi.setLegalName("Neokred Technologies Private Limited");
        upi.setFranchise("NEOKRED");
        upi.setMerchantType("LARGE");
        upi.setOwnerShipType("PRIVATE");
        upi.setGenre("ONLINE");
        upi.setOnboardingType("Aggregator");
        paymentDetail.setUpiDetails(upi);

        List<PaymentDetails> paymentDetailslist = new ArrayList<>();
        paymentDetailslist.add(paymentDetail);
        customer.setPaymentDetails(paymentDetailslist);
        CustomerAuthenticateResponse customerAuthenticateResponse = sendRequest(customer, merchantPGDetails,
                getAuthToken);
        if (customerAuthenticateResponse != null) {
            if (customerAuthenticateResponse.getStatus().equals("SUCCESS")) {
                return paymentId;
            }
        }
        return null;
    }

    public CreateVaResponse createVpaAccount(MultiValueMap<String, String> formData, String orderId) {
        return null;
    }

    public String updateFinalStatus(String orderId) {
        return null;
    }

    public String getAutheticateToken(String username, String password) throws JsonProcessingException {

        CustomerAuthenticate authenticate = new CustomerAuthenticate();
        authenticate.setUsername(username);
        authenticate.setPassword(password);
        logger.info("Neo Auth Req::" + Utility.convertDTO2JsonString(authenticate));
        CustomerAuthenticateResponse customerAuthenticateResponse = sendAuthenticateRequest(authenticate);
        logger.info("Neo Auth Res::" + Utility.convertDTO2JsonString(customerAuthenticateResponse));
        return customerAuthenticateResponse.getData();

    }

    public EasePayCallBackResp callBackTransactionStatus(String jsonObject)
            throws JsonMappingException, JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        NeoStatusResponse neoStatusResponse = objectMapper.readValue(jsonObject,
                NeoStatusResponse.class);
        paymentLogs.saveLogs(null, neoStatusResponse.getMerchantRequestId(), "PAYMENTCALLBACK", jsonObject, null, null);

        TransactionDetails transactionDetails = transactionDetailsRepository
                .findByOrderID(neoStatusResponse.getMerchantRequestId());
        neoCredSaveData.updateNeoTransaction(neoStatusResponse.getMerchantRequestId(),
                neoStatusResponse.getGatewayResponseStatus(), null, Utility.convertDTO2JsonString(neoStatusResponse));
        if (transactionDetails != null) {
            if (neoStatusResponse.getGatewayResponseCode().equals("00")) {
                transactionDetails.setStatus("SUCCESS");
            } else {
                transactionDetails.setStatus("FAILED");
            }
            transactionDetails.setTxtMsg(neoStatusResponse.getGatewayResponseMessage());
            transactionDetails.setPgOrderID(
                    neoStatusResponse.getGatewayTransactionId() + "-" + neoStatusResponse.getGatewayReferenceId());
            transactionDetails.setTxtPGTime(Utility.populateDbTime());
            transactionDetails.setSource("CallBackUrl");

            logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));
            transactionDetailsRepository.save(transactionDetails);
            // populateEasePayTransDetails(neoStatusResponse.getMerchantRequestId(),
            // easePayCallBackResponse);

            return generateResponse("300", "Status Updated Successfully", "Success");
        }
        logger.info("Transaction Update");

        return generateResponse("302", "Transaction Failed", "Failed");
    }

    private EasePayCallBackResp generateResponse(String respCode, String response, String respMsg) {

        EasePayCallBackResp easePayCallBackResp = new EasePayCallBackResp();
        easePayCallBackResp.setRespCode(respCode);
        easePayCallBackResp.setRespMsg(respMsg);
        easePayCallBackResp.setResponse(response);

        return easePayCallBackResp;
    }

    public TransactionDetails getUPIDBStatusDetails(String orderId) throws Exception {

        TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(orderId);
        if (transactionDetails == null) {
            return null;
        }
        if (!transactionDetails.getPgType().contains("NEO")) {
            return null;
        }
        if (Utility.checkIfTimePassed(String.valueOf(transactionDetails.getCreated().getTime()), 900)) {
            return null;
        }

        logger.info("neoStatusResponseDecode::" + Utility.convertDTO2JsonString(transactionDetails));
        return transactionDetails;
    }

    public CustomerAuthenticateResponse sendAuthenticateRequest(CustomerAuthenticate authenticate)
            throws JsonProcessingException {

        logger.info("Neo sendAuthenticateRequest::" + Utility.convertDTO2JsonString(authenticate));
        HttpResponse<CustomerAuthenticateResponse> customerAuthenticateResponse = Unirest
                .post(neocredAuthRequest).header("Content-Type", "application/json")
                .body(Utility.convertDTO2JsonString(authenticate)).asObject(CustomerAuthenticateResponse.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("Customer Authentication Response" + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();

                    }
                });
        logger.info("customerAuthenticateResponse::"
                + Utility.convertDTO2JsonString(customerAuthenticateResponse.getBody()));
        return customerAuthenticateResponse.getBody();

        // logger.info("Response :: " +
        // Utility.convertDTO2JsonString(SabPaisaTransactionDetails.getBody()));

    }

    public CustomerAuthenticateResponse sendRequest(Customer customer, MerchantPGDetails merchantPGDetails,
            String token)
            throws JsonProcessingException {

        logger.info("Neo sendRequest::" + Utility.convertDTO2JsonString(customer) + ":mid::"
                + merchantPGDetails.getMerchantPGAdd1());
        HttpResponse<CustomerAuthenticateResponse> customerAuthenticateResponse = Unirest
                .post(neocredPayRequest).header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + token)
                .header("clientHashId", merchantPGDetails.getMerchantPGAdd1())
                .body(Utility.convertDTO2JsonString(customer)).asObject(CustomerAuthenticateResponse.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("Customer Authentication Response::" + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });

        logger.info("Response :: " + Utility.convertDTO2JsonString(customerAuthenticateResponse.getBody()));
        return customerAuthenticateResponse.getBody();
    }
}

// public static void main(String[] args) {

// try {
// getAutheticateToken();
// } catch (JsonProcessingException e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }

// }
