package com.asktech.payment.util.atom;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.ErrorValues;
import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constant.atom.AtomConstants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.atom.AtomTransactionStatus;
import com.asktech.payment.dto.utilityServices.CardBinDetails;
import com.asktech.payment.enums.FormValidationExceptionEnums;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.AtomTransactionDetails;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.PGConfigurationDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.repository.AtomTransactionDetailsRepository;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.Utility;
import com.atom.ipg.data.security.SecureCardData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class AtomUtilityClass implements CashFreeFields, AtomConstants, ErrorValues {

	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	AtomTransactionDetailsRepository atomTransactionDetailsRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	PGConfigurationDetailsRepository pgConfigurationDetailsRepository;

	@Value("${pgEndPoints.atomReturnURL}")
	String atomReturnURL;
	@Value("${pgEndPoints.atomSubmitURL}")
	String atomSubmitURL;
	@Value("${pgEndPoints.atomStatusAPiEndPoint}")
	String atomStatusAPiEndPoint;
	@Value("${folderconfiguration.atomCallBack}")
	String atomCallBack;
	
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
	LocalDateTime now = LocalDateTime.now();

	static Logger logger = LoggerFactory.getLogger(AtomUtilityClass.class);

	public Model processAtomRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) throws ValidationExceptions, JsonProcessingException {

		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.NETBANKING)) {

			model = setNBDetailsAtom(orderId, model, orderId, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {

			model = setUPIDetailsAtom(orderId, model, orderId, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.CARD)) {

			model = setCardDetailsAtom(orderId, model, orderId, formData, merchantPGDetails);
		}

		populateAtomTransDetails(formData, merchantPGDetails, orderId);

		return model;

	}

	private Model generateModel(String loginId, String urlStr, Model model, MerchantPGDetails merchantPGDetails) {

		try {
			String patmentUrl = atomSubmitURL + "?" + IN_LOGIN + "=" + loginId + "&" + IN_ENCDATA + "="
					+ new AtomAES().encrypt(urlStr, merchantPGDetails.getMerchantPGAdd3(),
							merchantPGDetails.getMerchantPGAdd4());
			// logger.info("patmentUrl :: "+patmentUrl);
			model.addAttribute(PAYMENT_URL, patmentUrl);
		} catch (Exception e) {

		}

		return model;
	}

	private Model setCardDetailsAtom(String orderId, Model model, String data, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) throws ValidationExceptions{
		
		String decCardData = formData.get(CARD_NUMBER).get(0)+"|"+ formData.get(CARD_CVV).get(0)+"|"+
				formData.get(CARD_EXPYEAR).get(0)+"|"+ formData.get(CARD_EXPMONTH).get(0);
		
		String encCardData = null;
		SecureCardData sd = new SecureCardData();
		try {
			encCardData = sd.encryptData(decCardData);
		} catch (Exception e) {

		}
		
		
		
		String mdd= IN_CHANNELID+"="+IN_CHANNELID_VALUE+"|"+IN_CARDDATA+"="+encCardData+"|"+IN_CARDHNAME+"="+formData.get(CARD_HOLDER).get(0)+
				"|"+IN_CARDTYPE+"="+CARD_TYPE_CC+"|"+IN_CARD+"=VISA";
		
		//logger.info("Card mdd :: "+mdd);
		String signature = SignatureGenerate.getEncodedValueWithSha2(merchantPGDetails.getMerchantPGAdd1(),
				merchantPGDetails.getMerchantPGAppId(),
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()), TYPECARD,
				merchantPGDetails.getMerchantPGAdd7(), orderId,
				String.format("%.2f", (double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100), TXNCURR);

		// logger.info("Card signature :: "+signature);
		String urlStr = IN_LOGIN + "=" + merchantPGDetails.getMerchantPGAppId() + "&" + IN_PASS + "="
				+ Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()) + "&" + IN_TTYPE + "="
				+ TYPECARD + "&" + IN_PRODID + "=" + merchantPGDetails.getMerchantPGAdd7() + "&" + IN_AMT + "="
				+ String.format("%.2f", (double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100) + "&"
				+ IN_TXNCURR + "="
				+ TXNCURR + "&" + IN_TXNSCAMT + "=0&" + IN_CLIENTCODE + "=" + merchantPGDetails.getMerchantPGAdd8()
				+ "&" + IN_TXTID + "=" + orderId
				+ "&" + IN_DATE + "=" + dtf.format(now).replace(" ", "%20") + "&" + IN_CUSTACC + "=" + CUSTACC
				+ "&" + IN_MDD + "=" + mdd
				+ "&" + IN_RU + "=" + atomReturnURL
				+ "&" + IN_SIGNATURE + "=" + signature + "&" + IN_UDF1 + "=" + formData.get(CUSOMERNAME).get(0)
				+ "&" + IN_UDF2 + "=" + formData.get(CUSTOMEREMAIL).get(0) + "&" + IN_UDF3 + "="
				+ formData.get(CUSTOMERPHONE).get(0);

		logger.info("Card urlStr :: " + urlStr);
		model = generateModel(merchantPGDetails.getMerchantPGAppId(), urlStr, model, merchantPGDetails);

		return model;
	}

	private Model setNBDetailsAtom(String orderId, Model model, String data, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) throws ValidationExceptions, JsonProcessingException {

		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());
		logger.info("BANKLIST::" + Utility.convertDTO2JsonString(bankList));
		String signature = SignatureGenerate.getEncodedValueWithSha2(merchantPGDetails.getMerchantPGAdd1(),
				merchantPGDetails.getMerchantPGAppId(),
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()), TTYPENB,
				merchantPGDetails.getMerchantPGAdd7(), orderId,
				String.format("%.2f", (double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100), TXNCURR);

		String netCharges = getSerchargeAtom(bankList.getPgBankCode(), merchantPGDetails.getMerchantPGAppId(),
				String.format("%.2f", (double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100), formData);

		if (netCharges == null) {
			logger.info("netcharges exception ...");
			throw new ValidationExceptions(SERCHARGE_CALC_ERROR, FormValidationExceptionEnums.E0033,
					formData.get(RETURNURL).get(0), formData);
		}

		String urlStr = IN_LOGIN + "=" + merchantPGDetails.getMerchantPGAppId() + "&" + IN_PASS + "="
				+ Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()) + "&" + IN_TTYPE + "="
				+ TTYPENB + "&" + IN_PRODID + "=" + merchantPGDetails.getMerchantPGAdd7() + "&" + IN_AMT + "="
				+ String.format("%.2f", (double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100) + "&"
				+ IN_TXNCURR + "="
				+ TXNCURR + "&" + IN_TXNSCAMT + "=" + netCharges + "&" + IN_CLIENTCODE + "="
				+ merchantPGDetails.getMerchantPGAdd8() + "&" + IN_TXTID + "=" + orderId
				+ "&" + IN_DATE + "=" + dtf.format(now).replace(" ", "%20") + "&" + IN_CUSTACC + "=" + CUSTACC
				+ "&" + IN_BANKID + "=" + bankList.getPgBankCode()
				+ "&" + IN_RU + "=" + atomReturnURL
				+ "&" + IN_SIGNATURE + "=" + signature + "&" + IN_UDF1 + "=" + formData.get(CUSOMERNAME).get(0)
				+ "&" + IN_UDF2 + "=" + formData.get(CUSTOMEREMAIL).get(0) + "&" + IN_UDF3 + "="
				+ formData.get(CUSTOMERPHONE).get(0);

		model = generateModel(merchantPGDetails.getMerchantPGAppId(), urlStr, model, merchantPGDetails);

		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return model;
	}

	private Model setUPIDetailsAtom(String orderId, Model model, String data, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) {
		String signature = SignatureGenerate.getEncodedValueWithSha2(merchantPGDetails.getMerchantPGAdd1(),
				merchantPGDetails.getMerchantPGAppId(),
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()), TTYPENB,
				merchantPGDetails.getMerchantPGAdd7(), orderId,
				String.format("%.2f", (double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100), TXNCURR);

		// String signature =
		// SignatureGenerate.getEncodedValueWithSha2(merchantPGDetails.getMerchantPGAdd1(),
		// merchantPGDetails.getMerchantPGAppId(),
		// Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()),
		// TTYPENB,
		// merchantPGDetails.getMerchantPGAdd7(), orderId,
		// String.valueOf((double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) /
		// 100), TXNCURR);

		String urlStr = IN_LOGIN + "=" + merchantPGDetails.getMerchantPGAppId() + "&" + IN_PASS + "="
				+ Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()) + "&" + IN_TTYPE + "="
				+ TTYPENB + "&" + IN_PRODID + "=" + merchantPGDetails.getMerchantPGAdd7() + "&" + IN_AMT + "="
				+ String.format("%.2f", (double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100) + "&"
				+ IN_TXNCURR + "="
				+ TXNCURR + "&" + IN_TXNSCAMT + "=0&" + IN_CLIENTCODE + "=" + merchantPGDetails.getMerchantPGAdd8()
				+ "&" + IN_TXTID + "=" + orderId
				+ "&" + IN_DATE + "=" + dtf.format(now).replace(" ", "%20") + "&" + IN_CUSTACC + "=" + CUSTACC
				+ "&" + IN_MDD + "=" + "UP|SMSUPI|" + formData.get(UPI_VPI).get(0)
				+ "&" + IN_RU + "=" + atomReturnURL
				+ "&" + IN_SIGNATURE + "=" + signature + "&" + IN_UDF1 + "=" + formData.get(CUSOMERNAME).get(0)
				+ "&" + IN_UDF2 + "=" + formData.get(CUSTOMEREMAIL).get(0) + "&" + IN_UDF3 + "="
				+ formData.get(CUSTOMERPHONE).get(0);

		logger.info("UPA Request :: " + urlStr);

		model = generateModel(merchantPGDetails.getMerchantPGAppId(), urlStr, model, merchantPGDetails);

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(formData.get(UPI_VPI).get(0));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return model;
	}

	public TransactionDetails updateTransactionStatusAtom(MultiValueMap<String, String> responseFormData)
			throws Exception {

		logger.info("Inside method updateTransactionStatus()");

		JSONObject responseJsonObject = populateResponseAtom(responseFormData.get(RESP_LOGIN).get(0),
				responseFormData.get(RESP_ENCDATA).get(0));

		logger.info("responseJsonObject :: " + responseJsonObject.toString());

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(responseJsonObject.getString(RESP_MER_TXN));

		AtomTransactionDetails atomTransactionDetails = atomTransactionDetailsRepository
				.findByMerchantOrderIdAndOrderId(transactionDetails.getMerchantOrderId(),
						responseJsonObject.getString(RESP_MER_TXN));

		if (transactionDetails != null) {

			MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository
					.findByMerchantIDAndMerchantPGId(transactionDetails.getMerchantId(), transactionDetails.getPgId());

			if (validateReturnSignature(responseJsonObject, merchantPGDetails)) {
				logger.info("The return signature has been verified ...");

				AtomTransactionStatus atomTransactionStatus = getStatusApi(atomTransactionDetails, merchantPGDetails);
				String st = statusCheck(atomTransactionStatus);
				transactionDetails.setStatus(st);
			} else {
				logger.info("The return signature not verified ...");
				transactionDetails.setStatus(UserStatus.PENDING.toString());
			}
			// transactionDetails.setStatus(checkStatus(pgGatewayUtilService.checkResponseData(responseFormData,
			// RESP_STATUS)));
			transactionDetails.setPgOrderID(responseJsonObject.getString(RESP_MMP_TXN));
			transactionDetails.setPaymentMode(responseJsonObject.getString(RESP_DISCRIMINATOR));
			transactionDetails.setTxtMsg(responseJsonObject.getString(RESP_DESC));
			transactionDetails.setTxtPGTime(responseJsonObject.getString(RESP_DATE));
			transactionDetails.setSource("ReturnURL");
			transactionDetailsRepository.save(transactionDetails);
		}

		// logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = new UserDetails();
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			// logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = new MerchantDetails();
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			// logger.info("merchantDetails " +
			// Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				// logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					// logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		// logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		// logger.info("createMailRepo Email Complete");
		// logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");

		try {

			if (atomTransactionDetails == null) {

				atomTransactionDetails = new AtomTransactionDetails();

				atomTransactionDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
				atomTransactionDetails.setOrderAmount(responseJsonObject.getString(RESP_AMT));
				atomTransactionDetails.setOrderId(responseJsonObject.getString(RESP_MER_TXN));
				atomTransactionDetails.setPaymentMode(transactionDetails.getPaymentMode());
				atomTransactionDetails.setReferenceId(responseJsonObject.getString(RESP_MMP_TXN));
				atomTransactionDetails.setSignature(responseJsonObject.getString(RESP_SIGNATURE));
				atomTransactionDetails.setTxMsg(responseJsonObject.getString(RESP_DESC));
				atomTransactionDetails.setTxStatus(transactionDetails.getStatus());
				atomTransactionDetails.setTxTime(responseJsonObject.getString(RESP_DATE));
				atomTransactionDetails.setUpdateFlag("N");
				atomTransactionDetails.setSource("ReturnURL");
				atomTransactionDetails.setEmail(responseJsonObject.getString(RESP_UDF2));
				atomTransactionDetails.setPhoneNo(responseJsonObject.getString(RESP_UDF3));
				atomTransactionDetails
						.setResponseText(Encryption.encryptCardNumberOrExpOrCvv(responseFormData.toString()));
				atomTransactionDetails.setBankName(responseJsonObject.getString(RESP_BANK_NAME));
				atomTransactionDetails.setBankTransaction(responseJsonObject.getString(RESP_BANK_TXN));
				atomTransactionDetails.setMmpTxn(responseJsonObject.getString(RESP_MMP_TXN));
				atomTransactionDetails.setSercharge(responseJsonObject.getString(RESP_SURCHARGE));
			}else {
				atomTransactionDetails.setSource("ReturnURL");
				atomTransactionDetails.setReferenceId(responseJsonObject.getString(RESP_MMP_TXN));
				atomTransactionDetails.setSignature(responseJsonObject.getString(RESP_SIGNATURE));
				atomTransactionDetails.setTxMsg(responseJsonObject.getString(RESP_DESC));
				atomTransactionDetails.setTxStatus(transactionDetails.getStatus());
				atomTransactionDetails.setTxTime(responseJsonObject.getString(RESP_DATE));
				atomTransactionDetails.setBankName(responseJsonObject.getString(RESP_BANK_NAME));
				atomTransactionDetails.setBankTransaction(responseJsonObject.getString(RESP_BANK_TXN));
				atomTransactionDetails.setMmpTxn(responseJsonObject.getString(RESP_MMP_TXN));
				atomTransactionDetails.setSercharge(responseJsonObject.getString(RESP_SURCHARGE));
				
			}
			atomTransactionDetailsRepository.save(atomTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in AtomTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");

		return transactionDetails;
	}

	public Model getResponseProcess(TransactionDetails transactionDetails, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		// logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getAtomResponseProcess()");

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	private boolean validateReturnSignature(JSONObject jsonObject, MerchantPGDetails merchantPGDetails) {

		String signature = SignatureGenerate.getEncodedValueWithSha2(merchantPGDetails.getMerchantPGAdd2(),
				jsonObject.getString(RESP_MMP_TXN), jsonObject.getString(RESP_MER_TXN),
				jsonObject.getString(RESP_F_CODE), jsonObject.getString(RESP_PROD),
				jsonObject.getString(RESP_DISCRIMINATOR),
				jsonObject.getString(RESP_AMT), jsonObject.getString(RESP_BANK_TXN));

		if (signature.equalsIgnoreCase(jsonObject.getString(RESP_SIGNATURE))) {
			return true;
		}

		return false;
	}

	private JSONObject populateResponseAtom(String loginId, String encData) throws Exception {

		PGConfigurationDetails pgConfigurationDetails = pgConfigurationDetailsRepository.findByPgAppId(loginId);

		String dec = new AtomAES().decrypt(encData, pgConfigurationDetails.getPgAddInfo5(),
				pgConfigurationDetails.getPgAddInfo6());

		return new JSONObject(GeneralUtils.MultiValueMaptoJson(GeneralUtils.convertStringToMultiValueMap(dec)));

	}
	
	private JSONObject populateCallBackAtom(String formData) throws JSONException, JsonProcessingException {
		
		return  new JSONObject(GeneralUtils.MultiValueMaptoJson(GeneralUtils.convertStringToMultiValueMap(formData)));
	}
	
	
	public void populateAtomTransDetails(MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) {

		AtomTransactionDetails atomTransactionDetails = new AtomTransactionDetails();

		atomTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		atomTransactionDetails
				.setOrderAmount(String.valueOf((double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100));
		atomTransactionDetails.setOrderId(orderId);
		atomTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		atomTransactionDetails.setTxStatus(UserStatus.PENDING.toString());
		atomTransactionDetails.setUpdateFlag("N");
		atomTransactionDetails.setSource("Initiated");
		atomTransactionDetails.setEmail(formData.get(CUSTOMEREMAIL).get(0));
		atomTransactionDetails.setPhoneNo(formData.get(CUSTOMERPHONE).get(0));

		atomTransactionDetailsRepository.save(atomTransactionDetails);
	}

	private AtomTransactionStatus getStatusApi(AtomTransactionDetails atomTransactionDetails,
			MerchantPGDetails merchantPGDetails) throws Exception {

		logger.info("Inside getStatusApi :: ");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

		String str = STS_MERCHANTID + "=" + merchantPGDetails.getMerchantPGAppId() +
				"&" + STS_MERCHANTTXNID + "=" + atomTransactionDetails.getOrderId() +
				"&" + STS_AMT + "=" + atomTransactionDetails.getOrderAmount() +
				"&" + STS_TDATE + "=" + formatter.format(atomTransactionDetails.getCreated());

		// logger.info("Inside getStatusApi str :: "+str);
		String urlDetails = STS_LOGIN + "=" + merchantPGDetails.getMerchantPGAppId() + "&" + STS_ENCDATA + "="
				+ new AtomAES().encrypt(str, merchantPGDetails.getMerchantPGAdd3(),
						merchantPGDetails.getMerchantPGAdd4());
		// logger.info("Inside getStatusApi urlDetails :: "+urlDetails);
		return callAtomStatusapi(urlDetails, merchantPGDetails);
	}

	public AtomTransactionStatus callAtomStatusapi(String urlDetails, MerchantPGDetails merchantPGDetails)
			throws Exception {

		logger.info("Inside callAtomStatusapi urlDetails :: " + urlDetails);
		HttpResponse<String> atomTransactionDetails = Unirest.post(atomStatusAPiEndPoint + "?" + urlDetails)
				.asObject(String.class)
				.ifFailure(Object.class, r -> {
					Object e = r.getBody();
					try {
						logger.info("Atom Status Request Response Error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});

		// logger.info("Response :: " +
		// Utility.convertDTO2JsonString(atomTransactionDetails.getBody()));

		String dec = new AtomAES().decrypt(atomTransactionDetails.getBody(), merchantPGDetails.getMerchantPGAdd5(),
				merchantPGDetails.getMerchantPGAdd6());

		// logger.info("Inside callAtomStatusapi dec :: "+dec);

		ObjectMapper objectMapper = new ObjectMapper();
		TypeFactory typeFactory = objectMapper.getTypeFactory();
		List<AtomTransactionStatus> atomTransactionStatusList = objectMapper.readValue(dec,
				typeFactory.constructCollectionType(List.class, AtomTransactionStatus.class));

		return atomTransactionStatusList.get(0);

	}

	public String getSerchargeAtom(String bankId, String merchantID, String amount,
			MultiValueMap<String, String> formData)
			throws ValidationExceptions {

		HttpResponse<String> atomSerchargeDetails = Unirest
				.post("https://payment.atomtech.in/paynetz/getSurcharges?merchantId="
						+ merchantID + "&txnType=NB&txnAmount=" + amount + "&bankId=" + bankId)
				.asString()
				.ifFailure(Object.class, r -> {
					Object e = r.getBody();
					try {
						logger.info("Atom Sercharge Response Error ::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});
		if (GeneralUtils.convertStringToMap(atomSerchargeDetails.getBody()).get("netCharges") == null) {

			logger.info("Inside Exception");
			throw new ValidationExceptions(SERCHARGE_CALC_ERROR, FormValidationExceptionEnums.E0033,
					formData.get(RETURNURL).get(0), formData);
		}

		return GeneralUtils.convertStringToMap(atomSerchargeDetails.getBody()).get("netCharges");
	}

	private String statusCheck(AtomTransactionStatus statusApi) {
		if (statusApi.getStatusCode().equals("001") && statusApi.getVerified().equalsIgnoreCase("SUCCESS")) {
			return "SUCCESS";
		} else if (statusApi.getStatusCode().equals("002") && statusApi.getVerified().equalsIgnoreCase("FAILED")) {
			return "FAILED";
		} else if (statusApi.getStatusCode().equals("003") || statusApi.getStatusCode().equals("004")
				|| statusApi.getStatusCode().equals("006")) {
			return "FAILED";
		} else {
			return "PENDING";
		}
	}

	
	
	public String populateCallBackAPI(String responseFormData) throws ParseException, JSONException, JsonProcessingException {
		
		JSONObject callbackJsonObject = populateCallBackAtom(responseFormData);
		
		Utility.createFlatFiles(callbackJsonObject.toString(), atomCallBack, callbackJsonObject.getString(CALL_MERCHANTTXNID));
		
		AtomTransactionDetails atomTransactionDetails = 
				atomTransactionDetailsRepository.findByOrderId(callbackJsonObject.getString(CALL_MERCHANTTXNID));
		
		if(atomTransactionDetails != null) {
			
			atomTransactionDetails.setTxStatus(callbackJsonObject.getString(CALL_VERIFIED));
			atomTransactionDetails.setBankTransaction(callbackJsonObject.getString( CALL_BID));
			atomTransactionDetails.setBankName(callbackJsonObject.getString( CALL_BANKNAME));
			atomTransactionDetails.setMmpTxn(callbackJsonObject.getString( CALL_ATOMTXNID));
			atomTransactionDetails.setSercharge(callbackJsonObject.getString( CALL_SURCHARGE));
			atomTransactionDetails.setSource("CALLBACK_API");
			
			atomTransactionDetailsRepository.save(atomTransactionDetails);
			
			return "The request has been captured successfully.";
			
		}
		
		return "The merchantOrderID not found in system.";
	}

	private CardBinDetails populateAtomWiseCardBin(CardBinDetails cardBinDetails) {
		
		if(cardBinDetails.getCardBrand().equalsIgnoreCase("MASTERCARD")) {
			cardBinDetails.setCardBrand("MASTER");
		}else if(cardBinDetails.getCardBrand().equalsIgnoreCase("VISA")) {
			cardBinDetails.setCardBrand("VISA");
		}
		
		
		return cardBinDetails;
	}
}
