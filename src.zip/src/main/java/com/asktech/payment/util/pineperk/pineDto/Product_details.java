package com.asktech.payment.util.pineperk.pineDto;

import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Product_details {
    private String product_code;
    private Float  product_amount;
}
