package com.asktech.payment.util.pineperk.pineDto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class Billing_address_data {
    private String country;
    private String address3;
    private String address2;
    private String city;
    private String address1;
    private String pin_code;
    private String last_name;
    private String state;
    private String first_name;
}
