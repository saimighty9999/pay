package com.asktech.payment.util.icici;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.icici.ICICIConstants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.enums.PGServices;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.EaseBuzzTransactionDetails;
import com.asktech.payment.model.ICICIBankTransactionDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.PGServiceDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.TransactionDetailsAll;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.ICICIBankTransactionDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fiserv.fdc.FDConnectUtils;
import com.fiserv.fdc.inquiry.model.FDConnectInquiryRequest;
import com.fiserv.fdc.inquiry.model.FDConnectInquiryResponse;
import com.fiserv.fdc.response.model.FDConnectDecryptRequest;
import com.fiserv.fdc.response.model.FDConnectDecryptResponse;
import com.fiserv.fdc.sale.model.FDConnectSaleRequest;
import com.fiserv.fdc.sale.model.FDConnectSaleResponse;
import com.google.gson.Gson;

@Service
public class ICICIUtilityClass implements CashFreeFields {

	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	WalletListRepository walletListRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	ICICIBankTransactionDetailsRepository iciciBankTransactionDetailsRepository;

	@Value("${pgEndPoints.iciciBankGetToken}")
	String iciciBankGetToken;
	@Value("${pgEndPoints.iciciBankPaymentEndPoint}")
	String iciciBankPaymentEndPoint;
	@Value("${pgEndPoints.iciciBankDecryption}")
	String iciciBankDecryption;
	@Value("${pgEndPoints.iciciBankReturnURL}")
	String iciciBankReturnURL;

	static Logger logger = LoggerFactory.getLogger(ICICIUtilityClass.class);

	public Model processIciciBankRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) throws IOException, ParseException {

		FDConnectSaleRequest fdConnectSaleRequest = new FDConnectSaleRequest();
		fdConnectSaleRequest
				.setAmount(String.valueOf((double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100));
		fdConnectSaleRequest.setCurrencyCode(ICICIConstants.CURRENCY);
		fdConnectSaleRequest.setMerchantTxnId(orderId);
		fdConnectSaleRequest.setTransactionType(ICICIConstants.TRANSACTION_SALE);
		fdConnectSaleRequest.setApiURL(iciciBankGetToken);
		fdConnectSaleRequest.setResultURL(iciciBankReturnURL);
		fdConnectSaleRequest.setMerchantId(merchantPGDetails.getMerchantPGAppId());
		fdConnectSaleRequest.setKey(Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
		fdConnectSaleRequest.setIv(merchantPGDetails.getMerchantPGSaltKey());		
		fdConnectSaleRequest.setEmailId(formData.get(CUSTOMEREMAIL).get(0));
		fdConnectSaleRequest.setMobileNo(formData.get(CUSTOMERPHONE).get(0));

		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.NB.toString())) {
			model = createICICIRequestNB(fdConnectSaleRequest, formData, merchantPGDetails, model);
		}else if(formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.UPI.toString())) {
			model = createICICIRequestUPI(fdConnectSaleRequest, formData, merchantPGDetails, model);
		}
		
		populateICICIBankTransDetails(formData, merchantPGDetails, orderId);
		
		return model;
	}

	public Model createICICIRequestNB(FDConnectSaleRequest fdConnectSaleRequest, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, Model model) throws JsonProcessingException {

		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		fdConnectSaleRequest.setIntegrationType(
				FDConnectSaleRequest.INTEGRATION_TYPE.MERCHANT_PAYMENT_MODE_BANKORWALLET_INTEGRATION);
		fdConnectSaleRequest.setBankId(bankList.getPgBankCode());
		fdConnectSaleRequest.setBankName(bankList.getBankname());
		fdConnectSaleRequest.setPaymentMethodType(ICICIConstants.NB_CODE);

		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(fdConnectSaleRequest.getMerchantTxnId());
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return generateModel(fdConnectSaleRequest, model, merchantPGDetails);

	}
	
	public Model createICICIRequestUPI(FDConnectSaleRequest fdConnectSaleRequest, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, Model model) throws JsonProcessingException {

		fdConnectSaleRequest.setIntegrationType(
				FDConnectSaleRequest.INTEGRATION_TYPE.MERCHANT_PAYMENT_MODE_INTEGRATION);
		fdConnectSaleRequest.setvPAId(formData.get(UPI_VPI).get(0));
		fdConnectSaleRequest.setPaymentMethodType(ICICIConstants.UPI_CODE);

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(fdConnectSaleRequest.getMerchantTxnId());
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);


		return generateModel(fdConnectSaleRequest, model, merchantPGDetails);

	}

	public Model generateModel(FDConnectSaleRequest fdConnectSaleRequest, Model model,
			MerchantPGDetails merchantPGDetails) throws JsonProcessingException {

		FDConnectSaleResponse fdConnectSaleResponse = FDConnectUtils.saleTxn(fdConnectSaleRequest);
		String url = iciciBankPaymentEndPoint + "?sessionToken=" + fdConnectSaleResponse.getSessionTokenId()
				+ "\u0026configId=" + merchantPGDetails.getMerchantPGAdd1();

		model.addAttribute("redirect_url", url);

		return model;
	}

	public void updateTransactionStatusICICIBank(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException {
		logger.info("Inside method updateTransactionStatus()");
		
		FDConnectDecryptResponse fdConnectDecryptResponse = decryption(responseFormData);

		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(fdConnectDecryptResponse.getMerchantTxnId());

		if (transactionDetails != null) {
			
			transactionDetails.setStatus(fdConnectDecryptResponse.getTransactionStatus());
			transactionDetails.setPgOrderID(fdConnectDecryptResponse.getFpTransactionId());
			transactionDetails.setPaymentMode(fdConnectDecryptResponse.getPaymentMethod());
			transactionDetails.setTxtMsg(fdConnectDecryptResponse.getTransactionStatusDescription());
			transactionDetails.setTxtPGTime(fdConnectDecryptResponse.getTransactionDateTime());

			transactionDetails.setSource("ReturnURL");		

			transactionDetailsRepository.save(transactionDetails);
		} else {
			TransactionDetailsAll transactionDetailsAll = new TransactionDetailsAll();
			transactionDetails = transactionDetailsRepository.findByOrderID(fdConnectDecryptResponse.getMerchantTxnId());
			transactionDetailsAll.setOrderID(fdConnectDecryptResponse.getMerchantTxnId());
			transactionDetailsAll.setStatus(fdConnectDecryptResponse.getTransactionStatus());
			transactionDetailsAll.setPgOrderID(fdConnectDecryptResponse.getFpTransactionId());
			transactionDetailsAll.setPaymentMode(fdConnectDecryptResponse.getPaymentMethod());
			transactionDetails.setTxtMsg(fdConnectDecryptResponse.getTransactionStatusDescription());
			transactionDetails.setTxtPGTime(fdConnectDecryptResponse.getTransactionDateTime());

			transactionDetailsAllRepository.save(transactionDetailsAll);
		}
		
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		// logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");

		try {

			ICICIBankTransactionDetails iciciBankTransactionDetails = iciciBankTransactionDetailsRepository
					.findByMerchantOrderIdAndOrderId(transactionDetails.getMerchantOrderId(),fdConnectDecryptResponse.getMerchantTxnId());

			if (iciciBankTransactionDetails == null) {

				iciciBankTransactionDetails = new ICICIBankTransactionDetails();

				iciciBankTransactionDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
				iciciBankTransactionDetails.setOrderAmount(fdConnectDecryptResponse.getTransactionAmount());
				iciciBankTransactionDetails.setOrderId(transactionDetails.getOrderID());
				iciciBankTransactionDetails.setPaymentMode(fdConnectDecryptResponse.getPaymentMethod());
				iciciBankTransactionDetails.setPgOrderId(fdConnectDecryptResponse.getFpTransactionId());
				iciciBankTransactionDetails.setEncData(pgGatewayUtilService.checkResponseData(responseFormData, ICICIConstants.RESP_ENCDATA));						
				iciciBankTransactionDetails.setTxMsg(fdConnectDecryptResponse.getTransactionStatusDescription());
				iciciBankTransactionDetails.setTransactionStatus(fdConnectDecryptResponse.getTransactionStatus());
				iciciBankTransactionDetails.setTxTime(fdConnectDecryptResponse.getTransactionDateTime());
				iciciBankTransactionDetails.setUpdateFlag("N");
				iciciBankTransactionDetails.setSource("ReturnURL");				
				iciciBankTransactionDetails.setResponseText(Encryption.encryptCardNumberOrExpOrCvv(responseFormData.toString()));
			} else {
				iciciBankTransactionDetails.setSource("ReturnURL");
				iciciBankTransactionDetails.setPgOrderId(fdConnectDecryptResponse.getFpTransactionId());
				iciciBankTransactionDetails.setEncData(pgGatewayUtilService.checkResponseData(responseFormData, ICICIConstants.RESP_ENCDATA));
				iciciBankTransactionDetails.setTxMsg(fdConnectDecryptResponse.getTransactionStatusDescription());
				iciciBankTransactionDetails.setTransactionStatus(fdConnectDecryptResponse.getTransactionStatus());
				iciciBankTransactionDetails.setTxTime(fdConnectDecryptResponse.getTransactionDateTime());
				iciciBankTransactionDetails.setResponseText(Encryption.encryptCardNumberOrExpOrCvv(responseFormData.toString()));
			}
			iciciBankTransactionDetailsRepository.save(iciciBankTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in CashfreeTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");
	}

	public Model getResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, ICICIConstants.RESP_MERCHANTTRID));

		
		MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository
				.findByMerchantIDAndMerchantPGId(transactionDetails.getMerchantId(), transactionDetails.getPgId());		
		
		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	
	public FDConnectDecryptResponse decryption(MultiValueMap<String, String> responseFormData) {

		FDConnectDecryptRequest fdConnectDecryptRequest = new FDConnectDecryptRequest();

		fdConnectDecryptRequest.setEncData(pgGatewayUtilService.checkResponseData(responseFormData, ICICIConstants.RESP_ENCDATA));
		fdConnectDecryptRequest.setFpTxnId(pgGatewayUtilService.checkResponseData(responseFormData, ICICIConstants.RESP_FPTXNID));
		fdConnectDecryptRequest.setFpURL(iciciBankDecryption);
		fdConnectDecryptRequest.setMerchantId(pgGatewayUtilService.checkResponseData(responseFormData, ICICIConstants.RESP_MERCHANTID));

		FDConnectDecryptResponse resp = FDConnectUtils.decryptMsg(fdConnectDecryptRequest);		
		return resp;

	}

	public void populateICICIBankTransDetails(MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) {
		
		ICICIBankTransactionDetails iciciBankTransactionDetails = new ICICIBankTransactionDetails();
		
		iciciBankTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		iciciBankTransactionDetails.setOrderAmount(String.valueOf((double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100));
		iciciBankTransactionDetails.setOrderId(orderId);
		iciciBankTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		iciciBankTransactionDetails.setTransactionStatus(UserStatus.PENDING.toString());
		iciciBankTransactionDetails.setUpdateFlag("N");
		iciciBankTransactionDetails.setSource("Initiated");
		iciciBankTransactionDetails.setEmail(formData.get(CUSTOMEREMAIL).get(0));
		iciciBankTransactionDetails.setPhoneNo(formData.get(CUSTOMERPHONE).get(0));
		iciciBankTransactionDetailsRepository.save(iciciBankTransactionDetails);
	}
	
	
	
}
