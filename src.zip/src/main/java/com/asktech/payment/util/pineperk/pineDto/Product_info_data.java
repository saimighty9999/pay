package com.asktech.payment.util.pineperk.pineDto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Product_info_data {
    private List<Product_details> product_details;
}
