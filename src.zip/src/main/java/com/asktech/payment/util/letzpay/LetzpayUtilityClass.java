package com.asktech.payment.util.letzpay;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.constants.letzpay.LetsPayConstants;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.LetzpayTransactionDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.PGConfigurationDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.TransactionDetailsAll;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.CardPaymentDetailsRepository;
import com.asktech.payment.repository.LetzpayTransactionDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.service.PaymentVerification;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class LetzpayUtilityClass implements CashFreeFields {

	@Autowired
	PaymentVerification service;

	@Autowired
	CardPaymentDetailsRepository cardPaymentDetailsRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	LetzpayTransactionDetailsRepository letzpayTransactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	PGConfigurationDetailsRepository pgConfigurationDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;

	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	WalletListRepository walletListRepository;

	@Value("${pgEndPoints.letzpay}")
	String letzpayRRL;
	@Value("${pgEndPoints.letzpayReturnURL}")
	String letzpayReturnURL;

	static Logger logger = LoggerFactory.getLogger(LetzpayUtilityClass.class);

	public Model processLetzPayRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId)
			throws NoSuchAlgorithmException, JsonProcessingException {

		logger.info("Inside processLetzPayRequest()");
		Map<String, String> parameters = new LinkedHashMap<String, String>();
		parameters.put(LetsPayConstants.AMOUNT, formData.get(ORDERAMOUNT).get(0));
		parameters.put(LetsPayConstants.CURRENCY_CODE, "356");
		parameters.put(LetsPayConstants.CUST_EMAIL, formData.get(CUSTOMEREMAIL).get(0));
		parameters.put(LetsPayConstants.CUST_PHONE, formData.get(CUSTOMERPHONE).get(0));
		parameters.put(LetsPayConstants.ORDER_ID, orderId);

		parameters.put(LetsPayConstants.PAY_ID, merchantPGDetails.getMerchantPGAppId());
		parameters.put(LetsPayConstants.RETURN_URL, letzpayReturnURL);

		populateLetzPayTransactionDetails(formData, orderId, merchantPGDetails);

		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("card")) {

			parameters.put(LetsPayConstants.CVV, formData.get(CARD_CVV).get(0));
			parameters.put(LetsPayConstants.CARD_EXP_DT,
					formData.get(CARD_EXPMONTH).get(0) + formData.get(CARD_EXPYEAR).get(0));
			parameters.put(LetsPayConstants.CARD_HOLDER_NAME, formData.get(CARD_HOLDER).get(0));
			parameters.put(LetsPayConstants.CARD_NUMBER_LET, formData.get(CARD_NUMBER).get(0));
			parameters.put(LetsPayConstants.PAYMENT_TYPE, formData.get(PAYMENT_OPTION).get(0).toUpperCase());
			logger.info("LetzPay Parameters::"+parameters.toString());
			model = setCardDetailsLetspay(parameters, orderId, model, merchantPGDetails);
			logger.info("LetzPay Model::"+model);

		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
			logger.info("Inside processLetzPayRequest() into NB process");

			BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
					formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
					merchantPGDetails.getMerchantPGName());
			parameters.put(LetsPayConstants.PAYMENT_CODE, bankList.getPgBankCode());
			parameters.put(LetsPayConstants.CUST_NAME, formData.get(CUSOMERNAME).get(0));
			parameters.put(LetsPayConstants.PAYMENT_TYPE, formData.get(PAYMENT_OPTION).get(0).toUpperCase());
			logger.info("LetzPay Parameters::"+parameters.toString());
			model = setNBLetspay(parameters, orderId, model, merchantPGDetails);
			logger.info("LetzPay Model::"+model);
		}

		else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("wallet")) {

			logger.info("Inside processLetzPayRequest() into WALLET process");
			WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
					formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
					merchantPGDetails.getMerchantPGName());
			parameters.put(LetsPayConstants.PAYMENT_CODE, walletList.getPaymentcodepg());
			parameters.put(LetsPayConstants.CUST_NAME, formData.get(CUSOMERNAME).get(0));
			parameters.put(LetsPayConstants.PAYMENT_TYPE, LetsPayConstants.PAYMENT_TYPE_WL);
			logger.info("LetzPay Parameters::"+parameters.toString());
			model = setWalletLetspay(parameters, orderId, model, merchantPGDetails);
			logger.info("LetzPay Model::"+model);
		}

		else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("upi")) {

			logger.info("Inside processLetzPayRequest() into UPI process");
			parameters.put(LetsPayConstants.PAYER_ADDRESS, formData.get(UPI_VPI).get(0));
			parameters.put(LetsPayConstants.PAYER_NAME, formData.get(CUSOMERNAME).get(0));
			parameters.put(LetsPayConstants.PAYMENT_TYPE, LetsPayConstants.PAYMENT_TYPE_UPI);
			logger.info("LetzPay Parameters::"+parameters.toString());
			model = setUPILetspay(parameters, orderId, model, merchantPGDetails);
			logger.info("LetzPay Model::"+model);

		}
		logger.info("End processLetzPayRequest()");
		model.addAttribute("postPage", letzpayRRL);

		return model;

	}

	public Model setCardDetailsLetspay(Map<String, String> parameters, String orderId, Model model,
			MerchantPGDetails merchantPGDetails) throws NoSuchAlgorithmException {

		model = populateModelInfo(model, merchantPGDetails.getMerchantPGAppId(),
				LtzPay.generateEncryption(merchantPGDetails, parameters));

		return model;
	}

	public Model setNBLetspay(Map<String, String> parameters, String orderId, Model model,
			MerchantPGDetails merchantPGDetails) throws NoSuchAlgorithmException {

		logger.info("Inside setNBDetailsLetzPay()");
		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();

		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(parameters.get(LetsPayConstants.AMOUNT));
		nbPaymentDetails.setOrderCurrency(parameters.get(LetsPayConstants.CURRENCY_CODE));
		nbPaymentDetails.setCustomerName(parameters.get(LetsPayConstants.CARD_HOLDER_NAME));
		nbPaymentDetails.setCustomerEmail(parameters.get(LetsPayConstants.CUST_EMAIL));
		nbPaymentDetails.setCustomerPhone(parameters.get(LetsPayConstants.CUST_PHONE));
		nbPaymentDetails.setPaymentOption(parameters.get(LetsPayConstants.PAYMENT_TYPE));
		nbPaymentDetails.setPaymentCode(parameters.get(LetsPayConstants.PAYMENT_CODE));
				
		model = populateModelInfo(model, merchantPGDetails.getMerchantPGAppId(),
				LtzPay.generateEncryption(merchantPGDetails, parameters));

		nBPaymentDetailsRepository.save(nbPaymentDetails);
		logger.info("End setCardDetailsLetspay()");

		return model;
	}

	public Model setWalletLetspay(Map<String, String> parameters, String orderId, Model model,
			MerchantPGDetails merchantPGDetails) throws NoSuchAlgorithmException {

		logger.info("Inside setWalletDetailsLetzPay()123");
		WalletPaymentDetails walletPaymentDetails = new WalletPaymentDetails();

		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(parameters.get(LetsPayConstants.AMOUNT));
		walletPaymentDetails.setOrderCurrency(parameters.get(LetsPayConstants.CURRENCY_CODE));
		walletPaymentDetails.setCustomerName(parameters.get(LetsPayConstants.CARD_HOLDER_NAME));
		walletPaymentDetails.setCustomerEmail(parameters.get(LetsPayConstants.CUST_EMAIL));
		walletPaymentDetails.setCustomerPhone(parameters.get(LetsPayConstants.CUST_PHONE));
		walletPaymentDetails.setPaymentOption(parameters.get(LetsPayConstants.PAYMENT_TYPE));
		// walletPaymentDetails.setPaymentCode(SecurityUtils.encryptSaveData(parameters.get(LetsPay.PAYMENT_CODE)));
		walletPaymentDetails.setPaymentCode(parameters.get(LetsPayConstants.PAYMENT_CODE));

		model = populateModelInfo(model, merchantPGDetails.getMerchantPGAppId(),
				LtzPay.generateEncryption(merchantPGDetails, parameters));

		walletPaymentDetailsRepository.save(walletPaymentDetails);
		logger.info("End setWalletDetailsLetzPay()");

		return model;
	}

	public Model setUPILetspay(Map<String, String> parameters, String orderId, Model model,
			MerchantPGDetails merchantPGDetails) throws NoSuchAlgorithmException, JsonProcessingException {

		logger.info("Inside setUPILetspay()");
		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(parameters.get(LetsPayConstants.AMOUNT));
		upiPaymentDetails.setOrderCurrency(parameters.get(LetsPayConstants.CURRENCY_CODE));
		upiPaymentDetails.setCustomerName(parameters.get(LetsPayConstants.CARD_HOLDER_NAME));
		upiPaymentDetails.setCustomerEmail(parameters.get(LetsPayConstants.CUST_EMAIL));
		upiPaymentDetails.setCustomerPhone(parameters.get(LetsPayConstants.CUST_PHONE));
		upiPaymentDetails.setPaymentOption(parameters.get(LetsPayConstants.PAYMENT_TYPE));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(parameters.get(LetsPayConstants.PAYER_ADDRESS)));

		logger.info("Input Parameters :: " + Utility.convertDTO2JsonString(parameters));

		model = populateModelInfo(model, merchantPGDetails.getMerchantPGAppId(),
				LtzPay.generateEncryption(merchantPGDetails, parameters));
		upiPaymentDetailsRepository.save(upiPaymentDetails);
		logger.info("End setUPILetspay()");

		return model;
	}

	private Model populateModelInfo(Model model, String merchantAppId, String encData) {

		model.addAttribute(LetsPayConstants.MODEL_PAY_ID, merchantAppId);
		model.addAttribute(LetsPayConstants.MODEL_ENCDATA, encData);
		return model;
	}

	private void populateLetzPayTransactionDetails(MultiValueMap<String, String> formData, String orderId,
			MerchantPGDetails merchantPGDetails) {

		LetzpayTransactionDetails letzpayTransactionDetails = new LetzpayTransactionDetails();
		letzpayTransactionDetails.setAmount(formData.get(ORDERAMOUNT).get(0));
		letzpayTransactionDetails.setCurrencyCode("356");
		letzpayTransactionDetails.setCustEmail(formData.get(CUSTOMEREMAIL).get(0));
		letzpayTransactionDetails.setCustName(formData.get(CUSOMERNAME).get(0));
		letzpayTransactionDetails.setCustPhone(formData.get(CUSTOMERPHONE).get(0));
		letzpayTransactionDetails.setOrderId(orderId);
		letzpayTransactionDetails.setPayId(merchantPGDetails.getMerchantPGAppId());
		letzpayTransactionDetails.setPaymentType(formData.get(PAYMENT_OPTION).get(0));
		letzpayTransactionDetails.setReturnUrl(letzpayReturnURL);
		letzpayTransactionDetails.setStatus(UserStatus.PENDING.toString());

		letzpayTransactionDetailsRepository.save(letzpayTransactionDetails);

	}

	public String acceptNotifyURLLetzPay(MultiValueMap<String, String> responseFormData)
			throws NoSuchAlgorithmException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();

		logger.info("Inside method acceptNotifyURLLetzPay()");

		PGConfigurationDetails pgConfigurationDetails = pgConfigurationDetailsRepository
				.findByPgAppId(pgGatewayUtilService.checkResponseData(responseFormData, "PAY_ID"));

		String enCryption = LtzPay.generateDecryption(
				pgGatewayUtilService.checkResponseData(responseFormData, LetsPayConstants.RESP_ENCDATA),
				Encryption.decryptCardNumberOrExpOrCvv(pgConfigurationDetails.getPgSecret()));
		logger.info("LetzPay Derypted Response::"+enCryption);
		
		Map<String, String> response = generateLetsPayParams(enCryption);

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderIDAndStatus(response.get(LetsPayConstants.RESP_ORDER_ID), UserStatus.PENDING.toString());

		if (transactionDetails != null) {

			if (!isValidateSignature(response, response.get("HASH"), pgConfigurationDetails.getPgSaltKey())) {
				transactionDetails.setStatus("FAILED");
				transactionDetails.setTxtMsg("SIGNATURE MISMATCH");
			} else {
				transactionDetails.setStatus(checkStatus(response.get(LetsPayConstants.RESP_RESPONSE_CODE),response.get(LetsPayConstants.RESP_STATUS), response.get(LetsPayConstants.RESP_RESPONSE_MESSAGE)) );
				transactionDetails.setTxtMsg(response.get(LetsPayConstants.RESP_PG_TXN_MESSAGE));
			}
			transactionDetails.setPgOrderID(response.get(LetsPayConstants.RESP_TXN_ID));
			transactionDetails.setPaymentMode(response.get(LetsPayConstants.RESP_PAYMENT_TYPE));
			transactionDetails.setTxtPGTime(response.get(LetsPayConstants.RESP_RESPONSE_DATE_TIME));
			transactionDetails.setSource("ReturnURL");
			transactionDetailsRepository.save(transactionDetails);
		} else {
			TransactionDetailsAll transactionDetailsAll = new TransactionDetailsAll();
			transactionDetailsAll.setOrderID(response.get(LetsPayConstants.RESP_ORDER_ID));
			transactionDetailsAll.setStatus(checkStatus(response.get(LetsPayConstants.RESP_RESPONSE_CODE),response.get(LetsPayConstants.RESP_STATUS), response.get(LetsPayConstants.RESP_RESPONSE_MESSAGE)));
			transactionDetailsAll.setPgOrderID(response.get(LetsPayConstants.RESP_TXN_ID));
			transactionDetailsAll.setPaymentMode(response.get(LetsPayConstants.RESP_PAYMENT_TYPE));
			transactionDetailsAll.setTxtMsg(response.get(LetsPayConstants.RESP_RESPONSE_MESSAGE));
			transactionDetailsAll.setTxtPGTime(response.get(LetsPayConstants.RESP_RESPONSE_DATE_TIME));
			// transactionDetails.setSource("ReturnURL");
			transactionDetailsAllRepository.save(transactionDetailsAll);
		}

		UserDetails userDetails = userDetailsRepository.findById(transactionDetails.getUserID());

		MerchantDetails merchantDetails = merchantDetailsRepository
				.findByMerchantID(transactionDetails.getMerchantId());

		if (!merchantDetails.getTr_mail_flag().isEmpty()) {
			if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
				pgGatewayUtilService.createMailRepo(
						pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
						merchantDetails.getMerchantEMail(), "MerchantEmail");
			}
		}

		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);

		pgGatewayUtilService.populatePgResponseinDB(response, transactionDetails, "ReturnURL");
		logger.info("End of acceptNotifyURLLetzPay()");

		LetzpayTransactionDetails letzpayTransactionDetails = letzpayTransactionDetailsRepository
				.findByOrderId(response.get(LetsPayConstants.RESP_ORDER_ID));
		if (letzpayTransactionDetails != null) {

			letzpayTransactionDetails.setStatus(response.get(LetsPayConstants.RESP_STATUS));
			letzpayTransactionDetails.setPgRefNumber(response.get(LetsPayConstants.RESP_PG_REF_NUM));
			letzpayTransactionDetails.setResponseCode(response.get(LetsPayConstants.RESP_RESPONSE_CODE));
			letzpayTransactionDetails.setRrn(response.get(LetsPayConstants.RESP_RRN));
			letzpayTransactionDetails.setResponseMessage(response.get(LetsPayConstants.RESP_RESPONSE_MESSAGE));
			letzpayTransactionDetails.setResponseDateTime(response.get(LetsPayConstants.RESP_RESPONSE_DATE_TIME));
			letzpayTransactionDetails.setTxtId(response.get(LetsPayConstants.RESP_TXN_ID));
			letzpayTransactionDetails.setAcqId(response.get(LetsPayConstants.RESP_ACQ_ID));
			letzpayTransactionDetails.setHashValue(response.get(LetsPayConstants.RESP_HASH));

		} else {
			letzpayTransactionDetails = new LetzpayTransactionDetails();
			letzpayTransactionDetails.setAmount(response.get(LetsPayConstants.RESP_TOTAL_AMOUNT));
			letzpayTransactionDetails.setCurrencyCode(response.get(LetsPayConstants.RESP_CURRENCY_CODE));
			letzpayTransactionDetails.setCustEmail(response.get(LetsPayConstants.RESP_CUST_EMAIL));
			letzpayTransactionDetails.setCustPhone(response.get(LetsPayConstants.RESP_CUST_PHONE));
			letzpayTransactionDetails.setOrderId(response.get(LetsPayConstants.RESP_ORDER_ID));
			letzpayTransactionDetails.setPayId(response.get(LetsPayConstants.RESP_PAY_ID));
			letzpayTransactionDetails.setPaymentType(response.get(LetsPayConstants.RESP_PAYMENT_TYPE));
			letzpayTransactionDetails.setReturnUrl(response.get(LetsPayConstants.RESP_RETURN_URL));
			letzpayTransactionDetails.setStatus(response.get(LetsPayConstants.RESP_STATUS));

			letzpayTransactionDetails.setPgRefNumber(response.get(LetsPayConstants.RESP_PG_REF_NUM));
			letzpayTransactionDetails.setResponseCode(response.get(LetsPayConstants.RESP_RESPONSE_CODE));
			letzpayTransactionDetails.setRrn(response.get(LetsPayConstants.RESP_RRN));
			letzpayTransactionDetails.setResponseMessage(response.get(LetsPayConstants.RESP_RESPONSE_MESSAGE));
			letzpayTransactionDetails.setResponseDateTime(response.get(LetsPayConstants.RESP_TOTAL_AMOUNT));
			letzpayTransactionDetails.setTxtId(response.get(LetsPayConstants.RESP_TXN_ID));
			letzpayTransactionDetails.setAcqId(response.get(LetsPayConstants.RESP_ACQ_ID));
			letzpayTransactionDetails.setHashValue(response.get(LetsPayConstants.RESP_HASH));

		}

		letzpayTransactionDetailsRepository.save(letzpayTransactionDetails);

		return response.get(LetsPayConstants.RESP_ORDER_ID);

	}

	public Model getResponseProcessLetsPay(String orderId, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException {

		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(orderId);

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);

		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	private static Map<String, String> generateLetsPayParams(String strValue) {

		Map<String, String> parameters = new LinkedHashMap<String, String>();

		String[] arrOfStr = strValue.split("~");
		for (String fullParams : arrOfStr) {
			String[] keyValue = fullParams.split("=");
			parameters.put(keyValue[0], keyValue[1]);
		}

		return parameters;
	}

	public boolean isValidateSignature(Map<String, String> params, String returnHash, String saltKey)
			throws NoSuchAlgorithmException {

		params.remove("HASH");

		if (returnHash.equalsIgnoreCase(ChecksumUtils.generateCheckSum(params, saltKey))) {
			return true;
		}

		return false;
	}
	public String checkStatus(String statusCode, String status, String statusMsg) {
		String[] failedCodes = {"001","002","004","005","007","008","009","010","011","012","013","014","015","016","017","018","019","020","021","022","023","024","113"};
		String[] pendingCode = {"006","003"};
		if (status.equalsIgnoreCase("Captured") && statusCode.equalsIgnoreCase("000") && statusMsg.equalsIgnoreCase("SUCCESS")) {
			return UserStatus.SUCCESS.toString();
		}
		if (Utility.inArray(failedCodes, statusCode)) {
			return UserStatus.FAILED.toString();
		}
		if (Utility.inArray(pendingCode, statusCode)) {
			return UserStatus.PENDING.toString();
		}
		return status;
	}
	/*
	 * public static void main(String args[]) throws NoSuchAlgorithmException {
	 * String enCryption = LtzPay.generateDecryption(
	 * "nZ2Fbd1171ajE4M9Knbkljmurpa/FI9lObOMnYe6we+mUxavpH4OnH+BOwpXsXvETyAX4N/gxJ3P8NC6k8+LnCvZycywCoE/UEf9PvSdMARRXOa9p/4xxmxySkfh4aPQw0jGF6vJ0PC1gndrANSaa7ttvmOLw6nCE8t0tNGdLN99flf5F4T2C5N+64Zg6QcDQmIQRa7YDMe9RDr6bAnLfCTAVAGYgh4Nnby0mRBajK7fSXl/ct2SkKKybJZXMgkOzUmHTYDYojCgaS9Hepdd6h++4ej3fPu4jHsSyi7yHF4wmGPXpuQIQaaRLF5c4x8m41DgfaPDXEo+gvMgXJnOQjRiQdUykimNl6aTVGM8mvi5tzTdxb8eX5aR0QPL+X4hFmg5HEd9WQgT3ZoJp9uQH/KkJ7MHAQtWMqZl7KslMznAvzHhkmcLd3Q/mzv9vuxv18gYZ7HlYqwyfLODUZjD9kLvJwXP9SA6/YAS92zpYbS1on8UjJQvzHxeer6ydrEXi83mlasXBkfcTTIdauVvi+zT5drcienAeQYCUJf51wbj/tYIa65ceFUeQg8V30GdwvwdSXOh3LWU7Yhxg3ZlYvaKjcW45QjXxSmDRvrJVcdGvEPdQinSWbOwBAAtkhJVKhIGYftM4fiqvlTo0JUCJioSfnMS40iEptxlAoxbfpmgV9L0qdQUAWs9TixSJ+1ulfDvZkW6mY0efFxyTME2E9PgyHhxu60VJv0BkWWcEksKZOptMp8wrjZXtK3ZaHZ/X2qWhIymi5FLuP5BUH95+7USNy1r/+qu5iVvS9mE9hPDmGafLiICiOANsg4kkrJG2KMdMmwbcsNT5m0J1vt0FT1umg+nS0o32b+PBDZ5Ews",
	 * "8df248143ab14e93");
	 * 
	 * Map<String, String> params = generateLetsPayParams(enCryption);
	 * System.out.println("Decrypt Data :: " + params.toString());
	 * 
	 * params.remove("HASH"); System.out.println("After HASH Remove Data :: " +
	 * params.toString());
	 * 
	 * System.out.println("Generated HASH :: " +
	 * ChecksumUtils.generateCheckSum(params, "165161bdc6494db0"));
	 * 
	 * }
	 */

	/*
	 * public static void main(String args[]) throws NoSuchAlgorithmException {
	 * Map<String, String> parameters = new LinkedHashMap<String, String>();
	 * 
	 * parameters.put("PAY_ID", "1521500819125513"); parameters.put("ORDER_ID",
	 * "1645786485333064"); parameters.put("AMOUNT", "100");
	 * parameters.put("TXNTYPE", "STATUS"); parameters.put("CURRENCY_CODE", "356");
	 * System.out.println("Generated HASH :: " +
	 * ChecksumUtils.generateCheckSum(parameters, "165161bdc6494db0"));
	 * 
	 * }
	 */
}
