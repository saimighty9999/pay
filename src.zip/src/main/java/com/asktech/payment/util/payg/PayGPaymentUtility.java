package com.asktech.payment.util.payg;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.payg.PayGConstants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.payg.CustomerData;
import com.asktech.payment.dto.payg.IntegrationData;
import com.asktech.payment.dto.payg.Netbanking;
import com.asktech.payment.dto.payg.PayGErrorResponse;
import com.asktech.payment.dto.payg.PayGErrorResponseInitiator;
import com.asktech.payment.dto.payg.PayGOrderRequest;
import com.asktech.payment.dto.payg.PayGOrderStatusRequest;
import com.asktech.payment.dto.payg.PayGOrderStatusResponse;
import com.asktech.payment.dto.payg.PayGResponse;
import com.asktech.payment.dto.payg.TransactionData;
import com.asktech.payment.dto.payg.Upi;
import com.asktech.payment.dto.payg.Wallet;
import com.asktech.payment.dto.setu.SetuErrorResponse;
import com.asktech.payment.enums.PGServices;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.PGConfigurationDetails;
import com.asktech.payment.model.PayGTransactionDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.PayGTransactionDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;

@Service
public class PayGPaymentUtility implements CashFreeFields, PayGConstants {

	static Logger logger = LoggerFactory.getLogger(PayGPaymentUtility.class);

	@Value("${pgEndPoints.paygPayOrderCreate}")
	String paygPayOrderCreate;
	@Value("${pgEndPoints.paygPayOrderStatus}")
	String paygPayOrderStatus;
	@Value("${pgEndPoints.paygReturnURL}")
	String redirectUrl;

	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletListRepository walletListRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	PayGTransactionDetailsRepository payGTransactionDetailsRepository;
	@Autowired
	PGConfigurationDetailsRepository pgConfigurationDetailsRepository;
	@Value("${apiEndPoint}")
	String apiurl;
	ObjectMapper objectMapper = new ObjectMapper();

	public Model processPayGRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId, String ipAddress)
			throws IOException, ParseException, Exception {

		String paymentLink = "";
		SimpleDateFormat dt = new SimpleDateFormat("MMddyyyy");
		PayGResponse payGResponse = new PayGResponse();
		PayGOrderRequest payGOrderRequest = new PayGOrderRequest();
		CustomerData customerData = new CustomerData();
		IntegrationData integrationData = new IntegrationData();

		customerData.setEmail(formData.get(CUSTOMEREMAIL).get(0));
		customerData.setMobileNo(formData.get(CUSTOMERPHONE).get(0));
		customerData.setEmailReceipt(false);

		integrationData.setIntegrationType(INTEGRATIONTYPE);
		integrationData.setIpAddress(ipAddress);
		integrationData.setSource(SOURCE);

		payGOrderRequest.setMerchantkeyid(merchantPGDetails.getMerchantPGAppId());
		payGOrderRequest.setUniqueRequestId(Long.toHexString(Long.parseLong(orderId)));
		payGOrderRequest.setRequestDateTime(dt.format(new Date()));
		payGOrderRequest.setRedirectUrl(redirectUrl + "/"+payGOrderRequest.getUniqueRequestId());
		payGOrderRequest.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		payGOrderRequest.setCustomerData(customerData);
		payGOrderRequest.setIntegrationData(integrationData);

		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.NB.toString())) {

			payGResponse = generateNBRequest(payGOrderRequest, formData, merchantPGDetails, orderId);
			logger.info("payGResponse :: " + Utility.convertDTO2JsonString(payGResponse));
			try {
				if (StringUtils.isEmpty(payGResponse.getResponseCode())
						&& payGResponse.getPaymentResponseCode().equalsIgnoreCase("0")) {
					paymentLink = payGResponse.getPaymentProcessUrl();
				}
			} catch (Exception e) {

			}

		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.WALLET.toString())) {

			payGResponse = generateWalletRequest(payGOrderRequest, formData, merchantPGDetails, orderId);
			try {
				if (StringUtils.isEmpty(payGResponse.getResponseCode())
						&& payGResponse.getPaymentResponseCode().equalsIgnoreCase("0")) {
					paymentLink = payGResponse.getPaymentProcessUrl();
				}
			} catch (Exception e) {

			}

		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.UPI.toString())) {
			logger.info("PayG UPI Service");
			payGResponse = generateUPIRequest(payGOrderRequest, formData, merchantPGDetails, orderId);
			try {

				if (StringUtils.isEmpty(payGResponse.getResponseCode())
						&& payGResponse.getPaymentResponseCode().equalsIgnoreCase("4")) {
					paymentLink = "No_UPI_Link";
					logger.info("Payment Link::" + paymentLink + "|" + orderId);
					model.addAttribute("orderId", payGOrderRequest.getUniqueRequestId());
					model.addAttribute("merchantId", merchantPGDetails.getMerchantID());
					model.addAttribute("apiurl", apiurl);
					
				}
			} catch (Exception e) {
				logger.info(e.getMessage());
			}
		}

		populateTransactionDetails(payGOrderRequest, payGResponse, paymentLink, formData, orderId);

		if (paymentLink == "" || paymentLink.length() == 0) {
			model.addAttribute("ERROR", "");
		} else {

			model.addAttribute("urlLink", paymentLink);
		}

		return model;
	}

	private void populateTransactionDetails(PayGOrderRequest payGOrderRequest, PayGResponse payGResponse,
			String generatedHtml, MultiValueMap<String, String> formData, String orderId)
			throws JsonProcessingException {

		PayGTransactionDetails payGTransactionDetails = new PayGTransactionDetails();

		payGTransactionDetails.setEmailId(formData.get(CUSTOMEREMAIL).get(0));
		payGTransactionDetails.setInputRequest(Utility.convertDTO2JsonString(payGOrderRequest));
		payGTransactionDetails.setMerchnatkeyId(payGOrderRequest.getMerchantkeyid());
		payGTransactionDetails.setMobileNo(formData.get(CUSTOMERPHONE).get(0));
		payGTransactionDetails.setOrderAmount(payGOrderRequest.getOrderAmount());
		payGTransactionDetails.setOrderId(orderId);
		payGTransactionDetails.setOrderResponse(Utility.convertDTO2JsonString(payGResponse));
		payGTransactionDetails.setPayGOrderKeyId(payGResponse.getOrderKeyId());
		payGTransactionDetails.setPaygUniqueId(payGOrderRequest.getUniqueRequestId());
		payGTransactionDetails.setPaymentType(payGOrderRequest.getTransactionData().getPaymentType());
		payGTransactionDetails.setSource("TRInitiate");
		payGTransactionDetails.setStatus(UserStatus.PENDING.toString());

		payGTransactionDetailsRepository.save(payGTransactionDetails);
	}

	private PayGResponse generateNBRequest(PayGOrderRequest payGOrderRequest, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) throws IOException {

		logger.info("Inside PagNB Processor");
		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		logger.info("bankList :: " + bankList.getPgBankCode());
		TransactionData transactionData = new TransactionData();
		transactionData.setPaymentType(PAYMENT_TYPE_NB);

		Netbanking netbanking = new Netbanking();
		netbanking.setBankName(bankList.getPgBankCode());
		transactionData.setNetbanking(netbanking);
		payGOrderRequest.setTransactionData(transactionData);

		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		// logger.info("Bank
		// nbPaymentDetails::"+Utility.convertDTO2JsonString(nbPaymentDetails));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return generatePaymentLink(payGOrderRequest, merchantPGDetails);

	}

	private PayGResponse generateUPIRequest(PayGOrderRequest payGOrderRequest, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) throws IOException {

		TransactionData transactionData = new TransactionData();
		transactionData.setPaymentType(PAYMENT_TYPE_UPI);

		Upi upi = new Upi();
		upi.setVpa(formData.get(UPI_VPI).get(0));
		transactionData.setUpi(upi);

		payGOrderRequest.setTransactionData(transactionData);

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return generatePaymentLink(payGOrderRequest, merchantPGDetails);

	}

	private PayGResponse generateWalletRequest(PayGOrderRequest payGOrderRequest,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails, String orderId)
			throws IOException {

		WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		TransactionData transactionData = new TransactionData();
		transactionData.setPaymentType(PAYMENT_TYPE_WALLET);

		Wallet wallet = new Wallet();
		wallet.setWalletType(walletList.getPaymentcodepg());
		transactionData.setWallet(wallet);

		payGOrderRequest.setTransactionData(transactionData);
		payGOrderRequest.getIntegrationData().setPlatformId("");
		payGOrderRequest.getIntegrationData().setIntegrationType("1");

		WalletPaymentDetails walletPaymentDetails = new WalletPaymentDetails();

		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		walletPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		walletPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		walletPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		walletPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		walletPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		walletPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		// logger.info("Wallet
		// walletPaymentDetails::"+Utility.convertDTO2JsonString(walletPaymentDetails));
		walletPaymentDetailsRepository.save(walletPaymentDetails);

		return generatePaymentLink(payGOrderRequest, merchantPGDetails);
	}

	private PayGResponse generatePaymentLink(PayGOrderRequest payGOrderRequest, MerchantPGDetails merchantPGDetails)
			throws IOException {

		logger.debug("Request for Payg :: " + Utility.convertDTO2JsonString(payGOrderRequest));

		PayGResponse payGResponse = new PayGResponse();

		HttpResponse<JsonNode> payGPaymentResponse = Unirest.post(paygPayOrderCreate)
				.header(CONTENT_TYPE, CONTENT_TYPE_VALUE)
				.header(AUTHORIZATION,
						AUTHORIZATION_VALUE + populatePayGAuth(
								Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()),
								merchantPGDetails.getMerchantPGSaltKey(), merchantPGDetails.getMerchantPGAppId()))
				.header(ACCEPT, ACCEPT_VALUE).body(Utility.convertDTO2JsonString(payGOrderRequest)).asJson()
				.ifFailure(PayGErrorResponseInitiator.class, r -> {
					PayGErrorResponseInitiator e = r.getBody();
					try {
						logger.info("PayG Order Create Response Error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});
		// logger.debug("Parsing Error :: " + payGPaymentResponse.getParsingError());
		// logger.debug("Response from Payg ::
		// "+Utility.convertDTO2JsonString(payGPaymentResponse.getBody()));
		logger.debug("Response from Payg :: " + payGPaymentResponse.getBody());

		try {
			payGResponse = objectMapper.readValue(payGPaymentResponse.getBody().getObject().toString(),
					PayGResponse.class);
		} catch (Exception e) {
			logger.info("Unable to Map::" + e.getMessage());
			objectMapper.enable(DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS);
			PayGErrorResponse todoItems = objectMapper.readValue(payGPaymentResponse.getBody().getArray().toString(),
					PayGErrorResponse.class);
			payGResponse.setPayGErrorResponse(todoItems);
		}

		// objectMapper.readValue(payGPaymentResponse.getBody().toPrettyString(),
		// PayGResponse.class);
		logger.info("Map Complete::" + Utility.convertDTO2JsonString(payGResponse));
		return payGResponse;
	}

	private PayGOrderStatusResponse getOrderStatus(PayGOrderStatusRequest payGOrderStatusRequest,
			PGConfigurationDetails PGConfigurationDetails) throws JsonProcessingException {

		logger.debug("Request for Payg :: " + Utility.convertDTO2JsonString(payGOrderStatusRequest));

		HttpResponse<PayGOrderStatusResponse> payGOrderStatusResponse = Unirest.post(paygPayOrderStatus)
				.header(CONTENT_TYPE, CONTENT_TYPE_VALUE)
				.header(AUTHORIZATION,
						AUTHORIZATION_VALUE + populatePayGAuth(
								Encryption.decryptCardNumberOrExpOrCvv(PGConfigurationDetails.getPgSecret()),
								PGConfigurationDetails.getPgSaltKey(), PGConfigurationDetails.getPgAppId()))
				.header(ACCEPT, ACCEPT_VALUE).body(Utility.convertDTO2JsonString(payGOrderStatusRequest))
				.asObject(PayGOrderStatusResponse.class).ifFailure(SetuErrorResponse.class, r -> {
					SetuErrorResponse e = r.getBody();
					try {
						logger.info("PayG Order Create Response Error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});
		logger.info("PayG Status Response::" + Utility.convertDTO2JsonString(payGOrderStatusResponse.getBody()));
		return payGOrderStatusResponse.getBody();
	}

	private String populatePayGAuth(String authenticationKey, String authenticationToken, String MerchantKey) {

		String authStr = authenticationKey + ":" + authenticationToken + ":M:" + MerchantKey;

		byte[] bytesEncoded = Base64.getEncoder().encode(authStr.getBytes());
		String generatedAuth = new String(bytesEncoded);

		logger.debug("generatedAuth :: " + generatedAuth);
		return generatedAuth;

	}

	public TransactionDetails checkTransactionStatus(String orderId) throws JsonProcessingException {
		PayGTransactionDetails payGTransactionDetails = payGTransactionDetailsRepository.findByPaygUniqueId(orderId);
		if (payGTransactionDetails != null) {
			TransactionDetails transactionDetails = transactionDetailsRepository
					.findByOrderID(payGTransactionDetails.getOrderId());
			if (transactionDetails != null) {
				PGConfigurationDetails pgConfigurationDetails = pgConfigurationDetailsRepository
						.findByPgUuid(transactionDetails.getPgId());

				PayGOrderStatusRequest payGOrderStatusRequest = new PayGOrderStatusRequest();
				payGOrderStatusRequest.setMerchantKeyId(payGTransactionDetails.getMerchnatkeyId());
				payGOrderStatusRequest.setOrderKeyId(payGTransactionDetails.getPayGOrderKeyId());
				PayGOrderStatusResponse payGOrderStatusResponse = getOrderStatus(payGOrderStatusRequest,
						pgConfigurationDetails);

				if (payGOrderStatusResponse != null
						&& payGOrderStatusResponse.getOrderPaymentStatusText() != null) {
					transactionDetails.setStatus(checkStatus(payGOrderStatusResponse.getOrderPaymentStatusText(), payGOrderStatusResponse.getPaymentResponseCode()));
					transactionDetails.setSource(orderId);
					transactionDetails.setPgOrderID(payGTransactionDetails.getPayGOrderKeyId());
					// transactionDetails.setTxtPGTime(
					// payGOrderStatusResponse.getOrderPaymentTransactionDetail().get(0).getUpdatedDateTime());
					transactionDetails.setSource("StatusURL");

					transactionDetails = transactionDetailsRepository.save(transactionDetails);
					return transactionDetails;
				}
				return transactionDetails;
			}
			return transactionDetails;
		}
		return null;
	}

	public TransactionDetails updateTransactionStatus(String orderId) throws JsonProcessingException {

		PayGTransactionDetails payGTransactionDetails = payGTransactionDetailsRepository.findByPaygUniqueId(orderId);
		if (payGTransactionDetails != null) {
			TransactionDetails transactionDetails = transactionDetailsRepository
					.findByOrderID(payGTransactionDetails.getOrderId());
			if (transactionDetails != null) {
				PGConfigurationDetails pgConfigurationDetails = pgConfigurationDetailsRepository
						.findByPgUuid(transactionDetails.getPgId());

				PayGOrderStatusRequest payGOrderStatusRequest = new PayGOrderStatusRequest();
				payGOrderStatusRequest.setMerchantKeyId(payGTransactionDetails.getMerchnatkeyId());
				payGOrderStatusRequest.setOrderKeyId(payGTransactionDetails.getPayGOrderKeyId());
				PayGOrderStatusResponse payGOrderStatusResponse = getOrderStatus(payGOrderStatusRequest,
						pgConfigurationDetails);

				if (payGOrderStatusResponse != null
						&& payGOrderStatusResponse.getOrderPaymentTransactionDetail().size() > 0) {

					payGTransactionDetails.setStatus(payGOrderStatusResponse.getPaymentResponseText()+"-"+payGOrderStatusResponse.getPaymentResponseCode());
					payGTransactionDetails.setPaymentId(
							String.valueOf(payGOrderStatusResponse.getOrderPaymentTransactionDetail().get(0).getId()));
					payGTransactionDetails.setPaymentOrderId(String
							.valueOf(payGOrderStatusResponse.getOrderPaymentTransactionDetail().get(0).getOrderId()));
					payGTransactionDetails.setPaymentResponseCode(payGOrderStatusResponse
							.getOrderPaymentTransactionDetail().get(0).getResponseCode().toString());
					payGTransactionDetails.setPaymentResponseText(
							payGOrderStatusResponse.getOrderPaymentTransactionDetail().get(0).getResponseText());
					payGTransactionDetails.setPaymentTransactionId(String.valueOf(
							payGOrderStatusResponse.getOrderPaymentTransactionDetail().get(0).getTransactionId()));
					payGTransactionDetailsRepository.save(payGTransactionDetails);

					transactionDetails.setStatus(checkStatus(payGOrderStatusResponse.getPaymentResponseText(), payGOrderStatusResponse.getPaymentResponseCode()));
					transactionDetails.setSource(orderId);
					transactionDetails.setPgOrderID(payGTransactionDetails.getPayGOrderKeyId());
					transactionDetails.setTxtPGTime(
							payGOrderStatusResponse.getOrderPaymentTransactionDetail().get(0).getUpdatedDateTime());
					transactionDetails.setSource("ReturnURL");

					transactionDetails = transactionDetailsRepository.save(transactionDetails);

					UserDetails userDetails = null;
					try {
						userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
						// logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
					} catch (Exception e) {
						e.printStackTrace();
						logger.error("Unable to get Data" + e.getMessage());
					}
					MerchantDetails merchantDetails = null;
					try {
						merchantDetails = merchantDetailsRepository
								.findByMerchantID(transactionDetails.getMerchantId());
						// logger.info("merchantDetails " +
						// Utility.convertDTO2JsonString(merchantDetails));
					} catch (Exception e) {
						e.printStackTrace();
						logger.error("Unable to get Data" + e.getMessage());
					}
					if (merchantDetails != null) {
						if (!merchantDetails.getTr_mail_flag().isEmpty()) {
							// logger.info("merchantDetails getTr_mail_flag not empty");
							if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
								// logger.info("merchantDetails getTr_mail_flag Y");
								pgGatewayUtilService
										.createMailRepo(
												pgGatewayUtilService.createMerchantEmail(userDetails,
														transactionDetails, merchantDetails),
												merchantDetails.getMerchantEMail(), "MerchantEmail");
								// logger.info("createMailRepo Complete");
							}
						}
					}
					logger.info("createMailRepo 2");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
							userDetails.getEmailId(), "CustomerEmail");
					logger.info("createMailRepo Email Complete");
					logger.info("Send SMS Start");
					pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
					logger.info("Send SMS End");

					pgGatewayUtilService.populatePgResponseinDB(Utility.convertDTO2JsonString(payGOrderStatusResponse),
							transactionDetails, "ReturnURL");
					logger.info("populatePgResponseinDB");

					return transactionDetails;
				}
			}
		}

		return null;
	}

	public Model getResponseProcess(TransactionDetails transactionDetails, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	public String validatePayGRequest(MultiValueMap<String, String> formData) {

		if (Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) < 5100) {
			return "For NetBanking , amount should be greater than 51.00 ";
		}

		return null;
	}
    private String checkStatus(String responseText, String responseCodes) {
        if (responseText.equalsIgnoreCase("success") && responseCodes.equalsIgnoreCase("1")) {
            return UserStatus.SUCCESS.toString();
        }
        if (responseText.equalsIgnoreCase("approved") && responseCodes.equalsIgnoreCase("1")) {
            return UserStatus.SUCCESS.toString();
        }
        if (responseText.equalsIgnoreCase("declined") && responseCodes.equalsIgnoreCase("2")) {
            return UserStatus.FAILED.toString();
        }
        if (responseText.equalsIgnoreCase("failed") && responseCodes.equalsIgnoreCase("2")) {
            return UserStatus.FAILED.toString();
        }
        if (responseText.equalsIgnoreCase("submitted") && responseCodes.equalsIgnoreCase("4")) {
            return UserStatus.PENDING.toString();
        }
        if (responseText.equalsIgnoreCase("pending") && responseCodes.equalsIgnoreCase("4")) {
            return UserStatus.PENDING.toString();
        }
        return responseText.toUpperCase();
    }
}
