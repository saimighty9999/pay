package com.asktech.payment.util.zavion;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.EmptyStackException;
import java.util.Map;
import java.util.Stack;
import java.util.TreeMap;

import org.apache.commons.codec.binary.Hex;

public class ChecksumUtils {

	private static Stack<MessageDigest> stack = new Stack<>();
	private final static String separator = "~";
	private final static String equator = "=";
	private final static String hashingAlgo = "SHA-256";

	public static String generateCheckSum(Map<String, String> parameters, String secretKey)
			throws NoSuchAlgorithmException {
		Map<String, String> treeMap = new TreeMap<String, String>(parameters);
		StringBuilder allFields = new StringBuilder();
		for (String key : treeMap.keySet()) {

			allFields.append(separator);
			allFields.append(key);
			allFields.append(equator);
			allFields.append(treeMap.get(key));

		}

		allFields.deleteCharAt(0);
		allFields.append(secretKey);
		return getHash(allFields.toString());
	}

	public boolean validateResponseChecksum(Map<String, String> responseParameters, String secretKey,
			String responseHash) throws NoSuchAlgorithmException {
		boolean flag = false;
		String generatedHash = generateCheckSum(responseParameters, secretKey);
		if (generatedHash.equals(responseHash)) {
			flag = true;
		}
		return flag;
	}

	public static String getHash(String input) throws NoSuchAlgorithmException {
		String response = null;
		MessageDigest messageDigest = provide();
		messageDigest.update(input.getBytes());
		consume(messageDigest);
		response = new String(Hex.encodeHex(messageDigest.digest()));
		return response.toUpperCase();
	}

	private static MessageDigest provide() throws NoSuchAlgorithmException {
		MessageDigest digest = null;
		try {
			digest = stack.pop();
		} catch (EmptyStackException emptyStackException) {
			digest = MessageDigest.getInstance(hashingAlgo);
		}
		return digest;
	}

	private static void consume(MessageDigest digest) {
		stack.push(digest);
	}
}
