package com.asktech.payment.util.payaid;


import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.Utility;
import com.asktech.payment.util.nimble.nimbleDto.PollingStatusApiRes;
import com.asktech.payment.util.payaid.payaidDto.PaymentRequestDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Value;




@Component
public class PayaidUtility implements CashFreeFields {

    static Logger logger = LoggerFactory.getLogger(PayaidUtility.class);
    @Autowired
    PGConfigurationDetailsRepository pgConfigurationDetailsRepository;
    @Autowired
    UPIPaymentDetailsRepository upiPaymentDetailsRepository;
    @Autowired
    TransactionDetailsRepository transactionDetailsRepository;
    @Autowired
    PGGatewayUtilService pgGatewayUtilService;
    @Autowired
    BankListRepository bankListRepository;
    @Autowired
    MerchantPGDetailsRepository merchantPGDetailsRepository;
    @Autowired
    TransactionDetailsAllRepository transactionDetailsAllRepository;
    @Autowired
    UserDetailsRepository userDetailsRepository;
    @Autowired
    MerchantDetailsRepository merchantDetailsRepository;
    @Autowired
    PayAidModelRepo payAidModelRepo;

    @Value("${pgEndPoints.payaidReturnUpiUrl}")
    String payaidReturnUpiUrl;




    public  Model processRequest(MultiValueMap<String, String> formData, Model model,
            MerchantPGDetails merchantPGDetails, String orderId, String return_url)
            throws JsonProcessingException, ValidationExceptions, NoSuchAlgorithmException, UnsupportedEncodingException {

            PaymentRequestDto paymentReq = setPaymentRequest(formData, merchantPGDetails, orderId,   return_url);

            // ADD THE DETAILS TO MODEL
            PayAidModel payAidModel = new PayAidModel();
            payAidModel.setMerchantId(merchantPGDetails.getMerchantID());
            payAidModel.setOrderId(orderId);
            payAidModel.setAccessSecret(merchantPGDetails.getMerchantPGSaltKey());
            payAidModelRepo.save(payAidModel);

            model.addAttribute("hash", paymentReq.getHash());
            model.addAttribute("api_key", paymentReq.getApi_key());
            model.addAttribute("return_url", paymentReq.getReturn_url());
            model.addAttribute("mode", paymentReq.getMode());
            model.addAttribute("order_id", paymentReq.getOrder_id());

            model.addAttribute("amount", paymentReq.getAmount());
            model.addAttribute("currency", paymentReq.getCurrency());
            model.addAttribute("description", paymentReq.getDescription());
            model.addAttribute("name", paymentReq.getName());
            model.addAttribute("email", paymentReq.getEmail());

            model.addAttribute("phone", paymentReq.getPhone());
            model.addAttribute("address_line_1", paymentReq.getAddress_line_1());
            model.addAttribute("address_line_2", paymentReq.getAddress_line_2());
            model.addAttribute("city", paymentReq.getCity());
            model.addAttribute("state", paymentReq.getState());
            model.addAttribute("zip_code", paymentReq.getZip_code());
            model.addAttribute("country", paymentReq.getCountry());
            model.addAttribute("udf1", paymentReq.getUdf1());
            model.addAttribute("udf2", paymentReq.getUdf2());
            model.addAttribute("udf3", paymentReq.getUdf3());
            model.addAttribute("udf4", paymentReq.getUdf4());
            model.addAttribute("udf5", paymentReq.getUdf5());
            model.addAttribute("bank_code", paymentReq.getBank_code());
        return model;
    }

    public  PaymentRequestDto setPaymentRequest(MultiValueMap<String, String> formData,MerchantPGDetails merchantPGDetails, String orderId, /*String apiKey, String salt*/ String returnUrl) throws NoSuchAlgorithmException, UnsupportedEncodingException, JsonProcessingException{
        PaymentRequestDto paymentReq = new PaymentRequestDto();
        String returnURL = pgGatewayUtilService.getReturnUrl(payaidReturnUpiUrl ,
                merchantPGDetails.getMerchantID(), formData.get(PAYMENT_OPTION).get(0));
        
        // BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
        //     formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(),
        //     UserStatus.ACTIVE.toString(), merchantPGDetails.getMerchantPGName());
      
        paymentReq.setApi_key(merchantPGDetails.getMerchantPGAppId());
        paymentReq.setAddress_line_1("NetaJi Shubhash CHandra bose");
        paymentReq.setAddress_line_2("Pritampura");
       paymentReq.setAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
        paymentReq.setCity("Delhi");
        paymentReq.setCountry("IND");
        paymentReq.setCurrency("INR");
        paymentReq.setDescription("mail me if needed");
        paymentReq.setEmail(formData.get(CUSTOMEREMAIL).get(0));
        paymentReq.setMode("TEST");
        paymentReq.setName(formData.get(CUSOMERNAME).get(0));
        paymentReq.setOrder_id(orderId);
        paymentReq.setPhone(formData.get(CUSTOMERPHONE).get(0));
        paymentReq.setReturn_url(returnURL);
        paymentReq.setReturn_url_cancel(returnURL);
        paymentReq.setReturn_url_failure(returnURL);
        paymentReq.setState("Delhi");
        paymentReq.setUdf1("");
        paymentReq.setUdf2("");
        paymentReq.setUdf3("");
        paymentReq.setUdf4("");
        paymentReq.setUdf5("");
        paymentReq.setBank_code("DEMN");
        paymentReq.setZip_code("110001");
        String stringToHash = merchantPGDetails.getMerchantPGSaltKey() + "|" +  paymentReq.createStringToHash();


        // CREATE THE HASH
        System.out.println(stringToHash);
        String hash = createHMC512(stringToHash); 
        paymentReq.setHash(hash);
        return paymentReq;
 
    }

    public TransactionDetails updateTransactionStatus(MultiValueMap<String, String> responseFormData) throws JsonProcessingException, NoSuchAlgorithmException, UnsupportedEncodingException{

        TransactionDetails transactionDetails = null;
        String orderId  = responseFormData.get("order_id").get(0) ;
        PayAidModel payAidModel = payAidModelRepo.findByOrderId(orderId);
        payAidModel.setPgTransId(responseFormData.get("transaction_id").get(0));
        payAidModel.setPaymentResponse(GeneralUtils.MultiValueMaptoJson(responseFormData).toString());

        // CREATE THE HASH 
        String stringToHash = payAidModel.getAccessSecret() + "|" + responseFormData.get("address_line_1").get(0)+"|"+responseFormData.get("address_line_2").get(0)+"|"+responseFormData.get("amount").get(0)+"|"+responseFormData.get("city").get(0)+"|"+responseFormData.get("country").get(0)+"|"+responseFormData.get("currency").get(0)+"|"+responseFormData.get("description").get(0)+"|"+responseFormData.get("email").get(0)+"|"+responseFormData.get("name").get(0)+"|"+responseFormData.get("order_id").get(0)+"|"+responseFormData.get("payment_channel").get(0)+"|"+responseFormData.get("payment_datetime").get(0)+"|"+responseFormData.get("payment_mode").get(0)+"|"+responseFormData.get("phone").get(0)+"|"+responseFormData.get("response_code").get(0)+"|"+responseFormData.get("response_message").get(0)+"|"+responseFormData.get("state").get(0)+"|"+responseFormData.get("transaction_id").get(0)+"|"/*+udf1+"|"+udf2+"|"+udf3+"|"+udf4+"|"+udf5+"|"*/+responseFormData.get("zip_code").get(0); 

        String hash = createHMC512(stringToHash); 
        
        transactionDetails = transactionDetailsRepository
        .findByOrderID(orderId);

        if (transactionDetails != null) {
            
            if (hash.equals(responseFormData.get("hash").get(0)) ){
                if ((responseFormData.get("response_code").get(0)).equals("0")){
                    transactionDetails.setStatus("SUCCESS");
                }
                else{
                    transactionDetails.setStatus("PENDING");
                }
                
                transactionDetails.setTxtMsg(responseFormData.get("response_message").get(0));
                transactionDetails.setPgOrderID(responseFormData.get("transaction_id").get(0));
                transactionDetails.setTxtPGTime(responseFormData.get("payment_datetime").get(0));
            }
            else{
                transactionDetails.setStatus("PENDING");
                transactionDetails.setTxtMsg(responseFormData.get("response_message").get(0));
                transactionDetails.setPgOrderID(responseFormData.get("transaction_id").get(0));
                transactionDetails.setTxtPGTime(responseFormData.get("payment_datetime").get(0));

            }

            transactionDetailsRepository.save(transactionDetails);
        }
       



        payAidModelRepo.save(payAidModel);

        return transactionDetails;
    }









    // Support method
    public  String createHMC512(String data) throws NoSuchAlgorithmException, UnsupportedEncodingException{

        
        MessageDigest md = MessageDigest.getInstance("SHA-512");
        md.update(data.getBytes("UTF-8"));
        byte byteData[] = md.digest();
        StringBuffer hashCodeBuffer = new StringBuffer();
        for (int i = 0; i < byteData.length; i++) {
            hashCodeBuffer.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
        }

        return hashCodeBuffer.toString().toUpperCase();

    }



}
