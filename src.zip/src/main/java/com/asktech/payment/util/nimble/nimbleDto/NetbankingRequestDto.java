package com.asktech.payment.util.nimble.nimbleDto;

import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class NetbankingRequestDto {
    private String payment_mode;
    private String bank;
    private String order_id;
    private String offer_id;
    private String callback_url;
}
