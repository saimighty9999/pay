package com.asktech.payment.util.nimble.nimbleDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class IntiatePaymentRequestUpiDto {
    private String  order_id;
    private String  payment_mode;
    private String  upi_id;

    
}
