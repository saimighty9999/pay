package com.asktech.payment.util.asanpay;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constant.grezpay.GrezPayContants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.asanpay.AsanPayTransactionStatus;
import com.asktech.payment.dto.setu.SetuErrorResponse;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.AsanPayTransactionDetails;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.AsanPayTransactionDetailsRepository;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class AsanPayPaymentUtility implements CashFreeFields, GrezPayContants {

	static Logger logger = LoggerFactory.getLogger(AsanPayPaymentUtility.class);

	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	AsanPayTransactionDetailsRepository asanPayTransactionDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletListRepository walletListRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;

	@Value("${pgEndPoints.asanpaySeamLess}")
	String asanSeamLess;
	@Value("${pgEndPoints.asanpayReturnURL}")
	String asanPayReturnURL;
	@Value("${pgEndPoints.asanpayStatusAPI}")
	String AsanpayStatusAPI;

	public Model processAsanPayRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId)
			throws IOException, ParseException, NoSuchAlgorithmException {

		Map<String, String> params = new HashMap<String, String>();
		params.put(APP_ID, merchantPGDetails.getMerchantPGAppId());
		params.put(AMOUNT, formData.get(ORDERAMOUNT).get(0));
		params.put(CURRENCY_CODE, CURRENCY_VALUE);
		params.put(CUST_EMAIL, formData.get(CUSTOMEREMAIL).get(0));
		params.put(CUST_NAME, formData.get(CUSOMERNAME).get(0));
		params.put(CUST_PHONE, formData.get(CUSTOMERPHONE).get(0));
		params.put(ORDER_ID, orderId);
		params.put(PRODUCT_DESC, PRODUCTDESC_VALUE);
		params.put(RETURN_URL, asanPayReturnURL);
		params.put(TXNTYPE, TXTTYPE_VALUE);

		// model = generateGenericModel(model, merchantPGDetails, formData, orderId);

		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {
			params = setUPIDetailsAsanPay(orderId, params, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.NETBANKING)) {
			params = setNBDetailsAsanPay(orderId, params, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.WALLET)) {
			params = setWalletDetailsAsanPay(orderId, params, formData, merchantPGDetails);
		}

		String hash = ChecksumUtils.generateCheckSum(params,
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
		logger.info("Request Params::" + params.toString());
		model.addAllAttributes(params);
		model.addAttribute(HASH, hash);

		return model;

	}

	private Model generateGenericModel(Model model, MerchantPGDetails merchantPGDetails,
			MultiValueMap<String, String> formData, String orderId) {

		model.addAttribute(APP_ID, merchantPGDetails.getMerchantPGAppId());
		model.addAttribute(ORDER_ID, orderId);
		model.addAttribute(AMOUNT, formData.get(ORDERAMOUNT).get(0));
		model.addAttribute(TXNTYPE, TXTTYPE_VALUE);
		model.addAttribute(CUST_NAME, formData.get(CUSOMERNAME).get(0));
		model.addAttribute(CUST_PHONE, formData.get(CUSTOMERPHONE).get(0));
		model.addAttribute(CUST_EMAIL, formData.get(CUSTOMEREMAIL).get(0));
		model.addAttribute(PRODUCT_DESC, PRODUCTDESC_VALUE);
		model.addAttribute(CURRENCY_CODE, CURRENCY_VALUE);
		model.addAttribute(RETURN_URL, asanPayReturnURL);
		return model;
	}

	public Map<String, String> setWalletDetailsAsanPay(String orderId, Map<String, String> params,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails) {
		populateAsanPayTransactionDetails(formData, orderId, merchantPGDetails.getMerchantPGAppId());

		WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		// model.addAttribute(PAYMENT_TYPE, PAYMENT_TYPE_NB);
		// model.addAttribute(MOP_TYPE, walletList.getPaymentcodepg());
		params.put(PAYMENT_TYPE, PAYMENT_TYPE_WL);
		params.put(MOP_TYPE, walletList.getPaymentcodepg());
		WalletPaymentDetails walletPaymentDetails = new WalletPaymentDetails();

		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		walletPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		walletPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		walletPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		walletPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		walletPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		walletPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		walletPaymentDetailsRepository.save(walletPaymentDetails);

		return params;
	}

	public Map<String, String> setUPIDetailsAsanPay(String orderId, Map<String, String> params,
			MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) {

		populateAsanPayTransactionDetails(formData, orderId, merchantPGDetails.getMerchantPGAppId());

		// model.addAttribute(PAYMENT_TYPE, PAYMENT_TYPE_UPI_VALUE);
		// model.addAttribute(MOP_TYPE, MOP_TYPE_UPI_VALUE);
		// model.addAttribute(PAYMENT_TYPE_UPI_VPA, formData.get(UPI_VPI).get(0));

		params.put(PAYMENT_TYPE, PAYMENT_TYPE_UPI_VALUE);
		params.put(MOP_TYPE, MOP_TYPE_UPI_VALUE);
		params.put(PAYMENT_TYPE_UPI_VPA, formData.get(UPI_VPI).get(0));

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return params;
	}

	private Map<String, String> setNBDetailsAsanPay(String orderId, Map<String, String> params,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails) {
		populateAsanPayTransactionDetails(formData, orderId, merchantPGDetails.getMerchantPGAppId());
		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		// model.addAttribute(PAYMENT_TYPE, PAYMENT_TYPE_NB);
		// model.addAttribute(MOP_TYPE, bankList.getPgBankCode());
		params.put(PAYMENT_TYPE, PAYMENT_TYPE_NB);
		params.put(MOP_TYPE, bankList.getPgBankCode());

		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return params;
	}

	private void populateAsanPayTransactionDetails(MultiValueMap<String, String> formData, String orderId,
			String appid) {

		AsanPayTransactionDetails asanPayTransactionDetails = new AsanPayTransactionDetails();
		asanPayTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		asanPayTransactionDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		asanPayTransactionDetails.setOrderId(orderId);
		asanPayTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		asanPayTransactionDetails.setTxStatus(UserStatus.PENDING.toString());
		asanPayTransactionDetails.setUpdateFlag("N");
		asanPayTransactionDetails.setSource("TRInitiate");
		asanPayTransactionDetails.setAppId(appid);
		asanPayTransactionDetailsRepository.save(asanPayTransactionDetails);
	}

	public AsanPayTransactionDetails updateTransactionStatus(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException, ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException {

		logger.info("Inside method updateTransactionStatus()");
		logger.info("Response Form Data" + GeneralUtils.MultiValueMaptoJson(responseFormData));

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDER_ID));

		String returnHash = pgGatewayUtilService.checkResponseData(responseFormData, RESP_HASH);

		AsanPayTransactionDetails asanPayTransactionDetails = asanPayTransactionDetailsRepository
				.findByOrderId(transactionDetails.getOrderID());

		if (transactionDetails != null) {

			if (validateReturnSignature(transactionDetails, responseFormData, returnHash)) {
				logger.info("The return signature has been verified ...");
				transactionDetails.setStatus(
						checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE),
								pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));

				transactionDetails.setTxtMsg(
						getErrorMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE)) + "|"
								+ pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_MESSAGE));
			} else {

				AsanPayTransactionStatus asanPayTransactionStatus = callAsanPayStatusapi(
						asanPayTransactionDetails.getAppId(), asanPayTransactionDetails.getOrderId());
				logger.info("The return signature not verified ...");
				transactionDetails.setStatus(
						checkStatus(asanPayTransactionStatus.getResponseCode(), asanPayTransactionStatus.getStatus()));
				transactionDetails.setTxtMsg(getErrorMsg(asanPayTransactionStatus.getResponseCode()));

			}

			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetails.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXNID));
			transactionDetails
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENT_TYPE));

			transactionDetails
					.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_DATE_TIME));

			transactionDetails.setSource("ReturnURL");
			logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsRepository.save(transactionDetails);
		}
		logger.info("Transaction Update");

		logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");

		try {

			if (asanPayTransactionDetails == null) {
				asanPayTransactionDetails = new AsanPayTransactionDetails();
				asanPayTransactionDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
				asanPayTransactionDetails
						.setOrderAmount(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERAMOUNT));
				asanPayTransactionDetails
						.setOrderId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDER_ID));
				asanPayTransactionDetails
						.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_PAYMENT_TYPE));
				asanPayTransactionDetails.setSignature(returnHash);
				asanPayTransactionDetails
						.setTxMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE));
				asanPayTransactionDetails
						.setTxStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
				asanPayTransactionDetails
						.setTxTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_DATE_TIME));
				asanPayTransactionDetails.setUpdateFlag("N");
				asanPayTransactionDetails.setSource("ReturnURL");
			} else {
				asanPayTransactionDetails.setSignature(returnHash);
				asanPayTransactionDetails
						.setTxMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE));
				asanPayTransactionDetails
						.setTxStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
				asanPayTransactionDetails
						.setTxTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_DATE_TIME));
				asanPayTransactionDetails.setUpdateFlag("N");
				asanPayTransactionDetails.setSource("ReturnURL");
				asanPayTransactionDetails
						.setResponseText(Encryption.encryptCardNumberOrExpOrCvv(responseFormData.toString()));
			}
			asanPayTransactionDetailsRepository.save(asanPayTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in AsanPayTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");

		return asanPayTransactionDetails;
	}

	public Model getResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDER_ID));

		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, transactionDetails.getStatus(), transactionDetails);
	}

	public boolean validateReturnSignature(TransactionDetails transactionDetails,
			MultiValueMap<String, String> responseFormData, String returnHash) throws NoSuchAlgorithmException {

		MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository
				.findByMerchantIDAndMerchantPGId(transactionDetails.getMerchantId(), transactionDetails.getPgId());
		logger.info("Return Hash::" + GeneralUtils.convertMultiToRegularMap(responseFormData));
		responseFormData.remove(RESP_HASH);
		Map<String, String> params = GeneralUtils.convertMultiToRegularMap(responseFormData);

		String hash = ChecksumUtils.generateCheckSum(params,
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));
		logger.info("Return Hash::" + hash);
		if (hash.equalsIgnoreCase(returnHash)) {
			return true;
		}

		return false;
	}

	public AsanPayTransactionStatus callAsanPayStatusapi(String appId, String orderId) throws JsonProcessingException {
		logger.info(appId +"|"+ orderId);
		HttpResponse<AsanPayTransactionStatus> AsanPayTransactionDetails = Unirest.get(AsanpayStatusAPI)
				.queryString("APP_ID", appId)
				.queryString("ORDER_ID", orderId)
				.asObject(AsanPayTransactionStatus.class)
				.ifFailure(SetuErrorResponse.class, r -> {
					SetuErrorResponse e = r.getBody();
					try {
						logger.info("AsanPay Status Request Response Error::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				});

		logger.info("Response :: " + Utility.convertDTO2JsonString(AsanPayTransactionDetails.getBody()));

		return AsanPayTransactionDetails.getBody();

	}

	public String getErrorMsg(String subcode) {
		Map<String, String> map = new HashMap<>();
		map.put("000", "SUCCESS");
		map.put("004", "Declined");
		map.put("001", "Acquirer Error");
		map.put("002", "Denied");
		map.put("003", "Timeout");
		map.put("005", "Authenncation not available");
		map.put("006", "Transaction Processing");
		map.put("007", "Rejected by Acquirer");
		map.put("008", "Duplicate");
		map.put("009", "Response signature did not match");
		map.put("010", "Cancelled by user");
		map.put("011", "Authorization success but error processing");
		map.put("012", "Denied due to fraud detection");
		map.put("013", "Invalid request not available");
		map.put("014", "Refund amount you requested is greater than");
		map.put("007", "Failed/Failed by acquirer");
		map.put("015", "Status is yet to be received from Bank/Customer has led the transaction in middle");
		map.put("016", "Auto Reversal");
		map.put("300", "Invalid Request");
		map.put("113", "Payment option not supported");
		try {
			return map.get(subcode);
		} catch (Exception e) {
			return subcode;
		}

	}

	public String checkStatus(String errorCode, String errorMsg) {
		String[] successarr = { "000|success" };
		String[] pendingarr = { "006|PROCESSING", "015|SENT_TO_BANK" };
		String[] failedarr = { "004|DECLINED", "001|ACQUIRER_ERROR", "002|DENIED", "003|TIMEOUT",
				"005|AUTHENTICATION_UNAVAILABLE", "007|REJECTED", "008|DUPLICATE", "009|SIGNATURE_MISMATCH",
				"010|CANCELLED", "011|RECURRING_PAYMENT_UNSUCCESSFULL", "013|INVALID_REQUEST",
				"014|REFUND_INSUFFICIENT_BALANCE", "007|TXN_FAILED", "016|AUTO_REVERSAL", "007|FAILED_AT_ACQUIRER",
				"300|VALIDATION_FAILED", "113|PAYMENT_OPTION_NOT_SUPPORTED" };
		String[] flaggedarr = { "012|DENIED_BY_RISK" };

		String msg = errorCode + "|" + errorMsg;

		logger.info("MSG::" + msg);
		if (errorCode.equals("000") && errorMsg.equalsIgnoreCase("Captured")) {
			return UserStatus.SUCCESS.toString();
		} else if ((errorCode.equals("006")) || (errorCode.equals("015"))) {
			return UserStatus.PENDING.toString();
		} else if (errorCode.equals("012")) {
			return UserStatus.FLAGGED.toString();
		} else {
			return UserStatus.FAILED.toString();
		}

	}
}
