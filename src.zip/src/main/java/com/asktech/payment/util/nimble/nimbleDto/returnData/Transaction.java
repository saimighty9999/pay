package com.asktech.payment.util.nimble.nimbleDto.returnData;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Transaction {
    private String transaction_id;
    private String payment_mode;
    private String nimbbl_merchant_message;
    private String psp_transaction_id;
    private String nimbbl_error_code;
    private Sub_payment_mode sub_payment_mode;
    private String retry_allowed;
    private String nimbbl_consumer_message;
    private String payment_partner;
    private String status;
}
