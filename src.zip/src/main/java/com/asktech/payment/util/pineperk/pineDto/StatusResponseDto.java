package com.asktech.payment.util.pineperk.pineDto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusResponseDto {

    private String merchant_data;
    private String merchant_id;
    private String order_id;
    private OrderDataResponseDto order_data;
    private PaymentInfoDataResponse payment_info_data;

}
