package com.asktech.payment.util.onepay;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.ErrorValues;
import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constant.onepay.OnePayConstants;
import com.asktech.payment.constant.onepay.OnePayTransactionResponse;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.onepay.ResponseDecryptData;
import com.asktech.payment.dto.onepay.ResponseEncryptData;
import com.asktech.payment.enums.FormValidationExceptionEnums;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.EaseBuzzTransactionDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.OnePayTransactionDetails;
import com.asktech.payment.model.PGConfigurationDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.TransactionDetailsAll;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.OnePayTransactionDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class OnePayPaymentUtils implements CashFreeFields, OnePayConstants , ErrorValues{
	
	@Value("${pgEndPoints.onepaySeamLess}")
	String onepaySeamLess;
	@Value("${pgEndPoints.onepayReturnURL}")
	String onepayReturnURL;
	@Value("${easebuzz.productInfo}")
	String productInfo;
	@Value("${pgEndPoints.onePayPaymentStatus}")
	String onePayPaymentStatus;
	
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;	
	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	WalletListRepository walletListRepository;
	@Autowired
	PGConfigurationDetailsRepository pgConfigurationDetailsRepository;
	@Autowired
	OnePayTransactionDetailsRepository onePayTransactionDetailsRepository;

	static Logger logger = LoggerFactory.getLogger(OnePayPaymentUtils.class);

	public Model process1PayRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) throws IOException, ParseException {

		String secretKey = Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret());
		//String encdata = null;
		logger.info("process1PayRequest");
		JSONObject body = new JSONObject();
		body.put(DATETIME,new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
		body.put(AMOUNT, String.format("%.2f",(double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100));
		body.put(ISMULTISETTLEMENT, "0");
		body.put(CUSTMOBILE, formData.get(CUSTOMERPHONE).get(0));
		body.put(APIKEY, secretKey);
		body.put(PRODUCTID, "DEFAULT");
		body.put(TXNTYPE, "REDIRECT");
		body.put(UDF3,"NA");
		body.put(UDF1,"NA");
		body.put(UDF2,"NA");
		body.put(UDF4,"NA");
		body.put(UDF5,"NA");
		body.put(MERCHANTID, merchantPGDetails.getMerchantPGAppId());
		body.put(CUSTMAIL, formData.get(CUSTOMEREMAIL).get(0));
		body.put(RETURNURL1PAY, onepayReturnURL);
		body.put(CHANNELID,"0");
		body.put(TXNID,orderId);	
		logger.info("populateOnePayTransDetails");
		populateOnePayTransDetails(formData, merchantPGDetails, orderId);
		
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {
			body.put(INSTRUMENTID, "UPI");
			body.put(CARDTYPE, "UPI");			
			model = setUPIDetailsOnePay(body,orderId, model, secretKey, formData , merchantPGDetails);
			
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.NETBANKING)) {
			body.put(INSTRUMENTID, PAYMENT_MODE_NB);
			body.put(CARDTYPE, "NA");		
			
			model = setNBDetailsOnePay(body,orderId, model, secretKey, formData , merchantPGDetails);
			
		}else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.CARD)) {
			body.put(INSTRUMENTID, "DC");
			body.put(CARDTYPE, "Visa");
			body.put(CARDDETAILS, formData.get(CARD_HOLDER).get(0)+"|"+
						formData.get(CARD_HOLDER).get(0)+"|"+
						formData.get(CARD_EXPMONTH).get(0));
		}
		
		//populateOnePayTransDetails(formData, merchantPGDetails, orderId);
		
		return model;

	}	
	
	public Model setNBDetailsOnePay(JSONObject body,String orderId, Model model, String secretKey, MultiValueMap<String, 
			String> formData, MerchantPGDetails merchantPGDetails ) {
		
		
		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName
				(formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(),
						UserStatus.ACTIVE.toString(),merchantPGDetails.getMerchantPGName());

		body.put(CARDDETAILS,bankList.getPgBankCode());
		logger.info(body.toString());
		String encdata = EncryptionOnePay.encrypt(secretKey, secretKey.subSequence(0, 16).toString(),body.toString());
		model.addAttribute(MODEL_MERCHANTID, merchantPGDetails.getMerchantPGAppId());
		model.addAttribute(MODEL_REQDATA, encdata);		
		
		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return model;
	}

	public Model setUPIDetailsOnePay(JSONObject body,String orderId, Model model, String secretKey, MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails ) {

		body.put(CARDDETAILS,formData.get(UPI_VPI).get(0));
		logger.info(body.toString());
		String encdata = EncryptionOnePay.encrypt(secretKey, secretKey.subSequence(0, 16).toString(),body.toString());
		model.addAttribute(MODEL_MERCHANTID, merchantPGDetails.getMerchantPGAppId());
		model.addAttribute(MODEL_REQDATA, encdata);
		
		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return model;
	}

	
	public ResponseDecryptData updateTransactionStatus1Pay(MultiValueMap<String, String> responseFormData) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		
		logger.info("Inside method updateTransactionStatus()");
		logger.info("Response Form Data" + GeneralUtils.MultiValueMaptoJson(responseFormData));
		
		ResponseEncryptData responseEncryptData = mapper.readValue(GeneralUtils.MultiValueMaptoJson(responseFormData), ResponseEncryptData.class);
		
		logger.info("After Json Convert for Raw Response :: "+Utility.convertDTO2JsonString(responseEncryptData));
		
		PGConfigurationDetails pgConfigurationDetails = pgConfigurationDetailsRepository.findByPgAppId(responseEncryptData.getMerchantId());
		logger.info("pgConfigurationDetails :: "+Utility.convertDTO2JsonString(pgConfigurationDetails));
		
		if(pgConfigurationDetails == null) {
			throw new UserException(TEMPARE_ALERT, FormValidationExceptionEnums.E0087);
		}
		logger.info("Before Decryption");
		
		String decryptStr = EncryptionOnePay.decrypt(Encryption.decryptCardNumberOrExpOrCvv(pgConfigurationDetails.getPgSecret()),
				Encryption.decryptCardNumberOrExpOrCvv(pgConfigurationDetails.getPgSecret()).substring(0, 16), 
				responseEncryptData.getRespData());		
		ResponseDecryptData responseDecryptData = mapper.readValue(decryptStr, ResponseDecryptData.class);
		
		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(responseDecryptData.getTxnId());
		
		OnePayTransactionResponse onePayTransactionResponse = call1PayStatusApi(pgConfigurationDetails, transactionDetails);
		
		
		if (transactionDetails != null) {
			
			MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository.findByMerchantIDAndMerchantPGId(
					transactionDetails.getMerchantId(), transactionDetails.getPgId());	
			
			
			transactionDetails.setStatus(checkStatus(onePayTransactionResponse.getTrans_status()));			
			transactionDetails.setPgOrderID(responseDecryptData.getPgRefId());
			transactionDetails.setPaymentMode(responseDecryptData.getPaymentMode());
			transactionDetails.setTxtMsg(responseDecryptData.getRespMessage());
			transactionDetails.setTxtPGTime(responseDecryptData.getRespDateTime());
			
			transactionDetails.setSource("ReturnURL");
			//logger.info("Insert Transaction Details :: " + Utility.convertDTO2JsonString(transactionDetails));
			
			transactionDetailsRepository.save(transactionDetails);
		}else {
			TransactionDetailsAll transactionDetailsAll = new TransactionDetailsAll();
			//logger.info("Transaction Details Null");
			logger.info("Insert All Transaction Details");
			transactionDetails = transactionDetailsRepository.findByOrderID(responseDecryptData.getTxnId());

			//logger.info("Insert Transaction Details by orderId:: " + Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsAll.setOrderID(responseDecryptData.getTxnId());
			transactionDetailsAll.setStatus(responseDecryptData.getTransStatus());
			transactionDetailsAll.setPgOrderID(responseDecryptData.getPgRefId());
			transactionDetailsAll.setPaymentMode(responseDecryptData.getPaymentMode());
			transactionDetails.setTxtMsg(responseDecryptData.getRespMessage());
			transactionDetails.setTxtPGTime(responseDecryptData.getRespDateTime());

			transactionDetailsAllRepository.save(transactionDetailsAll);
		}
		
		//logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			//logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			//logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				//logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					//logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails), userDetails.getEmailId(), "CustomerEmail");
		
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");
		
		try {
			
			OnePayTransactionDetails onePayTransactionDetails  = 
					onePayTransactionDetailsRepository.findByMerchantOrderIdAndOrderId(transactionDetails.getMerchantOrderId(),
							responseDecryptData.getTxnId());
			
			if(onePayTransactionDetails == null) {
			 onePayTransactionDetails = new OnePayTransactionDetails();
			
			onePayTransactionDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
			onePayTransactionDetails.setOrderAmount(responseDecryptData.getTxnAmount());
			onePayTransactionDetails.setOrderId(responseDecryptData.getTxnId());
			onePayTransactionDetails.setPaymentMode(responseDecryptData.getPaymentMode());
			onePayTransactionDetails.setReferenceId(responseDecryptData.getBankRefId());
			onePayTransactionDetails.setTxMsg(responseDecryptData.getRespMessage());			
			onePayTransactionDetails.setTxStatus(checkStatus(responseDecryptData.getTransStatus()));
			onePayTransactionDetails.setTxTime(responseDecryptData.getTxnDateTime());
			onePayTransactionDetails.setUpdateFlag("N");
			onePayTransactionDetails.setSource("ReturnURL");
			onePayTransactionDetails.setResponseText(Encryption.encryptCardNumberOrExpOrCvv(responseFormData.toString()));
			
			}else  {
				onePayTransactionDetails.setReferenceId(responseDecryptData.getBankRefId());
				onePayTransactionDetails.setTxMsg(responseDecryptData.getRespMessage());			
				onePayTransactionDetails.setTxStatus(checkStatus(responseDecryptData.getTransStatus()));
				onePayTransactionDetails.setTxTime(responseDecryptData.getTxnDateTime());
				onePayTransactionDetails.setUpdateFlag("N");
				onePayTransactionDetails.setSource("ReturnURL");
				onePayTransactionDetails.setResponseText(Encryption.encryptCardNumberOrExpOrCvv(responseFormData.toString()));
			}
			
			onePayTransactionDetailsRepository.save(onePayTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in CashfreeTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");		
		return responseDecryptData;
	}
	
	
	
	public Model getResponseProcess(ResponseDecryptData responseDecryptData, Model model) throws InvalidKeyException, NoSuchAlgorithmException
			 {
		
		//logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(responseDecryptData.getTxnId());
		
		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		String status = checkStatus(responseDecryptData.getTransStatus());
		return pgGatewayUtilService.populateReturnModel(model, amt, status, transactionDetails);
	}
	
	public String checkStatus(String onepayStatus) {
		if (onepayStatus.equalsIgnoreCase(STATUS_OK)) {
			return UserStatus.SUCCESS.toString();
		}
		if (onepayStatus.equalsIgnoreCase(STATUS_FAILED)) {
			return UserStatus.FAILED.toString();
		}
		if (onepayStatus.equalsIgnoreCase(STATUS_TO)) {
			return UserStatus.DROPPED.toString();
		}
		return onepayStatus;
	}
	
	public OnePayTransactionResponse call1PayStatusApi(PGConfigurationDetails pgConfigurationDetails, 
			TransactionDetails transactionDetails )
			throws Exception {
		
		String requestURL = onePayPaymentStatus+"?merchantId="+pgConfigurationDetails.getPgAppId()+"&txnId="+transactionDetails.getOrderID();
				
		HttpResponse<OnePayTransactionResponse> onePayTransactionResponse = Unirest.post(requestURL)
				.header("Content-Type", "application/x-www-form-urlencoded")
				.asObject(OnePayTransactionResponse.class);
		return onePayTransactionResponse.getBody();
	}
	
	public void populateOnePayTransDetails(MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) {
		logger.info("Tr Init populateOnePayTransDetails");
		OnePayTransactionDetails onePayTransactionDetails = new OnePayTransactionDetails();
		
		onePayTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		onePayTransactionDetails.setOrderAmount(String.format("%.2f",(double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100));
		onePayTransactionDetails.setOrderId(orderId);
		onePayTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		onePayTransactionDetails.setTxStatus(UserStatus.PENDING.toString());
		onePayTransactionDetails.setUpdateFlag("N");
		onePayTransactionDetails.setSource("TRInitiate");
		logger.info("Insertion Done in to table on initiation");
		onePayTransactionDetailsRepository.save(onePayTransactionDetails);
	}
}
