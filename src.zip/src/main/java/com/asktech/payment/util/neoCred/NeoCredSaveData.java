package com.asktech.payment.util.neoCred;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.asktech.payment.model.NeoCredTransactionDetails;
import com.asktech.payment.repository.NeoCredTransactionDetailsRepo;
import com.asktech.payment.util.Utility;
import com.asktech.payment.util.neoCred.neoCredDto.Customer;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class NeoCredSaveData {

    @Autowired
    NeoCredTransactionDetailsRepo neoCredTransactionDetailsRepo;
    
    static Logger logger = LoggerFactory.getLogger(NeoCredSaveData.class);

    public boolean checkUpiId(String checkUpiId) throws JsonProcessingException {
        List<NeoCredTransactionDetails> neoCredTransactionDetails = neoCredTransactionDetailsRepo
                .findByUpiId(checkUpiId);
        logger.info("neo checkUpiId:: "+Utility.convertDTO2JsonString(neoCredTransactionDetails));
        if (neoCredTransactionDetails.size() > 0) {
            return true;
        }
        return false;
    }

    public void saveNeoTransaction(String orderId, String merchantId, String upiId, Customer customer, String upiLink) {
        NeoCredTransactionDetails neoCredTransactionDetails = new NeoCredTransactionDetails();
        neoCredTransactionDetails.setMerchantId(merchantId);
        neoCredTransactionDetails.setOrderId(orderId);
        neoCredTransactionDetails.setTransactionStatus("INITIATED");
        neoCredTransactionDetails.setUpiText(upiLink);
        neoCredTransactionDetails.setUpiId(upiId);
        if (customer != null) {
            try {
                neoCredTransactionDetails.setReqText(Utility.convertDTO2JsonString(customer));
            } catch (JsonProcessingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        neoCredTransactionDetailsRepo.save(neoCredTransactionDetails);
    }

    public void updateNeoTransaction(String orderId, String status, String response, String reqType) {
        NeoCredTransactionDetails neoCredTransactionDetails = neoCredTransactionDetailsRepo
                .findByOrderId(orderId);
        if (neoCredTransactionDetails != null) {
            neoCredTransactionDetails.setTransactionStatus(status);
            if(reqType.equals("STATUSAPI")){
                neoCredTransactionDetails.setStatusText(response);
            }else{
                neoCredTransactionDetails.setResponseText(response);
            }
            neoCredTransactionDetailsRepo.save(neoCredTransactionDetails);
        }
    }



}
