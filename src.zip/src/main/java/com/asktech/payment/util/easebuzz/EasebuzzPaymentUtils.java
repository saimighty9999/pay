package com.asktech.payment.util.easebuzz;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constant.easebuzz.EasebuzzConstants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.EaseBuzzTransactionDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.TransactionDetailsAll;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.EaseBuzzTransactionDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class EasebuzzPaymentUtils implements CashFreeFields, EasebuzzConstants {

	@Value("${pgEndPoints.easebuzzCreateLink}")
	String easebuzzCreateLink;
	@Value("${pgEndPoints.easebuzzSeamLess}")
	String easebuzzSeamLess;
	@Value("${pgEndPoints.easebuzzReturnURL}")
	String easebuzzReturnURL;
	@Value("${easebuzz.productInfo}")
	String productInfo;

	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	EaseBuzzTransactionDetailsRepository easeBuzzTransactionDetailsRepository;
	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	WalletListRepository walletListRepository;

	static Logger logger = LoggerFactory.getLogger(EasebuzzPaymentUtils.class);

	public Model processEaseBuzzRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) throws IOException, ParseException {

		Map<String, String> params = new HashMap<String, String>();
		params.put(TXTID, orderId);
		params.put(AMOUNT, String.valueOf((double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100));
		params.put(PRODUCTINFO, productInfo);
		params.put(FIRSTNAME, formData.get(CUSOMERNAME).get(0));
		params.put(EMAIL, formData.get(CUSTOMEREMAIL).get(0));
		params.put(PHONE, formData.get(CUSTOMERPHONE).get(0));
		params.put(SURL, easebuzzReturnURL);
		params.put(FURL, easebuzzReturnURL);
		params.put(REQUEST_FLOW, Request_FLOW_SEAMLESS);

		String data = createInitiatePaymentLink(params,
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()),
				merchantPGDetails.getMerchantPGSaltKey());
		//logger.info("Data :: " + data);

		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.UPI)) {
			model = setUPIDetailsEasebuzz(orderId, model, data, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.NETBANKING)) {
			model = setNBDetailsEasebuzz(orderId, model, data, formData, merchantPGDetails);
		} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(TransactioMethods.WALLET)) {
			model = setWalletDetailsEasebuzz(orderId, model, data, formData, merchantPGDetails);
		}

		populateEaseBuzzTransDetails(formData, merchantPGDetails, orderId);
		
		return model;

	}

	public String createInitiatePaymentLink(Map<String, String> params, String merchant_key, String salt)
			throws IOException, ParseException {

		params.put("key", merchant_key);
		String hash = generateCommanHash(params, merchant_key, salt);
		params.put(HASH, hash);

		StringBuilder sb = new StringBuilder();
		for (Map.Entry<String, String> e : params.entrySet()) {
			if (sb.length() > 0) {
				sb.append('&');
			}
			sb.append(URLEncoder.encode(e.getKey().trim(), "UTF-8")).append('=')
					.append(URLEncoder.encode(e.getValue().trim(), "UTF-8"));
		}
		// logger.info("String Builder output for Initiate Payment :: " +
		// sb.toString());

		URL url = new URL(easebuzzCreateLink + "payment/initiateLink");
		HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
		con.setRequestMethod("POST");
		con.setDoOutput(true);
		PrintStream ps = new PrintStream(con.getOutputStream());
		ps.println(sb);
		ps.close();
		con.connect();
		StringBuilder res = new StringBuilder();
		if (con.getResponseCode() == HttpsURLConnection.HTTP_OK) {
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String line;
			while ((line = br.readLine()) != null) {
				res.append(line);
			}
			br.close();
		}
		con.disconnect();
		// logger.info(res.toString());
		Object obj = new JSONParser().parse(res.toString());
		JSONObject jo = (JSONObject) obj;
		// logger.info("JSON Object :: " + Utility.convertDTO2JsonString(jo));
		return (String) jo.get("data");

	}

	public String generateCommanHash(Map<String, String> params, String merchant_key, String salt) {

		String hashString = "";
		String hash = "";

		String hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
		if (StringUtils.isEmpty(params.get("key"))) {
			logger.info("Generated HASH Exception due to KEY not found ");
		} else {
			String[] hashVarSeq = hashSequence.split("\\|");
			for (String part : hashVarSeq) {
				hashString = (StringUtils.isEmpty(params.get(part))) ? hashString.concat("")
						: hashString.concat(params.get(part));
				hashString = hashString.concat("|");
			}
			hashString = hashString.concat(salt);
			hash = Easebuzz_Generatehash512("SHA-512", hashString);
		}
		return hash;
	}

	public String generateReturnHash(Map<String, String> params) {

		String hashString = "";
		String hash = "";

		String hashSequence = "salt|status|udf10|udf9|udf8|udf7|udf6|udf5|udf4|udf3|udf2|udf1|email|firstname|productinfo|amount|txnid";
		if (StringUtils.isEmpty(params.get("salt"))) {
			logger.info("Generated HASH Exception due to salt not found ");
		} else {
			String[] hashVarSeq = hashSequence.split("\\|");
			for (String part : hashVarSeq) {
				hashString = (StringUtils.isEmpty(params.get(part))) ? hashString.concat("")
						: hashString.concat(params.get(part));
				hashString = hashString.concat("|");
			}
			hashString = hashString.concat(params.get("key"));
			// logger.info("Return HASH String :: "+hashString);

			hash = Easebuzz_Generatehash512("SHA-512", hashString);

		}
		return hash;
	}

	public String Easebuzz_Generatehash512(String type, String str) {
		byte[] hashseq = str.getBytes();
		StringBuffer hexString = new StringBuffer();
		try {
			MessageDigest algorithm = MessageDigest.getInstance(type);
			algorithm.reset();
			algorithm.update(hashseq);
			byte messageDigest[] = algorithm.digest();
			for (int i = 0; i < messageDigest.length; i++) {
				String hex = Integer.toHexString(0xFF & messageDigest[i]);
				if (hex.length() == 1) {
					hexString.append("0");
				}
				hexString.append(hex);
			}
		} catch (NoSuchAlgorithmException nsae) {
		}
		return hexString.toString();
	}

	public Model setWalletDetailsEasebuzz(String orderId, Model model, String data,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails) {

		WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());
		model.addAttribute(MODEL_DATA, data);
		model.addAttribute(MODEL_PAYMENT_MODE, PAYMENT_MODE_MW);
		model.addAttribute(MODEL_BANK_CODE, walletList.getPaymentcodepg());

		WalletPaymentDetails walletPaymentDetails = new WalletPaymentDetails();

		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(Utility.getAmountConversion(formData.get(ORDERAMOUNT).get(0)));
		walletPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		walletPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		walletPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		walletPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		walletPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		walletPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		walletPaymentDetailsRepository.save(walletPaymentDetails);

		return model;
	}

	public Model setNBDetailsEasebuzz(String orderId, Model model, String data, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) {

		BankList bankList = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
				formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(), UserStatus.ACTIVE.toString(),
				merchantPGDetails.getMerchantPGName());

		model.addAttribute(MODEL_DATA, data);
		model.addAttribute(MODEL_PAYMENT_MODE, PAYMENT_MODE_NB);
		model.addAttribute(MODEL_BANK_CODE, bankList.getPgBankCode());

		logger.info("data :: " + data + " , PAYMENT_MODE_NB :: " + PAYMENT_MODE_NB + " , MODEL_BANK_CODE :: "
				+ bankList.getPgBankCode());
		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return model;
	}

	public Model setUPIDetailsEasebuzz(String orderId, Model model, String data, MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails) {

		model.addAttribute(MODEL_DATA, data);
		model.addAttribute(MODEL_PAYMENT_MODE, PAYMENT_MODE_UPI);
		model.addAttribute(MODEL_UPI_VA, formData.get(UPI_VPI).get(0));

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency(formData.get(ORDERCURRENCY).get(0));
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));

		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return model;
	}

	public void updateTransactionStatusEasebuzz(MultiValueMap<String, String> responseFormData)
			throws JsonProcessingException {
		logger.info("Inside method updateTransactionStatus()");
		// logger.info("Response Form Data" +
		// GeneralUtils.MultiValueMaptoJson(responseFormData));

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, TXTID));

		if (transactionDetails != null) {

			MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository
					.findByMerchantIDAndMerchantPGId(transactionDetails.getMerchantId(), transactionDetails.getPgId());

			if (validateReturnSignature(GeneralUtils.convertMultiToRegularMap(responseFormData),
					Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()),
					merchantPGDetails.getMerchantPGSaltKey())) {
				logger.info("The return signature has been verified ...");

				transactionDetails
						.setStatus(checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));

				
				logger.info("The return signature not verified ...");
				transactionDetails.setStatus(UserStatus.FAILED.toString());
			}
			transactionDetails
					.setStatus(checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));
			transactionDetails.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_easepayid));
			transactionDetails.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_MODE));
			transactionDetails.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_error_Message));
			transactionDetails.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));

			transactionDetails.setSource("ReturnURL");
			// logger.info("Insert Transaction Details :: " +
			// Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsRepository.save(transactionDetails);
		} else {
			TransactionDetailsAll transactionDetailsAll = new TransactionDetailsAll();
			// logger.info("Transaction Details Null");
			logger.info("Insert All Transaction Details");
			transactionDetails = transactionDetailsRepository
					.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, TXTID));

			// logger.info("Insert Transaction Details by orderId:: " +
			// Utility.convertDTO2JsonString(transactionDetails));

			transactionDetailsAll.setOrderID(pgGatewayUtilService.checkResponseData(responseFormData, TXTID));
			transactionDetailsAll
					.setStatus(checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));
			transactionDetailsAll
					.setPgOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_easepayid));

			transactionDetailsAll.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_MODE));
			transactionDetails.setTxtMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_error_Message));
			transactionDetails.setTxtPGTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));

			transactionDetailsAllRepository.save(transactionDetailsAll);
		}

		// logger.info("Get User Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			// logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			// logger.info("merchantDetails " +
			// Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				// logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					// logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(
							pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		// logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails),
				userDetails.getEmailId(), "CustomerEmail");
		// logger.info("createMailRepo Email Complete");
		// logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");

		try {
			
			EaseBuzzTransactionDetails easeBuzzTransactionDetails = 
					easeBuzzTransactionDetailsRepository.findByMerchantOrderIdAndOrderId(transactionDetails.getMerchantOrderId(),
							pgGatewayUtilService.checkResponseData(responseFormData, TXTID));

			if(easeBuzzTransactionDetails ==null) {
			
				easeBuzzTransactionDetails = new EaseBuzzTransactionDetails();
				
			easeBuzzTransactionDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
			easeBuzzTransactionDetails
					.setOrderAmount(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDERAMOUNT));
			easeBuzzTransactionDetails.setOrderId(pgGatewayUtilService.checkResponseData(responseFormData, TXTID));
			easeBuzzTransactionDetails
					.setPaymentMode(pgGatewayUtilService.checkResponseData(responseFormData, RESP_MODE));
			easeBuzzTransactionDetails
					.setReferenceId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_easepayid));
			easeBuzzTransactionDetails
					.setSignature(pgGatewayUtilService.checkResponseData(responseFormData, RESP_HASH));
			easeBuzzTransactionDetails
					.setTxMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_error_Message));
			easeBuzzTransactionDetails
					.setTxStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
			easeBuzzTransactionDetails.setTxTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));
			easeBuzzTransactionDetails.setUpdateFlag("N");
			easeBuzzTransactionDetails.setSource("ReturnURL");
			easeBuzzTransactionDetails.setEmail(pgGatewayUtilService.checkResponseData(responseFormData, EMAIL));
			easeBuzzTransactionDetails.setPhoneNo(pgGatewayUtilService.checkResponseData(responseFormData, PHONE));
			easeBuzzTransactionDetails
					.setResponseText(Encryption.encryptCardNumberOrExpOrCvv(responseFormData.toString()));
			}else {
				easeBuzzTransactionDetails.setSource("ReturnURL");
				easeBuzzTransactionDetails
				.setReferenceId(pgGatewayUtilService.checkResponseData(responseFormData, RESP_easepayid));
				easeBuzzTransactionDetails
				.setSignature(pgGatewayUtilService.checkResponseData(responseFormData, RESP_HASH));
				easeBuzzTransactionDetails
				.setTxMsg(pgGatewayUtilService.checkResponseData(responseFormData, RESP_error_Message));
				easeBuzzTransactionDetails
				.setTxStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
				easeBuzzTransactionDetails.setTxTime(pgGatewayUtilService.checkResponseData(responseFormData, RESP_TXTIME));
			}
			easeBuzzTransactionDetailsRepository.save(easeBuzzTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in CashfreeTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");
	}

	public Model getResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		// logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, TXTID));

		String status = null;
		MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository
				.findByMerchantIDAndMerchantPGId(transactionDetails.getMerchantId(), transactionDetails.getPgId());
		logger.info(Utility.convertDTO2JsonString(merchantPGDetails));
		logger.info(Utility.convertDTO2JsonString(GeneralUtils.MultiValueMaptoJson(responseFormData)));
		if (validateReturnSignature(GeneralUtils.convertMultiToRegularMap(responseFormData),
				Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()),
				merchantPGDetails.getMerchantPGSaltKey())) {
			logger.info("The return signature has been verified ...");
			logger.info(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS));
			transactionDetails
					.setStatus(checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));

		} else {
			logger.info("The return signature not verified ...");
			transactionDetails.setStatus(UserStatus.FAILED.toString());
		}
		status = transactionDetails.getStatus();
		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		return pgGatewayUtilService.populateReturnModel(model, amt, status, transactionDetails);
	}

	public boolean validateReturnSignature(Map<String, String> params, String merchant_key, String salt) {

		// logger.info("Secret Key :: "+merchant_key);
		String retriveHash = params.get(HASH);
		// logger.info("Retrive HASH from EaseBuzz :: "+retriveHash);
		params.put("salt", salt);
		String generatedHash = generateReturnHash(params);
		// logger.info("Generated HASH To Verify :: "+generatedHash);
		if (retriveHash.equals(generatedHash)) {
			return true;
		}
		return false;
	}

	public String checkStatus(String eazeBuzz) {
		if (eazeBuzz.equalsIgnoreCase(STAT_SUCCESS)) {
			return UserStatus.SUCCESS.toString();
		}
		if (eazeBuzz.equalsIgnoreCase(STAT_INIT) || eazeBuzz.equalsIgnoreCase(STAT_PENDING)) {
			return UserStatus.PENDING.toString();
		}
		if (eazeBuzz.equalsIgnoreCase(STAT_FAILURE)) {
			return UserStatus.FAILED.toString();
		}
		if (eazeBuzz.equalsIgnoreCase(STAT_DROPPED) || eazeBuzz.equalsIgnoreCase(STAT_BOUNCED)
				|| eazeBuzz.equalsIgnoreCase(STAT_USER_CANCELLED)) {
			return UserStatus.DROPPED.toString();
		}
		return UserStatus.FAILED.toString();
	}
	
	public void populateEaseBuzzTransDetails(MultiValueMap<String, String> formData,
			MerchantPGDetails merchantPGDetails, String orderId) {
		
		EaseBuzzTransactionDetails easeBuzzTransactionDetails = new EaseBuzzTransactionDetails();
		
		easeBuzzTransactionDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		easeBuzzTransactionDetails.setOrderAmount(String.valueOf((double) Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) / 100));
		easeBuzzTransactionDetails.setOrderId(orderId);
		easeBuzzTransactionDetails.setPaymentMode(formData.get(PAYMENT_OPTION).get(0));
		easeBuzzTransactionDetails.setTxStatus(UserStatus.PENDING.toString());
		easeBuzzTransactionDetails.setUpdateFlag("N");
		easeBuzzTransactionDetails.setSource("Initiated");
		easeBuzzTransactionDetails.setEmail(formData.get(CUSTOMEREMAIL).get(0));
		easeBuzzTransactionDetails.setPhoneNo(formData.get(CUSTOMERPHONE).get(0));
		easeBuzzTransactionDetailsRepository.save(easeBuzzTransactionDetails);
	}

}
