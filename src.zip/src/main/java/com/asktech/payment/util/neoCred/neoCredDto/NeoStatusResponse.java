package com.asktech.payment.util.neoCred.neoCredDto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class NeoStatusResponse {
    @JsonProperty("gatewayResponseStatus")
    private String gatewayResponseStatus;
    @JsonProperty("amount")
    private String amount;
    @JsonProperty("gatewayReferenceId")
    private String gatewayReferenceId;
    @JsonProperty("gatewayTransactionId")
    private String gatewayTransactionId;
    @JsonProperty("payeeVpa")
    private String payeeVpa;
    @JsonProperty("gatewayResponseCode")
    private String gatewayResponseCode;
    @JsonProperty("payerName")
    private String payerName;
    @JsonProperty("payerVpa")
    private String payerVpa;
    @JsonProperty("merchantRequestId")
    private String merchantRequestId;
    @JsonProperty("payeeMcc")
    private String payeeMcc;
    @JsonProperty("transactionTimestamp")
    private String transactionTimestamp;
    @JsonProperty("gatewayResponseMessage")
    private String gatewayResponseMessage;
}
