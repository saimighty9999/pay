package com.asktech.payment.util.nimble.nimbleDto;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Extra_infoNetBankingDto {    
   private DataNetbanking data;
}
