package com.asktech.payment.util.pineperk.pineDto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Merchant_data {
    private String merchant_return_url;
    private String merchant_access_code;
    private String merchant_order_id;
    private String merchant_id;
}
