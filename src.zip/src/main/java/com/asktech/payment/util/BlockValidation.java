package com.asktech.payment.util;

import java.util.List;
import java.util.Set;

import com.asktech.payment.constant.CardsFields;
import com.asktech.payment.constant.TransactioMethods;
import com.asktech.payment.constant.UpiFields;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BlockList;
import com.asktech.payment.repository.BlockListRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

@Component
public class BlockValidation implements TransactioMethods, CardsFields, UpiFields {
    @Autowired
    BlockListRepo blockListRepo;

    public String validateContent(MultiValueMap<String, String> formData) throws ValidationExceptions {
        Set<String> keyvalue = formData.keySet();
        if (!keyvalue.contains(PAYMENTOPTION)) {
            return "Field is missing1";

        }

        List<BlockList> phn = blockListRepo.findByPhonenumber(formData.get(CUSTOMERPHONE).get(0));
        if (phn.size() > 0) {
            return "Customer Phone number is Black Listed";
        }
        List<BlockList> email = blockListRepo.findByEmail(formData.get(CUSTOMEREMAIL).get(0));
        if (email.size() > 0) {
            return "Customer Email number is Black Listed";
        }
        List<String> paymentopt = formData.get(PAYMENTOPTION);
        switch (paymentopt.get(0).toLowerCase()) {
            case CARD:
                List<BlockList> details = blockListRepo.findByCardno(formData.get(CARD_NUMBER).get(0));
                if (details.size() > 0) {
                    return "Card Number is Black Listed";
                }
                break;
            case UPI:
                List<BlockList> dts = blockListRepo.findByVpaid(formData.get(UPI_VPA).get(0));
                if (dts.size() > 0) {
                    return "VPA is Black Listed";
                }
                break;
            default:
                return null;
        }
        return null;
    }

    public String validateIpAddress(String IpAddress){
        return null;
    }

    public String validateReturnUrl(){
        return null;
    }
}

