// package com.asktech.payment.util.trustlypay;


// import java.io.UnsupportedEncodingException;
// import java.security.MessageDigest;
// import java.security.NoSuchAlgorithmException;

// import javax.crypto.Mac;
// import javax.crypto.spec.IvParameterSpec;
// import javax.crypto.spec.PBEKeySpec;
// import javax.crypto.spec.SecretKeySpec;

// import org.apache.commons.codec.binary.Hex;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.stereotype.Component;
// import org.springframework.ui.Model;
// import org.springframework.util.MultiValueMap;

// import com.asktech.payment.constants.cashfree.CashFreeFields;
// import com.asktech.payment.exception.ValidationExceptions;
// import com.asktech.payment.model.MerchantPGDetails;
// import com.asktech.payment.repository.MerchantDetailsRepository;
// import com.asktech.payment.repository.MerchantPGDetailsRepository;
// import com.asktech.payment.repository.PGConfigurationDetailsRepository;
// import com.asktech.payment.repository.TransactionDetailsAllRepository;
// import com.asktech.payment.repository.TransactionDetailsRepository;
// import com.asktech.payment.repository.UPIPaymentDetailsRepository;
// import com.asktech.payment.repository.UserDetailsRepository;
// import com.asktech.payment.service.PGGatewayUtilService;
// import com.asktech.payment.util.Utility;
// import com.asktech.payment.util.trustlypay.trustlydto.Requestdto;
// import com.fasterxml.jackson.core.JsonProcessingException;



// public class Trustlypayutility implements CashFreeFields {

//     static Logger logger = LoggerFactory.getLogger( Trustlypayutility.class);
//     @Autowired
//     PGConfigurationDetailsRepository pgConfigurationDetailsRepository;
//     @Autowired
//     UPIPaymentDetailsRepository upiPaymentDetailsRepository;
//     @Autowired
//     TransactionDetailsRepository transactionDetailsRepository;
//     @Autowired
//     PGGatewayUtilService pgGatewayUtilService;
//     @Autowired
//     MerchantPGDetailsRepository merchantPGDetailsRepository;
//     @Autowired
//     TransactionDetailsAllRepository transactionDetailsAllRepository;
//     @Autowired
//     UserDetailsRepository userDetailsRepository;
//     @Autowired
//     MerchantDetailsRepository merchantDetailsRepository;

//     public static Model processRequest(MultiValueMap<String, String> formData, Model model,
//     MerchantPGDetails merchantPGDetails, String orderId, String return_url)
//     throws Exception {

//    String clientId="TP_test_TUfuyXQYWSTDXHbO";
//    String clientSecret ="vSomQozCGpEOYUoS";
//     String hashkey="uTKDbWQroxZoIqJ2";
//      String saltkey="R7EvQbLtWa5HVb4D";
//    String AesRequestkey="CLlQzkkpS7lkT4hU";


//    Requestdto paymentReq = setPaymentRequest();
//    return  model;
// }

//   //public static Requestdto setPaymentRequest(MultiValueMap<String, String> formData,MerchantPGDetails merchantPGDetails, String orderId, String apiKey, String salt, String returnUrl) throws NoSuchAlgorithmException, UnsupportedEncodingException{
//        // Requestdto paymentReq = new Requestdto();
// public static Requestdto setPaymentRequest() throws Exception{
//     Requestdto paymentReq = new Requestdto();
//     paymentReq.setAmount("1000");
//     paymentReq.setClientId("TP_test_TUfuyXQYWSTDXHbO");
//     paymentReq.setClientSecret("vSomQozCGpEOYUoS");
//     paymentReq.setEmailId("tech@analytiqbv.com");
//     paymentReq.setMobileNumber("9829829945");
//     paymentReq.setRequestHashKey("CLlQzkkpS7lkT4hU");
// paymentReq.setTxncurr("INR");
// paymentReq.setUsername("tech");
// signatureCreation(paymentReq);
// return paymentReq;
// }




// /**
//  * @param key
//  * @param Id
//  * @param secret
//  * @param txcur
//  * @param amount
//  * @param email
//  * @param mobile
//  * @return
//  * @throws Exception
//  */
// public static void signatureCreation(
//     // tring key, String Id, String secret, String txcur, String amount, String email, String mobile, 
//     Requestdto trust) throws Exception {
//     //  = new Requestdto();
//     // String signature = e(trust.getRequestHashKey(), trust.getClientId(), trust.getClientSecret(), trust.getTxncurr(),trust.getAmount(),trust.getEmailId(),trust.getMobileNumber());
//         Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
//         SecretKeySpec secret_key = new SecretKeySpec(trust.getRequestHashKey().getBytes("UTF-8"), "HmacSHA256");
        
//         sha256_HMAC.init(secret_key);
//         String request = null;
        
//         // StringBuilder sb = new StringBuilder();
//         // for (String s :  ) {
//         // sb.append(s);
//         // }
//         // request=sb.toString();
//         // return
        

//         String sb = trust.getClientId()+trust.getClientSecret()+trust.getTxncurr()+trust.getAmount()+trust.getEmailId()+trust.getMobileNumber();
//         System.out.println(sb);
//         String nb=       Hex.encodeHexString(sha256_HMAC.doFinal(sb.getBytes("UTF-8")));
//         System.out.println("\n\n");
//         System.out.println(nb);
//         // return signature;
//         // System.out.println(signature);
//         }


//         public class TrustlypayAESEncryption {
//             private final byte[] ivBytes = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };
//             private String aesKey = "5cc34da0-8bbe-4b8c-8a55-abb420cac1f1";
//             private String saltIVKey = "5cc34da0-8bbe-4b8c-8a55-abb420cac1f1";
//             public String encryption(String jsonToString, String saltKey, String
//             aesEncRequestKey)
//             throws Exception
//             {
            
//             // www.trustlypay.in 15
            
//             this.aesKey = aesEncRequestKey;
//             this.saltIVKey = saltKey;
//             return encryptJsonData(jsonToString);
//             }
            
//             private String encryptJsonData(String jsonToString) throws Exception
//             {
//             byte[] saltBytes = this.saltIVKey.getBytes("UTF-8");
//             // SecretKeyFactory factory =
            
//             // SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            
//             PBEKeySpec spec = new PBEKeySpec(this.aesKey.toCharArray(),saltBytes,
//             65536,256);
//             // SecretKey secretKey = factory.generateSecret(spec);
//             // SecretKeySpec secret = new SecretKeySpec(secretKey.getEncoded(), "AES");
//             IvParameterSpec localIvParameterSpec = new IvParameterSpec(this.ivBytes);
//             // Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
//             // cipher.init(1, secret, localIvParameterSpec);
//             // byte[] encryptedTextBytes = cipher.doFinal(jsonToString.getBytes("UTF-8"));
//             return byteToHex(encryptedTextBytes);
//             }
            
//             private String byteToHex(byte[] byData) {
//             StringBuffer sb = new StringBuffer(byData.length * 2);
//             for (int i = 0; i < byData.length; ++i) {
//             int v = byData[i] & 0xFF;
//             if (v < 16)
//             sb.append('0');
//             sb.append(Integer.toHexString(v));
//             }
//             return sb.toString().toUpperCase();
            
//             // www.trustlypay.in 16
//             }
//             private byte[] hex2ByteArray(String sHexData) {
//             byte[] rawData = new byte[sHexData.length() / 2];
//             for (int i = 0; i < rawData.length; ++i) {
//             int index = i * 2;
//             int v = Integer.parseInt(sHexData.substring(index, index + 2), 16);
//             rawData[i] = (byte)v;
//             }
//             return rawData;
//             }
//             }

// public static void main(String[] args) throws Exception {
    
//     System.out.println("Hello");
//     setPaymentRequest();
//     // encode();

// }



// }
