package com.asktech.payment.util.airPay.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Chkvaluest {
    String status; 
}
