package com.asktech.payment.util.pineperk.pineDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Payment_info_data {
    private Float amount;
    private String order_desc;
    private String currency_code;
}
