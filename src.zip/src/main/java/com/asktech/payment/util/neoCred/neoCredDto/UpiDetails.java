package com.asktech.payment.util.neoCred.neoCredDto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpiDetails {
    @JsonProperty("legalName")
    private String legalName;
    @JsonProperty("brandName")
    private String brandName;
    @JsonProperty("franchise")
    private String franchise;
    @JsonProperty("genre")
    private String genre;
    @JsonProperty("mcc")
    private String mcc;
    @JsonProperty("merchantType")
    private String merchantType;
    @JsonProperty("ownerShipType")
    private String ownerShipType;
    @JsonProperty("onboardingType")
    private String onboardingType;
    @JsonProperty("merchantName")
    private String merchantName;
    
}
