package com.asktech.payment.util.pineperk.pineDto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Paymentrequest {
    private Carddata carddata;
    private Customer_data customer_data;
    
}
