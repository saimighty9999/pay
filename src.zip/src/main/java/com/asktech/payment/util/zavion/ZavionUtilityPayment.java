package com.asktech.payment.util.zavion;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.MerchantResponseContants;
import com.asktech.payment.constant.zavion.ZavionContants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.enums.PGServices;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.TransactionDetailsAll;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.ZavionTransactionDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.CardPaymentDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.ZavionTransactionDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class ZavionUtilityPayment implements CashFreeFields,ZavionContants {

	static Logger logger = LoggerFactory.getLogger(ZavionUtilityPayment.class);

	//@Autowired
	//CardPaymentDetailsRepository cardPaymentDetailsRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	ZavionTransactionDetailsRepository zavionTransactionDetailsRepository;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;
		

	@Autowired
	BankListRepository bankListRepository;

	@Value("${pgEndPoints.zavionURL}")
	String zavionURL;
	@Value("${pgEndPoints.zavionReturnURL}")
	String zavionReturnURL;

	public Model processZavionRequest(MultiValueMap<String, String> formData, Model model,
			MerchantPGDetails merchantPGDetails, String orderId) throws NoSuchAlgorithmException {
		
		logger.info("Inside processZavionRequest() :: ");

		Map<String, String> parameters = new HashMap<String, String>();
		String hashStr = "";
		parameters.put("APP_ID", merchantPGDetails.getMerchantPGAppId());
		parameters.put("ORDER_ID", orderId);
		parameters.put("RETURN_URL", zavionReturnURL);
		parameters.put("TXNTYPE", "SALE");
		parameters.put("AMOUNT", formData.get(ORDERAMOUNT).get(0));
		parameters.put("CURRENCY_CODE", "356");
		parameters.put("CUST_EMAIL", formData.get(CUSTOMEREMAIL).get(0));
		parameters.put("CUST_PHONE", formData.get(CUSTOMERPHONE).get(0));

		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.NB.toString())) {

			parameters.put("PAYMENT_TYPE", PGServices.NB.toString());
			parameters.put("MOP_TYPE", "1000");
			
			
			hashStr = ChecksumUtils.generateCheckSum(parameters,
					Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));

			parameters.put("HASH", hashStr);
			
			model = setNBDetailsZavion(formData, orderId, model, hashStr, merchantPGDetails);
			logger.info("Zavion Hash :: "+hashStr);
			logger.info("Zavion Model :: "+model.toString());		
		}
		else if(formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase(PGServices.UPI.toString())) {
			parameters.put("PAYMENT_TYPE", "UP");
			parameters.put("MOP_TYPE", "505");
			parameters.put("VPA", formData.get(UPI_VPI).get(0));			
			
			hashStr = ChecksumUtils.generateCheckSum(parameters,
					Encryption.decryptCardNumberOrExpOrCvv(merchantPGDetails.getMerchantPGSecret()));

			parameters.put("HASH", hashStr);
			
			model = setUPIDetailsZavion(formData, orderId, model, hashStr, merchantPGDetails);
			logger.info("Zavion Hash :: "+hashStr);
			
		}

		return model;
	}
	
	public Model setUPIDetailsZavion(MultiValueMap<String, String> formData, String orderId, Model model, String sign,
			MerchantPGDetails merchantPGDetails) {

		logger.info("Inside setNBDetailsZavion()");
		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		model.addAttribute("APP_ID", merchantPGDetails.getMerchantPGAppId());
		model.addAttribute("ORDER_ID", orderId);
		model.addAttribute("RETURN_URL", zavionReturnURL);
		model.addAttribute("TXNTYPE", "SALE");
		model.addAttribute("PAYMENT_TYPE", "UP");
		model.addAttribute("MOP_TYPE", "505");
		model.addAttribute("AMOUNT", formData.get(ORDERAMOUNT).get(0));
		model.addAttribute("CURRENCY_CODE", "356");
		model.addAttribute("CUST_EMAIL", formData.get(CUSTOMEREMAIL).get(0));
		model.addAttribute("CUST_PHONE", formData.get(CUSTOMERPHONE).get(0));
		model.addAttribute("VPA", formData.get(UPI_VPI).get(0));
		model.addAttribute("HASH",sign);

		logger.info("End of setNBDetailsZavion()");

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		upiPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		upiPaymentDetails.setOrderCurrency("356");
		upiPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		upiPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		upiPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		upiPaymentDetails.setPaymentOption(PGServices.NB.toString());
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));
		
		upiPaymentDetailsRepository.save(upiPaymentDetails);

		return model;
	}

	public Model setNBDetailsZavion(MultiValueMap<String, String> formData, String orderId, Model model, String sign,
			MerchantPGDetails merchantPGDetails) {

		logger.info("Inside setNBDetailsZavion()");
		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();

		model.addAttribute("APP_ID", merchantPGDetails.getMerchantPGAppId());
		model.addAttribute("ORDER_ID", orderId);
		model.addAttribute("RETURN_URL", zavionReturnURL);
		model.addAttribute("TXNTYPE", "SALE");
		model.addAttribute("PAYMENT_TYPE", PGServices.NB.toString());
		model.addAttribute("MOP_TYPE", "1000");
		model.addAttribute("AMOUNT", formData.get(ORDERAMOUNT).get(0));
		model.addAttribute("CURRENCY_CODE", "356");
		model.addAttribute("CUST_EMAIL", formData.get(CUSTOMEREMAIL).get(0));
		model.addAttribute("CUST_PHONE", formData.get(CUSTOMERPHONE).get(0));
		model.addAttribute("HASH",sign);

		logger.info("End of setNBDetailsZavion()");

		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(formData.get(ORDERAMOUNT).get(0));
		nbPaymentDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		nbPaymentDetails.setOrderCurrency("356");
		nbPaymentDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
		nbPaymentDetails.setCustomerEmail(formData.get(CUSTOMEREMAIL).get(0));
		nbPaymentDetails.setCustomerPhone(formData.get(CUSTOMERPHONE).get(0));
		nbPaymentDetails.setPaymentOption(PGServices.NB.toString());
		//nbPaymentDetails.setPaymentCode(SecurityUtils.encryptSaveData(formData.get(PAYMENTCODE).get(0)));
		nbPaymentDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
		nBPaymentDetailsRepository.save(nbPaymentDetails);

		return model;
	}
	
	
	public void updateTransactionStatusZavion(MultiValueMap<String, String> responseFormData)
			throws Exception {

		logger.info("Inside method updateTransactionStatus()" + responseFormData.toString());

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderIDAndStatus(responseFormData.get("ORDER_ID").get(0), "PENDING");
		
		logger.info("Validate Signature :: "+validateSignature(responseFormData, transactionDetails.getPgId(), transactionDetails.getMerchantId()));
		
		if (transactionDetails != null) {

			transactionDetails.setStatus(responseFormData.get("STATUS").get(0));
			transactionDetails.setTxtPGTime(Utility.populateDbTime());
			transactionDetails.setSource("ReturnURL");
			transactionDetails.setPgOrderID(responseFormData.get("TXN_ID").get(0));
			
			transactionDetailsRepository.save(transactionDetails);
		} else {
			TransactionDetailsAll transactionDetailsAll = new TransactionDetailsAll();
			transactionDetailsAll.setOrderID(responseFormData.get("ORDER_ID").get(0));
			transactionDetailsAll.setStatus(responseFormData.get("STATUS").get(0));
			transactionDetailsAll.setTxtPGTime(Utility.populateDbTime());
			transactionDetailsAll.setPgOrderID(responseFormData.get("TXN_ID").get(0));

			transactionDetailsAllRepository.save(transactionDetailsAll);
		}
		logger.info("Transaction Update");
		logger.info("GetUser Details::" + transactionDetails.getUserID());
		UserDetails userDetails = null;
		try {
			userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			logger.info("userDetails " + Utility.convertDTO2JsonString(userDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		MerchantDetails merchantDetails = null;
		try {
			merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			logger.info("merchantDetails " + Utility.convertDTO2JsonString(merchantDetails));
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Unable to get Data" + e.getMessage());
		}
		if (merchantDetails != null) {
			if (!merchantDetails.getTr_mail_flag().isEmpty()) {
				logger.info("merchantDetails getTr_mail_flag not empty");
				if (merchantDetails.getTr_mail_flag().equalsIgnoreCase("Y")) {
					logger.info("merchantDetails getTr_mail_flag Y");
					pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createMerchantEmail(userDetails, transactionDetails, merchantDetails),
							merchantDetails.getMerchantEMail(), "MerchantEmail");
					logger.info("createMailRepo Complete");
				}
			}
		}
		logger.info("createMailRepo 2");
		pgGatewayUtilService.createMailRepo(pgGatewayUtilService.createCustomerEmail(userDetails, transactionDetails), userDetails.getEmailId(), "CustomerEmail");
		logger.info("createMailRepo Email Complete");
		logger.info("Send SMS Start");
		pgGatewayUtilService.sendSMS(userDetails, transactionDetails);
		logger.info("Send SMS End");

		pgGatewayUtilService.populatePgResponseinDB(responseFormData, transactionDetails, "ReturnURL");

		try {
			ZavionTransactionDetails zavionTransactionDetails = new ZavionTransactionDetails();

			zavionTransactionDetails.setAmount(responseFormData.get(AMOUNT).get(0));
			zavionTransactionDetails.setAppId(responseFormData.get(APP_ID).get(0));
			zavionTransactionDetails.setAuthCode(responseFormData.get(AUTH_CODE).get(0));
			zavionTransactionDetails.setCurrencyCode(responseFormData.get(CURRENCY_CODE).get(0));
			zavionTransactionDetails.setCustEmail(responseFormData.get(CUST_EMAIL).get(0));
			zavionTransactionDetails.setCustPhone(responseFormData.get(CUST_PHONE).get(0));
			zavionTransactionDetails.setDuplicateYn(responseFormData.get(DUPLICATE_YN).get(0));
			zavionTransactionDetails.setHash(responseFormData.get(HASH).get(0));
			zavionTransactionDetails.setMoptype(responseFormData.get(MOP_TYPE).get(0));
			zavionTransactionDetails.setOrderId(responseFormData.get(ORDER_ID).get(0));
			zavionTransactionDetails.setPaymentType(responseFormData.get(PAYMENT_TYPE).get(0));
			zavionTransactionDetails.setResponseCode(responseFormData.get(RESPONSE_CODE).get(0));
			zavionTransactionDetails.setResponseDateTime(responseFormData.get(RESPONSE_DATE_TIME).get(0));
			zavionTransactionDetails.setResponseMessage(responseFormData.get(RESPONSE_MESSAGE).get(0));
			zavionTransactionDetails.setReturnUrl(responseFormData.get(RETURN_URL).get(0));
			zavionTransactionDetails.setTxnId(responseFormData.get(TXN_ID).get(0));
			zavionTransactionDetails.setTxnKey(responseFormData.get(TXN_KEY).get(0));
			zavionTransactionDetails.setTxtType(responseFormData.get(TXNTYPE).get(0));
			zavionTransactionDetails.setStatus(responseFormData.get(STATUS).get(0));

			zavionTransactionDetailsRepository.save(zavionTransactionDetails);

		} catch (Exception e) {
			logger.error("Exception in CashfreeTransactionDetails population ...");
		}
		logger.info("End method updateTransactionStatus()");
	}
	
	public Model getResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {
		logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		
		TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(responseFormData.get(ORDER_ID).get(0));

		String status = "";
		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);

		logger.info("Transaction Updated time ::" + transactionDetails.getUpdated().toString());

		/*
		String tr_time = Utility.populateDbTime();
		signature = pgGatewayUtilService.populateReturnSignature(status, transactionDetails.getPaymentOption(),
				transactionDetails.getMerchantOrderId(), String.valueOf(amt), transactionDetails.getOrderID(), tr_time,
				transactionDetails.getMerchantId(), "", "");

		logger.info("Transaction Amt final:" + amt);
		model.addAttribute(MerchantResponseContants.returnUrl, transactionDetails.getMerchantReturnURL().replaceAll("\\p{C}", ""));
		model.addAttribute(MerchantResponseContants.status, responseFormData.get(STATUS).get(0));
		model.addAttribute(MerchantResponseContants.paymentOption, transactionDetails.getPaymentOption());
		model.addAttribute(MerchantResponseContants.MerchantorderId, transactionDetails.getMerchantOrderId());
		model.addAttribute(MerchantResponseContants.orderAmount, amt);
		model.addAttribute(MerchantResponseContants.VendorOrderId, transactionDetails.getOrderID());
		model.addAttribute(MerchantResponseContants.txtDate, tr_time);
		model.addAttribute(MerchantResponseContants.signature, signature);

		if (transactionDetails.getMerchantAlertURL() != null) {

			logger.info("Merchant Notify URL :: " + transactionDetails.getMerchantAlertURL());
			
			notiFyURLService2Merchant.sendNotifyDetails2Merchant(status, transactionDetails.getPaymentOption(),
					transactionDetails.getMerchantOrderId(), amt, transactionDetails.getOrderID(), tr_time, signature,
					transactionDetails.getMerchantAlertURL());
		}
		pgGatewayUtilService.populateResponseToMerchant(transactionDetails, model.toString());
		logger.info("END Method getResponseProcess()");
		return model;
		*/
		return pgGatewayUtilService.populateReturnModel(model, amt, status, transactionDetails);
	}
	
	public boolean validateSignature(MultiValueMap<String, String> responseFormData, String pgUuid, String merchantId) throws NoSuchAlgorithmException {
		
		MerchantPGDetails MerchantPGDetails = merchantPGDetailsRepository.findByMerchantIDAndMerchantPGId(merchantId, pgUuid);
		
		String retriveHash = responseFormData.get(HASH).get(0);
		responseFormData.remove(HASH);		
		
		logger.info("Response Hash from Zavion :: "+retriveHash);
		logger.info("Before Hash Generation :: "+GeneralUtils.convertMultiToRegularMap(responseFormData));
		
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put(RESPONSE_DATE_TIME, responseFormData.get(RESPONSE_DATE_TIME).get(0));
		parameters.put(RESPONSE_CODE, responseFormData.get(RESPONSE_CODE).get(0));
		parameters.put(AUTH_CODE, responseFormData.get(AUTH_CODE).get(0));
		parameters.put(CUST_PHONE, responseFormData.get(CUST_PHONE).get(0));
		parameters.put(MOP_TYPE, responseFormData.get(MOP_TYPE).get(0));
		parameters.put(CURRENCY_CODE, responseFormData.get(CURRENCY_CODE).get(0));
		parameters.put(STATUS, responseFormData.get(STATUS).get(0));
		parameters.put(AMOUNT, responseFormData.get(AMOUNT).get(0));
		parameters.put(RESPONSE_MESSAGE, responseFormData.get(RESPONSE_MESSAGE).get(0));
		parameters.put(CUST_EMAIL, responseFormData.get(CUST_EMAIL).get(0));
		parameters.put(APP_ID, responseFormData.get(APP_ID).get(0));
		parameters.put(TXN_ID, responseFormData.get(TXN_ID).get(0));
		parameters.put(TXN_KEY, responseFormData.get(TXN_KEY).get(0));
		parameters.put(TXNTYPE, responseFormData.get(TXNTYPE).get(0));
		//parameters.put(DUPLICATE_YN, responseFormData.get(DUPLICATE_YN).get(0));
		parameters.put(PAYMENT_TYPE, responseFormData.get(PAYMENT_TYPE).get(0));
		parameters.put(RETURN_URL, responseFormData.get(RETURN_URL).get(0));
		parameters.put(ORDER_ID, responseFormData.get(ORDER_ID).get(0));
		
		
		String generateHash = ChecksumUtils.generateCheckSum(parameters,
				Encryption.decryptCardNumberOrExpOrCvv(MerchantPGDetails.getMerchantPGSecret()));
		
		logger.info("Generated Hash from PGCode :: "+generateHash);
		if(!retriveHash.equalsIgnoreCase(generateHash)) {
			return false;
		}
				
		return true;
	}

}
