package com.asktech.payment.util.nimble;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.asktech.payment.util.nimble.nimbleDto.PaymentResUpiDto;

@Component
public class NimbleSaveData {
    @Autowired
    NimbleModelRepo nimbleModelRepo;
    public void saveUpiRequestData(String OrderId, PaymentResUpiDto paymentResUpiDto ){

    }
}