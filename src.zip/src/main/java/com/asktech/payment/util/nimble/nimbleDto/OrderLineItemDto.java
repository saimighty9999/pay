package com.asktech.payment.util.nimble.nimbleDto;

import lombok.AllArgsConstructor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OrderLineItemDto {
    private String referrer_platform_sku_id;
    private String title;
    private String description;
    private String quantity;
    private String rate;
    private String amount_before_tax;
    private String tax;
    private String total_amount;
    private String image_url;
}
