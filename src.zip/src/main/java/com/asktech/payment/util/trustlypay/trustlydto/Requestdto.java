package com.asktech.payment.util.trustlypay.trustlydto;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
 
 public class Requestdto {
String clientId;
String clientSecret;
String txncurr;
String amount;
String username;
String emailId;
String mobileNumber; 
String requestHashKey;

}
