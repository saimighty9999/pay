package com.asktech.payment.util.nimble;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NimbleModelRepo extends JpaRepository<NimbleModel, String> {
    NimbleModel findByOrderId(String orderId);

    NimbleModel findByPgOrderId(String pgOrderId);
    
}
