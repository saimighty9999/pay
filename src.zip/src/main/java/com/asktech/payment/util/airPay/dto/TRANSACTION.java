package com.asktech.payment.util.airPay.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class TRANSACTION {
    public String TRANSACTIONPAYMENTSTATUS;
	public String mercid;
	public String CHMOD;
	public String AMOUNT;
	public String TRANSACTIONSTATUS;
	public String MESSAGE;
	public String TRANSACTIONTYPE;
	public String ap_SecureHash;
}
