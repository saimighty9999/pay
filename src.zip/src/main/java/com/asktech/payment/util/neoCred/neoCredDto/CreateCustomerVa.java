package com.asktech.payment.util.neoCred.neoCredDto;

import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CreateCustomerVa {
    private String accountId;
    private String phone;
    private String vpa;
    private String name;
    private String email;
}
