package com.asktech.payment.enums;

public enum ValidationExceptions {
FATAL_EXCEPTION, ALL_FIELDS_MANDATORY;
	
	ValidationExceptions(){
		
	}
}
