package com.asktech.payment.enums;

public enum TransactionMethods {

	CARD, WALLET, NETBANKING, UPI;
	TransactionMethods(){
		
	}
}
