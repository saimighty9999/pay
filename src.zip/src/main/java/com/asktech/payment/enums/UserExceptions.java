package com.asktech.payment.enums;

public enum UserExceptions {
	INVALID_EMAIL;
	UserExceptions(){
		
	}
}
