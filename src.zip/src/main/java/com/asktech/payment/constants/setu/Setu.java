package com.asktech.payment.constants.setu;

public interface Setu {

	String AUTHORIZATION 			= "Authorization";
	String PRODUCTID				= "X-Setu-Product-Instance-ID";
	String CONTENTTYPE				= "Content-Type";
	String CONTENTVALUE				= "application/json";
	String ACCEPT					= "Accept";
	String ACCEPTVALUE				= "application/json";
	
	String SETU_CURRENCY			= "INR";
	String SETU_EXACTNESS			= "EXACT";
}
