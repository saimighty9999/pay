package com.asktech.payment.constants.cashfree;

public interface CashFreeSubmitFields {

	String CUSTDETAILS 			= "custDetails";
	String SUBMIT_SIGNATURE 	= "signature";
	String SUBMIT_RETURNURL 	= "returnUrl";
	String SUBMIT_NOTIFYURL		= "notifyUrl";
	String SUBMIT_APPID			= "appId";
	
	String SUBMIT_ORDERNOTE 	= "orderNote";
	String SUBMIT_ORDERCURRENCY = "orderCurrency";
	String SUBMIT_CUSTOMERNAME 	= "customerName";
	String SUBMIT_CUSTOMEREMAIL = "customerEmail";
	String SUBMIT_CUSTOMERPHONE = "customerPhone";
	String SUBMIT_ORDERAMOUNT 	= "orderAmount";
	String SUBMIT_ORDERID		= "orderId";
	String SUBMIT_PAYMENTOPTION = "paymentOption";
	
	String SUBMIT_UPI_VPA 		= "upi_vpa";
	
	String SUBMIT_PAYMENTCODE	= "paymentCode";

	String SUBMIT_CARDHOLDER 	= "cardHolder";
	String SUBMIT_CARDEXPIRYMONTH = "cardExpiryMonth";
	String SUBMIT_CARDEXPIRYYEAR = "cardExpiryYear";
	String SUBMIT_CARDCVV		= "cardCvv";
	String SUBMIT_CARDNUMBER	= "cardNumber";
}
