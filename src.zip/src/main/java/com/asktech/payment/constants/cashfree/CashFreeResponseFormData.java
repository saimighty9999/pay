package com.asktech.payment.constants.cashfree;

public interface CashFreeResponseFormData {

	String RESP_TXSTATUS 			= "txStatus";
	String RESP_REFERENCEID 		= "referenceId";
	String RESP_PAYMENTMODE 		= "paymentMode";
	String RESP_TXMSG 				= "txMsg";
	String RESP_TXTIME 				= "txTime";
	String RESP_ORDERID				= "orderId";
	String RESP_ORDERAMOUNT			= "orderAmount";
	String RESP_SIGNATURE			= "signature";
	
	String STATUS_PAYMENT_SUCCESSFUL = "PAYMENT_SUCCESSFUL";
}
