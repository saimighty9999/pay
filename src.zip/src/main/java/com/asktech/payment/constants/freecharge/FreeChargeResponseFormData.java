package com.asktech.payment.constants.freecharge;

public interface FreeChargeResponseFormData {

	String RESP_MERCHANTTXNID = "merchantTxnId";
	String RESP_STATUS = "status";
	String RESP_TXNID = "txnId";
	String RESP_AMOUNT = "amount";
	String RESP_CHECKSUM = "checksum";
	String RESP_ERRORCODE = "errorCode";
	String RESP_ERRORMESSAGE = "errorMessage";
}
