package com.asktech.payment.constants.freecharge;

public interface Freechagre {
	
	public static final String CONTENTTYPE = "Content-Type";
	public static final String CONTENTVALUE = "application/x-www-form-urlencoded";
	public static final String ACCEPT	= "Accept";
	public static final String CHANNEL_WEB = "WEB";
	//public static final String FURL_DATA = "https://pgapi.eazypaymentz.com/pg/notifyurlFreeCharge";
	//public static final String SURL_DATA = "https://pgapi.eazypaymentz.com/pg/notifyurlFreeCharge";
	
	
	public static final String AMOUNT = "amount";
	public static final String CHANNEL = "channel";
	public static final String FURL= "furl";
	public static final String SURL= "surl";
	public static final String MERCHANTID = "merchantId";
	public static final String MERCHANTTXNID = "merchantTxnId";
	public static final String CHECKSUM = "checksum";
}
