package com.asktech.payment.constants.setu;

public interface SetuResponseFormData {

	String RESP_ORDERID = "orderId";
	String RESP_MERCHANTDID = "merchantId";
	
	String STATUS_PAYMENT_SUCCESSFUL = "PAYMENT_SUCCESSFUL";
}
