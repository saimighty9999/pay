package com.asktech.payment.dto.utility;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignatureRequestNb  extends SignatureRequestParent{
	private String paymentOption;
	private String paymentCode;
}
