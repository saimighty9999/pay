package com.asktech.payment.dto.ippoPay;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Order {

	@JsonProperty("public_key")
	private String publicKey;
	@JsonProperty("amount")
	private Integer amount;
	@JsonProperty("merchant")
	private Merchant merchant;
	@JsonProperty("source")
	private String source;
	@JsonProperty("notify_url")
	private String notifyUrl;
	@JsonProperty("mode")
	private String mode;
	@JsonProperty("createdAt")
	private String createdAt;
	@JsonProperty("payment_modes")
	private PaymentModes payment_modes;
	@JsonProperty("__v")
	private Integer intV;
	@JsonProperty("currency")
	private String currency;
	@JsonProperty("_id")
	private String uuidId;
	@JsonProperty("order_id")
	private String orderId;
	@JsonProperty("customer")
	private Customer customer;
	@JsonProperty("status")
	private String status;
	@JsonProperty("updatedAt")
	private String updatedAt;

}