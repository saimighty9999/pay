package com.asktech.payment.dto.payu;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CardValidateResponse {

	private String issuingBank;
	private String cardType;
	private String cardCategory;
	private String isDomestic;
}
