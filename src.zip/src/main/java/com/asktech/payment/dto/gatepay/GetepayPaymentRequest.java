package com.asktech.payment.dto.gatepay;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class GetepayPaymentRequest {

	
	private String login;
	private String pass;
	private BigDecimal amt;
	private String paymentMode;
	private String txncurr;
	private String merchantTxnId;
	private String date;
	private String od;
	private String mobile;
	private String carddata;
	private String ru;
	private String signature;
	private String bankid;
	private Long transactionId;
	private String requestType;
	private String paymentType;
	@JsonProperty("memail")
	private String mEmail;
	@JsonProperty("mnumber")	
	private String mNumber;
	private String productType;
	private Long merchantId;
	private String txnType;
	private String productDetails;
	private String van;
	private String udf1;
	private String udf2;
	private String udf3;
	private String udf4;
	private String udf5;
}
