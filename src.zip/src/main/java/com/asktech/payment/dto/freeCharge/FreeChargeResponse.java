package com.asktech.payment.dto.freeCharge;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FreeChargeResponse {

	private String amount;
	private String authCode;
	private String merchantLogo;
	private String merchantName;
	private String merchantTxnId;
	private String metadata;
	private String status;
	private String txnId;
	
}
