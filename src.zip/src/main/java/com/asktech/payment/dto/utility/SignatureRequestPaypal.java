package com.asktech.payment.dto.utility;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignatureRequestPaypal extends SignatureRequestParent{
	private String paymentOption;
}
