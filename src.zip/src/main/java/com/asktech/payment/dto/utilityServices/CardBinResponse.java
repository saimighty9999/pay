package com.asktech.payment.dto.utilityServices;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CardBinResponse {
	private Cards cards;
	private String status;
}
