package com.asktech.payment.dto.setu;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Data {

	private String name;
    private PaymentLink paymentLink;
    private String platformBillID;
}
