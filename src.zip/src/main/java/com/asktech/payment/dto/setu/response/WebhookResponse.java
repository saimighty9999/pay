package com.asktech.payment.dto.setu.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class WebhookResponse {

	@JsonProperty("partnerDetails")
	private PartnerDetails partnerDetails;
	@JsonProperty("events")
    private List<Events> events;
}
