package com.asktech.payment.dto.onepay;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseDecryptData {

	@JsonProperty("payment_mode")
	private String paymentMode;
	@JsonProperty("resp_message")
	private String respMessage;
	@JsonProperty("udf5")
	private String udf5;
	@JsonProperty("custEmailId")
	private String cust_email_id;
	@JsonProperty("udf3")
	private String udf3;
	@JsonProperty("merchant_id")
	private String merchantId;
	@JsonProperty("txn_amount")
	private String txnAmount;
	@JsonProperty("udf4")
	private String udf4;
	@JsonProperty("udf1")
	private String udf1;
	@JsonProperty("udf2")
	private String udf2;
	@JsonProperty("pg_ref_id")
	private String pgRefId;
	@JsonProperty("txn_id")
	private String txnId;
	@JsonProperty("resp_date_time")
	private String respDateTime;
	@JsonProperty("bank_ref_id")
	private String bankRefId;
	@JsonProperty("resp_code")
	private String respCode;
	@JsonProperty("txn_date_time")
	private String txnDateTime;
	@JsonProperty("trans_status")
	private String transStatus;
	@JsonProperty("cust_mobile_no")
	private String custMobileNo;
}
