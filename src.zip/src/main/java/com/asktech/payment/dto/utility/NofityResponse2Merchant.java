package com.asktech.payment.dto.utility;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NofityResponse2Merchant {

	private String status;		
	private String paymentOption;
	private String merchantorderId;
	private String orderAmount;
	private String vendorOrderId;
	private String txtDate;
	private String signature;
	private String code;
	private String errorMsg;
	private String custName;
	private String custEmail;
	private String custPhone;
	private String cardNumber;
	private String upiVpa;
	private String walletCode;
	private String bankCode;
}
