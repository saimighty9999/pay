package com.asktech.payment.dto.setu;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class SetuPaymentLinkCreation {

	private Amount amount;
	private String billerBillID;
	private String amountExactness;

}
