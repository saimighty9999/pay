package com.asktech.payment.dto.utilityServices;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardBinDetails {

	@JsonProperty("country")
	private String country;
	@JsonProperty("countrycode")
	private String countryCode;
	@JsonProperty("cardbrand")
	private String cardBrand;
	@JsonProperty("iscommercial")
	private Boolean isCommercial;
	@JsonProperty("binnumber")
	private Integer binNumber;
	@JsonProperty("issuer")
	private String issuer;
	@JsonProperty("issuerwebsite")
	private String issuerWebsite;
	@JsonProperty("valid")
	private Boolean valid;
	@JsonProperty("cardtype")
	private String cardType;
	@JsonProperty("isprepaid")
	private Boolean isPrepaid;
	@JsonProperty("cardcategory")
	private String cardCategory;
	@JsonProperty("issuerphone")
	private String issuerPhone;
	@JsonProperty("currencycode")
	private String currencyCode;
	@JsonProperty("countrycode3")
	private String countryCode3;

}
