package com.asktech.payment.dto.paytm;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Paytmpopulate {
    String orderId;
    String paymentMode;
    String status;
    String txnamount;
    String txndate;
    String txnid;
}
