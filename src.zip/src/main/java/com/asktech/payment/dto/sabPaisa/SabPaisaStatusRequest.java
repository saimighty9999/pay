package com.asktech.payment.dto.sabPaisa;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SabPaisaStatusRequest {

	private String clientCode;
	private String clientxnId;
}
