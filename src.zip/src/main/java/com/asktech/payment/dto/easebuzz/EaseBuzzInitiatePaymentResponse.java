package com.asktech.payment.dto.easebuzz;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EaseBuzzInitiatePaymentResponse {
	private String status;
	private String data;
}
