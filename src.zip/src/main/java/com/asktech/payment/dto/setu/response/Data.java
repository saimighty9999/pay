package com.asktech.payment.dto.setu.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class Data {

	@JsonProperty("amountPaid")	
	private AmountPaid amountPaid;
	private String billerBillID;
	private String payerVpa;
	private String platformBillID;
	private String status;
	private String transactionId;
}
