package com.asktech.payment.dto.seam;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CrLinkdto {
	private String appid;
	private String custName;
	private String custPhone;
	private String custEmail;
	private String custAmount;
}
