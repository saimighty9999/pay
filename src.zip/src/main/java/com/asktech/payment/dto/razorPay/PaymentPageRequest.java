package com.asktech.payment.dto.razorPay;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class PaymentPageRequest {

	private int amount;
	private String currency;
	private String contact;
	private String email;
	private String order_id;
	private String method;
	private String vpa;
	private String wallet;
	private String bank;
	private Card card;
	private String ip;
	@JsonProperty("user_agent")
	private String userAgent;
	@JsonProperty("callback_url")
	private String callbackUrl;
	private String customerName;
}
