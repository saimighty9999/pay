package com.asktech.payment.dto.gatepay;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GatePayPaymentResponse {

	private String login;
	private String amt;
	private String txncurr;
	private String merchantTxnId;
	private String ru;
	private String merchantRefNumber;
	private String processorCode;
	private String responseCode;
	private String status;
	private String description;
	private String threeDSecureUrl;
	private Long transactionId;
	private boolean result;
	private Long mId;
	private String atomUrl;
}
