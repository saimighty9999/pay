package com.asktech.payment.dto.ippoPay;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Data {

	private Order order;
}
