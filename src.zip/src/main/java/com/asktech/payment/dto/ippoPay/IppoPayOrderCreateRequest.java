package com.asktech.payment.dto.ippoPay;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IppoPayOrderCreateRequest {

	@JsonProperty("amount")
	private String amount;
	@JsonProperty("currency")
	private String currency;
	@JsonProperty("payment_modes")
	private String paymentModes;
	@JsonProperty("notify_url")
	private String notifyUrl;
	@JsonProperty("customer")
	private Customer customer;
	@JsonProperty("return_url")
	private String returnUrl;
	
}
