package com.asktech.payment.dto.email;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerEmail {
	
	private String amount;
	private String orderId;
	private String transactionId;
	private String transactionTime;
	private String custName;
	private String custEmail;
	private String custPhone;
	private String paymentModel;
	private String paymentStatus;
}
