package com.asktech.payment.dto.sabPaisa;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class SabPaisaResponse {

	@JsonProperty("Add")
	private String add;
	@JsonProperty("lastName")	
	private String lastName;
	@JsonProperty("udf7")
	private String udf7;
	@JsonProperty("udf8")
	private String udf8;
	@JsonProperty("udf18")
	private String udf18;
	@JsonProperty("udf17")
	private String udf17;
	@JsonProperty("udf16")
	private String udf16;
	@JsonProperty("udf15")
	private String udf15;
	@JsonProperty("udf14")
	private String udf14;
	@JsonProperty("udf13")
	private String udf13;
	@JsonProperty("udf12")
	private String udf12;
	@JsonProperty("udf11")
	private String udf11;
	@JsonProperty("udf10")
	private String udf10;
	@JsonProperty("udf19")
	private String udf19;
	@JsonProperty("udf9")
	private String udf9;
	@JsonProperty("udf5")
	private String udf5;
	@JsonProperty("udf6")
	private String udf6;
	@JsonProperty("udf20")
	private String udf20;
	@JsonProperty("SabPaisaTxId")
	private String sabPaisaTxId;
	@JsonProperty("pgRespCode")
	private String pgRespCode;
	@JsonProperty("clientTxnId")
	private String clientTxnId;
	@JsonProperty("transDate")
	private String transDate;
	@JsonProperty("email")
	private String email;
	@JsonProperty("amount")
	private String amount;
	@JsonProperty("PGTxnNo")
	private String PGTxnNo;
	@JsonProperty("payMode")
	private String payMode;
	@JsonProperty("m3")
	private String m3;
	@JsonProperty("orgTxnAmount")
	private String orgTxnAmount;
	@JsonProperty("midName")
	private String midName;
	@JsonProperty("spRespStatus")
	private String spRespStatus;
	@JsonProperty("mobileNo")
	private String mobileNo;
	@JsonProperty("param3")
	private String param3;
	@JsonProperty("param4")
	private String param4;
	@JsonProperty("authIdCode")
	private String authIdCode;
	@JsonProperty("param1")
	private String param1;
	@JsonProperty("param2")
	private String param2;
	@JsonProperty("firstName")
	private String firstName;
	@JsonProperty("spRespCode")
	private String spRespCode;
	@JsonProperty("challanNo")
	private String challanNo;
	@JsonProperty("payeeProfile")
	private String payeeProfile;
	@JsonProperty("clientCode")
	private String clientCode;
	@JsonProperty("issuerRefNo")
	private String issuerRefNo;
	@JsonProperty("reMsg")
	private String reMsg;
	@JsonProperty("bid")
	private String bid;
	@JsonProperty("programId")
	private String programId;
	@JsonProperty("cid")
	private String cid;
}
