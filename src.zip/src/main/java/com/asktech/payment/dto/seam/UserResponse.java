package com.asktech.payment.dto.seam;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserResponse {

	private String userName;
	private String userPhone;
	private String userEmail;
	private String amount;
	private String uuid;
	private String jwtToken;
}
