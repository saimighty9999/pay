package com.asktech.payment.dto.easePay;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EasePayCallBackResponse {

	@JsonProperty("ORDER_ID")
	private String orderId;
	@JsonProperty("TXN_STATUS")
	private String txtStatus;
	@JsonProperty("TXN_AMOUNT")
	private String txtAmount;
	@JsonProperty("RESP_MSG")
	private String respMsg;
	@JsonProperty("RES_CODE")
	private String respCode;
	@JsonProperty("RRN")
	private String rrn;
}
