package com.asktech.payment.dto.razorPay;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Card {

	private String number;
	private String name;
	private int expiry_month;
	private int expiry_year;
	private int cvv;
}
