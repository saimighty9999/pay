package com.asktech.payment.dto.easePay;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatusRes {
    private String TRANSACTION_STATUSMESSAGE;
    private String TRANSACTION_STATUS;
    private String REQUEST_REFERENCE_NO;
    private String BANK_REFERENCE_NO;
}
