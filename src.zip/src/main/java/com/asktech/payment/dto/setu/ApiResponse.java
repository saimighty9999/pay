package com.asktech.payment.dto.setu;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ApiResponse {

	private String status;
	private String successCode;
	private String successMsg;
	private String errorCode;
	private String errorMsg;
	
}
