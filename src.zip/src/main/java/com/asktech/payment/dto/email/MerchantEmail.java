package com.asktech.payment.dto.email;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MerchantEmail {

	private String merchantName;
	private String merchantId;
	private String amount;
	private String orderId;
	private String transactionId;
	private String transactionTime;
	private String custName;
	private String custEmail;
	private String custPhone;
	private String paymentModel;
}
