package com.asktech.payment.dto.utility;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MerchantValidationFilterDto {
	private String status;
	private String msg;
}
