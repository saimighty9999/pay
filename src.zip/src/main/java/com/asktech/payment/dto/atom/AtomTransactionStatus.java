package com.asktech.payment.dto.atom;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AtomTransactionStatus {
	private String merchantID;
	private String merchantTxnID;
	private String amt;
	private String verified;
	private String statusCode;
	private String desc;
	private String bid;
	private String bankName;
	private String atomTxnId;
	private String discriminator;
	private String surcharge;
	//private String cardNumber;
	private String txnDate;
	//private String udf9;
	private String reconStatus;
	//private String sdt;

}
