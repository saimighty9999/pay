package com.asktech.payment.dto.setu;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Error {

	private String code;

	private String detail;

	private String docURL;

	private String title;

	private List<String> errors;

	private String traceID;
}
