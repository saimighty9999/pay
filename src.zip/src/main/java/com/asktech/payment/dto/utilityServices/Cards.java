package com.asktech.payment.dto.utilityServices;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Cards { 

   private String bank;
   private String scheme;
   private String countryCode;
   private String subType;
   private String type;

}
