package com.asktech.payment.dto.ippoPay;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentModes {

	@JsonProperty("credit_card")
	private Boolean creditCard;
	@JsonProperty("international_cards")
	private Boolean internationalCards;
	@JsonProperty("net_banking")
	private Boolean netBanking;
	@JsonProperty("debit_card")
	private Boolean debitCard;
	@JsonProperty("upi")
	private Boolean upi;

}