package com.asktech.payment.dto.easePay;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusApiReqDto {
    @JsonProperty("CPCODE")
    private String CPCODE;
    @JsonProperty("REQUEST_REFERENCE_NO")
    private String REQUEST_REFERENCE_NO;
    @JsonProperty("CUSTOMER_MOBILE")
    private String CUSTOMER_MOBILE;
}
