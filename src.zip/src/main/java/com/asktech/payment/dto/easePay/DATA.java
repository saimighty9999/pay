package com.asktech.payment.dto.easePay;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class DATA {
    @JsonProperty("REQUEST_REFERENCE_NO")
    private String REQUEST_REFERENCE_NO;
    @JsonProperty("CUSTOMER_MOBILE")
    private String CUSTOMER_MOBILE;
    @JsonProperty("TRANSFER_AMOUNT")
    private String TRANSFER_AMOUNT;
    @JsonProperty("TRANSACTION_STATUSMESSAGE")
    private String TRANSACTION_STATUSMESSAGE;
    @JsonProperty("BANK_REFERENCE_NO")
    private String BANK_REFERENCE_NO;
    @JsonProperty("TRANSACTION_STATUS")
    private String TRANSACTION_STATUS;
}
