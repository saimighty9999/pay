package com.asktech.payment.dto.freeCharge;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FreeChargeRequest {

	private String amount;
	private String channel;
	private String furl;
	private String merchantId;
	private String merchantTxnId;	
	private String surl;
	
}
