package com.asktech.payment.constant.gatepay;

public interface GatePayContants {

	String CURRENCY = "INR";	
	String PRODUCTTYPE = "IPG";
	String PAYMENTTYPE = "ALL";
	String TXNTYPE = "single";
	String REQUESTTYPE = "PAYMENT_API";
	String UPI_CODE = "61220121";
	
	String RESP_ORDERID = "merchantOrderNo";
	String RESP_AMOUNT = "txnAmount";
	String RESP_PGORDERID = "getepayTxnId";
	String RESP_SIGNATURE = "signature";
	String RESP_STATUS = "txnStatus";
	String RESP_MID = "mid";
	String RESP_PAYMENTTYPE = "discriminator";
}
