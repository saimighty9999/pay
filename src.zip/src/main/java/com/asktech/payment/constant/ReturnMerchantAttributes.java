package com.asktech.payment.constant;

public interface ReturnMerchantAttributes {

	String RET_RETURNURL 			= "returnUrl";
	String RET_STATUS				= "status";
	String RET_PAYMENTOPTION 		= "paymentOption";
	String RET_MERCHANTORDERID 		= "MerchantorderId";
	String RET_ORDERAMOUNT 			= "orderAmount";
	String RET_VENDORORDERID 		= "VendorOrderId";
	String RET_TXTDATE 				= "txtDate";
	String RET_SIGNATURE 			= "signature";
	String RET_CUSTNAME				= "custName";
	String RET_CUSTPHONE			= "custPhone";
	String RET_CUSTEMAIL			= "custEmail";
	String RET_CARD_NUMBER			= "cardNumber";
	String RET_UPI_ID				= "upiVpa";
	String RET_BANK_CODE			= "bankCode";
	String RET_WALLET_CODE			= "walletCode";
	String RET_ERRORCODE			= "errorCode";
	String RET_ERRORDETAILS			= "errorMsg";
	
	String SIG_STATUS				= "status";
	String SIG_PAYMENTOPTION		= "paymentOption";
	String SIG_MERCHANTORDERID		= "MerchantorderId";
	String SIG_ORDERAMOUNT			= "orderAmount";
	String SIG_VENDORORDERID		= "VendorOrderId";
	String SIG_TXTDATE				= "txtDate";
	String SIG_ERRORCODE			= "errorCode";
	String SIG_ERRORDETAILS			= "errorMsg";
	String SIG_CUSTNAME				= "custName";
	String SIG_CUSTPHONE			= "custPhone";
	String SIG_CUSTEMAIL			= "custEmail";
	String SIG_CARD_NUMBER			= "cardNumber";
	String SIG_UPI_ID				= "upiVpa";
	String SIG_BANK_CODE			= "bankCode";
	String SIG_WALLET_CODE			= "walletCode";
}
