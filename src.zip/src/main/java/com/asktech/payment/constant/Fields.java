package com.asktech.payment.constant;

public interface Fields {
	String CUSTOMERNAME = "customerName";
	String CUSTOMERPHONE = "customerPhone";
	String CUSTOMEREMAIL = "customerEmail";
	String ORDERID = "orderid";
	String PAYMENTOPTION = "paymentOption";	
	String SIGNATURE = "signature";
	String CUSTOMERID = "customerid";
	String ORDERCURRENCY ="orderCurrency";
	String ORDERNOTE = "orderNote";
	String RETURNURL = "returnUrl";
	String NOTIFYURL = "notifyUrl";
	String ORDERAMOUNT = "orderAmount";
	String NBACTIVE = "nbactive";
	String UPIACTIVE = "upiactive";
	String CARDACTIVE = "cardactive";
	String WALLETACTIVE = "walletactive";
	String UPIQRACTIVE = "upiqractive";
	String ALERTURL = "alertUrl";
	
}
