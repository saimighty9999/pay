package com.asktech.payment.constant;

public interface NetBankingFields extends Fields{
	String NB_PAYMENT_CODE = "paymentCode";
}
