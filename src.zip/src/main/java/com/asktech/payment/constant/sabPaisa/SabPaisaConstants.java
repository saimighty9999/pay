package com.asktech.payment.constant.sabPaisa;

public interface SabPaisaConstants {

	String CLIENTNAME = "clientName";
	String USERN = "usern";
	String PASS = "pass";
	String AMT = "amt";
	String TXNID = "txnId";
	String FIRSTNAME = "firstName";
	String LASTNAME = "lstName";
	String CONTACTNO = "contactNo";
	String EMAIL = "Email";
	String ADD = "Add";
	String RU = "ru";
	String FAILUREURL = "failureURL";
	String MODETRANSFER = "modeTransfer";
	String UDF19 = "udf19";
	String BYPASSFLAG = "byPassFlag";
	
	
	String UPI_MODE_TRANSFER = "UPI_MODE_TRANSFER";
	String NB_MODE_TRANSFER = "NB_MODE_TRANSFER";
	String WALLET_MODE_TRANSFER = "WALLET_MODE_TRANSFER";
}
