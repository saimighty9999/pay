package com.asktech.payment.constant.ippopay;

public interface IppoPayConstants {

	String IN_AMOUNT = "amount";
	String IN_CURRENCY = "INR";
	String IN_PAYMENT_MODES = "cc,dc,nb,upi";
	
}
