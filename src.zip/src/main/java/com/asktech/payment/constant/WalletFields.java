package com.asktech.payment.constant;

public interface WalletFields extends Fields{
	String PAYMENT_CODE = "paymentcode";
}
