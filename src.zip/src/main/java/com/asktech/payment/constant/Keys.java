package com.asktech.payment.constant;

public abstract class Keys {
	
	//protected static final String  FrontKey = "StSqWAlh1QqcT7GObxZKUrJYf4hcQRdv";
	//protected static final String  FrontSalt = "7F598785B49A8E5C";
	//protected static final String  BackKey = "StSqWAlh1QqcT7GObxZKUrJYf4hcQRdv";
	//protected static final String  BackSalt = "7F598785B49A8E5C";

	//public static final String askTechSecret = "superAdmins7905093601SuperAdmins";
	//public static final String askTechSalt = "superAdmin!!!!!!!!SuperAdmin";
	
	//public static final String askTechFTSecret = "asktech123wallet";
	//public static final String askTechFTSalt = "ashtech123wallet";
	
	//public static final String serviceFactoryInstance = "PBKDF2WithHmacSHA256";
	//public static final String cipherInstance = "AES/CBC/PKCS5Padding";
	//public static final String secretKeyType = "AES";
	public static final String publickey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCCGVdLunh1Kj0tBIw7XQYd70fwyzr4MUEOUwVEfGXq2BY1bteq0gAri3d808WnuVO36lBNZ2C9L/8+fgvNjqvehWHgN9pEaXMc1w12l3pjFB7OetPCE68T08qDtsChMJZDdR/9aqJk1BRomThKtp9gaNYgvciCrQJG5s57JYgMRQIDAQAB";
	public static final String privatekey = "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBAIIZV0u6eHUqPS0EjDtdBh3vR/DLOvgxQQ5TBUR8ZerYFjVu16rSACuLd3zTxae5U7fqUE1nYL0v/z5+C82Oq96FYeA32kRpcxzXDXaXemMUHs5608ITrxPTyoO2wKEwlkN1H/1qomTUFGiZOEq2n2Bo1iC9yIKtAkbmznsliAxFAgMBAAECgYB+2/j8lgLZtOtcV1/qjuXlEKtkyLdixpx6PEgZpPe4jSbyyXexUP7rdx53cQT+bL+OygOtxo1VTVUl+cDGm0VIzIUHIAH9iW64r7K0yXqZqG3LpEtFLXA1/Dbd+Ul8UCWwvsjmnNmsC68Jt0HzX9wAA8MZKRUq89Yj9JLp6RZYYQJBAPg2DzkAby6gp7vXS1Xt90gO4+rLCw3a5/JBRTLokH9u9CZjoSme4IGJ3vSQ0wPLAm7EKQCF069oZkxMCfW3LP0CQQCGLnUt2B2/avq4DQORgnlI9zw/Xd0KVXxUqeFAgJCejtT2zHVrmY1QeUhPG8gdW7JMiDpC5cT9w9QWC6HAOKLpAkAYogTQu2JNVlRPKAap+HvaAuBLpOrr7RWnzSJ48uukOfaw+KI95y6QrIYb72OBtNwA8ia/joh7l/jPCZzTbeJhAkBCWTqL/q9G9Ykf9R9slg2O7OGXm7wu3fJqks3U7T2ViZ74okT1faoIvs/ofh5Hlg3mFf5pEeCEco6uj/XdbKPxAkAUYuPrBcH9P6zUK8R29+cP61CAuOoAhzqY1BgsN37Aa2i1gQvluGxt30MHTaDUdxrf3+cVPBlCWVi95a80X82l";

	public static final String utfType = "UTF-8";
}
