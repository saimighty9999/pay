package com.asktech.payment.constant.payu;

public interface PayUConstants {

	String TXNID = "txnid";
	String PRODUCTINFO = "productinfo";
	String AMOUNT = "amount";
	String FIRSTNAME = "firstname";
	String LASTNAME = "lastname";
	String EMAIL = "email";
	String PHONE = "phone";
	String SURL = "surl";
	String FURL = "furl";
	String REQUEST_FLOW = "request_flow";
	String HASH ="hash";	
	String KEY = "key";
	String PG = "pg";
	
	
	String MODEL_KEY = "key";
	String MODEL_TXNID = "txnid";
	String MODEL_PRODUCTINFO = "productinfo";
	String MODEL_AMOUNT = "amount";
	String MODEL_EMAIL = "email";
	String MODEL_FIRSTNAME = "firstname";
	String MODEL_PG = "pg";
	String MODEL_BANKCODE = "bankcode";
	String MODEL_VPA = "vpa";
	String MODEL_SURL = "surl";
	String MODEL_FURL = "furl";
	String MODEL_PHONE = "phone";
	String MODEL_HASH = "hash";
	
	String PAYMENT_CCNUM = "ccnum";
	String PAYMENT_CCNAME = "ccname";
	String PAYMENT_CCVV = "ccvv";
	String PAYMENT_CCEXPMON = "ccexpmon";
	String PAYMENT_CCEXPYR = "ccexpyr";
	
	String PAYMENT_MODE_NB = "NB";
	String PAYMENT_MODE_MW = "WALLET";
	String PAYMENT_MODE_OM = "OM";
	String PAYMENT_BANKCODE_UPI = "UPI";
	String PAYMENT_UPI = "UPI";
	
	
	String RESP_ORDERID = "txnid";
	String RESP_TXMSG ="field9";
	String RESP_TXSTATUS = "status";
	String RESP_REFERENCEID ="mihpayid";
	String RESP_PAYMENTMODE = "mode";
	String RESP_TXTIME = "addedon";
	String RESP_ORDERAMOUNT = "amount";
	String RESP_SIGNATURE = "hash";
	String RESP_PRODUCTINFO = "productinfo";
	String RESP_FIRSTNAME = "firstname";
	String RESP_EMAIL = "email";
	
	
	String STATUS_SUCCESS = "success";
	String STATUS_FAILED = "failure";
	String STATUS_DROPPED = "dropped";
	String STATUS_PENDING = "pending";
	String STATUS_failed_PENDING = "failed";
	
}
