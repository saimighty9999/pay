package com.asktech.payment.constant.zavion;

public interface ZavionContants {

	//Response Parameter 
	String RESPONSE_DATE_TIME = "RESPONSE_DATE_TIME";
	String RESPONSE_CODE = "RESPONSE_CODE";
	String AUTH_CODE = "AUTH_CODE";
	String CUST_PHONE = "CUST_PHONE";
	String MOP_TYPE = "MOP_TYPE";
	String CURRENCY_CODE = "CURRENCY_CODE";
	String STATUS = "STATUS";
	String AMOUNT = "AMOUNT";
	String RESPONSE_MESSAGE = "RESPONSE_MESSAGE";
	String CUST_EMAIL = "CUST_EMAIL";
	String APP_ID = "APP_ID";
	String TXN_ID = "TXN_ID";
	String TXN_KEY = "TXN_KEY";
	String TXNTYPE = "TXNTYPE";
	String DUPLICATE_YN = "DUPLICATE_YN";
	String HASH = "HASH";
	String PAYMENT_TYPE = "PAYMENT_TYPE";
	String RETURN_URL = "RETURN_URL";
	String ORDER_ID = "ORDER_ID";
}
