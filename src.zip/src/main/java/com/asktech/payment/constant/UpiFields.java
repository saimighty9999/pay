package com.asktech.payment.constant;

public interface UpiFields extends Fields{
	String UPI_VPA = "upi_vpa";
}
