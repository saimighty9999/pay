package com.asktech.payment.constant.paytm;

public interface PaytmResponseFormData {

	String RESP_ORDERID = "ORDERID";
	String RESP_STATUS = "STATUS";
}
