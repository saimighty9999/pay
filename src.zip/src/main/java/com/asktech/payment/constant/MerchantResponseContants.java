package com.asktech.payment.constant;

public interface MerchantResponseContants {

	String returnUrl = "returnUrl";
	String status = "status";
	String paymentOption = "paymentOption";
	String MerchantorderId = "MerchantorderId";
	String orderAmount = "orderAmount";
	String VendorOrderId = "VendorOrderId";
	String txtDate = "txtDate";
	String signature = "signature";
	String custName = "custName";
	String custPhone = "custPhone";
	String custEmail = "custEmail";
	String cardNumber = "cardNumber";
	String upiId = "upiId";
}
