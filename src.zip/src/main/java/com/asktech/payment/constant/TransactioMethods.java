package com.asktech.payment.constant;

public interface TransactioMethods {
	String CARD = "card"; 
	String WALLET = "wallet"; 
	String NETBANKING = "nb";
	String UPI = "upi";
	String UPI_QR = "upi_qr";
}
