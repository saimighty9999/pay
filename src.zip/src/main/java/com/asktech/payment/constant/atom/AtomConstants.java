package com.asktech.payment.constant.atom;

public interface AtomConstants {
	
	String TTYPENB = "NBFundTransfer";
	String TTYPEUPI = "NBFundTransfer";
	String TYPECARD= "CCFundTransfer";
	String TXNCURR = "INR";
	String CUSTACC = "100000036600";
	
	String IN_TXTID = "txnid";
	String IN_LOGIN = "login";
	String IN_PASS = "pass";
	String IN_TTYPE = "ttype";
	String IN_PRODID = "prodid";
	String IN_AMT = "amt";
	String IN_TXNCURR = "txncurr";
	String IN_TXNSCAMT = "txnscamt";
	String IN_CLIENTCODE = "clientcode";
	String IN_DATE = "date";
	String IN_CUSTACC = "custacc";
	String IN_BANKID = "bankid";
	String IN_RU = "ru";
	String IN_SIGNATURE = "signature";
	String IN_UDF1 = "udf1";
	String IN_UDF2 = "udf2";
	String IN_UDF3 = "udf3";
	String IN_ENCDATA = "encdata";
	String IN_MDD = "mdd";
	String IN_CHANNELID = "channelid";
	String IN_CARDDATA = "carddata"; 
	String IN_CARDHNAME = "cardhname";
	String IN_CARDTYPE = "cardtype";
	String IN_CARD = "card";
	
	
	String IN_CHANNELID_VALUE = "INT";
	String CARD_TYPE_CC = "CC";
	String CARD_TYPE_DC = "DC";
	
	
	
	String PAYMENT_URL = "paymentUrl";
	
	String RESP_LOGIN = "login";
	String RESP_ENCDATA = "encdata";
	String RESP_MER_TXN = "mer_txn";
	String RESP_MMP_TXN = "mmp_txn";
	String RESP_F_CODE = "f_code";
	String RESP_PROD = "prod";
	String RESP_DISCRIMINATOR = "discriminator";
	String RESP_AMT = "amt";
	String RESP_BANK_TXN = "bank_txn";
	String RESP_SIGNATURE = "signature";
	String RESP_DESC = "desc";
	String RESP_DATE = "date";
	String RESP_UDF1 = "udf1";
	String RESP_UDF2 = "udf2";
	String RESP_UDF3 = "udf3";
	String RESP_BANK_NAME = "bank_name";
	String RESP_SURCHARGE = "surcharge";

	
	String STS_MERCHANTID = "merchantid";
	String STS_MERCHANTTXNID = "merchanttxnid";
	String STS_AMT = "amt";
	String STS_TDATE = "tdate";
	String STS_LOGIN = "login";
	String STS_ENCDATA = "encdata";
	
	String CALL_MERCHANTID = "MerchantID";
	String CALL_MERCHANTTXNID = "MerchantTxnID";
	String CALL_AMT = "AMT";
	String CALL_VERIFIED = "VERIFIED";
	String CALL_BID = "BID";
	String CALL_BANKNAME = "BankName";
	String CALL_ATOMTXNID = "AtomTxnId";
	String CALL_DISCRIMINATOR = "Discriminator";
	String CALL_SURCHARGE = "Surcharge";
	String CALL_CARDNUMBER = "CardNumber";
	String CALL_TXNDATE = "TxnDate";
	String CALL_CUSTOMERACCNO = "CustomerAccNo";
	String CALL_CLIENTCODE = "Clientcode";
	
}
