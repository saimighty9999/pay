package com.asktech.payment.constant.airPay;

public interface AirPayConstants {

	String IN_BUYEREMAIL = "buyerEmail";
	String IN_BUYERPHONE = "buyerPhone";
	String IN_BUYERFIRSTNAME = "buyerFirstName";
	String IN_BUYERLASTNAME = "buyerLastName";
	String IN_ORDERID = "orderid";
	String IN_AMOUNT = "amount";
	String IN_UID = "UID";
	//String IN_PAYERVPA = "payerVPA";
	String IN_PAYERVPA = "vpa";
	String IN_PRIVATEKEY = "privatekey";
	String IN_MERCID = "mercid";
	String IN_CHMOD = "chmod";
	String IN_CHECKSUM = "checksum";
	String IN_CURRENCY = "currency";
	String IN_ISOCURRENCY = "isocurrency";
	String IN_MODE = "mode";
	String IN_CHANNEL = "channel";
	String IN_DOMAINURL = "domainurl";
	String IN_MER_DOM = "mer_dom";	
	String IN_PAYMENTURL = "paymentUrl";
}
