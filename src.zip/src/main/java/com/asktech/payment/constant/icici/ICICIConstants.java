package com.asktech.payment.constant.icici;

public interface ICICIConstants {

	String CURRENCY = "INR";	
	String TRANSACTION_SALE = "SALE";
	String NB_CODE = "NETBANKING";
	String WALLET_CODE = "WALLET";
	String UPI_CODE = "UPI";
	
	String MODEL_ENDPOINT = "endPoint";
	String MODEL_SESSION_TOKEN ="sessionToken";
	String MODEL_CONFIGID = "configId";
	
	
	String RESP_MERCHANTTRID = "MerchantTxnId";
	String RESP_MERCHANTID = "merchantId";
	String RESP_FPTXNID = "fpTxnId";
	String RESP_ENCDATA = "encData";
	String RESP_FDCTRANSACTIONID = "FDCTransactionId";
	String RESP_TRANSACTIONSTATUS = "TransactionStatus";
	String RESP_TRANSACTIONSTATUSCODE = "TransactionStatusCode";
}
