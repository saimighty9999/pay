package com.asktech.payment.mail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.security.Encryption;

@Service
public class MailContentBuilder {

	private TemplateEngine templateEngine;

	@Autowired
	public MailContentBuilder(TemplateEngine templateEngine) {
		this.templateEngine = templateEngine;
	}

	
	public String forgetPasswordOTP(String mailText) {
		Context context = new Context();		
		context.setVariable("mailText", mailText);
		return templateEngine.process("/emailCommunication/forgetPassowrd", context);
	}

	public String createMerchant(MerchantDetails merchantDetails) {
		Context context = new Context();		
		context.setVariable("merchantName", merchantDetails.getMerchantName());
		context.setVariable("merchantEmail", merchantDetails.getMerchantEMail());
		context.setVariable("password", Encryption.getDecryptedPassword(merchantDetails.getPassword()));
		return templateEngine.process("/emailCommunication/welcome", context);
	}


	public String createComplaint(String mailText) {
		Context context = new Context();		
		context.setVariable("mailText", mailText);
		return templateEngine.process("/emailCommunication/createComplaint", context);
	}
	
	public String createMerchantTransaction(UserDetails userDetails , MerchantDetails merchantDetails , TransactionDetails transactionDetails) {
		
		Context context = new Context();		
		context.setVariable("merchantName", merchantDetails.getMerchantName());
		context.setVariable("orderId", transactionDetails.getMerchantOrderId());
		context.setVariable("transactionId", transactionDetails.getOrderID());
		context.setVariable("transactionTime", transactionDetails.getTxtPGTime());
		context.setVariable("amount", transactionDetails.getAmount());
		context.setVariable("custName",userDetails.getCustomerName());
		context.setVariable("custEmail",userDetails.getEmailId());
		context.setVariable("custPhone",userDetails.getPhoneNumber());
		context.setVariable("paymentMode",transactionDetails.getPaymentMode());
		return templateEngine.process("/emailCommunication/txn_status_Merchant", context);
	}


	public String createCustomerTransaction(UserDetails userDetails, TransactionDetails transactionDetails) {
		Context context = new Context();		
		
		context.setVariable("orderId", transactionDetails.getMerchantOrderId());
		context.setVariable("transactionId", transactionDetails.getOrderID());
		context.setVariable("transactionTime", transactionDetails.getTxtPGTime());
		context.setVariable("amount", transactionDetails.getAmount());
		context.setVariable("custName",userDetails.getCustomerName());
		context.setVariable("custEmail",userDetails.getEmailId());
		context.setVariable("custPhone",userDetails.getPhoneNumber());
		context.setVariable("paymentMode",transactionDetails.getPaymentMode());
		return templateEngine.process("/emailCommunication/txn_status_customer", context);
	}
	
}
