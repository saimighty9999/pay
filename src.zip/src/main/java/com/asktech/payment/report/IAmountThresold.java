package com.asktech.payment.report;

public interface IAmountThresold {

	String getThresholdAmount();
}
