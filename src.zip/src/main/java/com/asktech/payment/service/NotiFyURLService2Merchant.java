package com.asktech.payment.service;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.asktech.payment.constant.ReturnMerchantAttributes;
import com.asktech.payment.dto.utility.NofityResponse2Merchant;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.util.EncryptSignature;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class NotiFyURLService2Merchant implements ReturnMerchantAttributes{

	static Logger logger = LoggerFactory.getLogger(NotiFyURLService2Merchant.class);
	
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;

	public void sendNotifyDetails2Merchant(String status, String paymentOption, String merchantorderId,
			String orderAmount, String vendorOrderId, String txtDate, String signature, String alertURL,
			String custName, String custEmail, String custPhone, String cardNumber, String upiVpa,
			String bankCode, String walletCode) {

		NofityResponse2Merchant nofityResponse2Merchant = new NofityResponse2Merchant();
		nofityResponse2Merchant.setMerchantorderId(merchantorderId);
		nofityResponse2Merchant.setOrderAmount(orderAmount);
		nofityResponse2Merchant.setPaymentOption(paymentOption);
		nofityResponse2Merchant.setSignature(signature);
		nofityResponse2Merchant.setStatus(status);
		nofityResponse2Merchant.setTxtDate(txtDate);
		nofityResponse2Merchant.setVendorOrderId(vendorOrderId);
		nofityResponse2Merchant.setCustName(custName);
		nofityResponse2Merchant.setCustEmail(custEmail);
		nofityResponse2Merchant.setCustPhone(custPhone);
		nofityResponse2Merchant.setCardNumber(cardNumber);
		nofityResponse2Merchant.setUpiVpa(upiVpa);
		nofityResponse2Merchant.setBankCode(bankCode);
		nofityResponse2Merchant.setWalletCode(walletCode);

		try {
			HttpResponse<Object> alertUrlCreateResponse = Unirest.post(alertURL)
					.header("Content-Type", "application/json").header("Accept", "*/*").body(nofityResponse2Merchant)
					.asObject(Object.class);

			//logger.info("Status Code ::" + alertUrlCreateResponse.getStatus());
			//logger.info("Status Response from Merchant Side ::" + alertUrlCreateResponse.getBody().toString());

		} catch (Exception e) {

			logger.error("Exception in nofity URL , please check with Merchant");
			e.printStackTrace();

		}
	}

	public void sendNotifyDetails2MerchantError(String paymentOption, String merchantorderId,
			String orderAmount,  String signature, String alertURL, String errorCode, String errorMsg,
			String custName, String custEmail, String custPhone, String cardNumber, String upiVpa,
			String bankCode, String walletCode
			) {

		NofityResponse2Merchant nofityResponse2Merchant = new NofityResponse2Merchant();
		nofityResponse2Merchant.setMerchantorderId(merchantorderId);
		nofityResponse2Merchant.setOrderAmount(orderAmount);
		nofityResponse2Merchant.setPaymentOption(paymentOption);
		nofityResponse2Merchant.setSignature(signature);		
		nofityResponse2Merchant.setCode(errorCode);
		nofityResponse2Merchant.setErrorMsg(errorMsg);

		try {
			HttpResponse<Object> alertUrlCreateResponse = Unirest.post(alertURL)
					.header("Content-Type", "application/json").header("Accept", "*/*").body(nofityResponse2Merchant)
					.asObject(Object.class);

			//logger.info("Status Code ::" + alertUrlCreateResponse.getStatus());
			//logger.info("Status Response from Merchant Side ::" + alertUrlCreateResponse.getBody().toString());

		} catch (Exception e) {

			logger.error("Exception in nofity URL , please check with Merchant");
			e.printStackTrace();

		}
	}
	
	public void populateReturnDetails(TransactionDetails transactionDetails)
			throws InvalidKeyException, NoSuchAlgorithmException {

		
		if (transactionDetails.getMerchantAlertURL() != null) {
			MerchantDetails merchantDetails = merchantDetailsRepository.findByMerchantID(transactionDetails.getMerchantId());
			UserDetails userDetails = userDetailsRepository.findById(transactionDetails.getUserID());
			String upiVpa = Utility
					.maskUpiCode(checkNullValue(SecurityUtils.decryptSaveData(transactionDetails.getVpaUPI())));
			String bankCode = "";
			String walletCode = "";
			String cardNumber = "";

			String signature = populateReturnSignature(transactionDetails.getStatus(),
					transactionDetails.getPaymentOption(), transactionDetails.getMerchantOrderId(),
					String.valueOf(transactionDetails.getAmount()), transactionDetails.getOrderID(),
					transactionDetails.getTxtPGTime(), transactionDetails.getMerchantId(), "", "",
					userDetails.getCustomerName(), userDetails.getEmailId(), userDetails.getPhoneNumber(), "", upiVpa,
					bankCode, walletCode, merchantDetails);

			notiFyURLService2Merchant.sendNotifyDetails2Merchant(transactionDetails.getStatus(),
					transactionDetails.getPaymentOption(), transactionDetails.getMerchantOrderId(),
					String.valueOf(transactionDetails.getAmount()), transactionDetails.getPgOrderID(),
					transactionDetails.getTxtPGTime(), signature, transactionDetails.getMerchantAlertURL(),
					userDetails.getCustomerName(), userDetails.getEmailId(), userDetails.getPhoneNumber(), cardNumber,
					upiVpa, bankCode, walletCode);
		}
	}
	
	public String populateReturnSignature(String status, String paymentOption, String merchantOrderId,
			String orderAmount, String verdorOrderId, String txtDate, String merchantId, String errorCode,
			String errorDetails, String custName, String custEmail, String custMobile, String cardNumber, String upiVpa,
			String bankCode, String walletCode, MerchantDetails merchantDetails)
			throws InvalidKeyException, NoSuchAlgorithmException {

		//logger.info("Inside Method populateReturnSignature()");
		Map<String, String> objectMap = new LinkedHashMap<String, String>();

		objectMap.put(SIG_STATUS, status);
		objectMap.put(SIG_PAYMENTOPTION, paymentOption);
		objectMap.put(SIG_MERCHANTORDERID, merchantOrderId);
		objectMap.put(SIG_ORDERAMOUNT, orderAmount);
		objectMap.put(SIG_VENDORORDERID, verdorOrderId);
		objectMap.put(SIG_TXTDATE, txtDate);
		objectMap.put(SIG_ERRORCODE, errorCode);
		objectMap.put(SIG_ERRORDETAILS, errorDetails);
		objectMap.put(SIG_CUSTNAME, custName);
		objectMap.put(SIG_CUSTEMAIL, custEmail);
		objectMap.put(SIG_CUSTPHONE, custMobile);
		objectMap.put(SIG_CARD_NUMBER, cardNumber);
		objectMap.put(SIG_UPI_ID, upiVpa);
		objectMap.put(SIG_BANK_CODE, bankCode);
		objectMap.put(SIG_WALLET_CODE, walletCode);

		//logger.info("End Method populateReturnSignature()");

		return EncryptSignature.encryptSignature(Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getSecretId()),
				objectMap);
	}
	
	public String checkNullValue(String str) {
		if (str == null) {
			return "";
		}
		return str;
	}
}
