package com.asktech.payment.service.webhook;

import java.security.NoSuchAlgorithmException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constants.letzpay.LetsPayConstants;
import com.asktech.payment.model.LetzpayTransactionDetails;
import com.asktech.payment.model.PGConfigurationDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.repository.LetzpayTransactionDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.letzpay.LetzpayUtilityClass;

@Service
public class WebhookServiceLetsPay {

	static Logger logger = LoggerFactory.getLogger(WebhookServiceLetsPay.class);

	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	LetzpayTransactionDetailsRepository letzpayTransactionDetailsRepository;
	@Autowired
	PGConfigurationDetailsRepository pgConfigurationDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	LetzpayUtilityClass letzpayUtilityClass;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;

	public String updateWebhookLetsPay(MultiValueMap<String, String> responseFormData) throws NoSuchAlgorithmException {

		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, LetsPayConstants.RESP_ORDER_ID));

		LetzpayTransactionDetails letzPayTransactionDetails = letzpayTransactionDetailsRepository
				.findByOrderId(transactionDetails.getOrderID());
		if (transactionDetails != null) {

			if (letzPayTransactionDetails != null) {
				
				PGConfigurationDetails pgConfigurationDetails = pgConfigurationDetailsRepository
						.findByPgAppId(transactionDetails.getPgId()); 
				
				Map<String, String> response =   GeneralUtils.convertMultiToRegularMap(responseFormData);				
				
				if (!letzpayUtilityClass.isValidateSignature(response, response.get("HASH"), pgConfigurationDetails.getPgSaltKey())) {
					
					transactionDetails.setStatus(letzpayUtilityClass.checkStatus(response.get(LetsPayConstants.RESP_RESPONSE_CODE),response.get(LetsPayConstants.RESP_STATUS), response.get(LetsPayConstants.RESP_RESPONSE_MESSAGE)) );
					transactionDetails.setSource("WebHook");

					letzPayTransactionDetails.setStatus(letzpayUtilityClass.checkStatus(response.get(LetsPayConstants.RESP_RESPONSE_CODE),response.get(LetsPayConstants.RESP_STATUS), response.get(LetsPayConstants.RESP_RESPONSE_MESSAGE)) );
					

					transactionDetailsRepository.save(transactionDetails);
					letzpayTransactionDetailsRepository.save(letzPayTransactionDetails);

					try {
						notiFyURLService2Merchant.populateReturnDetails(transactionDetails);
					} catch (Exception e) {
						logger.error("Exception in notify to merchant :: " + e.toString());
					}
				}

				
			}
		}

		return "Request has been received successfully. Thanks";

	}
}
