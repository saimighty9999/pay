package com.asktech.payment.service;

import java.io.IOException;
import java.net.URLDecoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.ErrorValues;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.setu.ApiResponse;
import com.asktech.payment.dto.setu.response.WebhookResponse;
import com.asktech.payment.enums.FormValidationExceptionEnums;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.CustomerInputDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.MerchantPGServices;
import com.asktech.payment.model.MerchantRequest4Customer;
import com.asktech.payment.model.PGConfigurationDetails;
import com.asktech.payment.model.PGInputFromCustomerDetails;
import com.asktech.payment.model.SetuWebhookResponse;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletList;
import com.asktech.payment.model.seam.CustomerRequest;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.CashfreeTransactionDetailsRepository;
import com.asktech.payment.repository.CustomerInputDetailsRepository;
import com.asktech.payment.repository.FreeChargeTransactionDetailsRepo;
import com.asktech.payment.repository.InputFromPgTransactionUpdateRepository;
import com.asktech.payment.repository.LetzpayTransactionDetailsRepository;
import com.asktech.payment.repository.MailDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.MerchantPGServicesRepository;
import com.asktech.payment.repository.MerchantRequest4CustomerRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.PGInputFromCustomerDetailsRepository;
import com.asktech.payment.repository.ResponstToMerchantDetailsRepository;
import com.asktech.payment.repository.SMSDetailsRepository;
import com.asktech.payment.repository.ServiceWisePaymentThresholdRepo;
import com.asktech.payment.repository.SetuWebhookResponseRepository;
import com.asktech.payment.repository.TransactionDetailsAllRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.seam.CustomerRequestRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.util.BlockValidation;
import com.asktech.payment.util.FormValidationsCashFree;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.PaytmUtilityFunction;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.asktech.payment.util.Validator;
import com.asktech.payment.util.airPay.AirPayPaymentUtility;
import com.asktech.payment.util.asanpay.AsanPayPaymentUtility;
import com.asktech.payment.util.atom.AtomUtilityClass;
import com.asktech.payment.util.cashfree.CashFreeUtilityClass;
import com.asktech.payment.util.easebuzz.EasebuzzPaymentUtils;
import com.asktech.payment.util.easypay.EasyPayUtility;
import com.asktech.payment.util.freecharge.FreeChargeUtility;
import com.asktech.payment.util.gatepay.GetePayUtilities;
import com.asktech.payment.util.grezpay.GrezPayPaymentUtility;
import com.asktech.payment.util.icici.ICICIUtilityClass;
import com.asktech.payment.util.ippopay.IppoPayPaymentUtility;
import com.asktech.payment.util.isgpg.IsgPgUtility;
import com.asktech.payment.util.letzpay.LetzpayUtilityClass;
import com.asktech.payment.util.neoCred.NeoCredUtility;
import com.asktech.payment.util.nimble.NimbleUtility;
import com.asktech.payment.util.nsdl.NSDLUtilityClass;
import com.asktech.payment.util.onepay.OnePayPaymentUtils;
import com.asktech.payment.util.payaid.PayaidUtility;
import com.asktech.payment.util.pineperk.PinePerkUtility;
import com.asktech.payment.util.payg.PayGPaymentUtility;
import com.asktech.payment.util.paytm.PaytmPgUtility;
import com.asktech.payment.util.payu.PayUPaymentUtility;
import com.asktech.payment.util.razorPay.RazorPayPaymentUtility;
import com.asktech.payment.util.sabPaisa.SabPaisaPaymentUtility;
import com.asktech.payment.util.setu.SetuUpiUtility;
import com.asktech.payment.util.zavion.ZavionUtilityPayment;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class PGGatewayService implements CashFreeFields, ErrorValues {

	@Autowired
	PaymentVerification service;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	MerchantPGServicesRepository merchantPGServicesRepository;
	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	TransactionDetailsAllRepository transactionDetailsAllRepository;
	@Autowired
	PGConfigurationDetailsRepository pgConfigurationDetailsRepository;
	@Autowired
	BankListRepository bankListRepository;
	@Autowired
	WalletListRepository walletListRepository;
	@Autowired
	SMSDetailsRepository smsDetailsRepository;
	@Autowired
	MailDetailsRepository mailDetailsRepository;
	@Autowired
	CustomerInputDetailsRepository customerInputDetailsRepository;
	@Autowired
	MerchantRequest4CustomerRepository merchantRequest4CustomerRepository;
	@Autowired
	PGInputFromCustomerDetailsRepository pgInputFromCustomerDetailsRepository;
	@Autowired
	InputFromPgTransactionUpdateRepository inputFromPgTransactionUpdateRepository;
	@Autowired
	ResponstToMerchantDetailsRepository responstToMerchantDetailsRepository;
	@Autowired
	LetzpayTransactionDetailsRepository letzpayTransactionDetailsRepository;
	@Autowired
	CashfreeTransactionDetailsRepository cashfreeTransactionDetailsRepository;
	@Autowired
	SetuWebhookResponseRepository setuWebhookResponseRepository;
	@Autowired
	FreeChargeTransactionDetailsRepo freeChargeTransactionDetailsRepo;
	@Autowired
	ServiceWisePaymentThresholdRepo serviceWisePaymentThresholdRepo;
	@Autowired
	ZavionUtilityPayment ZavionUtilityPayment;
	@Autowired
	EasebuzzPaymentUtils easebuzzPaymentUtils;
	@Autowired
	PayUPaymentUtility payUPaymentUtility;
	@Autowired
	CustomerRequestRepository customerRequestRepository;
	@Autowired
	OnePayPaymentUtils onePayPaymentUtils;
	@Autowired
	ICICIUtilityClass iciciUtilityClass;

	@Autowired
	LetzpayUtilityClass letzpayUtilityClass;
	@Autowired
	CashFreeUtilityClass cashFreeUtilityClass;
	@Autowired
	SetuUpiUtility setuUpiUtility;
	@Autowired
	FreeChargeUtility freeChargeUtility;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;
	@Autowired
	PaytmPgUtility paytmPgUtility;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	PaytmUtilityFunction paytmUtilityFunction;
	@Autowired
	GetePayUtilities gatePayUtilities;
	@Autowired
	NSDLUtilityClass nsdlUtilityClass;
	@Autowired
	GrezPayPaymentUtility grezPayPaymentUtility;
	@Autowired
	AsanPayPaymentUtility asanPayPaymentUtility;
	@Autowired
	RazorPayPaymentUtility razorPayPaymentUtility;
	@Autowired
	PayGPaymentUtility payGPaymentUtility;
	@Autowired
	SabPaisaPaymentUtility sabPaisaPaymentUtility;
	@Autowired
	AtomUtilityClass atomUtilityClass;
	@Autowired
	AirPayPaymentUtility airPayPaymentUtility;
	@Autowired
	IppoPayPaymentUtility ippoPayPaymentUtility;
	@Autowired
	EasyPayUtility easyPayUtility;
	@Autowired
	IsgPgUtility isgPgUtility;
	@Autowired
	NeoCredUtility neoCredUtility;
	@Autowired
	NimbleUtility nimbleUtility;
	@Autowired
	PayaidUtility PayaidUtility;
	@Autowired
	PinePerkUtility PinePerkUtility;

	@Value("${smsSenderId}")
	String smsSenderId;
	@Value("${mailSenderId}")
	String mailSenderId;
	@Value("${smsTextFormat.customerTRSMS}")
	String customerSMS;

	@Value("${apiEndPoint}")
	String apiEndPoint;
	@Value("${apiCustomerNotifyUrl}")
	String apiCustomerNotifyUrl;
	@Value("${folderconfiguration.setuWebHook}")
	String setuWebHook;
	@Value("${returnPage}")
	String returnPage;
	@Value("${upiLimit}")
	int upiLimit;
	static Logger logger = LoggerFactory.getLogger(PGGatewayService.class);

	public Map<String, Object> getRequestProcess(MultiValueMap<String, String> formDataInput, Model model,
			String device, String ipAddress) throws ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException,
			ParseException, IOException {

		logger.info("Input getRequestProcess() method. ");

		MultiValueMap<String, String> formData = getDecrypInput(formDataInput);
		Map<String, Object> objectMap = getRequestProcessAll(formData, model, device, ipAddress);

		logger.info("Ended getRequestProcess() method. " + formDataInput.toString());
		return objectMap;

	}

	public Map<String, Object> getInitialRequestProcess(MultiValueMap<String, String> formDataInput, Model model,
			String device, String ipAddress) throws ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException,
			JsonProcessingException, ParseException {

		logger.info("Input getRequestProcess() method. ");
		logger.info(GeneralUtils.MultiValueMaptoJson(formDataInput).toString());
		MultiValueMap<String, String> formData = getDecrypInput(formDataInput);
		logger.info(GeneralUtils.MultiValueMaptoJson(formData).toString());
		// MerchantDetails merhantDetails =
		// pgGatewayUtilService.getMerchantFromAppId(formData.get(APPID).get(0),
		// formData);
		// MerchantPGDetails merchantPGDetails =
		// merchantPGDetailsRepository.findByMerchantID(merhantDetails.getMerchantID());
		// PGConfigurationDetails pgDetails =
		// pgConfigurationDetailsRepository.findByPgName(merchantPGDetails.getMerchantPGName());

		System.out.println("\n\n");
		System.out.println(formData.get(APPID).get(0));
		System.out.println("\n\n");
		

		PGConfigurationDetails pgDetails = pgGatewayUtilService.getPgDetailsByAppId(formData.get(APPID).get(0),
				formData.get(PAYMENT_OPTION).get(0).toUpperCase());
		String link = apiEndPoint;
		if (pgDetails.getPgMerchantLink() != null) {
			link = pgDetails.getPgMerchantLink();
		}
		Map<String, Object> objectMap = new LinkedHashMap<String, Object>();

		model.addAttribute("pgredirectLink", link + "/collectPaymentLink");
		model.addAttribute("merchantId", formDataInput.get("merchantId").get(0));
		model.addAttribute("encryptedData", formDataInput.get("encryptedData").get(0));
		objectMap.put("Model", model);
		objectMap.put("Theme", "paymentpagelink");
		// Map<String, Object> objectMap = getRequestProcessAll(formData, model, device,
		// ipAddress);

		logger.info("Ended getRequestProcess() method. " + model.toString());
		return objectMap;

	}

	public MerchantDetails getMerchantDetailsByMerchantId(String merchantid) {
		MerchantDetails merchantDetails = merchantDetailsRepository.findByMerchantID(merchantid);
		return merchantDetails;
	}

	public Map<String, Object> getRequestProcessInit(MultiValueMap<String, String> formData, Model model, String device,
			String ipAddress)
			throws ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			ParseException {

		return null;
	}

	@Autowired
	BlockValidation blockValidation;

	public Map<String, Object> getRequestProcessAll(MultiValueMap<String, String> formData, Model model, String device,
			String ipAddress)
			throws ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException, ParseException, IOException {
		logger.info(GeneralUtils.MultiValueMaptoJson(formData));
		CustomerInputDetails customerInputDetails = new CustomerInputDetails();
		customerInputDetails.setInputEncData(formData.toString());
		customerInputDetails.setInputDecrptData(GeneralUtils.MultiValueMaptoJson(formData));
		customerInputDetails.setIpAddress(ipAddress);
		customerInputDetails.setTrxType(formData.get(PAYMENT_OPTION).get(0));
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
			customerInputDetails.setPaymentInfo(formData.get(UPI_VPI).get(0));
		}
		
		Map<String, Object> objectMap = new LinkedHashMap<String, Object>();

		if (!FormValidationsCashFree.AllFieldsValueBlank(formData)) {

			logger.error("Validation error inside FormValidationsCashFree.AllFieldsValueBlank().");
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
							UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0003.toString(), ALL_FIELDS_MANDATORY));
			throw new ValidationExceptions(ALL_FIELDS_MANDATORY, FormValidationExceptionEnums.E0003,
					formData.get(RETURNURL).get(0), formData);
		}

		if (!FormValidationsCashFree.checkAllAvailableFields(formData)) {
			logger.error("Validation error inside FormValidationsCashFree.checkAllAvailableFields().");
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
							UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0003.toString(), FORM_VALIDATION_FAILED));
			throw new ValidationExceptions(FORM_VALIDATION_FAILED, FormValidationExceptionEnums.E0033,
					formData.get(RETURNURL).get(0), formData);
		}
		// ------------------BLOCK BLACK LIST -----------------------
		String reason = blockValidation.validateContent(formData);
		if (reason != null) {
			logger.error("Validation Block");
			pgGatewayUtilService.createCustomerRequest(customerInputDetails);
			throw new ValidationExceptions(reason, FormValidationExceptionEnums.E0088,
					formData.get(RETURNURL).get(0), formData);
		}
		// ----------------------------------- -----------------------
		String orderId = SecurityUtils.getOrderNumber();
		String returnURL = formData.get(RETURNURL).get(0);

		MerchantDetails merhantDetails = pgGatewayUtilService.getMerchantFromAppId(formData.get(APPID).get(0),
				returnURL, formData);
		logger.info("After Merchant Selection");

		customerInputDetails.setMerchantId(merhantDetails.getMerchantID());
		// ------------------------- Check Merchant Active --------------------

		if (!merhantDetails.getUserStatus().equals("ACTIVE")) {
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0090.toString(), MERCHANT_INACTIVE));

			throw new ValidationExceptions(MERCHANT_INACTIVE, FormValidationExceptionEnums.E0090, returnURL, formData);
		}
		// ------------------------- --------------------
		// customerInputDetailsRepository.save(customerInputDetails);

		String pgID = getPGIDFromMerchantIdandServiceAndStatus(merhantDetails.getMerchantID(),
				formData.get(PAYMENT_OPTION).get(0), UserStatus.ACTIVE.toString(), returnURL, formData,
				customerInputDetails);
		logger.info("pgID :: " + pgID);
		// ------------------------- Check PG Active --------------------
		PGConfigurationDetails pGConfigurationDetails = pgConfigurationDetailsRepository.findByPgUuid(pgID);
		logger.info("Checking the merchant and PG status and Service status.");

		if (!pGConfigurationDetails.getStatus().equals("ACTIVE")) {
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0090.toString(), PG_NOT_ACTIVE));

			throw new ValidationExceptions(PG_NOT_ACTIVE, FormValidationExceptionEnums.E0090, returnURL, formData);

		}
		String amt = transactionDetailsRepository.getPgLimitTotal(pGConfigurationDetails.getPgName());
		if (amt != null) {
			long amount = Long.parseLong(amt);
			if (pGConfigurationDetails.getPgDailyLimit() != null) {
				if (amount >= Long.parseLong(pGConfigurationDetails.getPgDailyLimit())) {
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0091.toString(), PG_LIMIT_EXEDED));
					logger.info("PG Limit Exeeded");
					throw new ValidationExceptions(PG_LIMIT_EXEDED, FormValidationExceptionEnums.E0091, returnURL,
							formData);
				}
			}
		}
		// ------------------------- --------------------
		MerchantPGServices merchantPGService = merchantPGServicesRepository.findByMerchantIDAndPgIDAndServiceAndStatus(
				merhantDetails.getMerchantID(), pgID, formData.get(PAYMENT_OPTION).get(0).toUpperCase(),
				UserStatus.ACTIVE.toString());

		if (merchantPGService == null) {
			logger.error(" merchanteService details not found / not active for MerchantId :: "
					+ merhantDetails.getMerchantID());

			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
							UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0050.toString(), MERCHANT_PG_SERVICE_NOT_FOUND));
			throw new ValidationExceptions(MERCHANT_PG_SERVICE_NOT_FOUND, FormValidationExceptionEnums.E0050, returnURL,
					formData);
		}

		MerchantPGDetails merchantPGDetails = getPGDetailsWithMerchantId(merhantDetails.getMerchantID(),
				merchantPGService.getPgID(), returnURL, formData, customerInputDetails);

		// logger.info("merchantPGDetails :: " +
		// Utility.convertDTO2JsonString(merchantPGDetails));

		if (!FormValidationsCashFree.isVerifySignature(formData,
				Encryption.decryptCardNumberOrExpOrCvv(merhantDetails.getSecretId()))) {

			logger.error("Signature Mismatch in FormValidations.isVerifySignature()");
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0008.toString(), SIGNATURE_MISMATCH));

			throw new ValidationExceptions(SIGNATURE_MISMATCH, FormValidationExceptionEnums.E0008, returnURL, formData);
		}

		inputValidator(formData, merchantPGDetails, returnURL, customerInputDetails);
		// -------------------Random Phn Number -------------------
		if ((merhantDetails.getRandPhn() != null) && merhantDetails.getRandPhn().equals("TRUE")) {
			String phn = Utility.getRandomPhn();
			logger.info("RANDOM PHN NUMBER::" + phn);
			formData.set(CUSTOMERPHONE, phn);
			logger.info("SET RANDOM PHN NUMBER::" + formData.get(CUSTOMERPHONE).get(0));
		}
		// -----------------------------------------
		// -------------------Multiple UPI Number -------------------
		if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
			logger.info("UPI Limit Check");
			List<CustomerInputDetails> custDetails = customerInputDetailsRepository
					.getTodaysInputDetails(formData.get(PAYMENT_OPTION).get(0), formData.get(UPI_VPI).get(0));
			logger.info(Utility.convertDTO2JsonString(custDetails));
			if (custDetails.size() >= upiLimit) {

				pgGatewayUtilService.createCustomerRequest(
						pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
								UserStatus.ERROR.toString(),
								FormValidationExceptionEnums.E0092.toString(), UPI_LIMIT_EXCEED));

				throw new ValidationExceptions(UPI_LIMIT_EXCEED, FormValidationExceptionEnums.E0008, returnURL,
						formData);

			}
		}
		// -----------------------------------------
		if (merchantPGDetails.getMerchantPGName().contains("CASHFREE")) {

			logger.info("Inside CashFree Selection Block");
			model = cashFreeUtilityClass.processCashFreeRequest(formData, model, merchantPGDetails, orderId);
			logger.info("After Model creation ...");

			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("card")) {
				objectMap.put("Model", model);
				objectMap.put("Theme", "cashfree/paymentcardpage");
			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("nb")) {
				objectMap.put("Model", model);
				objectMap.put("Theme", "cashfree/paymentnbpage");
			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("wallet")) {
				objectMap.put("Model", model);
				objectMap.put("Theme", "cashfree/paymentwalletpage");
			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("upi")) {
				if (formData.get(CashFreeFields.UPI_VPI) != null) {
					objectMap.put("Model", model);
					objectMap.put("Theme", "cashfree/paymentupipage");
				} else if (formData.get(CashFreeFields.UPIMODE).get(0).equalsIgnoreCase("gpay")) {
					objectMap.put("Model", model);
					objectMap.put("Theme", "cashfree/paymentgpaypage");
				}
			}
			logger.info("End CashFree Selection Block");
		}

		if (merchantPGDetails.getMerchantPGName().contains("LETZPAY")) {
			logger.info("Inside Letzpay processor ...");

			model = letzpayUtilityClass.processLetzPayRequest(formData, model, merchantPGDetails, orderId);
			logger.info("After Model creation ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("card")) {
				objectMap.put("Model", model);

				objectMap.put("Theme", "letzpay/paymentpage");
			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("nb")) {
				objectMap.put("Model", model);
				objectMap.put("Theme", "letzpay/paymentpage");
			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("wallet")) {
				objectMap.put("Model", model);
				objectMap.put("Theme", "letzpay/paymentpage");
			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("upi")) {
				if (formData.get(CashFreeFields.UPI_VPI) != null) {
					objectMap.put("Model", model);
					objectMap.put("Theme", "letzpay/paymentpage");
				}
			}
			logger.info("End Letzpay processor ...");
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("SETU")) {
			logger.info("Inside SETU- UPI processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("upi")) {
				model = setuUpiUtility.processSetuRequest(formData, model, merchantPGDetails, orderId, device);
				objectMap.put("Model", model);
				objectMap.put("Theme", "setu/paymentpage");
			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("upi_qr")) {
				logger.info("Inside SETU UPI QR Block");
				model = setuUpiUtility.processSetuRequest(formData, model, merchantPGDetails, orderId, device);
				logger.info("Before set into Object Map for Setu");

				objectMap.put("Model", model);
				objectMap.put("Theme", "setu/paymentpage");
			}
			logger.info("After Model creation ...");
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("FREECHARGE")) {
			logger.info("Inside FREECHARGE processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")) {
				try {
					model = freeChargeUtility.populateModelInfo(model, merchantPGDetails, formData, orderId);
				} catch (Exception e) {
					e.printStackTrace();
				}
				objectMap.put("Model", model);
				objectMap.put("Theme", "freeCharge/freeChargeWallet");
			}
			logger.info("After Model creation ...");
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("PAYTM")) {
			logger.info("Inside PAYTM processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")) {
				try {
					model = paytmPgUtility.processPaytmRequest(formData, model, merchantPGDetails, orderId);
				} catch (Exception e) {
					logger.info(e.getMessage());
					e.printStackTrace();
				}
				objectMap.put("Model", model);
				objectMap.put("Theme", "paytm/paytmWallet");
			}
			logger.info("After Model creation ...");
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("ZAVION")) {
			logger.info("Inside Zavion processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = ZavionUtilityPayment.processZavionRequest(formData, model, merchantPGDetails, orderId);
				} catch (Exception e) {
					logger.error("Exception in Zavion Request :::");
					e.printStackTrace();
				}
				objectMap.put("Model", model);
				objectMap.put("Theme", "zavion/paymentnbpage");
			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = ZavionUtilityPayment.processZavionRequest(formData, model, merchantPGDetails, orderId);
				} catch (Exception e) {
					logger.error("Exception in Zavion Request :::");
					e.printStackTrace();
				}
				objectMap.put("Model", model);
				objectMap.put("Theme", "zavion/paymentupipage");
			}

			logger.info("After Model creation ...");
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("EASEBUZZ")) {
			logger.info("Inside EASEBUZZ processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = easebuzzPaymentUtils.processEaseBuzzRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "easebuzz/easebuzzUPI");

			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = easebuzzPaymentUtils.processEaseBuzzRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "easebuzz/easebuzzNB");

			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")) {
				try {
					model = easebuzzPaymentUtils.processEaseBuzzRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				// logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "easebuzz/easebuzzWALLET");
			}
			logger.info("After Model creation ...");
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("PAYU")) {
			logger.info("Inside PAYU processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = payUPaymentUtility.processPayURequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				// logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "payu/paymentupipage");
			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = payUPaymentUtility.processPayURequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				// logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "payu/paymentnbpage");

			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")) {
				try {
					model = payUPaymentUtility.processPayURequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				// logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "payu/paymentwalletpage");

			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("CARD")) {
				try {
					model = payUPaymentUtility.processPayURequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}

				objectMap.put("Model", model);
				objectMap.put("Theme", "payu/paymentcardpage");

			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI_QR")) {
				try {
					model = payUPaymentUtility.processPayURequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}

				objectMap.put("Model", model);
				objectMap.put("Theme", "payu/paymentpage");

			}
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("1PAY")) {
			logger.info("Inside 1PAY processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = onePayPaymentUtils.process1PayRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				// logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "1pay/1payRequest");

			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = onePayPaymentUtils.process1PayRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				// logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "1pay/1payRequest");

			}
			logger.info("After Model creation ...");
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("ICICI")) {
			logger.info("Inside ICICIBANK processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = iciciUtilityClass.processIciciBankRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				// logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "icici/iciciRequest");

			} else if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = iciciUtilityClass.processIciciBankRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				// logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "icici/iciciRequest");

			}
			logger.info("After Model creation ...");
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("GETEPAY")) {
			logger.info("Inside GATEPAY processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = gatePayUtilities.processGatePayRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					logger.info(e.getMessage());
					e.printStackTrace();

				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "gatepay/gatepayPaymentPage");

			}
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("NSDL")) {
			logger.info("Inside NSDL processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = nsdlUtilityClass.processNSDLNBRequest(formData, model, merchantPGDetails, orderId,
							ipAddress, returnURL);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "nsdl/nsdlauthenticationpage");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("CARD")) {
				try {
					model = nsdlUtilityClass.processNSDLCardRequest(formData, model, merchantPGDetails, orderId,
							ipAddress, returnURL);

				} catch (Exception e) {
					e.printStackTrace();
				}

				if (model.containsAttribute("ERROR")) {
					throw new ValidationExceptions("Issue with PG , contact Administrator.",
							FormValidationExceptionEnums.E0053, returnURL, formData);
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "nsdl/nsdlauthenticationpage");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = nsdlUtilityClass.processNSDLUPIRequest(formData, model, merchantPGDetails, orderId,
							ipAddress, returnURL);

				} catch (Exception e) {
					e.printStackTrace();
				}

				if (model.containsAttribute("errorMsg")) {
					TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(orderId);
					transactionDetails.setStatus("FAILED");
					transactionDetails.setTxtMsg(model.asMap().get("errorMsg").toString());
					transactionDetailsRepository.save(transactionDetails);
					model = pgGatewayUtilService.populateReturnModel(model,
							String.valueOf(transactionDetails.getAmount()), "FAILED", transactionDetails);
					model.addAttribute("errorCode", "");
					model.addAttribute("errorMsg", "");
					objectMap.put("Model", model);
					objectMap.put("Theme", "paymentResponseToMerchant");
					// throw new ValidationExceptions("Issue with PG , contact Administrator.",
					// FormValidationExceptionEnums.E0053, returnURL, formData);
				} else {
					logger.info("Model Details :: " + model.toString());

					objectMap.put("Model", model);
					objectMap.put("Theme", "nsdl/paymentpage");
				}
			}
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("GREZPAY")) {
			logger.info("Inside GREZPAY processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = grezPayPaymentUtility.processGrezPayRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "grezpay/grezpayUpiPayment");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = grezPayPaymentUtility.processGrezPayRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "grezpay/grezpayNBPayment");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")) {
				try {
					model = grezPayPaymentUtility.processGrezPayRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "grezpay/grezpayWalletPayment");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("CARD")) {
				try {
					model = grezPayPaymentUtility.processGrezPayRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					logger.info(e.getMessage());
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "grezpay/grezpayCardPayment");

			}
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("ASANPAY")) {
			logger.info("Inside ASANPAY processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = asanPayPaymentUtility.processAsanPayRequest(formData, model, merchantPGDetails, orderId);
					// model = grezPayPaymentUtility.processGrezPayRequest(formData, model,
					// merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "asanpay/asanpayUpiPayment");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = asanPayPaymentUtility.processAsanPayRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "asanpay/asanpayNBPayment");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")) {
				try {
					model = asanPayPaymentUtility.processAsanPayRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "asanpay/asanpayWalletPayment");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("CARD")) {
				try {
					model = asanPayPaymentUtility.processAsanPayRequest(formData, model, merchantPGDetails, orderId);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "asanpay/asanpayCardPayment");

			}
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("RAZORPAY")) {
			logger.info("Inside RAZORPAY processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = razorPayPaymentUtility.processRazorPayRequest(formData, model, merchantPGDetails, orderId,
							ipAddress);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				// objectMap.put("Theme", "razorPay/razopPayPayment");
				objectMap.put("Theme", "razorPay/razorPayNonSeam");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = razorPayPaymentUtility.processRazorPayRequest(formData, model, merchantPGDetails, orderId,
							ipAddress);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				// objectMap.put("Theme", "razorPay/razopPayPayment");
				objectMap.put("Theme", "razorPay/razorPayNonSeam");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")) {
				try {
					model = razorPayPaymentUtility.processRazorPayRequest(formData, model, merchantPGDetails, orderId,
							ipAddress);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				// objectMap.put("Theme", "razorPay/razopPayPayment");
				objectMap.put("Theme", "razorPay/razorPayNonSeam");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("CARD")) {
				try {
					model = razorPayPaymentUtility.processRazorPayRequest(formData, model, merchantPGDetails, orderId,
							ipAddress);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				// objectMap.put("Theme", "razorPay/razopPayPayment");
				objectMap.put("Theme", "razorPay/razorPayNonSeam");

			}
		}
		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("PAYG")) {
			logger.info("Inside PAYG processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")) {
				try {
					model = payGPaymentUtility.processPayGRequest(formData, model, merchantPGDetails, orderId,
							ipAddress);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "payg/payGPaymentSubmit");

			}

			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				String payGval = payGPaymentUtility.validatePayGRequest(formData);
				if (payGval != null) {
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0033.toString(), payGval));
					throw new ValidationExceptions(payGval, FormValidationExceptionEnums.E0033, returnURL,
							formData);
				}

				try {
					model = payGPaymentUtility.processPayGRequest(formData, model, merchantPGDetails, orderId,
							ipAddress);

				} catch (Exception e) {
					e.printStackTrace();
				}

				if (model.containsAttribute("ERROR")) {
					throw new ValidationExceptions("Issue with PG , contact Administrator.",
							FormValidationExceptionEnums.E0053, returnURL, formData);
				}

				logger.info("Model Details :: " + model.toString());

				objectMap.put("Model", model);
				objectMap.put("Theme", "payg/payGPaymentSubmit");

			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {

					model = payGPaymentUtility.processPayGRequest(formData, model, merchantPGDetails, orderId,
							ipAddress);

				} catch (Exception e) {
					e.printStackTrace();
				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "payg/paymentpage");

			}
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("SABPAISA")) {
			logger.info("Inside SABPAISA processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI") ||
					formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB") ||
					formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")) {
				try {
					model = sabPaisaPaymentUtility.processSabPaisaRequest(formData, model, merchantPGDetails, orderId,
							ipAddress);
				} catch (Exception e) {
					e.printStackTrace();
					logger.error("SABPAISA ERROR::" + e.getMessage());
					throw new ValidationExceptions(e.getMessage(), FormValidationExceptionEnums.E0088,
							formData.get(RETURNURL).get(0), formData);

				}
				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "sabPaisa/sabPaisaPayment");

			}

		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("ATOM")) {

			logger.info("Inside ATOM processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI") ||
					formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB") ||
					formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("CARD")) {

				model = atomUtilityClass.processAtomRequest(formData, model, merchantPGDetails, orderId);

				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "atom/atomPayment");

			}

		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("AIRPAY")) {
			logger.info("Inside AIRPAY processor ...");

			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {

				model = airPayPaymentUtility.processAirPayRequest(formData, model, merchantPGDetails, orderId);

				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "airPay/paymentpage");
			}

		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("IPPOPAY")) {
			logger.info("Inside IPPOPAY processor ...");

			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {

				model = ippoPayPaymentUtility.processIppoPayRequest(formData, model, merchantPGDetails, orderId);

				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "ippoPay/paymentPageippoPay");
			}

		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("EASYPAY")) {
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI") ||
					formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB") ||
					formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")
					|| formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("CARD")) {
				logger.info("EASYPAY START");
				model = easyPayUtility.processEasyPayRequest(formData, model, merchantPGDetails, orderId);

				logger.info("Model Details :: " + model.toString());
				objectMap.put("Model", model);
				objectMap.put("Theme", "easypay/easyPayPayment");
			}

		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("ISGPG")) {
			logger.info("Inside NSDL processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = isgPgUtility.processIsgUPIRequest(formData, model, merchantPGDetails, orderId,
							ipAddress, returnURL);

				} catch (Exception e) {
					e.printStackTrace();
				}

				if (model.containsAttribute("errorMsg")) {
					TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(orderId);
					transactionDetails.setStatus("FAILED");
					transactionDetails.setTxtMsg(model.asMap().get("errorMsg").toString());
					transactionDetailsRepository.save(transactionDetails);
					model = pgGatewayUtilService.populateReturnModel(model,
							String.valueOf(transactionDetails.getAmount()), "FAILED", transactionDetails);
					model.addAttribute("errorCode", "");
					model.addAttribute("errorMsg", "");
					objectMap.put("Model", model);
					objectMap.put("Theme", "paymentResponseToMerchant");
					// throw new ValidationExceptions("Issue with PG , contact Administrator.",
					// FormValidationExceptionEnums.E0053, returnURL, formData);
				} else {
					logger.info("Model Details :: " + model.toString());

					objectMap.put("Model", model);
					objectMap.put("Theme", "isg/paymentpage");
				}
			}
		}
		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("NEO")) {
			logger.info("Inside NEO processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				try {
					model = neoCredUtility.processRequest(formData, model, merchantPGDetails, orderId, returnURL);
				} catch (Exception e) {
					e.printStackTrace();
				}

				if (model.containsAttribute("errorMsg")) {
					TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(orderId);
					transactionDetails.setStatus("FAILED");
					transactionDetails.setTxtMsg(model.asMap().get("errorMsg").toString());
					transactionDetailsRepository.save(transactionDetails);
					model = pgGatewayUtilService.populateReturnModel(model,
							String.valueOf(transactionDetails.getAmount()), "FAILED", transactionDetails);
					model.addAttribute("errorCode", "");
					model.addAttribute("errorMsg", "");
					objectMap.put("Model", model);
					objectMap.put("Theme", "paymentResponseToMerchant");
					// throw new ValidationExceptions("Issue with PG , contact Administrator.",
					// FormValidationExceptionEnums.E0053, returnURL, formData);
				} else {
					logger.info("Model Details :: " + model.toString());

					objectMap.put("Model", model);
					objectMap.put("Theme", "neo/paymentpage");
				}
			}
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("NIMB")) {
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("UPI")) {
				model = nimbleUtility.processRequest(formData, model, merchantPGDetails, orderId);
				logger.info("Model Details :: " + model.toString());

				objectMap.put("Model", model);
				objectMap.put("Theme", "nimbbl/upiPaymentPage");
			}
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("WALLET")
					|| formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				model = nimbleUtility.processRequest(formData, model, merchantPGDetails, orderId);
				logger.info("Model Details :: " + model.toString());

				objectMap.put("Model", model);
				objectMap.put("Theme", "nimbbl/nbPaymentPage");
			}

		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("PAYAID")) {
			logger.info("Inside PAYAID processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = PayaidUtility.processRequest(formData, model, merchantPGDetails, orderId, returnURL);
				} catch (Exception e) {
					e.printStackTrace();
				}

				if (model.containsAttribute("errorMsg")) {
					TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(orderId);
					transactionDetails.setStatus("FAILED");
					transactionDetails.setTxtMsg(model.asMap().get("errorMsg").toString());
					transactionDetailsRepository.save(transactionDetails);
					model = pgGatewayUtilService.populateReturnModel(model,
							String.valueOf(transactionDetails.getAmount()), "FAILED", transactionDetails);
					model.addAttribute("errorCode", "");
					model.addAttribute("errorMsg", "");
					objectMap.put("Model", model);
					objectMap.put("Theme", "paymentResponseToMerchant");
					// throw new ValidationExceptions("Issue with PG , contact Administrator.",
					// FormValidationExceptionEnums.E0053, returnURL, formData);
				} else {
					logger.info("Model Details :: " + model.toString());

					objectMap.put("Model", model);
					objectMap.put("Theme", "payaid/paymentPage");
				}
			}
		}

		if (merchantPGDetails.getMerchantPGName().toUpperCase().contains("PINE")) {
			logger.info("Inside PINE processor ...");
			if (formData.get(PAYMENT_OPTION).get(0).equalsIgnoreCase("NB")) {
				try {
					model = PinePerkUtility.processRequest(formData, model, merchantPGDetails, orderId, returnURL);
				} catch (Exception e) {
					e.printStackTrace();
				}

				if (model.containsAttribute("errorMsg")) {
					TransactionDetails transactionDetails = transactionDetailsRepository.findByOrderID(orderId);
					transactionDetails.setStatus("FAILED");
					transactionDetails.setTxtMsg(model.asMap().get("errorMsg").toString());
					transactionDetailsRepository.save(transactionDetails);
					model = pgGatewayUtilService.populateReturnModel(model,
							String.valueOf(transactionDetails.getAmount()), "FAILED", transactionDetails);
					model.addAttribute("errorCode", "");
					model.addAttribute("errorMsg", "");
					objectMap.put("Model", model);
					objectMap.put("Theme", "paymentResponseToMerchant");
					// throw new ValidationExceptions("Issue with PG , contact Administrator.",
					// FormValidationExceptionEnums.E0053, returnURL, formData);
				} else {
					logger.info("Model Details :: " + model.toString());

					objectMap.put("Model", model);
					objectMap.put("Theme", "pineperk/paymentpage");
				}
			}
		}


		pgGatewayUtilService.createCustomerRequest(
				pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.SUCCESS.toString(),
						null, null));

		UserDetails userDetails = populateUser(formData, merhantDetails);
		pgGatewayUtilService.populateTransactionDetails(merhantDetails, formData, merchantPGDetails,
				formData.get(RETURNURL).get(0),
				formData.get(ORDERID).get(0), orderId, userDetails);

		logger.info("return from method getRequestProcessAll()");

		PGInputFromCustomerDetails pgInputFromCustomerDetails = new PGInputFromCustomerDetails();
		pgInputFromCustomerDetails.setMerchantId(merhantDetails.getMerchantID());
		pgInputFromCustomerDetails.setMerchantOrderId(formData.get(ORDERID).get(0));
		pgInputFromCustomerDetails.setOrderID(orderId);
		pgInputFromCustomerDetails.setInputData(model.toString());

		pgInputFromCustomerDetailsRepository.save(pgInputFromCustomerDetails);

		return objectMap;

	}

	private void inputValidator(MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails,
			String returnURL, CustomerInputDetails customerInputDetails) throws ValidationExceptions {

		logger.info("Inside inputValidator() method");

		if (!Validator.isValidEmail(formData.get(CUSTOMEREMAIL).get(0))) {
			logger.error("Custom Exception :: " + EMAIL_VALIDATION_FAILED);
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0033.toString(), EMAIL_VALIDATION_FAILED));

			throw new ValidationExceptions(EMAIL_VALIDATION_FAILED, FormValidationExceptionEnums.E0033, returnURL,
					formData);
		}
		if (!Validator.isValidName(formData.get(CUSOMERNAME).get(0))) {
			logger.error("Custom Exception :: " + NAME_VALIDATION_FAILED);
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0033.toString(), NAME_VALIDATION_FAILED));
			throw new ValidationExceptions(NAME_VALIDATION_FAILED, FormValidationExceptionEnums.E0033, returnURL,
					formData);
		}
		if (!Validator.isValidPhoneNumber(formData.get(CUSTOMERPHONE).get(0))) {
			logger.error("Custom Exception :: " + PHONE_VAIDATION_FILED);
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0033.toString(), PHONE_VAIDATION_FILED));
			throw new ValidationExceptions(PHONE_VAIDATION_FILED, FormValidationExceptionEnums.E0033, returnURL,
					formData);
		}
		if (Integer.parseInt(formData.get(ORDERAMOUNT).get(0)) < 100) {
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0033.toString(), VALIDATION_ERROR_ORDER_AMOUNT));
			throw new ValidationExceptions(VALIDATION_ERROR_ORDER_AMOUNT, FormValidationExceptionEnums.E0033, returnURL,
					formData);
		}

		List<TransactionDetails> listTransactionDetails = transactionDetailsRepository
				.findAllByMerchantIdAndMerchantOrderId(merchantPGDetails.getMerchantID(), formData.get(ORDERID).get(0));
		if (listTransactionDetails.size() > 0) {
			logger.error("Custom Exception :: " + MerchatOrderIdExists);
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0079.toString(), MerchatOrderIdExists));

			throw new ValidationExceptions(MerchatOrderIdExists, FormValidationExceptionEnums.E0079, returnURL,
					formData);
		}

		// Amount check logic implemented as per requirement
		logger.info("Input Data :: " + formData.get(PAYMENT_OPTION).get(0) + " , " + merchantPGDetails.getMerchantPGId()
				+ " , " + formData.get(ORDERAMOUNT).get(0));

		String iAmountThresold = serviceWisePaymentThresholdRepo.getPaymentLimit(merchantPGDetails.getMerchantID(),
				merchantPGDetails.getMerchantPGId(), formData.get(PAYMENT_OPTION).get(0).toUpperCase());
		logger.info("Thresold Amount :: " + iAmountThresold);

		if (iAmountThresold == null) {
			logger.error("Custom Exception :: " + ThresholdAmountError);
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0084.toString(), ThresholdAmountError));
			throw new ValidationExceptions(ThresholdAmountError, FormValidationExceptionEnums.E0084, returnURL,
					formData);
		}

		logger.info("formData.get(ORDERAMOUNT).get(0) :: " + formData.get(ORDERAMOUNT).get(0));
		if (Long.parseLong(formData.get(ORDERAMOUNT).get(0)) > Long.parseLong(iAmountThresold)) {
			logger.error("Custom Exception :: " + AMOUNT_GREATER_THAN_EXPECTED);
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0078.toString(), AMOUNT_GREATER_THAN_EXPECTED));
			throw new ValidationExceptions(AMOUNT_GREATER_THAN_EXPECTED, FormValidationExceptionEnums.E0078, returnURL,
					formData);
		}
		// Amount check logic end

		switch (formData.get(PAYMENT_OPTION).get(0).toUpperCase()) {
			case "NB":

				logger.info("Payment Code::" + formData.get(PAYMENTCODE).get(0));
				if (!Validator.isNumeric(formData.get(PAYMENTCODE).get(0))) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				if (formData.get(PAYMENTCODE).get(0).length() != 4) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}

				BankList banklist = bankListRepository.findAllByBankcodeAndMerchantIdAndStatusAndPgName(
						formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(),
						UserStatus.ACTIVE.toString(),
						merchantPGDetails.getMerchantPGName());

				if (banklist == null) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				break;
			case "CARD":

				if (!Validator.isValidCardUserName(formData.get(CARD_HOLDER).get(0))) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				if (Validator.isValidateIdNumber(formData.get(CARD_NUMBER).get(0), "CARD") != 1) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				if (!Validator.isNumeric(formData.get(CARD_EXPYEAR).get(0))) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				if (formData.get(CARD_EXPYEAR).get(0).length() != 4) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				if (!Validator.isNumeric(formData.get(CARD_EXPMONTH).get(0))) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				if ((Integer.parseInt(formData.get(CARD_EXPMONTH).get(0)) > 12)
						|| (Integer.parseInt(formData.get(CARD_EXPMONTH).get(0)) < 1)) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				if (!Validator.isNumeric(formData.get(CARD_CVV).get(0))) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				if (formData.get(CARD_CVV).get(0).length() != 3) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				break;

			case "UPI":

				if (Validator.isValidateIdNumber(formData.get(UPI_VPI).get(0), "UPI") != 1) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				if (!Validator.amountCheck(Long.parseLong(formData.get(ORDERAMOUNT).get(0)))) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0078.toString(), AMOUNT_GREATER_THAN_EXPECTED));
					throw new ValidationExceptions(AMOUNT_GREATER_THAN_EXPECTED, FormValidationExceptionEnums.E0078,
							returnURL, formData);
				}

				break;

			case "UPI_QR":

				if (!Validator.amountCheck(Long.parseLong(formData.get(ORDERAMOUNT).get(0)))) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0078.toString(), AMOUNT_GREATER_THAN_EXPECTED));
					throw new ValidationExceptions(AMOUNT_GREATER_THAN_EXPECTED, FormValidationExceptionEnums.E0078,
							returnURL, formData);
				}
				break;

			case "WALLET":

				if (!Validator.isNumeric(formData.get(PAYMENTCODE).get(0))) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				if (formData.get(PAYMENTCODE).get(0).length() != 4) {
					logger.error("Custom Exception :: " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}

				WalletList walletList = walletListRepository.findByPaymentcodeAndMerchantIdAndStatusAndPgname(
						formData.get(PAYMENTCODE).get(0), merchantPGDetails.getMerchantID(),
						UserStatus.ACTIVE.toString(),
						merchantPGDetails.getMerchantPGName());
				if ((walletList == null)) {
					logger.error("Custom Exception :: wallet code not found " + DATA_INVALID);
					pgGatewayUtilService.createCustomerRequest(
							pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
									UserStatus.ERROR.toString(),
									FormValidationExceptionEnums.E0057.toString(), DATA_INVALID));
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057, returnURL,
							formData);
				}
				break;
			default:
				logger.error("Custom Exception :: " + UNKNOWN_OPTION);
				pgGatewayUtilService.createCustomerRequest(
						pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
								UserStatus.ERROR.toString(),
								FormValidationExceptionEnums.E0053.toString(), UNKNOWN_OPTION));
				throw new ValidationExceptions(UNKNOWN_OPTION, FormValidationExceptionEnums.E0053, returnURL, formData);
		}
		logger.info("Ended inputValidator() method");
	}

	public String getPGIDFromMerchantIdandServiceAndStatus(String merchantId, String service, String status,
			String retrunURL, MultiValueMap<String, String> formData, CustomerInputDetails customerInputDetails)
			throws JsonProcessingException, ValidationExceptions {

		logger.info("Inside getPGIDFromMerchantIdandServiceAndStatus() method");

		String pgId = null;
		MerchantPGServices merchantPGServices = new MerchantPGServices();

		if (service.equalsIgnoreCase("WALLET")) {
			WalletList walletList = walletListRepository
					.findByPaymentcodeAndMerchantIdAndStatus(formData.get(PAYMENTCODE).get(0), merchantId, status);
			if (walletList == null) {
				logger.error("Custom Exception :: " + Merchant_WITH_Wallet_Not_Mapped);
				pgGatewayUtilService.createCustomerRequest(
						pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
								UserStatus.ERROR.toString(),
								FormValidationExceptionEnums.E0082.toString(), Merchant_WITH_Wallet_Not_Mapped));
				throw new ValidationExceptions(Merchant_WITH_Wallet_Not_Mapped, FormValidationExceptionEnums.E0082,
						retrunURL, formData);
			}
			pgId = pgConfigurationDetailsRepository.findByPgName(walletList.getPgname()).getPgUuid();

		} else if (service.equalsIgnoreCase("NB")) {
			BankList bankList = bankListRepository
					.findAllByBankcodeAndMerchantIdAndStatus(formData.get(PAYMENTCODE).get(0), merchantId, status);
			if (bankList == null) {
				logger.error("Custom Exception :: " + Merchant_WITH_BankCode_Not_Mapped);
				pgGatewayUtilService.createCustomerRequest(
						pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails,
								UserStatus.ERROR.toString(),
								FormValidationExceptionEnums.E0082.toString(), Merchant_WITH_BankCode_Not_Mapped));
				throw new ValidationExceptions(Merchant_WITH_BankCode_Not_Mapped, FormValidationExceptionEnums.E0083,
						retrunURL, formData);
			}
			pgId = pgConfigurationDetailsRepository.findByPgName(bankList.getPgName()).getPgUuid();
		}

		if (pgId == null) {
			merchantPGServices = merchantPGServicesRepository.findByMerchantIDAndServiceAndStatus(merchantId, service,
					status);
		} else {

			merchantPGServices = merchantPGServicesRepository.findByMerchantIDAndPgIDAndServiceAndStatus(merchantId,
					pgId, service, status);
		}
		logger.info("Merchant Detals :: " + Utility.convertDTO2JsonString(merchantPGServices));

		if (merchantPGServices == null) {

			logger.error("Custom Exception :: " + MERCHANT_PG_SERVICE_NO_MAPPED);
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0012.toString(), MERCHANT_PG_SERVICE_NO_MAPPED));
			throw new ValidationExceptions(MERCHANT_PG_SERVICE_NO_MAPPED, FormValidationExceptionEnums.E0012, retrunURL,
					formData);
		}

		logger.info("End getPGIDFromMerchantIdandServiceAndStatus() method");
		return merchantPGServices.getPgID();
	}

	public MerchantPGDetails getPGDetailsWithMerchantId(String merchantId, String pgId, String returnURL,
			MultiValueMap<String, String> formData, CustomerInputDetails customerInputDetails)
			throws JsonProcessingException, ValidationExceptions {

		logger.info("Inside getPGDetailsWithMerchantId() method::" + merchantId + "||" + pgId);
		MerchantPGDetails merchantPGDetails = merchantPGDetailsRepository.findByMerchantIDAndMerchantPGId(merchantId,
				pgId);
		logger.info("Merchant Detals :: " + Utility.convertDTO2JsonString(merchantPGDetails));

		if (merchantPGDetails == null) {
			logger.error("Custom Exception :: " + MERCHANT_PG_CONFIG_NOT_FOUND);
			pgGatewayUtilService.createCustomerRequest(
					pgGatewayUtilService.updateCustomerInputDetails(customerInputDetails, UserStatus.ERROR.toString(),
							FormValidationExceptionEnums.E0012.toString(), MERCHANT_PG_CONFIG_NOT_FOUND));
			throw new ValidationExceptions(MERCHANT_PG_CONFIG_NOT_FOUND, FormValidationExceptionEnums.E0012, returnURL,
					formData);
		}

		logger.info("End getPGDetailsWithMerchantId() method");

		return merchantPGDetails;
	}

	public UserDetails populateUser(MultiValueMap<String, String> formData, MerchantDetails merhantDetails) {

		logger.info("Inside UserDetails()");
		UserDetails userDetails = new UserDetails();
		UserDetails userDetailsResponse = new UserDetails();

		List<UserDetails> userDetailsList = userDetailsRepository.findAllByEmailIdAndPhoneNumberAndMerchantId(
				formData.get(CUSTOMEREMAIL).get(0), formData.get(CUSTOMERPHONE).get(0), merhantDetails.getMerchantID());

		if (userDetailsList.size() == 0) {
			userDetails = new UserDetails();
			userDetails.setCustomerName(formData.get(CUSOMERNAME).get(0));
			userDetails.setEmailId(formData.get(CUSTOMEREMAIL).get(0));
			userDetails.setMerchantId(merhantDetails.getMerchantID());
			userDetails.setPhoneNumber(formData.get(CUSTOMERPHONE).get(0));

			userDetailsResponse = userDetailsRepository.save(userDetails);

			return userDetailsResponse;
		} else {
			userDetails = userDetailsList.get(0);
		}

		logger.info("End UserDetails()");
		return userDetails;
	}

	public TransactionDetails populateTransactionDetails(MerchantDetails merhantDetails,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails, String merchantReturnURL,
			String merchantOrderId, String orderId, UserDetails userDetails, TransactionDetails transactionDetails)
			throws JsonProcessingException {

		logger.info("Before populateTransactionDetails()");
		// TransactionDetails transactionDetails = new TransactionDetails();
		transactionDetails.setAmount(Integer.parseInt(formData.get(ORDERAMOUNT).get(0)));
		transactionDetails.setMerchantId(merhantDetails.getMerchantID());
		transactionDetails.setOrderID(orderId);
		transactionDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		transactionDetails.setPgType(merchantPGDetails.getMerchantPGName());
		transactionDetails.setStatus("PENDING");
		transactionDetails.setUserID(userDetails.getId());
		transactionDetails.setPgId(merchantPGDetails.getMerchantPGId());
		transactionDetails.setMerchantOrderId(merchantOrderId);
		transactionDetails.setMerchantReturnURL(merchantReturnURL);
		transactionDetails.setCustOrderId(Utility.generateAppId());
		transactionDetails.setSource("RequestPayment");
		transactionDetails.setEmailId(formData.get(CUSTOMEREMAIL).get(0));

		if (formData.get(ALERTURL) != null) {
			transactionDetails.setMerchantAlertURL(formData.get(ALERTURL).get(0));
		}

		if (formData.get(ORDERNOTE) != null) {
			transactionDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		}

		/*
		 * if (transactionDetails.getPaymentOption().equalsIgnoreCase("CARD")) { if
		 * (formData.get(CARD_NUMBER).get(0) != null) { if
		 * (formData.get(CARD_NUMBER).get(0).length() != 0) {
		 * transactionDetails.setCardNumber(SecurityUtils.encryptSaveData(formData.get(
		 * CARD_NUMBER).get(0))); } } }
		 */
		if (transactionDetails.getPaymentOption().equalsIgnoreCase("NB")
				|| transactionDetails.getPaymentOption().equalsIgnoreCase("WALLET")) {
			if (formData.get(PAYMENTCODE).get(0) != null) {
				if (formData.get(PAYMENTCODE).get(0).length() != 0) {
					// transactionDetails.setPaymentCode(SecurityUtils.encryptSaveData(formData.get(PAYMENTCODE).get(0)));
					transactionDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
				}
			}
		} else if (transactionDetails.getPaymentOption().equalsIgnoreCase("UPI")) {
			if (formData.get(UPI_VPI).get(0) != null) {
				if (formData.get(UPI_VPI).get(0).length() != 0) {
					transactionDetails.setVpaUPI(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));
				}
			}
		}

		logger.info("End populateTransactionDetails()");
		logger.info(Utility.convertDTO2JsonString(transactionDetails));

		return transactionDetailsRepository.save(transactionDetails);
	}

	public MultiValueMap<String, String> getDecrypInput(MultiValueMap<String, String> formData)
			throws ValidationExceptions {

		logger.info("Inside Method getDecrypInput()");

		String merchantId = formData.get("merchantId").get(0);
		String encryptedData = formData.get("encryptedData").get(0);

		logger.info("Input merchantId :: " + merchantId);

		MultiValueMap<String, String> response = new LinkedMultiValueMap<>();

		MerchantDetails merchantDetals = merchantDetailsRepository.findByMerchantID(merchantId);
		if (merchantDetals == null) {
			logger.error("Custom Error :: " + MERCHANT_NOT_FOUND);
			throw new ValidationExceptions(MERCHANT_NOT_FOUND, FormValidationExceptionEnums.E0011);
		}
		try {
			// logger.error("encryptedData=====" + encryptedData);
			// logger.error("salt=====" + merchantDetals.getSaltKey());
			// logger.error("secret=====" +
			// Encryption.decryptCardNumberOrExpOrCvv(merchantDetals.getSecretId()));

			String decryptData = SecurityUtils
					.decryptInputData(URLDecoder.decode(encryptedData, "UTF-8"), merchantDetals.getSaltKey(),
							Encryption.decryptCardNumberOrExpOrCvv(merchantDetals.getSecretId()).substring(0, 16))
					.trim();

			String[] arrOfStr = decryptData.split("~");

			for (String str : arrOfStr) {
				String[] insideSplit = str.split("=");
				response.add(insideSplit[0].trim(), insideSplit[1].trim());

			}

		} catch (Exception e) {
			logger.error("Custom Error :: " + DECRYPTION_ERROR);
			throw new ValidationExceptions(DECRYPTION_ERROR, FormValidationExceptionEnums.E0060);
		}

		logger.info("End Method getDecrypInput()");
		return response;
	}

	public Map<String, Object> checkCustomerRequest(String dynamicStr, Model model) throws ValidationExceptions {

		Map<String, Object> objectMap = new LinkedHashMap<String, Object>();

		logger.info(apiEndPoint + "/customerRequest/" + dynamicStr);

		MerchantRequest4Customer merchantRequest4Customer = merchantRequest4CustomerRepository
				.findByLinkCustomer(apiEndPoint + "/customerRequest/" + dynamicStr);
		if (merchantRequest4Customer == null) {
			logger.error("Custom Error :: " + VALIDATION_ERROR_SHORT_LINK_CUST);
			throw new ValidationExceptions(VALIDATION_ERROR_SHORT_LINK_CUST, FormValidationExceptionEnums.E0075);
		}
		Calendar cal = Calendar.getInstance();
		Date dat = cal.getTime();
		logger.info("CURRENT TIME::" + dat.toString());
		logger.info("Link Time::" + merchantRequest4Customer.getLinkExpiryTime().toString());
		if (merchantRequest4Customer.getLinkExpiryTime().before(dat)) {
			logger.info("Link Time Expired TIME::" + merchantRequest4Customer.getLinkExpiryTime().toString());
			throw new ValidationExceptions(LINK_EXPIRED, FormValidationExceptionEnums.E0076);
		}

		TransactionDetails transactionDetails = transactionDetailsRepository.findByMerchantIdAndMerchantOrderId(
				merchantRequest4Customer.getMerchantId(), merchantRequest4Customer.getOrderId());
		if (transactionDetails != null) {
			throw new ValidationExceptions(LINK_ALREADY_USED, FormValidationExceptionEnums.E0086);
		}

		CustomerRequest customerRequest = customerRequestRepository.findByMerchantIdAndOrderId(
				merchantRequest4Customer.getMerchantId(), merchantRequest4Customer.getOrderId());
		if (customerRequest != null) {
			customerRequestRepository.delete(customerRequest);
		}

		logger.info("Inside checkCustomerRequest()");

		model.addAttribute("orderAmount", merchantRequest4Customer.getAmount());
		model.addAttribute("orderCurrency", merchantRequest4Customer.getOrderCurrency());
		model.addAttribute("orderNote", merchantRequest4Customer.getOrderNote());
		model.addAttribute("customerName", merchantRequest4Customer.getCustName());
		model.addAttribute("customerPhone", merchantRequest4Customer.getCustPhone());
		model.addAttribute("customerEmail", merchantRequest4Customer.getCustEmail());
		model.addAttribute("customerid", merchantRequest4Customer.getAppId());
		model.addAttribute("orderId", merchantRequest4Customer.getOrderId());
		model.addAttribute("notifyUrl", merchantRequest4Customer.getReturnUrl());
		model.addAttribute("signature", merchantRequest4Customer.getSignature().trim());

		merchantRequest4Customer.setStatus(UserStatus.INITIATED.toString());
		merchantRequest4CustomerRepository.save(merchantRequest4Customer);
		model.addAttribute("redirectPage", apiEndPoint + "/custreq/");

		objectMap.put("Model", model);
		objectMap.put("Theme", "custrequest/custPayment");

		logger.info("Ended checkCustomerRequest()");

		return objectMap;
	}

	public String pgEstablishmentName(String pgName) {
		String responseStr = null;

		if (pgName.contains("CASHFREE")) {
			responseStr = "CASHFREE";
		} else if (pgName.contains("LETZPAY")) {
			responseStr = "LETZPAY";
		}

		return responseStr;
	}

	public ApiResponse setuWeebhook(String responseFormSetu) {
		logger.info("Inside setu Web Hook Process");
		ApiResponse apiResponse = new ApiResponse();
		ObjectMapper mapper = new ObjectMapper();
		JSONObject jsonObject = new JSONObject(responseFormSetu);
		try {

			Utility.getJsonFileCreate(jsonObject, "Test", setuWebHook);
			apiResponse = new ApiResponse();
			apiResponse.setStatus("SUCCESS");
			apiResponse.setSuccessCode("200");
			apiResponse.setSuccessMsg("Request Has been Captured Success");

			WebhookResponse webhookResponse = mapper.readValue(responseFormSetu, WebhookResponse.class);
			SetuWebhookResponse setuWebhookResponse = new SetuWebhookResponse();
			setuWebhookResponse.setAppId(webhookResponse.getPartnerDetails().getAppId());
			setuWebhookResponse.setBillerBillId(webhookResponse.getEvents().get(0).getData().getBillerBillID());
			setuWebhookResponse
					.setCurrencyCode(webhookResponse.getEvents().get(0).getData().getAmountPaid().getCurrencyCode());
			setuWebhookResponse.setIdSetu(webhookResponse.getEvents().get(0).getId());
			setuWebhookResponse.setPayerVpa(webhookResponse.getEvents().get(0).getData().getPayerVpa());
			setuWebhookResponse.setPlatformBillId(webhookResponse.getEvents().get(0).getData().getPlatformBillID());
			setuWebhookResponse.setProductInstanceId(webhookResponse.getPartnerDetails().getProductInstanceId());
			setuWebhookResponse.setStatus(webhookResponse.getEvents().get(0).getData().getStatus());
			setuWebhookResponse.setTimeStamp(String.valueOf(webhookResponse.getEvents().get(0).getTimeStamp()));
			setuWebhookResponse.setTransactionId(webhookResponse.getEvents().get(0).getData().getTransactionId());
			setuWebhookResponse.setType(webhookResponse.getEvents().get(0).getType());
			setuWebhookResponse
					.setValue(String.valueOf(webhookResponse.getEvents().get(0).getData().getAmountPaid().getValue()));
			setuWebhookResponseRepository.save(setuWebhookResponse);

		} catch (Exception e) {
			e.printStackTrace();

			apiResponse = new ApiResponse();
			apiResponse.setStatus("FAILURE");
			apiResponse.setErrorCode("100");
			apiResponse.setErrorMsg("Getting parsing error , Please check with Administrator ");
		}
		return apiResponse;
	}

	public TransactionDetails getSetutransactionDetails(String orderId) {

		return transactionDetailsRepository.findByOrderID(orderId);
	}

}
