package com.asktech.payment.service.webhook;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.grezpay.GrezPayContants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.model.AsanPayTransactionDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.repository.AsanPayTransactionDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.asanpay.AsanPayPaymentUtility;

@Service
public class WebhookServiceAsanpay implements CashFreeFields, GrezPayContants {
	
	static Logger logger = LoggerFactory.getLogger(WebhookServiceAsanpay.class);
	
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	AsanPayTransactionDetailsRepository asanPayTransactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	AsanPayPaymentUtility asanPayPaymentUtility;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;

	public String updateWebhookAsanPay(MultiValueMap<String, String> responseFormData) {
		
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDER_ID));
		
		AsanPayTransactionDetails asanPayTransactionDetails = asanPayTransactionDetailsRepository
				.findByOrderId(transactionDetails.getOrderID());
		if(transactionDetails != null) {
			
			if(asanPayTransactionDetails != null ) {
				
				transactionDetails.setStatus(
						asanPayPaymentUtility.checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE),
								pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));
				transactionDetails.setSource("WebHook");
				
				asanPayTransactionDetails.setTxStatus(asanPayPaymentUtility.checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE),
								pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));
				asanPayTransactionDetails.setSource("WebHook");
				
				transactionDetailsRepository.save(transactionDetails);
				asanPayTransactionDetailsRepository.save(asanPayTransactionDetails);
				
				try {
                    notiFyURLService2Merchant.populateReturnDetails(transactionDetails);
                } catch (Exception e) {
                    logger.error("Exception in notify to merchant :: " + e.toString());
                }
			}
		}
		
		return "Request has been received successfully. Thanks";
		
	}
}
