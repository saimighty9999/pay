package com.asktech.payment.service;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.config.CashfreeConfig;
import com.asktech.payment.constant.ErrorValues;
import com.asktech.payment.constant.Fields;
import com.asktech.payment.constant.Keys;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.enums.FormValidationExceptionEnums;
import com.asktech.payment.exception.SessionExpiredException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.BankList;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGServices;
import com.asktech.payment.model.seam.CustomerRequest;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.MerchantPGServicesRepository;
import com.asktech.payment.repository.WalletListRepository;
import com.asktech.payment.repository.customeinterface.IBankList;
import com.asktech.payment.repository.customeinterface.IWalletList;
import com.asktech.payment.repository.seam.CustomerRequestRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.util.EncryptSignature;
import com.asktech.payment.util.FormValidationsCashFree;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.asktech.payment.util.Validator;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class PGNonSeamLessService implements ErrorValues, CashFreeFields, Fields {
	long EXPIRATION_TIME = 60 * 24;

	int totalyears = 10;

	@Value("${idealSessionTimeOut}")
	long IDEAL_EXPIRATION_TIME;

	@Value("${pgEndPoints.nonSeamSubmitUrl}")
	String submitUrl;

	@Autowired
	CustomerRequestRepository customerRequestRepository;

	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;

	@Autowired
	BankListRepository bankList;

	@Autowired
	WalletListRepository walletrepo;

	@Autowired
	PGGatewayService pGGatewayServiceCashFree;

	@Autowired
	WalletListRepository walletListRepository;

	@Autowired
	MerchantPGServicesRepository merchantPGServicesRepository;

	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	PGGatewayUtilService pGGatewayUtilService;

	static Logger logger = LoggerFactory.getLogger(PGNonSeamLessService.class);

	public String getRequestProcess(MultiValueMap<String, String> formData, Model model, String useragent,
			String ipaddress) throws ValidationExceptions, JsonProcessingException {
		String sessionToken = "";
		logger.info("Input Data from Customer::" + GeneralUtils.MultiValueMaptoJson(formData));
		if (FormValidationsCashFree.FormFieldValidation(formData)) {
			logger.info("--Form Validation complete--");
			String useruuid = UUID.randomUUID().toString();
			String userName = formData.get(Fields.CUSTOMERNAME).get(0);
			String userPhone = formData.get(Fields.CUSTOMERPHONE).get(0);
			String userEmail = formData.get(Fields.CUSTOMEREMAIL).get(0);
			String amount = formData.get(Fields.ORDERAMOUNT).get(0);

			String returnUrl = formData.get(Fields.NOTIFYURL).get(0);
			String orderId = formData.get(Fields.ORDERID).get(0);
			String customerId = formData.get(Fields.CUSTOMERID).get(0);
			String orderCurrency = formData.get(Fields.ORDERCURRENCY).get(0);
			String orderNote = "";
			String alerturl = "";
			CustomerRequest customerRequest = new CustomerRequest();
			customerRequest.setUuid(useruuid);
			customerRequest.setUserName(userName);
			customerRequest.setUserPhone(userPhone);
			customerRequest.setUserEmail(userEmail);
			customerRequest.setAmount(amount);
			customerRequest.setReturnUrl(returnUrl);
			customerRequest.setOrderId(orderId);
			customerRequest.setCustomerId(customerId);
			customerRequest.setOrderCurrency(orderCurrency);
			customerRequest.setIpaddress(ipaddress);
			customerRequest.setStatus("PAGE_OPENED");
			customerRequest.setMessage("Waiting to select Option");
			customerRequest.setDevicetype(useragent);

			if (formData.containsKey(Fields.ORDERNOTE)) {
				orderNote = formData.get(Fields.ORDERNOTE).get(0);
			}
			if (formData.containsKey(Fields.ALERTURL)) {
				alerturl = formData.get(Fields.ALERTURL).get(0);
			}
			customerRequest.setOrderNote(orderNote);
			customerRequest.setAlertUrl(alerturl);

			if (!Validator.isValidName(userName)) {
				customerRequest.setStatus("PAGE_OPENED");
				customerRequest.setMessage("Invalid userName");
				updateData(customerRequest);
				throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
			}

			if (!Validator.isValidPhoneNumber(userPhone)) {
				customerRequest.setStatus("PAGE_OPENED");
				customerRequest.setMessage("Invalid Phone Number");
				updateData(customerRequest);
				throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
			}
			if (!Validator.isValidEmail(userEmail)) {
				customerRequest.setStatus("PAGE_OPENED");
				customerRequest.setMessage("Invalid Email");
				updateData(customerRequest);
				throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
			}
			if (!Validator.isNumeric(amount)) {
				customerRequest.setStatus("PAGE_OPENED");
				customerRequest.setMessage("Invalid Amount");
				updateData(customerRequest);
				throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
			}
			if (!orderCurrency.trim().equals("INR")) {
				customerRequest.setStatus("PAGE_OPENED");
				customerRequest.setMessage("Invalid Currency");
				updateData(customerRequest);
				throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
			}
			String sessionStatus = "Valid";

			sessionToken = Encryption.getSHA256Hash(
					useruuid + "|" + userName + "|" + userPhone + "|" + userEmail + "|" + amount.toString());
			ZonedDateTime expirationTime = ZonedDateTime.now(ZoneOffset.UTC).plus(EXPIRATION_TIME, ChronoUnit.MINUTES);
			Date sessionExpiryDate = Date.from(expirationTime.toInstant());

			ZonedDateTime idealExpirationTime = ZonedDateTime.now(ZoneOffset.UTC).plus(IDEAL_EXPIRATION_TIME,
					ChronoUnit.MINUTES);
			Date idealSessionExpiry = Date.from(idealExpirationTime.toInstant());
			customerRequest.setSessionStatus(sessionStatus);
			customerRequest.setSessionExpiryDate(sessionExpiryDate);
			customerRequest.setIdealSessionExpiry(idealSessionExpiry);
			customerRequest.setSessionToken(sessionToken);

			if (userName.isEmpty()) {
				logger.info("Invalid userName");
				customerRequest.setStatus("PAGE_OPENED");
				customerRequest.setMessage("Invalid userName");
				try {
					customerRequestRepository.save(customerRequest);
				} catch (Exception e) {
					if (e.getMessage().contains("ConstraintViolationException")) {
						logger.info(e.getMessage());
						throw new ValidationExceptions(DUPLICATE_ORDERID, FormValidationExceptionEnums.E0051);
					} else {
						logger.info(e.getMessage());
					}
				}
				throw new ValidationExceptions("Invalid" + Fields.CUSTOMERNAME, FormValidationExceptionEnums.E0058);
			}
			MerchantDetails merhantDetails = getMerchantFromAppId(formData.get(CUSTOMERID).get(0), model);
			logger.info("Merchant Details::" + Utility.convertDTO2JsonString(merhantDetails));
			customerRequest.setMerchantId(merhantDetails.getMerchantID());
			// System.out.println("SECRET++"+Encryption.decryptCardNumberOrExpOrCvv(merhantDetails.getSecretId()));
			if (!FormValidationsCashFree.isVerifySignature(formData,
					Encryption.decryptCardNumberOrExpOrCvv(merhantDetails.getSecretId()))) {
				logger.info("Invalid Signatures");
				customerRequest.setStatus("PAGE_OPENED");
				customerRequest.setMessage("Invalid Signatures");
				try {
					customerRequestRepository.save(customerRequest);
				} catch (Exception e) {
					if (e.getMessage().contains("ConstraintViolationException")) {
						logger.info(e.getMessage());
						throw new ValidationExceptions(DUPLICATE_ORDERID, FormValidationExceptionEnums.E0051);
					} else {
						logger.info(e.getMessage());
					}
				}
				throw new ValidationExceptions(SIGNATURE_MISMATCH, FormValidationExceptionEnums.E0008);
			}

			try {
				customerRequestRepository.save(customerRequest);
			} catch (Exception e) {
				if (e.getMessage().contains("ConstraintViolationException")) {
					logger.info(e.getMessage());
					throw new ValidationExceptions(DUPLICATE_ORDERID, FormValidationExceptionEnums.E0051);
				} else {
					logger.info(e.getMessage());
				}
			}
			List<MerchantPGServices> merchantpgservices = merchantPGServicesRepository
					.findAllByMerchantIDAndStatus(merhantDetails.getMerchantID(), "ACTIVE");

			List<String> services = new ArrayList<String>();
			for (MerchantPGServices pgservices : merchantpgservices) {
				services.add(pgservices.getService());
			}

			/*
			 * for (MerchantPGServices pgservices : merchantpgservices) {
			 * services.add(pgservices.getService()); if
			 * (pgservices.getService().contains("UPI")) { model.addAttribute("setu", true);
			 * List<MerchantPGDetails> pgdetails = merchantPGDetailsRepository
			 * .findByMerchantPGId(merchantpgservices.get(0).getPgID()); for
			 * (MerchantPGDetails pgdetail : pgdetails) { if
			 * (pgdetail.getMerchantPGName().contains("SETU")) { model.addAttribute("setu",
			 * false); } } } }
			 */
			String serviceSelected = "";
			if (services.contains("NB")) {
				serviceSelected = "NB";
				List<IBankList> bankdetails = new ArrayList<IBankList>();
				try {
					bankdetails = bankList.findMerchantBankList(merhantDetails.getMerchantID());
				} catch (Exception e) {
					e.printStackTrace();
					logger.info("Invalid Merchant ID for Bank Code List" + e.getMessage());
					customerRequest.setStatus("PAGE_OPENED");
					customerRequest.setMessage("Invalid Merchant ID for Bank Code List");
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				model.addAttribute("banklist", bankdetails);
				model.addAttribute("nbactive", true);
				if (formData.containsKey(Fields.NBACTIVE)) {
					if (formData.getFirst(Fields.NBACTIVE).equalsIgnoreCase("false")) {
						model.addAttribute("nbactive", false);
					}
				}

			}
			if (services.contains("WALLET")) {
				serviceSelected = "WALLET";
				try {
					logger.info("Merchant ID:" + merhantDetails.getMerchantID());
					List<IWalletList> WalletList = walletrepo.findMerchantWalletList(merhantDetails.getMerchantID());
					logger.info((Utility.convertDTO2JsonString((WalletList))));
					model.addAttribute("walletlist", WalletList);
					model.addAttribute("walletactive", true);
					if (formData.containsKey(Fields.WALLETACTIVE)) {
						if (formData.getFirst(Fields.WALLETACTIVE).equalsIgnoreCase("false")) {
							model.addAttribute("walletactive", false);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.info("Invalid Merchant ID for Wallet Code List" + e.getMessage());
					customerRequest.setStatus("PAGE_OPENED");
					customerRequest.setMessage("Invalid Merchant ID for Wallet Code List");
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
			}
			if (services.contains("CARD")) {
				serviceSelected = "CARD";
				int year = Calendar.getInstance().get(Calendar.YEAR);

				ArrayList<String> yearlist = new ArrayList<String>();

				for (int i = 0; i <= totalyears; i++) {
					String ayear = String.valueOf(year);
					yearlist.add(ayear);
					year = year + 1;
				}
				model.addAttribute("yearlist", yearlist);
				model.addAttribute("cardactive", true);
				if (formData.containsKey(Fields.CARDACTIVE)) {
					if (formData.getFirst(Fields.CARDACTIVE).equalsIgnoreCase("false")) {
						model.addAttribute("cardactive", false);
					}
				}
			}
			if (services.contains("UPI")) {
				serviceSelected = "UPI";
				model.addAttribute("upiactive", true);
				model.addAttribute("upiactiveinput", true);
				if (formData.containsKey(Fields.UPIACTIVE)) {
					if (formData.getFirst(Fields.UPIACTIVE).equalsIgnoreCase("false")) {
						model.addAttribute("upiactive", false);
						model.addAttribute("upiactiveinput", false);
					}
				}
			}
			if (services.contains("UPI_QR")) {
				serviceSelected = "UPI_QR";
				model.addAttribute("upiactive", true);
				model.addAttribute("upiqractive", true);
				if (formData.containsKey(Fields.UPIQRACTIVE)) {
					if (formData.getFirst(Fields.UPIQRACTIVE).equalsIgnoreCase("false")) {
						model.addAttribute("upiqractive", false);
						if (formData.containsKey(Fields.UPIACTIVE)) {
							if (formData.getFirst(Fields.UPIACTIVE).equalsIgnoreCase("false")) {
								model.addAttribute("upiactive", false);
							}
						}
					}
				}
			}

			String key = CashfreeConfig.publickey;
			model.addAttribute("pubkey", key);
			model.addAttribute("amount", orderCurrency + " " + formData.get(Fields.ORDERAMOUNT).get(0));
			model.addAttribute("name", formData.get(CUSTOMERNAME).get(0));
			model.addAttribute("submitUrl", submitUrl);
			String gateWayLink = pGGatewayUtilService
					.getPgDetailsByAppId(formData.get(CUSTOMERID).get(0), serviceSelected).getPgMerchantLink();
			if (gateWayLink != null) {
				String lastPage = submitUrl.substring(submitUrl.lastIndexOf('/') + 1);
				logger.info("Routing To::" + gateWayLink + "/" + lastPage);
				model.addAttribute("submitUrl", gateWayLink + "/" + lastPage);
			}

		}
		return sessionToken;
	}

	public String getSubmitPayment(MultiValueMap<String, String> formData, Model model, String sessionToken,
			String device, String ipAddress)
			throws SessionExpiredException, ValidationExceptions, InvalidKeyException, NoSuchAlgorithmException,
			ParseException, IOException {
		logger.info("getSubmit Init");
		CustomerRequest customerRequest = customerRequestRepository.findAllBySessionToken(sessionToken);
		logger.info("OrderID = " + customerRequest.getOrderId());
		try {
			logger.info("Check Session");
			checkSession(customerRequest);
		} catch (Exception e) {
			customerRequest.setMessage(e.getMessage());
			customerRequest.setStatus(DATA_INVALID);
			logger.info(DATA_INVALID + ":Session Exception");
			customerRequestRepository.save(customerRequest);
			throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
		}
		logger.info("getSubmit");
		String dt = "";

		customerRequest.setFormRequest(GeneralUtils.MultiValueMaptoJson(formData));
		customerRequest.setStatus("PAYMENT_SUBMITTED");
		// customerRequest.setMerchantId(customerRequest.getMerchantId());
		try {
			dt = SecurityUtils.decryptRSABase64(formData.get("data").get(0), Keys.privatekey);
			logger.info("Decrypted Data:"+dt);
		} catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException | NoSuchAlgorithmException
				| NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			customerRequest.setMessage(e.getMessage());
			customerRequest.setStatus(DATA_INVALID);
			customerRequestRepository.save(customerRequest);
			throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);

		}

		customerRequest.setFormRequest(dt);
		String[] details = dt.split(Pattern.quote("|"));
		MultiValueMap<String, String> formFinalData = new LinkedMultiValueMap<String, String>();
		formFinalData.add(CashFreeFields.APPID, customerRequest.getCustomerId());
		logger.info(customerRequest.getCustomerId());

		// Conversion to Paisa
		logger.info("Convert to paisa:" + customerRequest.getAmount());
		int amt = (int) (Double.valueOf(customerRequest.getAmount()) * 100);
		logger.info("AMT:" + String.valueOf(amt));

		formFinalData.add(CashFreeFields.CUSOMERNAME, customerRequest.getUserName());
		formFinalData.add(CashFreeFields.CUSTOMEREMAIL, customerRequest.getUserEmail());
		formFinalData.add(CashFreeFields.CUSTOMERPHONE, customerRequest.getUserPhone());
		formFinalData.add(CashFreeFields.ORDERAMOUNT, String.valueOf(amt));
		formFinalData.add(CashFreeFields.RETURNURL, customerRequest.getReturnUrl());
		formFinalData.add(CashFreeFields.ORDERID, customerRequest.getOrderId());
		formFinalData.add(CashFreeFields.ORDERCURRENCY, customerRequest.getOrderCurrency());
		formFinalData.add(CashFreeFields.ORDERNOTE, customerRequest.getOrderNote());
		formFinalData.add(CashFreeFields.PAYMENT_OPTION, details[0]);
		if (customerRequest.getAlertUrl().length() > 2) {
			formFinalData.add(CashFreeFields.ALERTURL, customerRequest.getAlertUrl());
		}
		logger.info("getSubmit:: Form Submit");

		switch (details[0]) {
			case "nb":
				if (!Validator.isValidCardUserName(details[1])) {
					logger.info("Invalid Nb Name");
					customerRequest.setMessage("Invalid Nb Name");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				logger.info("Payment Code::" + details[2]);
				if (!Validator.isNumeric(details[2])) {
					logger.info("BankCode is not Number");
					customerRequest.setMessage("BankCode is not Number");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if (details[2].length() != 4) {
					logger.info("BankCode is not of valid length");
					customerRequest.setMessage("BankCode is not of valid length");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				List<BankList> banklist = bankList.findAllByBankcode(details[2]);
				if (banklist.isEmpty()) {
					logger.info("Invalid Bank Code");
					customerRequest.setMessage("Invalid Bank Code");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if (banklist.get(0) == null) {
					logger.info("No Bank Code available");
					customerRequest.setMessage("No Bank Code available");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				formFinalData.add(CashFreeFields.PAYMENTCODE, details[2]);
				banklist = null;
				logger.info("getSubmit:: Form Add NB");
				break;

			case "card":
				String cardno = details[2];
				String cardname = details[1];
				String year = details[3];
				String month = details[4];
				String cvv = details[5];

				if (!Validator.isValidCardUserName(cardname)) {
					logger.info("Invalid Card Name");
					customerRequest.setMessage("Invalid Card Name");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if (Validator.isValidateIdNumber(cardno, "CARD") != 1) {
					logger.info("Invalid Card Number");
					customerRequest.setMessage("Invalid Card Number");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if (!Validator.isNumeric(year)) {
					logger.info("Year is not Number");
					customerRequest.setMessage("Year is not Number");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if (year.length() != 4) {
					logger.info("Year is not of valid length");
					customerRequest.setMessage("Year is not of valid length");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if (!Validator.isNumeric(month)) {
					logger.info("Month is not Number");
					customerRequest.setMessage("Month is not Number");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if ((Integer.parseInt(month) > 12) || (Integer.parseInt(month) < 1)) {
					logger.info("Month is not of valid length");
					customerRequest.setMessage("Month is not of valid length");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if (!Validator.isNumeric(cvv)) {
					logger.info("CVV is not Number");
					customerRequest.setMessage("CVV is not Number");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if (cvv.length() != 3) {
					logger.info("cvv is not of valid length");
					customerRequest.setMessage("cvv is not of valid length");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if (month.length() == 1) {
					month = "0" + month;
				}
				formFinalData.add(CashFreeFields.CARD_HOLDER, cardname);
				formFinalData.add(CashFreeFields.CARD_NUMBER, cardno);
				formFinalData.add(CashFreeFields.CARD_EXPYEAR, year);
				formFinalData.add(CashFreeFields.CARD_EXPMONTH, month);
				formFinalData.add(CashFreeFields.CARD_CVV, cvv);
				logger.info("getSubmit:: Form Add CARD");
				break;
			case "upi":
				String upivpa = details[1];
				if (Validator.isValidateIdNumber(upivpa, "UPI") != 1) {
					logger.info("Invalid UPI Number");
					customerRequest.setMessage("Invalid UPI Number");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}

				formFinalData.add(CashFreeFields.UPI_VPI, upivpa);
				logger.info("getSubmit:: Form Add UPI" + upivpa);
				break;
			case "upi_qr":
				logger.info("getSubmit:: Form Run UPI QR");
				break;
			case "wallet":
				String wallet = details[1];
				if (!Validator.isNumeric(details[1])) {
					logger.info("WalletCode is not Number");
					customerRequest.setMessage("WalletCode is not Number");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				if (details[1].length() != 4) {
					logger.info("WalletCode is not of valid length");
					customerRequest.setMessage("WalletCode is not of valid length");
					customerRequest.setStatus(DATA_INVALID);
					customerRequestRepository.save(customerRequest);
					throw new ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057);
				}
				/*
				 * WalletList pglist =
				 * walletListRepository.findMerchantWallet(customerRequest.getCustomerId(),
				 * UserStatus.ACTIVE.toString(), wallet);
				 * logger.info(Utility.convertDTO2JsonString(pglist)); String walletpgcode =
				 * pglist.getPaymentcode(); // logger.info("WALLET:" + walletpgcode +
				 * "|walletui:" + wallet); if ((walletpgcode == null) || (walletpgcode.length()
				 * < 4)) { logger.info("No Wallet Code available"); throw new
				 * ValidationExceptions(DATA_INVALID, FormValidationExceptionEnums.E0057); }
				 */
				formFinalData.add(CashFreeFields.PAYMENTCODE, wallet);
				logger.info("getSubmit:: Form Add WALLET");
				break;
			default:
				logger.info("getSubmit:: Form Invalid");
				customerRequest.setMessage("Form Invalid");
				customerRequest.setStatus(UNKNOWN_OPTION);
				customerRequestRepository.save(customerRequest);
				throw new ValidationExceptions(UNKNOWN_OPTION, FormValidationExceptionEnums.E0053);
		}
		MerchantDetails merhantDetails = getMerchantFromAppId(customerRequest.getCustomerId(), model);
		Map<String, String> m = GeneralUtils.convertMultiToRegularMap(formFinalData);
		logger.info("Merchant Details...");
		System.out.println(m);
		String signature = EncryptSignature
				.encryptSignature(Encryption.decryptCardNumberOrExpOrCvv(merhantDetails.getSecretId()), m);
		formFinalData.add(CashFreeFields.SIGNATURE, signature);
		logger.info(customerRequest.getOrderId());
		customerRequest.setFormFinal(GeneralUtils.MultiValueMaptoJson(formFinalData));
		updateSession(customerRequest);
		logger.info("Sending Request...");
		return (String) pGGatewayServiceCashFree.getRequestProcessAll(formFinalData, model, device, ipAddress)
				.get("Theme");
	}

	public MerchantDetails getMerchantFromAppId(String appId, Model model)
			throws JsonProcessingException, ValidationExceptions {

		MerchantDetails merhantDetails = merchantDetailsRepository
				.findByAppID(appId);
		logger.info("Merchant Detals :: " + Utility.convertDTO2JsonString(merhantDetails));

		if (merhantDetails == null) {
			model.addAttribute("errormsg", MERCHANT_NOT_FOUND);
			throw new ValidationExceptions(MERCHANT_NOT_FOUND + appId, FormValidationExceptionEnums.E0011);
		}

		return merhantDetails;
	}

	private void checkSession(CustomerRequest customerRequest) throws SessionExpiredException {
		Calendar cal = Calendar.getInstance();
		Date dat = cal.getTime();
		if (customerRequest.getSessionExpiryDate().before(dat)) {
			throw new SessionExpiredException("Session Expired", FormValidationExceptionEnums.E0024);
		}
		if (customerRequest.getIdealSessionExpiry().before(dat)) {
			throw new SessionExpiredException("Session Expired", FormValidationExceptionEnums.E0025);
		}
	}

	private void updateSession(CustomerRequest customerRequest) {
		ZonedDateTime idealExpirationTime = ZonedDateTime.now(ZoneOffset.UTC).plus(IDEAL_EXPIRATION_TIME,
				ChronoUnit.MINUTES);
		Date idealDate = Date.from(idealExpirationTime.toInstant());
		customerRequest.setIdealSessionExpiry(idealDate);
		customerRequestRepository.save(customerRequest);

	}

	private void updateData(CustomerRequest customerRequest) throws ValidationExceptions {
		logger.info("Save Msg " + customerRequest.getMessage());
		try {
			customerRequestRepository.save(customerRequest);
		} catch (Exception e) {
			if (e.getMessage().contains("ConstraintViolationException")) {
				logger.info(e.getMessage());
				throw new ValidationExceptions(DUPLICATE_ORDERID, FormValidationExceptionEnums.E0051);
			} else {
				logger.info(e.getMessage());
			}
		}
	}

}