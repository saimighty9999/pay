package com.asktech.payment.service;

import java.io.UnsupportedEncodingException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.thymeleaf.util.StringUtils;

import com.asktech.payment.constant.ErrorValues;
import com.asktech.payment.constant.ReturnMerchantAttributes;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.email.CustomerEmail;
import com.asktech.payment.dto.email.MerchantEmail;
import com.asktech.payment.dto.setu.SetuErrorResponse;
import com.asktech.payment.dto.utility.SignatureRequestAll;
import com.asktech.payment.dto.utilityServices.CardBinDetails;
import com.asktech.payment.dto.utilityServices.CardBinResponse;
import com.asktech.payment.enums.FormValidationExceptionEnums;
import com.asktech.payment.enums.PGServices;
import com.asktech.payment.enums.UserStatus;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.CustomerInputDetails;
import com.asktech.payment.model.InputFromPgTransactionUpdate;
import com.asktech.payment.model.MailDetails;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.model.MerchantPGDetails;
import com.asktech.payment.model.MerchantRequest4Customer;
import com.asktech.payment.model.NBPaymentDetails;
import com.asktech.payment.model.PGConfigurationDetails;
import com.asktech.payment.model.ResponstToMerchantDetails;
import com.asktech.payment.model.SMSDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.model.UPIPaymentDetails;
import com.asktech.payment.model.UserDetails;
import com.asktech.payment.model.WalletPaymentDetails;
import com.asktech.payment.repository.CustomerInputDetailsRepository;
import com.asktech.payment.repository.InputFromPgTransactionUpdateRepository;
import com.asktech.payment.repository.MailDetailsRepository;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.repository.MerchantPGDetailsRepository;
import com.asktech.payment.repository.MerchantRequest4CustomerRepository;
import com.asktech.payment.repository.NBPaymentDetailsRepository;
import com.asktech.payment.repository.PGConfigurationDetailsRepository;
import com.asktech.payment.repository.ResponstToMerchantDetailsRepository;
import com.asktech.payment.repository.SMSDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.repository.UPIPaymentDetailsRepository;
import com.asktech.payment.repository.UserDetailsRepository;
import com.asktech.payment.repository.WalletPaymentDetailsRepository;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.util.EncryptSignature;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.SecurityUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Service
public class PGGatewayUtilService implements ErrorValues, ReturnMerchantAttributes, CashFreeFields {

	static Logger logger = LoggerFactory.getLogger(PGGatewayUtilService.class);

	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	MailDetailsRepository mailDetailsRepository;
	@Autowired
	SMSDetailsRepository smsDetailsRepository;
	@Autowired
	InputFromPgTransactionUpdateRepository inputFromPgTransactionUpdateRepository;
	@Autowired
	ResponstToMerchantDetailsRepository responstToMerchantDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;
	@Autowired
	UserDetailsRepository userDetailsRepository;
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;

	@Autowired
	UPIPaymentDetailsRepository upiPaymentDetailsRepository;
	// @Autowired
	// CardPaymentDetailsRepository cardPaymentDetailsRepository;
	@Autowired
	NBPaymentDetailsRepository nBPaymentDetailsRepository;
	@Autowired
	WalletPaymentDetailsRepository walletPaymentDetailsRepository;
	@Autowired
	MerchantRequest4CustomerRepository merchantRequest4CustomerRepository;
	@Autowired
	CustomerInputDetailsRepository customerInputDetailsRepository;

	@Value("${smsSenderId}")
	String smsSenderId;
	@Value("${mailSenderId}")
	String mailSenderId;
	@Value("${smsTextFormat.customerTRSMS}")
	String customerSMS;
	@Value("${utilityService.neutrinoapiUserId}")
	String neutrinoapiUserId;
	@Value("${utilityService.neutrinoapiKey}")
	String neutrinoapiKey;
	@Value("${utilityService.neutrinoEndPoint}")
	String neutrinoEndPoint;

	@Value("${utilityService.cardDeterminator}")
	String cardDeterminator;

	public String populateReturnSignature(String status, String paymentOption, String merchantOrderId,
			String orderAmount, String verdorOrderId, String txtDate, String merchantId, String errorCode,
			String errorDetails,
			String custName, String custEmail, String custMobile, String cardNumber, String upiVpa,
			String bankCode, String walletCode)
			throws InvalidKeyException, NoSuchAlgorithmException {

		logger.info("Inside Method populateReturnSignature()");
		Map<String, String> objectMap = new LinkedHashMap<String, String>();

		objectMap.put(SIG_STATUS, status);
		objectMap.put(SIG_PAYMENTOPTION, paymentOption);
		objectMap.put(SIG_MERCHANTORDERID, merchantOrderId);
		objectMap.put(SIG_ORDERAMOUNT, orderAmount);
		objectMap.put(SIG_VENDORORDERID, verdorOrderId);
		objectMap.put(SIG_TXTDATE, txtDate);
		objectMap.put(SIG_ERRORCODE, errorCode);
		objectMap.put(SIG_ERRORDETAILS, errorDetails);
		objectMap.put(SIG_CUSTNAME, custName);
		objectMap.put(SIG_CUSTEMAIL, custEmail);
		objectMap.put(SIG_CUSTPHONE, custMobile);
		objectMap.put(SIG_CARD_NUMBER, cardNumber);
		objectMap.put(SIG_UPI_ID, upiVpa);
		objectMap.put(SIG_BANK_CODE, bankCode);
		objectMap.put(SIG_WALLET_CODE, walletCode);

		MerchantDetails merchantDetails = merchantDetailsRepository.findByMerchantID(merchantId);

		logger.info("End Method populateReturnSignature()");

		return EncryptSignature.encryptSignature(Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getSecretId()),
				objectMap);
	}

	public String populateInterSignature(String venderOrderId, String status, String merchantId)
			throws InvalidKeyException, NoSuchAlgorithmException {

		logger.info("Inside Method populateReturnSignature()");
		Map<String, String> objectMap = new LinkedHashMap<String, String>();

		objectMap.put(SIG_STATUS, status);
		objectMap.put("vendorOrderId", venderOrderId);
		objectMap.put("merchantId", merchantId);

		MerchantDetails merchantDetails = merchantDetailsRepository.findByMerchantID(merchantId);

		logger.info("End Method populateReturnSignature()");

		return EncryptSignature.encryptSignature(Encryption.decryptCardNumberOrExpOrCvv(merchantDetails.getSecretId()),
				objectMap);
	}

	public MerchantDetails getMerchantFromAppId(String appId, String returnURL, MultiValueMap<String, String> formData)
			throws JsonProcessingException, ValidationExceptions {

		logger.info("Inside getMerchantFromAppId() method App Id :: " + appId);
		logger.info("Inside getMerchantFromAppId() method App Id :: " + Encryption.encryptCardNumberOrExpOrCvv(appId));

		MerchantDetails merhantDetails = merchantDetailsRepository.findByAppID(appId);
		logger.info("Merchant Detals :: " + Utility.convertDTO2JsonString(merhantDetails));

		if (merhantDetails == null) {
			logger.error("Custom Exception :: " + MERCHANT_NOT_FOUND);
			throw new ValidationExceptions(MERCHANT_NOT_FOUND + appId, FormValidationExceptionEnums.E0011, returnURL,
					formData);
		}

		if (StringUtils.isEmpty(merhantDetails.getUserStatus())) {
			logger.error("Custom Exception :: " + MERCHANT_NOT_ACTIVE);
			throw new ValidationExceptions(MERCHANT_NOT_ACTIVE + appId, FormValidationExceptionEnums.E0080, returnURL,
					formData);
		}

		// if(!merhantDetails.getUserStatus().equalsIgnoreCase("ACTIVE") ) {
		// logger.error("Custom Exception :: " + MERCHANT_NOT_ACTIVE);
		// throw new ValidationExceptions(MERCHANT_NOT_ACTIVE + appId,
		// FormValidationExceptionEnums.E0080,returnURL,formData);
		// }

		logger.info("End getMerchantFromAppId() method");

		return merhantDetails;
	}

	public MerchantDetails getMerchantFromAppId(String appId, MultiValueMap<String, String> formData)
			throws JsonProcessingException, ValidationExceptions {

		logger.info("Inside getMerchantFromAppId() method App Id :: " + appId);
		logger.info("Inside getMerchantFromAppId() method App Id :: " + Encryption.encryptCardNumberOrExpOrCvv(appId));

		MerchantDetails merhantDetails = merchantDetailsRepository.findByAppID(appId);
		logger.info("Merchant Detals :: " + Utility.convertDTO2JsonString(merhantDetails));

		return merhantDetails;
	}

	public String createMerchantEmail(UserDetails userDetails, TransactionDetails transactionDetails,
			MerchantDetails merchantDetails) throws JsonProcessingException {

		logger.info("Inside createMerchantEmail() method ");
		MerchantEmail merchantEmail = new MerchantEmail();
		merchantEmail.setAmount(String.valueOf(transactionDetails.getAmount()));
		merchantEmail.setCustEmail(userDetails.getEmailId());
		merchantEmail.setCustName(userDetails.getCustomerName());
		merchantEmail.setCustPhone(userDetails.getPhoneNumber());
		merchantEmail.setMerchantId(transactionDetails.getMerchantId());
		merchantEmail.setMerchantName(merchantDetails.getMerchantName());
		merchantEmail.setOrderId(transactionDetails.getOrderID());
		merchantEmail.setPaymentModel(transactionDetails.getPaymentMode());
		merchantEmail.setTransactionId(transactionDetails.getCustOrderId());
		merchantEmail.setTransactionTime(transactionDetails.getTxtPGTime());
		logger.info("End createMerchantEmail() method ");
		return Utility.convertDTO2JsonString(merchantEmail);
	}

	public void createMailRepo(String mailString, String sendTo, String opsType) {

		logger.info("Inside createMailRepo() method ");
		MailDetails mailDetails = new MailDetails();
		mailDetails.setMailSubject("Transaction Email from paymentz.com");
		mailDetails.setMailText(mailString);
		mailDetails.setRecipientId(sendTo);
		mailDetails.setSenderId(mailSenderId);
		mailDetails.setStatus(UserStatus.PENDING.toString());
		mailDetails.setOpsType(opsType);
		logger.info("End createMailRepo() method ");

		mailDetailsRepository.save(mailDetails);
	}

	public String createCustomerEmail(UserDetails userDetails, TransactionDetails transactionDetails)
			throws JsonProcessingException {

		logger.info("Inside createCustomerEmail() method ");
		CustomerEmail customerEmail = new CustomerEmail();
		customerEmail.setAmount(String.valueOf(transactionDetails.getAmount()));
		customerEmail.setCustEmail(userDetails.getEmailId());
		customerEmail.setCustName(userDetails.getCustomerName());
		customerEmail.setCustPhone(userDetails.getPhoneNumber());
		customerEmail.setOrderId(transactionDetails.getOrderID());
		customerEmail.setPaymentStatus(transactionDetails.getStatus());
		customerEmail.setPaymentModel(transactionDetails.getPaymentMode());
		customerEmail.setTransactionId(transactionDetails.getCustOrderId());
		customerEmail.setTransactionTime(transactionDetails.getTxtPGTime());
		logger.info("Ended createCustomerEmail() method ");

		return Utility.convertDTO2JsonString(customerEmail);
	}

	public void sendSMS(UserDetails userDetails, TransactionDetails transactionDetails) {

		logger.info("Inside sendSMS() method ");
		SMSDetails smsDetails = new SMSDetails();

		smsDetails.setSenderNo(userDetails.getPhoneNumber());
		smsDetails.setSmsCLI(smsSenderId);
		smsDetails.setSmsText(customerSMS.replace("{CUSTOMERNAME}", userDetails.getCustomerName())
				.replace("{AMT}", String.valueOf(transactionDetails.getAmount()))
				.replace("{DATEANDTIME}", transactionDetails.getTxtPGTime())
				.replace("{TXNSTATUS}", transactionDetails.getStatus()));
		smsDetails.setStatus(UserStatus.PENDING.toString());
		smsDetailsRepository.save(smsDetails);
		logger.info("End sendSMS() method ");

	}

	public void populatePgResponseinDB(MultiValueMap<String, String> response, TransactionDetails transactionDetails,
			String source) throws JsonProcessingException {
		logger.info("populatePgResponseinDB Inside");

		InputFromPgTransactionUpdate inputFromPgTransactionUpdate = new InputFromPgTransactionUpdate();

		inputFromPgTransactionUpdate.setMerchantId(transactionDetails.getMerchantId());
		inputFromPgTransactionUpdate.setMerchantOrderId(transactionDetails.getMerchantOrderId());
		inputFromPgTransactionUpdate.setOrderId(transactionDetails.getOrderID());
		inputFromPgTransactionUpdate.setInputFromPg(GeneralUtils.MultiValueMaptoJson(response));
		inputFromPgTransactionUpdate.setSource(source);
		logger.info("populatePgResponseinDB Save" + Utility.convertDTO2JsonString(inputFromPgTransactionUpdate));
		inputFromPgTransactionUpdateRepository.save(inputFromPgTransactionUpdate);
	}

	public void populatePgResponseinDB(String response, TransactionDetails transactionDetails,
			String source) throws JsonProcessingException {
		logger.info("populatePgResponseinDB Inside");

		InputFromPgTransactionUpdate inputFromPgTransactionUpdate = new InputFromPgTransactionUpdate();

		inputFromPgTransactionUpdate.setMerchantId(transactionDetails.getMerchantId());
		inputFromPgTransactionUpdate.setMerchantOrderId(transactionDetails.getMerchantOrderId());
		inputFromPgTransactionUpdate.setOrderId(transactionDetails.getOrderID());
		inputFromPgTransactionUpdate.setInputFromPg(response);
		inputFromPgTransactionUpdate.setSource(source);
		logger.info("populatePgResponseinDB Save" + Utility.convertDTO2JsonString(inputFromPgTransactionUpdate));
		inputFromPgTransactionUpdateRepository.save(inputFromPgTransactionUpdate);
	}

	public void populatePgResponseinDB(Map<String, String> response, TransactionDetails transactionDetails,
			String source) throws JsonProcessingException {
		logger.info("populatePgResponseinDB Inside");

		InputFromPgTransactionUpdate inputFromPgTransactionUpdate = new InputFromPgTransactionUpdate();

		inputFromPgTransactionUpdate.setMerchantId(transactionDetails.getMerchantId());
		inputFromPgTransactionUpdate.setMerchantOrderId(transactionDetails.getMerchantOrderId());
		inputFromPgTransactionUpdate.setOrderId(transactionDetails.getOrderID());
		inputFromPgTransactionUpdate.setInputFromPg(Utility.convertDTO2JsonString(response));
		inputFromPgTransactionUpdate.setSource(source);
		// logger.info("populatePgResponseinDB Save" +
		// Utility.convertDTO2JsonString(inputFromPgTransactionUpdate));
		inputFromPgTransactionUpdateRepository.save(inputFromPgTransactionUpdate);
	}

	public void populateResponseToMerchant(TransactionDetails transactionDetails, String strValue) {

		ResponstToMerchantDetails responstToMerchantDetails = new ResponstToMerchantDetails();
		responstToMerchantDetails.setMerchantId(transactionDetails.getMerchantId());
		responstToMerchantDetails.setMerchantOrderId(transactionDetails.getMerchantOrderId());
		responstToMerchantDetails.setOrderId(transactionDetails.getOrderID());
		responstToMerchantDetails.setInputForMerchant(strValue);
		responstToMerchantDetailsRepository.save(responstToMerchantDetails);

	}

	public UPIPaymentDetails populateUPIInputRepo(String orderId, SignatureRequestAll signatureRequest) {

		UPIPaymentDetails upiPaymentDetails = new UPIPaymentDetails();

		upiPaymentDetails.setOrderId(orderId);
		upiPaymentDetails.setOrderAmount(signatureRequest.getOrderAmount());
		upiPaymentDetails.setOrderNote(signatureRequest.getOrderNote());
		upiPaymentDetails.setOrderCurrency(signatureRequest.getOrderCurrency());
		upiPaymentDetails.setCustomerName(signatureRequest.getCustomerName());
		upiPaymentDetails.setCustomerEmail(signatureRequest.getCustomerEmail());
		upiPaymentDetails.setCustomerPhone(signatureRequest.getCustomerPhone());
		upiPaymentDetails.setPaymentOption(signatureRequest.getPaymentOption());
		upiPaymentDetails.setUpi_vpa(SecurityUtils.encryptSaveData(signatureRequest.getUpi_vpa()));

		return upiPaymentDetailsRepository.save(upiPaymentDetails);

	}
	/*
	 * public CardPaymentDetails populateCardInputRepo(String orderId,
	 * SignatureRequestAll signatureRequest) {
	 * 
	 * CardPaymentDetails cardPaymentDetails = new CardPaymentDetails();
	 * cardPaymentDetails.setOrderId(orderId);
	 * cardPaymentDetails.setOrderAmount(signatureRequest.getOrderAmount());
	 * cardPaymentDetails.setOrderNote(signatureRequest.getOrderNote());
	 * cardPaymentDetails.setOrderCurrency(signatureRequest.getOrderCurrency());
	 * cardPaymentDetails.setCustomerName(signatureRequest.getCustomerName());
	 * cardPaymentDetails.setCustomerEmail(signatureRequest.getCustomerEmail());
	 * cardPaymentDetails.setCustomerPhone(signatureRequest.getCustomerPhone());
	 * cardPaymentDetails.setCardNumber(SecurityUtils.encryptSaveData(
	 * signatureRequest.getCard_number()));
	 * cardPaymentDetails.setCardExpiryMonth(SecurityUtils.encryptSaveData(
	 * signatureRequest.getCard_expiryMonth()));
	 * cardPaymentDetails.setCardExpiryYear(SecurityUtils.encryptSaveData(
	 * signatureRequest.getCard_expiryYear()));
	 * cardPaymentDetails.setCardHolder(signatureRequest.getCard_holder());
	 * cardPaymentDetails.setPaymentOption(signatureRequest.getPaymentOption());
	 * 
	 * return cardPaymentDetailsRepository.save(cardPaymentDetails);
	 * }
	 * return cardPaymentDetailsRepository.save(cardPaymentDetails); }
	 */

	public NBPaymentDetails populateNBInputRepo(String orderId, SignatureRequestAll signatureRequest) {

		NBPaymentDetails nbPaymentDetails = new NBPaymentDetails();
		nbPaymentDetails.setOrderId(orderId);
		nbPaymentDetails.setOrderAmount(signatureRequest.getOrderAmount());
		nbPaymentDetails.setOrderNote(signatureRequest.getOrderNote());
		nbPaymentDetails.setOrderCurrency(signatureRequest.getOrderCurrency());
		nbPaymentDetails.setCustomerName(signatureRequest.getCustomerName());
		nbPaymentDetails.setCustomerEmail(signatureRequest.getCustomerEmail());
		nbPaymentDetails.setCustomerPhone(signatureRequest.getCustomerPhone());
		nbPaymentDetails.setPaymentOption(signatureRequest.getPaymentOption());
		// nbPaymentDetails.setPaymentCode(SecurityUtils.encryptSaveData(signatureRequest.getPaymentCode()));
		nbPaymentDetails.setPaymentCode(signatureRequest.getPaymentCode());
		return nBPaymentDetailsRepository.save(nbPaymentDetails);
	}

	public WalletPaymentDetails populateWalletInputRepo(String orderId, SignatureRequestAll signatureRequest) {

		WalletPaymentDetails walletPaymentDetails = new WalletPaymentDetails();
		walletPaymentDetails.setOrderId(orderId);
		walletPaymentDetails.setOrderAmount(signatureRequest.getOrderAmount());
		walletPaymentDetails.setOrderNote(signatureRequest.getOrderNote());
		walletPaymentDetails.setOrderCurrency(signatureRequest.getOrderCurrency());
		walletPaymentDetails.setCustomerName(signatureRequest.getCustomerName());
		walletPaymentDetails.setCustomerEmail(signatureRequest.getCustomerEmail());
		walletPaymentDetails.setCustomerPhone(signatureRequest.getCustomerPhone());
		walletPaymentDetails.setPaymentOption(signatureRequest.getPaymentOption());
		// walletPaymentDetails.setPaymentCode(SecurityUtils.encryptSaveData(signatureRequest.getPaymentCode()));
		walletPaymentDetails.setPaymentCode(signatureRequest.getPaymentCode());

		return walletPaymentDetailsRepository.save(walletPaymentDetails);
	}

	public String checkResponseData(MultiValueMap<String, String> responseFormData, String fieldName) {

		try {
			return responseFormData.get(fieldName).get(0);
		} catch (Exception e) {
			logger.error("Exception in Response Data :: " + fieldName);
		}
		return "";
	}

	@Value("${apiEndPoint}")
	String apiEndPoint;

	public Model populateReturnModel(Model model, String amt, String status, TransactionDetails transactionDetails)
			throws InvalidKeyException, NoSuchAlgorithmException {

		logger.info("Inside populateReturnModel PgFinalReturn  ( )");

		String signature = pgGatewayUtilService.populateInterSignature(transactionDetails.getOrderID(),
				transactionDetails.getStatus(), transactionDetails.getMerchantId());

		model.addAttribute(RET_RETURNURL, apiEndPoint + "/returnurlf");
		model.addAttribute(RET_SIGNATURE, signature);
		model.addAttribute(RET_VENDORORDERID, transactionDetails.getOrderID());
		logger.info("Inside populateReturnModel PgFinalReturn|" + transactionDetails.getOrderID() + "|" + signature);
		// populateResponseToMerchant(transactionDetails, model.toString());
		logger.info("END Method getFInalResponseProcess()");
		return model;

	}

	public Model getCustResponseProcess(MultiValueMap<String, String> responseFormData, Model model)
			throws UnsupportedEncodingException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			UserException, ValidationExceptions {

		logger.info(Utility.convertDTO2JsonString(GeneralUtils.convertMultiToRegularMap(responseFormData)));
		logger.info("Inside Method getResponseProcess()");
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, "VendorOrderId"));

		String status = "";
		String amt = String.format("%.2f", Double.parseDouble(String.valueOf(transactionDetails.getAmount())) / 100);
		status = transactionDetails.getStatus();
		String signature = pgGatewayUtilService.populateInterSignature(transactionDetails.getOrderID(),
				transactionDetails.getStatus(), transactionDetails.getMerchantId());
		if (!responseFormData.get(SIGNATURE).get(0).equals(signature)) {
			logger.error("Inter Signature::" + signature);
			throw new ValidationExceptions("Inter Signature invalid", FormValidationExceptionEnums.E0011);
		}
		return pgGatewayUtilService.populateReturnModelFinal(model, amt, status, transactionDetails);
	}

	public Model populateReturnModelFinal(Model model, String amt, String status, TransactionDetails transactionDetails)
			throws InvalidKeyException, NoSuchAlgorithmException {

		logger.info("Inside populateReturnModel Cashfree  ( )");

		String tr_time = Utility.populateDbTime();
		String cardNumber = Utility
				.maskCardNumber(checkNullValue(SecurityUtils.decryptSaveData(transactionDetails.getCardNumber())));
		String upiVpa = Utility
				.maskUpiCode(checkNullValue(SecurityUtils.decryptSaveData(transactionDetails.getVpaUPI())));
		String bankCode = "";
		String walletCode = "";
		logger.info("After created all required check .");

		if (transactionDetails.getPaymentOption().equalsIgnoreCase(PGServices.NB.toString())) {
			// bankCode =
			// SecurityUtils.decryptSaveData(transactionDetails.getPaymentCode());
			bankCode = transactionDetails.getPaymentCode();
		} else if (transactionDetails.getPaymentOption().equalsIgnoreCase(PGServices.WALLET.toString())) {
			// walletCode =
			// SecurityUtils.decryptSaveData(transactionDetails.getPaymentCode());
			walletCode = transactionDetails.getPaymentCode();
		}

		logger.info("setup done for bankcode and wallet code");

		UserDetails userDetails = userDetailsRepository.findById(transactionDetails.getUserID());

		String signature = pgGatewayUtilService.populateReturnSignature(status, transactionDetails.getPaymentOption(),
				transactionDetails.getMerchantOrderId(), String.valueOf(amt), transactionDetails.getOrderID(), tr_time,
				transactionDetails.getMerchantId(), "", "",
				userDetails.getCustomerName(), userDetails.getEmailId(), userDetails.getPhoneNumber(),
				cardNumber,
				upiVpa,
				bankCode,
				walletCode);

		model.addAttribute(RET_RETURNURL, transactionDetails.getMerchantReturnURL().replaceAll("\\p{C}", ""));
		model.addAttribute(RET_STATUS, status);
		model.addAttribute(RET_PAYMENTOPTION, transactionDetails.getPaymentOption());
		model.addAttribute(RET_MERCHANTORDERID, transactionDetails.getMerchantOrderId());
		model.addAttribute(RET_ORDERAMOUNT, amt);
		model.addAttribute(RET_VENDORORDERID, transactionDetails.getOrderID());
		model.addAttribute(RET_TXTDATE, tr_time);
		model.addAttribute(RET_CUSTNAME, userDetails.getCustomerName());
		model.addAttribute(RET_CUSTEMAIL, userDetails.getEmailId());
		model.addAttribute(RET_CUSTPHONE, userDetails.getPhoneNumber());
		model.addAttribute(RET_CARD_NUMBER, cardNumber);
		model.addAttribute(RET_UPI_ID, upiVpa);
		model.addAttribute(RET_BANK_CODE, bankCode);
		model.addAttribute(RET_WALLET_CODE, walletCode);

		model.addAttribute(RET_SIGNATURE, signature);
		model.addAttribute(RET_ERRORCODE, "");
		model.addAttribute(RET_ERRORDETAILS, "");

		if (transactionDetails.getMerchantAlertURL() != null) {

			logger.info("Merchant Notify URL :: " + transactionDetails.getMerchantAlertURL());

			notiFyURLService2Merchant.sendNotifyDetails2Merchant(status, transactionDetails.getPaymentOption(),
					transactionDetails.getMerchantOrderId(), amt, transactionDetails.getOrderID(), tr_time, signature,
					transactionDetails.getMerchantAlertURL(), userDetails.getCustomerName(), userDetails.getEmailId(),
					userDetails.getPhoneNumber(), cardNumber, upiVpa, bankCode, walletCode);
		}
		populateResponseToMerchant(transactionDetails, model.toString());
		logger.info("END Method getResponseProcess()");
		return model;

	}

	public String checkNullValue(String str) {
		if (str == null) {
			return "";
		}
		return str;
	}

	public void updateCustomerLinkData(TransactionDetails transactionDetails) {

		MerchantRequest4Customer merchantRequest4Customer = merchantRequest4CustomerRepository
				.findByOrderIdAndMerchantId(transactionDetails.getMerchantOrderId(),
						transactionDetails.getMerchantId());
		if (merchantRequest4Customer != null) {
			merchantRequest4Customer.setStatus(transactionDetails.getStatus());
			merchantRequest4CustomerRepository.save(merchantRequest4Customer);
		}

	}

	public void createCustomerRequest(CustomerInputDetails customerInputDetails) {
		customerInputDetailsRepository.save(customerInputDetails);
	}

	public CustomerInputDetails updateCustomerInputDetails(CustomerInputDetails customerInputDetails,
			String status, String errorCode, String errorMessage) {

		if (status.equalsIgnoreCase(UserStatus.ERROR.toString())) {
			customerInputDetails.setErrorCode(errorCode);
			customerInputDetails.setErrorMessage(errorMessage);
		}
		customerInputDetails.setStatus(status);

		return customerInputDetails;
	}

	public TransactionDetails populateTransactionDetails(MerchantDetails merhantDetails,
			MultiValueMap<String, String> formData, MerchantPGDetails merchantPGDetails, String merchantReturnURL,
			String merchantOrderId, String orderId, UserDetails userDetails) throws JsonProcessingException {

		logger.info("Before populateTransactionDetails()");
		TransactionDetails transactionDetails = new TransactionDetails();
		transactionDetails.setAmount(Integer.parseInt(formData.get(ORDERAMOUNT).get(0)));
		transactionDetails.setMerchantId(merhantDetails.getMerchantID());
		transactionDetails.setOrderID(orderId);
		transactionDetails.setPaymentOption(formData.get(PAYMENT_OPTION).get(0));
		transactionDetails.setPgType(merchantPGDetails.getMerchantPGName());
		transactionDetails.setStatus("PENDING");
		transactionDetails.setUserID(userDetails.getId());
		transactionDetails.setPgId(merchantPGDetails.getMerchantPGId());
		transactionDetails.setMerchantOrderId(merchantOrderId);
		transactionDetails.setMerchantReturnURL(merchantReturnURL);
		transactionDetails.setCustOrderId(Utility.generateAppId());
		transactionDetails.setSource("RequestPayment");
		transactionDetails.setEmailId(formData.get(CUSTOMEREMAIL).get(0));

		if (formData.get(ALERTURL) != null) {
			transactionDetails.setMerchantAlertURL(formData.get(ALERTURL).get(0));
		}

		if (formData.get(ORDERNOTE) != null) {
			transactionDetails.setOrderNote(formData.get(ORDERNOTE).get(0));
		}

		/*
		 * if (transactionDetails.getPaymentOption().equalsIgnoreCase("CARD")) { if
		 * (formData.get(CARD_NUMBER).get(0) != null) { if
		 * (formData.get(CARD_NUMBER).get(0).length() != 0) {
		 * transactionDetails.setCardNumber(SecurityUtils.encryptSaveData(formData.get(
		 * CARD_NUMBER).get(0))); } } }
		 */
		if (transactionDetails.getPaymentOption().equalsIgnoreCase("NB")
				|| transactionDetails.getPaymentOption().equalsIgnoreCase("WALLET")) {
			if (formData.get(PAYMENTCODE).get(0) != null) {
				if (formData.get(PAYMENTCODE).get(0).length() != 0) {
					// transactionDetails.setPaymentCode(SecurityUtils.encryptSaveData(formData.get(PAYMENTCODE).get(0)));
					transactionDetails.setPaymentCode(formData.get(PAYMENTCODE).get(0));
				}
			}
		} else if (transactionDetails.getPaymentOption().equalsIgnoreCase("UPI")) {
			if (formData.get(UPI_VPI).get(0) != null) {
				if (formData.get(UPI_VPI).get(0).length() != 0) {
					transactionDetails.setVpaUPI(SecurityUtils.encryptSaveData(formData.get(UPI_VPI).get(0)));
				}
			}
		}

		logger.info("End populateTransactionDetails()");
		logger.info(Utility.convertDTO2JsonString(transactionDetails));

		return transactionDetailsRepository.save(transactionDetails);
	}

	public CardBinResponse getCardDeterminator(String cardBin) {

		logger.info("Card Bin :: " + cardBin);
		HttpResponse<CardBinResponse> cardBinResponse = Unirest.get(cardDeterminator + cardBin)
				.asObject(CardBinResponse.class);

		return cardBinResponse.getBody();
	}

	@Autowired
	MerchantPGDetailsRepository merchantPGDetailsRepository;
	@Autowired
	PGConfigurationDetailsRepository pgConfigurationDetailsRepository;

	public PGConfigurationDetails getPgDetailsByAppId(String appid, String paymentMode) throws JsonProcessingException {
		MerchantDetails merhantDetails = merchantDetailsRepository.findByAppID(appid);
		logger.info("merchantdetails::"+Utility.convertDTO2JsonString(merhantDetails)+":PM:"+paymentMode);
		PGConfigurationDetails pgDetails = pgConfigurationDetailsRepository
				.getByPgUuidAndService(merhantDetails.getMerchantID(), paymentMode);
		logger.info("pgDetails::" + Utility.convertDTO2JsonString(pgDetails));
		return pgDetails;

	}

	public PGConfigurationDetails getPgDetailsByMerchantId(String merchantId, String paymentMode)
			throws JsonProcessingException {
		PGConfigurationDetails pgDetails = pgConfigurationDetailsRepository
				.getByPgUuidAndService(merchantId, paymentMode);
		logger.info("pgDetails::" + Utility.convertDTO2JsonString(pgDetails));
		return pgDetails;

	}

	public String getReturnUrl(String submitUrl, String merchantId, String paymentMode) throws JsonProcessingException {
		PGConfigurationDetails pgDetails = getPgDetailsByMerchantId(merchantId, paymentMode);
		String lastPage = submitUrl.substring(submitUrl.lastIndexOf('/') + 1);
		if (pgDetails.getPgMerchantLink() != null) {
			if (lastPage.equals("pg")) {
				return pgDetails.getPgMerchantLink();
			}
			return pgDetails.getPgMerchantLink() + "/" + lastPage;
		} else {
			return submitUrl;
		}
	}

	public String getWebhookUrl(String submitUrl, String merchantId, String paymentMode)
			throws JsonProcessingException {
		PGConfigurationDetails pgDetails = getPgDetailsByMerchantId(merchantId, paymentMode);
		String lastPage = submitUrl.substring(submitUrl.lastIndexOf('/') + 1);
		if (pgDetails.getPgMerchantLink() != null) {
			return pgDetails.getPgMerchantLink() + "/" + lastPage;
		} else {
			return submitUrl;
		}
	}

	public CardBinDetails getCardBin(String cardNumber) throws IOException {

		ObjectMapper mapper = new ObjectMapper();

		HttpResponse<String> cardBinDetailsResp = Unirest
				.post(neutrinoEndPoint + "?bin-number="
						+ String.valueOf(Long.parseLong(cardNumber)).substring(0, 6)
						+ "&user-id=" + neutrinoapiUserId + "&api-key=" + neutrinoapiKey)
				.asString().ifFailure(SetuErrorResponse.class, r -> {
					SetuErrorResponse e = r.getBody();
					try {
						logger.info("Card Bin Extract Response Error ::" + Utility.convertDTO2JsonString(e));
					} catch (JsonProcessingException e1) {

						e1.printStackTrace();
					}
				});

		return mapper.readValue(cardBinDetailsResp.getBody().replace("-", ""), CardBinDetails.class);

	}

}
