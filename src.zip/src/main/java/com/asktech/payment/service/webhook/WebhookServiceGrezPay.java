package com.asktech.payment.service.webhook;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.asktech.payment.constant.grezpay.GrezPayContants;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.model.GrezPayTransactionDetails;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.repository.GrezPayTransactionDetailsRepository;
import com.asktech.payment.repository.TransactionDetailsRepository;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.util.grezpay.GrezPayPaymentUtility;

@Service
public class WebhookServiceGrezPay implements CashFreeFields, GrezPayContants {
	
	static Logger logger = LoggerFactory.getLogger(WebhookServiceGrezPay.class);
	
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	@Autowired
	GrezPayTransactionDetailsRepository grezPayTransactionDetailsRepository;
	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	GrezPayPaymentUtility grezPayPaymentUtility;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;

	public String updateWebhookAsanPay(MultiValueMap<String, String> responseFormData) {
		
		TransactionDetails transactionDetails = transactionDetailsRepository
				.findByOrderID(pgGatewayUtilService.checkResponseData(responseFormData, RESP_ORDER_ID));
		
		GrezPayTransactionDetails grezPayTransactionDetails = grezPayTransactionDetailsRepository
				.findByOrderId(transactionDetails.getOrderID());
		if(transactionDetails != null) {
			
			if(grezPayTransactionDetails != null ) {
				
				transactionDetails.setStatus(
						grezPayPaymentUtility.checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE),
								pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));
				transactionDetails.setSource("WebHook");
				
				grezPayTransactionDetails.setTxStatus(grezPayPaymentUtility.checkStatus(pgGatewayUtilService.checkResponseData(responseFormData, RESP_RESPONSE_CODE),
								pgGatewayUtilService.checkResponseData(responseFormData, RESP_STATUS)));
				grezPayTransactionDetails.setSource("WebHook");
				
				transactionDetailsRepository.save(transactionDetails);
				grezPayTransactionDetailsRepository.save(grezPayTransactionDetails);
				
				try {
                    notiFyURLService2Merchant.populateReturnDetails(transactionDetails);
                } catch (Exception e) {
                    logger.error("Exception in notify to merchant :: " + e.toString());
                }
			}
		}
		
		return "Request has been received successfully. Thanks";
		
	}
}
