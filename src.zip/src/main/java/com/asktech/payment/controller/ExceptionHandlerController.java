package com.asktech.payment.controller;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.asktech.payment.constant.ReturnMerchantAttributes;
import com.asktech.payment.constants.cashfree.CashFreeFields;
import com.asktech.payment.dto.error.ErrorResponseDto;
import com.asktech.payment.exception.UserException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.repository.MerchantDetailsRepository;
import com.asktech.payment.service.NotiFyURLService2Merchant;
import com.asktech.payment.service.PGGatewayUtilService;
import com.fasterxml.jackson.core.JsonProcessingException;

@ControllerAdvice
public class ExceptionHandlerController extends Exception {

	static Logger logger = LoggerFactory.getLogger(ExceptionHandlerController.class);

	@Autowired
	PGGatewayUtilService pgGatewayUtilService;
	@Autowired
	MerchantDetailsRepository merchantDetailsRepository;
	@Autowired
	NotiFyURLService2Merchant notiFyURLService2Merchant;

	@ExceptionHandler(ValidationExceptions.class)
	public String validationException(final ValidationExceptions ue, Model model)
			throws InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException, ValidationExceptions {

		ErrorResponseDto err = new ErrorResponseDto();
		String returnText = null;
		err.setExceptionEnum(ue.getException());
		err.getMsg().add(ue.getMessage());

		if (StringUtils.isEmpty(ue.getReturnURL())) {

			logger.info("Without ReturnURL");
			model.addAttribute("errorMsg", ue.getMessage().toString());
			model.addAttribute("code", ue.getException().toString());
			returnText = "error";

		} else {

			String amt = String.format("%.2f",
					Double.parseDouble(String.valueOf(ue.getFormData().get(CashFreeFields.ORDERAMOUNT).get(0))) / 100);
			logger.info("With ReturnURL" + ue.getFormData().toString());
			logger.info("Inside Exception Controller..");

			String signature = pgGatewayUtilService.populateReturnSignature(
					"",
					ue.getFormData().get(CashFreeFields.PAYMENT_OPTION).get(0),
					ue.getFormData().get(CashFreeFields.ORDERID).get(0),
					amt,
					"",
					"",
					pgGatewayUtilService.getMerchantFromAppId(
							ue.getFormData().get(CashFreeFields.APPID).get(0),
							ue.getFormData().get(CashFreeFields.RETURNURL).get(0),
							ue.getFormData()).getMerchantID(),
					ue.getException().toString(),
					ue.getMessage().toString(),
					ue.getFormData().get(CashFreeFields.CUSOMERNAME).get(0),
					ue.getFormData().get(CashFreeFields.CUSTOMEREMAIL).get(0),
					ue.getFormData().get(CashFreeFields.CUSTOMERPHONE).get(0), "", "", "", "");

			model.addAttribute(ReturnMerchantAttributes.RET_RETURNURL,
					ue.getReturnURL().toString().replaceAll("\\p{C}", ""));
			model.addAttribute(ReturnMerchantAttributes.RET_STATUS, "");
			model.addAttribute(ReturnMerchantAttributes.RET_PAYMENTOPTION,
					ue.getFormData().get("paymentOption").get(0));
			model.addAttribute(ReturnMerchantAttributes.RET_MERCHANTORDERID,
					ue.getFormData().get(CashFreeFields.ORDERID).get(0));
			model.addAttribute(ReturnMerchantAttributes.RET_ORDERAMOUNT, amt);
			model.addAttribute(ReturnMerchantAttributes.RET_VENDORORDERID, "");
			model.addAttribute(ReturnMerchantAttributes.RET_TXTDATE, "");
			model.addAttribute(ReturnMerchantAttributes.RET_CUSTNAME,
					ue.getFormData().get(CashFreeFields.CUSOMERNAME).get(0));
			model.addAttribute(ReturnMerchantAttributes.RET_CUSTEMAIL,
					ue.getFormData().get(CashFreeFields.CUSTOMEREMAIL).get(0));
			model.addAttribute(ReturnMerchantAttributes.RET_CUSTPHONE,
					ue.getFormData().get(CashFreeFields.CUSTOMERPHONE).get(0));
			model.addAttribute(ReturnMerchantAttributes.RET_CARD_NUMBER, "");
			model.addAttribute(ReturnMerchantAttributes.RET_UPI_ID, "");
			model.addAttribute(ReturnMerchantAttributes.RET_BANK_CODE, "");
			model.addAttribute(ReturnMerchantAttributes.RET_WALLET_CODE, "");
			model.addAttribute(ReturnMerchantAttributes.RET_ERRORCODE, ue.getException().toString());
			model.addAttribute(ReturnMerchantAttributes.RET_ERRORDETAILS, ue.getMessage().toString());
			model.addAttribute(ReturnMerchantAttributes.RET_SIGNATURE, signature);

			pgGatewayUtilService.checkResponseData(ue.getFormData(), CashFreeFields.ALERTURL);

			if (pgGatewayUtilService.checkResponseData(ue.getFormData(), CashFreeFields.ALERTURL).length() > 0) {
				notiFyURLService2Merchant.sendNotifyDetails2MerchantError(ue.getFormData().get("paymentOption").get(0),
						ue.getFormData().get(CashFreeFields.ORDERID).get(0),
						amt,
						signature,
						ue.getFormData().get(CashFreeFields.ALERTURL).get(0),
						ue.getException().toString(), ue.getMessage().toString(),
						ue.getFormData().get(CashFreeFields.CUSOMERNAME).get(0),
						ue.getFormData().get(CashFreeFields.CUSTOMEREMAIL).get(0),
						ue.getFormData().get(CashFreeFields.CUSTOMERPHONE).get(0),
						"", "", "", "");
			}

			returnText = "paymentResponseToMerchant";

		}

		return returnText;
	}

	@ExceptionHandler(UserException.class)
	public String userException(final UserException ue, Model model) {
		ErrorResponseDto err = new ErrorResponseDto();
		err.setExceptionEnum(ue.getException());
		err.getMsg().add(ue.getMessage());
		logger.error("Exception :: ", ue.getMessage());
		model.addAttribute("errorMsg", ue.getMessage().toString());

		return "error";
	}

	@ExceptionHandler(Exception.class)
	public String exception(final Exception e, Model model) {
		ErrorResponseDto err = new ErrorResponseDto();
		err.getMsg().add(e.getMessage());
		logger.error("Exception.class Exception :: ", e.getMessage().toString());
		model.addAttribute("errorMsg", e.getMessage().toString());

		return "error";
	}
}
