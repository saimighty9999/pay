package com.asktech.payment.controller;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.asktech.payment.constant.ErrorValues;
import com.asktech.payment.dto.easePay.EasePayCallBackResp;
import com.asktech.payment.dto.onepay.ResponseDecryptData;
import com.asktech.payment.exception.FormValidationException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.TransactionDetails;
import com.asktech.payment.service.PGGatewayService;
import com.asktech.payment.service.PGGatewayUtilService;
import com.asktech.payment.service.PaymentVerification;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.Utility;
import com.asktech.payment.util.airPay.AirPayPaymentUtility;
import com.asktech.payment.util.airPay.dto.Chkvaluest;
import com.asktech.payment.util.asanpay.AsanPayPaymentUtility;
import com.asktech.payment.util.atom.AtomUtilityClass;
import com.asktech.payment.util.cashfree.CashFreeUtilityClass;
import com.asktech.payment.util.easebuzz.EasebuzzPaymentUtils;
import com.asktech.payment.util.easypay.EasyPayUtility;
import com.asktech.payment.util.freecharge.FreeChargeUtility;
import com.asktech.payment.util.gatepay.GetePayUtilities;
import com.asktech.payment.util.grezpay.GrezPayPaymentUtility;
import com.asktech.payment.util.icici.ICICIUtilityClass;
import com.asktech.payment.util.isgpg.IsgPgUtility;
import com.asktech.payment.util.letzpay.LetzpayUtilityClass;
import com.asktech.payment.util.neoCred.NeoCredUtility;
import com.asktech.payment.util.nimble.NimbleUtility;
import com.asktech.payment.util.nsdl.NSDLUtilityClass;
import com.asktech.payment.util.onepay.OnePayPaymentUtils;
import com.asktech.payment.util.payaid.PayaidUtility;
import com.asktech.payment.util.axis.AxisUtility;
import com.asktech.payment.util.payg.PayGPaymentUtility;
import com.asktech.payment.util.paytm.PaytmPgUtility;
import com.asktech.payment.util.payu.PayUPaymentUtility;
import com.asktech.payment.util.razorPay.RazorPayPaymentUtility;
import com.asktech.payment.util.sabPaisa.SabPaisaPaymentUtility;
import com.asktech.payment.util.setu.SetuUpiUtility;
import com.asktech.payment.util.zavion.ZavionUtilityPayment;

@Controller
public class PGGatewayController implements ErrorValues {

	static Logger logger = LoggerFactory.getLogger(PGGatewayController.class);

	@Autowired
	PGGatewayService pgGatewayService;
	@Autowired
	PaymentVerification service;
	@Autowired
	PaytmPgUtility paytmPgUtility;
	@Autowired
	ZavionUtilityPayment zavionUtilityPayment;
	@Autowired
	CashFreeUtilityClass cashFreeUtilityClass;
	@Autowired
	SetuUpiUtility setuUpiUtility;
	@Autowired
	FreeChargeUtility freeChargeUtility;
	@Autowired
	EasebuzzPaymentUtils easebuzzPaymentUtils;
	@Autowired
	PayUPaymentUtility payUPaymentUtility;
	@Autowired
	OnePayPaymentUtils onePayPaymentUtils;
	@Autowired
	ICICIUtilityClass iciciUtilityClass;
	@Autowired
	NSDLUtilityClass nsdlUtilityClass;
	@Autowired
	GrezPayPaymentUtility grezPayPaymentUtility;
	@Autowired
	AsanPayPaymentUtility asanPayPaymentUtility;
	@Autowired
	GetePayUtilities getePayUtilities;
	@Autowired
	LetzpayUtilityClass letzpayUtilityClass;
	@Autowired
	RazorPayPaymentUtility razorPayPaymentUtility;
	@Autowired
	PayGPaymentUtility payGPaymentUtility;
	@Autowired
	SabPaisaPaymentUtility sabPaisaPaymentUtility;
	@Autowired
	AtomUtilityClass atomUtilityClass;
	@Autowired
	PGGatewayUtilService pGGatewayUtilService;
	@Autowired
	AxisUtility axisUtility;

	@RequestMapping(value = "/collectPayment", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String paymentPage(@RequestBody MultiValueMap<String, String> formData, Model model,
			@RequestHeader("User-Agent") String device, HttpServletRequest request)
			throws FormValidationException, ValidationExceptions,
			InvalidKeyException, NoSuchAlgorithmException, ParseException, IOException {
		logger.info("Collect Payment");
		HttpServletRequest req = (HttpServletRequest) request;
		String ipaddress = Utility.getClientIp(req);

		Map<String, Object> objectMap = pgGatewayService.getInitialRequestProcess(formData, model, device, ipaddress);

		model = (Model) objectMap.get("Model");
		String template = (String) objectMap.get("Theme");
		logger.info(template);
		return template;
	}

	@RequestMapping(value = "/collectPaymentLink", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String paymentPageLink(@RequestBody MultiValueMap<String, String> formData, Model model,
			@RequestHeader("User-Agent") String device, HttpServletRequest request)
			throws FormValidationException, ValidationExceptions,
			InvalidKeyException, NoSuchAlgorithmException, ParseException, IOException {

		HttpServletRequest req = (HttpServletRequest) request;
		String ipaddress = Utility.getClientIp(req);
		logger.info("IPADDRESS::" + ipaddress);
		Map<String, Object> objectMap = pgGatewayService.getRequestProcess(formData, model, device, ipaddress);

		model = (Model) objectMap.get("Model");
		String template = (String) objectMap.get("Theme");
		logger.info(template);
		return template;
	}

	@RequestMapping(value = "/returnurl", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String acceptReturnCashfree(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest()");

		logger.info("CashFree Response From PG :: " + responseFormData.toString());
		cashFreeUtilityClass.updateTransactionStatus(responseFormData);
		logger.info("updateTransactionStatus Complete");
		logger.info("getResponseProcess Start");
		model = cashFreeUtilityClass.getResponseProcess(responseFormData, model);

		logger.info("getResponseProcess Complete");
		return "paymentResponseToDynamicMerchant";

	}

	@RequestMapping(value = "/returnurlf", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String acceptReturnf(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest()");

		logger.info("Final Response From PG :: " + responseFormData.toString());

		model = pGGatewayUtilService.getCustResponseProcess(responseFormData, model);

		logger.info("getResponseProcess Complete");
		return "paymentResponseToMerchant";

	}

	@RequestMapping(value = "/notifyurl", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> acceptNofityCashfree(@RequestBody MultiValueMap<String, String> responseFormData)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest() Notify");
		logger.info("CashFree Response From PG :: " + responseFormData.toString());
		cashFreeUtilityClass.updateTransactionWithNotifyCashfree(responseFormData);

		return ResponseEntity.ok().body("The request has been received..");

	}

	@RequestMapping(value = "/notifyurlLetsPay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String acceptNofityLetspay(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest()");
		logger.info("webhookRequest Request From UI :: " + responseFormData.toString());

		String orderId = letzpayUtilityClass.acceptNotifyURLLetzPay(responseFormData);
		logger.info("After letzpayUtilityClass.acceptNotifyURLLetzPay()");

		model = letzpayUtilityClass.getResponseProcessLetsPay(orderId, model);
		logger.info("After generate Model Info");

		return "paymentResponseToMerchant";
		// return ResponseEntity.ok().body(responseFormData.toString());
	}

	@RequestMapping(value = "/testConsume", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String testComsume(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  testConsume()");
		logger.info("testConsume Request From UI :: " + responseFormData.toString());
		// Map<String, Object> objectMap =
		// pgGatewayService.processReturn(responseFormData, model);

		// model = (Model) objectMap.get("Model");
		// String template = (String) objectMap.get("Theme");
		// pgGatewayService.updateTransactionStatus(responseFormData);
		// logger.info(template);
		return null;
	}

	@RequestMapping(value = "/testConsumeNotify", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> testConsumeNotify(@RequestBody String responseFormData) throws ParseException, Exception {

		logger.info("Method  testConsumeNotify() test end Point for Merchant Notify URL testing");
		logger.info("testConsume Request From PostRequest from Analytics:: " + responseFormData.toString());
		// pgGatewayServiceCashFree.updateTransactionStatus(responseFormData);
		return ResponseEntity.ok().body(responseFormData.toString());
	}

	@RequestMapping(value = "/customerRequest/{requestId}", method = RequestMethod.GET)
	public String custRequest(@PathVariable(value = "requestId") String requestId, Model model)
			throws ParseException, Exception {

		logger.info("Method  testConsume()");
		logger.info("testConsume Request From UI :: " + requestId);

		Map<String, Object> objectMap = pgGatewayService.checkCustomerRequest(requestId, model);

		model = (Model) objectMap.get("Model");
		String template = (String) objectMap.get("Theme");

		return template;
	}

	@RequestMapping(value = "/customerPayment/{requestId}", method = RequestMethod.GET)
	public String customerPayment(@PathVariable(value = "requestId") String requestId, Model model)
			throws ParseException, Exception {

		logger.info("Method  testConsume()");
		logger.info("testConsume Request From UI :: " + requestId);

		Map<String, Object> objectMap = pgGatewayService.checkCustomerRequest(requestId, model);

		model = (Model) objectMap.get("Model");
		String template = (String) objectMap.get("Theme");

		return template;
	}

	@RequestMapping(value = "/setuResponseConsume/{requestId}", method = RequestMethod.POST)
	public ResponseEntity<?> setuWebhook(@RequestBody String responseFormSetu,
			@PathVariable(value = "requestId") String requestId) throws ParseException, Exception {

		logger.info("Method  testConsume() requestId :: " + requestId);
		logger.info("setu WeebHook Request From UI :: " + responseFormSetu);

		return ResponseEntity.ok().body(pgGatewayService.setuWeebhook(responseFormSetu));
	}

	@RequestMapping(value = "/notifyurlSetu", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String acceptNofitySetu(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Setu Response From PG :: " + responseFormData.toString());
		setuUpiUtility.updateTransactionStatusSetu(responseFormData);
		logger.info("updateTransactionStatus Complete");
		logger.info("getResponseProcess Start");
		model = setuUpiUtility.getResponseProcess(responseFormData, model);
		logger.info("getResponseProcess Complete");
		return "paymentResponseToMerchant";

	}

	@RequestMapping(value = "/getSetuTransactionDetails/{orderId}", method = RequestMethod.GET)
	public ResponseEntity<?> getSetuTransactionUpdate(@PathVariable(value = "orderId") String orderId)
			throws ParseException, Exception {

		logger.info("Method  getSetuTransactionDetails() orderId :: " + orderId);

		return ResponseEntity.ok().body(pgGatewayService.getSetutransactionDetails(orderId));
	}

	@RequestMapping(value = "/notifyurlFreeCharge", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String acceptFreeChargeNotify(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Freecharge Response From PG :: " + responseFormData.toString());
		freeChargeUtility.updateTransactionStatusFreeCharge(responseFormData);
		logger.info("updateTransactionStatus Complete");
		model = freeChargeUtility.getResponseProcessFreeCharge(responseFormData, model);
		logger.info("getResponseProcess Complete");
		return "paymentResponseToMerchant";

	}

	@RequestMapping(value = "/paytmNotify", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String paytmNotify(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Paytm WebHook Request From UI :: " + responseFormData);
		paytmPgUtility.updateTransactionStatusPaytm(responseFormData);
		model = paytmPgUtility.getResponseProcess(responseFormData, model);
		logger.info("getResponseProcess Complete");
		return "paymentResponseToMerchant";

	}

	@RequestMapping(value = "/notifyurlZavion", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String zavionNotify(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Zavion WebHook Request From UI :: " + responseFormData);
		zavionUtilityPayment.updateTransactionStatusZavion(responseFormData);
		model = zavionUtilityPayment.getResponseProcess(responseFormData, model);
		logger.info("getResponseProcess Complete");
		// return "paymentResponseToMerchant";
		return "paymentResponseToMerchant";

	}

	@RequestMapping(value = "/returnurlEasebuzz", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String returnurlEasebuzz(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Easebuzz WebHook Request From UI :: " + responseFormData);

		easebuzzPaymentUtils.updateTransactionStatusEasebuzz(responseFormData);
		logger.info("updateTransactionStatus Complete");
		logger.info("getResponseProcess Start");
		model = easebuzzPaymentUtils.getResponseProcess(responseFormData, model);

		logger.info("getResponseProcess Complete");
		return "paymentResponseToMerchant";

	}

	@RequestMapping(value = "/returnurlPayU", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String acceptReturnPayU(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest()");

		logger.info("PayU Response From PG :: " + responseFormData.toString());
		payUPaymentUtility.updateTransactionStatus(responseFormData);
		logger.info("updateTransactionStatus Complete");
		logger.info("getResponseProcess Start");
		model = payUPaymentUtility.getResponseProcess(responseFormData, model);

		logger.info("getResponseProcess Complete");
		return "paymentResponseToMerchant";

	}

	@RequestMapping(value = "/payUWebHook", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> payUWeebHook(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest PayU () :: " + responseFormData.toString());
		payUPaymentUtility.updateWebhookPayUResponse(responseFormData);

		return ResponseEntity.ok().body(responseFormData);
	}

	@RequestMapping(value = "/returnurl1Pay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String acceptReturn1Pay(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest()");

		logger.info("1Pay Response From PG :: " + responseFormData.toString());
		logger.info("1Pay Response From PG End:: ");

		ResponseDecryptData responseDecryptData = onePayPaymentUtils.updateTransactionStatus1Pay(responseFormData);

		logger.info("updateTransactionStatus Complete");
		logger.info("getResponseProcess Start");
		model = onePayPaymentUtils.getResponseProcess(responseDecryptData, model);

		logger.info("getResponseProcess Complete");

		return "paymentResponseToMerchant";

	}

	@RequestMapping(value = "/returnURLIcici", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String acceptReturnIcici(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest()" + responseFormData.toString());

		logger.info("ICICI Response From PG :: " + responseFormData.toString());

		iciciUtilityClass.updateTransactionStatusICICIBank(responseFormData);

		logger.info("updateTransactionStatus Complete");
		logger.info("getResponseProcess Start");
		model = iciciUtilityClass.getResponseProcess(responseFormData, model);

		logger.info("getResponseProcess Complete");

		return "paymentResponseToMerchant";

	}

	@RequestMapping(value = "/returnUrld", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	// public ResponseEntity<?> returnUrlnsdl(@RequestBody MultiValueMap<String,
	// String> responseFormData)
	// throws ParseException, Exception {
	public String returnUrlnsdl(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {
		logger.info("Method  testConsumeNotify() test end Point for returnUrlnsdl URL testing");
		logger.info("testConsume Request From PostRequest from Analytics:: " + responseFormData.toString());
		nsdlUtilityClass.prepareAuthentication(responseFormData, model);

		// return ResponseEntity.ok().body(responseFormData);
		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/returnUrlnsdlCard", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String returnUrlnsdlCard(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  testConsumeNotify() test end Point for returnUrlnsdl URL testing");
		logger.info("testConsume Request From PostRequest from Analytics:: " + responseFormData.toString());
		nsdlUtilityClass.prepareAuthenticationCard(responseFormData, model);
		return "paymentResponseToMerchant";
	}

	/*
	 * @RequestMapping(value = "/returnUrlnsdlUPI", method = RequestMethod.POST,
	 * consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	 * public ResponseEntity<?> returnUrlnsdlUPI(@RequestBody MultiValueMap<String,
	 * String> responseFormData)
	 * throws ParseException, Exception {
	 * 
	 * logger.
	 * info("Method  testConsumeNotify() test end Point for returnUrlnsdl URL testing"
	 * );
	 * logger.info("testConsume Request From PostRequest from Analytics:: " +
	 * responseFormData.toString());
	 * 
	 * return ResponseEntity.ok().body(responseFormData);
	 * }
	 */

	@RequestMapping(value = "/returnURLGetePay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String returnURLGatePay(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  GateWay Return URL test end Point for returnUrlgatePay URL testing");
		logger.info("GateWay Return URL from Analytics:: " + responseFormData.toString());
		getePayUtilities.updateTransactionStatus(responseFormData);
		model = getePayUtilities.getResponseProcess(responseFormData, model);
		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/returngrezpay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String returngrezpay(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  GrezPay Return URL test end Point for returnUrlnsdl URL testing");
		logger.info("GrezPay Return URL from Analytics:: " + responseFormData.toString());
		grezPayPaymentUtility.updateTransactionStatus(responseFormData);
		model = grezPayPaymentUtility.getResponseProcess(responseFormData, model);
		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/returnasanpay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String returnasanpay(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  AsanPay Return URL test end Point for returnUrlnsdl URL testing");
		logger.info("AsanPay Return URL from Analytics:: " + responseFormData.toString());
		asanPayPaymentUtility.updateTransactionStatus(responseFormData);
		model = asanPayPaymentUtility.getResponseProcess(responseFormData, model);
		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/returnRazorPay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String returnRazorPay(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("RazorPay Return URL from Analytics:: " + responseFormData.toString());

		String orderId = razorPayPaymentUtility.updateTransactionStatus(responseFormData);
		model = razorPayPaymentUtility.getResponseProcess(orderId, model);

		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/returnURLPayG/{orderId}", method = RequestMethod.GET)
	public String returnURLPayG(@PathVariable(value = "orderId") String orderId, Model model)
			throws ParseException, Exception {

		logger.info("Method  getReturnURLPayGDetails() orderId :: " + orderId);

		model = payGPaymentUtility.getResponseProcess(payGPaymentUtility.updateTransactionStatus(orderId), model);

		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/getPayGDetails/{orderId}", method = RequestMethod.GET)
	public ResponseEntity<?> getPayGDetails(@PathVariable(value = "orderId") String orderId, Model model)
			throws ParseException, Exception {

		logger.info("Method  getReturnURLPayGDetails() orderId :: " + orderId);

		String trDetails = Utility.convertDTO2JsonString(payGPaymentUtility.checkTransactionStatus(orderId));

		return ResponseEntity.ok().header("Content-Type", "application/json").body(trDetails);
	}

	@RequestMapping(value = "/getDStatusAPI/{orderId}", method = RequestMethod.GET)
	public ResponseEntity<?> getNSDLStatusAPI(@PathVariable(value = "orderId") String orderId)
			throws ParseException, Exception {

		logger.info("Method  getSetuTransactionDetails() orderId :: " + orderId);

		return ResponseEntity.ok().body(nsdlUtilityClass.getUPIDBStatusDetails(orderId, false));
	}

	@RequestMapping(value = "/returnUrldUPI/{orderId}", method = RequestMethod.GET)
	public String returnUrlnsdlUPI(@PathVariable(value = "orderId") String orderId, Model model)
			throws ParseException, Exception {

		logger.info("Method  getSetuTransactionDetails() orderId :: " + orderId);

		model = nsdlUtilityClass.NSDLreturnUrlUPI(orderId, model);

		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/returnsb", method = RequestMethod.GET)
	public String returnsabPaisa(@RequestParam("query") String query, @RequestParam("clientCode") String clientCode,
			Model model)
			throws ParseException, Exception {

		logger.info("Method  SabPaisa Return URL test end Point");
		logger.info("SabPaisa Return URL from Analytics:: " + query);
		TransactionDetails transactionDetails = sabPaisaPaymentUtility.updateTransactionStatus(query, clientCode);
		model = sabPaisaPaymentUtility.getResponseProcess(transactionDetails, model);
		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/callbacksb", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String callbacksb(@RequestParam("query") String query, @RequestParam("clientCode") String clientCode,
			Model model)
			throws ParseException, Exception {

		logger.info("Method  SabPaisa Return URL test end Point");
		logger.info("SabPaisa Return URL from Analytics:: " + query);
		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/returnProcess100", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String returnAtom(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Atom Return URL from Analytics:: " + responseFormData.toString());
		TransactionDetails transactionDetails = atomUtilityClass.updateTransactionStatusAtom(responseFormData);
		model = atomUtilityClass.getResponseProcess(transactionDetails, model);
		return "paymentResponseToDynamicMerchant";
	}

	@RequestMapping(value = "/callbackApi100", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> callbackAtom(@RequestBody String responseFormData)
			throws ParseException, Exception {

		return ResponseEntity.ok().body(atomUtilityClass.populateCallBackAPI(responseFormData));
	}

	@Autowired
	AirPayPaymentUtility airPayPaymentUtility;

	@RequestMapping(value = "/returnProcess101/{orderId}", method = RequestMethod.GET)
	public String returnAirpay(@PathVariable(value = "orderId") String orderId, Model model)
			throws ParseException, Exception {
		logger.info("returnProcess101::returnAirpay::" + orderId);
		TransactionDetails transactionDetails = airPayPaymentUtility.updateTransactionStatus(orderId);
		model = airPayPaymentUtility.getResponseProcess(transactionDetails, model);
		return "paymentResponseToDynamicMerchant";
	}

	@RequestMapping(value = "/statusProcess101/{orderId}", method = RequestMethod.GET)
	public ResponseEntity<?> statusAirpay(@PathVariable(value = "orderId") String orderId)
			throws ParseException, Exception {
		logger.info("statusProcess101::statusAirpay::" + orderId);
		Chkvaluest dt = airPayPaymentUtility.checkStatus(orderId);
		return ResponseEntity.ok().body(dt);
	}

	@RequestMapping(value = "/returnProcess102", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> returnIppoPay(@RequestBody MultiValueMap<String, String> responseFormData)
			throws ParseException, Exception {
		logger.info(GeneralUtils.MultiValueMaptoJson(responseFormData));
		return ResponseEntity.ok().body(responseFormData);
	}

	@RequestMapping(value = "/callbackProcess103", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> returnEasyPayCallBack(@RequestBody String responseFormData, HttpServletRequest request)
			throws ParseException, Exception {
		logger.info("EasyPay return callback::" + responseFormData);
		HttpServletRequest req = (HttpServletRequest) request;
		String ipaddress = Utility.getClientIp(req);
		logger.info("CallBack IP address::" + ipaddress);
		String whiteips = "13.234.228.182, 35.154.144.67";
		if (whiteips.contains(ipaddress)) {
			EasePayCallBackResp status = easyPayUtility.callBackTransactionStatus(responseFormData);
			return ResponseEntity.ok().body(status);
		} else {
			return ResponseEntity.ok().body(new EasePayCallBackResp("302", "FAILED", "Invalid Request"));
		}
	}
	// String success = "{\"RESP_CODE\": 300,\"RESPONSE\": \"Success\",\"RESP_MSG\":
	// \"Status Updated Successfully\"}";

	@Autowired
	EasyPayUtility easyPayUtility;

	@RequestMapping(value = "/returnProcess103/{orderId}", method = RequestMethod.GET)
	public String returnEasyPay(@PathVariable(value = "orderId") String orderId, Model model)
			throws ParseException, Exception {

		logger.info("EasyPay return::" + orderId);
		TransactionDetails transactionDetails = easyPayUtility.updateTransactionStatus(orderId);
		model = easyPayUtility.getResponseProcess(transactionDetails, model);
		return "paymentResponseToDynamicMerchant";
	}

	@Autowired
	IsgPgUtility isgPgUtility;

	@RequestMapping(value = "/returnProcess106U/{orderId}", method = RequestMethod.GET)
	public String returnUrlISGUPI(@PathVariable(value = "orderId") String orderId, Model model)
			throws ParseException, Exception {

		logger.info("Method  getSetuTransactionDetails() orderId :: " + orderId);

		model = isgPgUtility.ISGreturnUrlUPI(orderId, model);

		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/statusProcess106/{orderId}", method = RequestMethod.GET)
	public ResponseEntity<?> getISGStatusAPI(@PathVariable(value = "orderId") String orderId)
			throws ParseException, Exception {

		logger.info("Method  getSetuTransactionDetails() orderId :: " + orderId);

		return ResponseEntity.ok().body(isgPgUtility.getUPIDBStatusDetails(orderId, false));
	}

	@Autowired
	NeoCredUtility neoCredUtility;

	@RequestMapping(value = "/returnProcess107/{orderId}", method = RequestMethod.GET)
	public ResponseEntity<?> getNeoReturnAPI(@PathVariable(value = "orderId") String orderId)
			throws ParseException, Exception {

		logger.info("Method  getNeoTransactionDetails() orderId :: " + orderId);

		return ResponseEntity.ok().body(neoCredUtility.updateFinalStatus(orderId));
	}

	@RequestMapping(value = "/callbackProcess107", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> returnNeoCallBack(@RequestBody String responseFormData, HttpServletRequest request)
			throws ParseException, Exception {
		logger.info("Neo return callback::" + responseFormData);
		HttpServletRequest req = (HttpServletRequest) request;
		String ipaddress = Utility.getClientIp(req);
		logger.info("CallBack IP address::" + ipaddress);

		EasePayCallBackResp status = neoCredUtility.callBackTransactionStatus(responseFormData);
		return ResponseEntity.ok().body(status);

	}

	@RequestMapping(value = "/statusProcess107/{orderId}", method = RequestMethod.GET)
	public ResponseEntity<?> getNeoStatusAPI(@PathVariable(value = "orderId") String orderId)
			throws ParseException, Exception {

		logger.info("Method  getNeoTransactionDetails() orderId :: " + orderId);

		return ResponseEntity.ok().body(neoCredUtility.getUPIDBStatusDetails(orderId));
	}
	@Autowired
	NimbleUtility nimbleUtility;
	
	@RequestMapping(value = "/returnProcessU108/{orderId}", method = RequestMethod.GET )
	public String getNimbUpiReturnAPI(@PathVariable(value = "orderId") String orderId, Model model)
			throws ParseException, Exception {

		logger.info("Method  getNimbTransactionDetails() orderId :: " + orderId);
		TransactionDetails transactionDetails = nimbleUtility.updateTransactionStatus(orderId, "UPI");
		model = nimbleUtility.getResponseProcess(transactionDetails, model);
		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/returnProcess108", method = RequestMethod.GET)
	public String getNimbReturnAPI(Model model, @RequestParam String response)
			throws ParseException, Exception {
				logger.info(Utility.decodeBase64(response));

		TransactionDetails transactionDetails = nimbleUtility.updateTransactionStatus(Utility.decodeBase64(response),"OTHERS");
		model = nimbleUtility.getResponseProcess(transactionDetails, model);
		return "paymentResponseToMerchant";
	}

	@RequestMapping(value = "/callbackProcess108", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> returnNimbCallBack(@RequestBody String responseFormData, HttpServletRequest request)
			throws ParseException, Exception {
		logger.info("Neo return callback::" + responseFormData);
		HttpServletRequest req = (HttpServletRequest) request;
		String ipaddress = Utility.getClientIp(req);
		logger.info("CallBack IP address::" + ipaddress);

		EasePayCallBackResp status = neoCredUtility.callBackTransactionStatus(responseFormData);
		return ResponseEntity.ok().body(status);

	}

	@RequestMapping(value = "/statusProcess108/{orderId}", method = RequestMethod.GET)
	public ResponseEntity<?> getNimbStatusAPI(@PathVariable(value = "orderId") String orderId)
			throws ParseException, Exception {

		logger.info("Method  getNimbTransactionDetails() orderId :: " + orderId);

		return ResponseEntity.ok().body(nimbleUtility.getStatusCheck(orderId));
	}

	// RETURN URL ENDPOINT PAYAID

	@Autowired
	PayaidUtility payaidUtility ;


	@RequestMapping(value = "/returnProcess109", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> returnPaidReturn(@RequestBody MultiValueMap<String, String> responseFormData)
			throws ParseException, Exception {
				logger.info(GeneralUtils.MultiValueMaptoJson(responseFormData));
				payaidUtility.updateTransactionStatus(responseFormData);
				return ResponseEntity.ok().body(responseFormData);

	}

	// CALLBACK URL FOR AXIS BANK
	@RequestMapping(value = "/callbackProcess110", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> returnAxisCallBack(@RequestBody String responseFormData, HttpServletRequest request)
			throws ParseException, Exception {
		logger.info("Axis return callback::" + responseFormData);
		HttpServletRequest req = (HttpServletRequest) request;
		String ipaddress = Utility.getClientIp(req);
		logger.info("CallBack IP address::" + ipaddress);
		axisUtility.callBackTransactionStatus(responseFormData);
		return ResponseEntity.ok().body("status");

	}



}

