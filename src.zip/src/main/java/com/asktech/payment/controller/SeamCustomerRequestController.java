package com.asktech.payment.controller;

import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.asktech.payment.constant.ErrorValues;
import com.asktech.payment.enums.FormValidationExceptionEnums;
import com.asktech.payment.exception.FormValidationException;
import com.asktech.payment.exception.SessionExpiredException;
import com.asktech.payment.exception.ValidationExceptions;
import com.asktech.payment.model.MerchantDetails;
import com.asktech.payment.repository.BankListRepository;
import com.asktech.payment.repository.customeinterface.IBankList;
import com.asktech.payment.security.Encryption;
import com.asktech.payment.service.PGGatewayService;
import com.asktech.payment.service.PGNonSeamLessService;
import com.asktech.payment.service.PaymentVerification;
import com.asktech.payment.service.UserRequestSeamService;
import com.asktech.payment.util.EncryptSignature;
import com.asktech.payment.util.GeneralUtils;
import com.asktech.payment.util.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;

@Controller
public class SeamCustomerRequestController implements ErrorValues {

	static Logger logger = LoggerFactory.getLogger(SeamCustomerRequestController.class);

	@Autowired
	UserRequestSeamService userRequestSeamService;
	@Autowired
	PGGatewayService pgGatewayServiceCashFree;
	@Autowired
	PaymentVerification service;
	@Autowired
	PGNonSeamLessService pGNonSeamLessService;
	@Autowired
	PGGatewayService pgGatewayService;
	@Value("${merApiEndPoint}")
	String merApiEndPoint;
	@Value("${apiEndPoint}")
	String apiEndPoint;
	@Autowired
	BankListRepository bankListRepository;

	@RequestMapping(value = "/custreq", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String custreq(@RequestBody MultiValueMap<String, String> formData, Model model,
			HttpServletResponse response, @RequestHeader("User-Agent") String useragent, ServletRequest request)
			throws FormValidationException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			ValidationExceptions {
		logger.info("Inside SeamCustomerRequestController :: custreq()");
		logger.info("Request Agent :: " + useragent);
		String sessionToken = "";
		String errmsg = "";
		HttpServletRequest req = (HttpServletRequest) request;
		String ipaddress = Utility.getClientIp(req);

		sessionToken = pGNonSeamLessService.getRequestProcess(formData, model, useragent, ipaddress);

		model.addAttribute("cardnumber", "None");
		System.out.println(sessionToken);
		model.addAttribute("tk", sessionToken);
		if (!sessionToken.equals("")) {
			return "paymentpage";
		} else {
			model.addAttribute("errormsg", errmsg);
			return "error";

		}

	}



	@RequestMapping(value = "/paymentPageSubmit", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String paymentPageSubmit(@RequestBody MultiValueMap<String, String> formData, Model model,
			HttpServletRequest request, @RequestHeader("User-Agent") String device)
			throws ValidationExceptions, SessionExpiredException, JsonProcessingException, ParseException,
			GeneralSecurityException, GeneralSecurityException {

		String page = "error";
		String sessionToken = "";
		sessionToken = formData.getFirst("tk");
		if (sessionToken.length() < 5) {
			logger.info("Session key not found");
			throw new ValidationExceptions("Invalid Session", FormValidationExceptionEnums.E0052);
		}
		device = Utility.deviceType(device);
		String ipAddress = Utility.getClientIp(request);
		logger.info("Device Type::" + device);
		try {
			page = pGNonSeamLessService.getSubmitPayment(formData, model, sessionToken, device, ipAddress);
		} catch (Exception e) {
			model.addAttribute("errormsg", e.getMessage());
		}
		return page;
	}


	@RequestMapping(value = "/customerLink/{merchantId}", method = RequestMethod.GET)
	public String customerLink(@PathVariable(value = "merchantId") String merchantId, Model model)
			throws ParseException, Exception {
		logger.info("Request from Merchant for permanent link");

		MerchantDetails merchantdetails = pgGatewayService.getMerchantDetailsByMerchantId(merchantId);
		if (merchantdetails == null) {
			throw new ValidationExceptions(INVALID_MERCHANT_DETAILS,
					FormValidationExceptionEnums.E0087);
		}
		model.addAttribute("merchantId", merchantId);
		model.addAttribute("merchantAppId", merchantdetails.getAppID());
		model.addAttribute("source", "PERMALINK");
		model.addAttribute("title", merchantdetails.getCompanyName());
		String storedSignature = Encryption.decryptCardNumberOrExpOrCvv(merchantdetails.getSecretId());
		String hashstr = merchantId + "|" + merchantdetails.getAppID() + "|" + "PERMALINK";
		model.addAttribute("sec", EncryptSignature.getSecretHash(hashstr, storedSignature));
		model.addAttribute("base_url", merApiEndPoint);
		model.addAttribute("returnUrl", apiEndPoint + "/paymentNotify");
		return "paymentDetails.html";
	}

	@RequestMapping(value = "/paymentNotify", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String paymentNotify(@RequestBody MultiValueMap<String, String> responseFormData, Model model)
			throws ParseException, Exception {

		logger.info("Method  testConsume()");
		logger.info("testConsume Request From UI :: " + responseFormData.toString());
		Map<String, String> resdt = GeneralUtils.convertMultiToRegularMap(responseFormData);
		System.out.println(resdt);
		model.addAllAttributes(resdt);
		// pgGatewayService.updateTransactionStatus(responseFormData);
		return "paymentNotify.html";
	}

	@RequestMapping(value = "/mobresp", method = RequestMethod.GET)
	public String mobresp(Model model)
			throws ParseException, Exception {
		logger.info("Method  testConsume()");
		// pgGatewayService.updateTransactionStatus(responseFormData);
		return "mobileresp.html";
	}
	@RequestMapping(value = "/paymentpage", method = RequestMethod.GET)
	public String paymentpage(HttpServletResponse response, @RequestHeader("User-Agent") String useragent,
			ServletRequest request, Model model)
			throws FormValidationException, InvalidKeyException, NoSuchAlgorithmException, JsonProcessingException,
			ValidationExceptions {
		List<IBankList> banklist = bankListRepository.findMerchantBankList("624947050390");
		model.addAttribute("banklist", banklist);
		model.addAttribute("nbactive", true);
		return "paymentPage/desktop";

	}
}