package com.asktech.payment.controller;

import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.asktech.payment.service.webhook.WebhookServiceAsanpay;
import com.asktech.payment.service.webhook.WebhookServiceGrezPay;
import com.asktech.payment.service.webhook.WebhookServiceLetsPay;

@Controller
public class WebhookController {

	static Logger logger = LoggerFactory.getLogger(PGGatewayController.class);

	@Autowired
	WebhookServiceAsanpay webhookServiceAsanpay;
	@Autowired
	WebhookServiceGrezPay webhookServiceGrezPay;
	@Autowired
	WebhookServiceLetsPay webhookServiceLetsPay;

	@RequestMapping(value = "/webhook/cashfree", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> webhookCashfree(@RequestBody MultiValueMap<String, String> responseFormData)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest() Notify");
		logger.info("CashFree Response From PG :: " + responseFormData.toString());

		return ResponseEntity.ok().body("The request has been received..");

	}

	@RequestMapping(value = "/webhook/asanpay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> webhookAsanpay(@RequestBody MultiValueMap<String, String> responseFormData)
			throws ParseException, Exception {

		logger.info("Method  webhookAsanpay() Notify");
		logger.info("AsanPay Response From PG :: " + responseFormData.toString());

		return ResponseEntity.ok().body(webhookServiceAsanpay.updateWebhookAsanPay(responseFormData));

	}

	@RequestMapping(value = "/webhook/grezpay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> webhookGrezpay(@RequestBody MultiValueMap<String, String> responseFormData)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest() Notify");
		logger.info("GrezPay Response From PG :: " + responseFormData.toString());

		return ResponseEntity.ok().body(webhookServiceGrezPay.updateWebhookAsanPay(responseFormData));

	}

	@RequestMapping(value = "/webhook/getepay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> webhookGetepay(@RequestBody MultiValueMap<String, String> responseFormData)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest() Notify");
		logger.info("Getepay Response From PG :: " + responseFormData.toString());

		return ResponseEntity.ok().body("The request has been received..");

	}

	@RequestMapping(value = "/webhook/letzpay", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> webhookLetzpay(@RequestBody MultiValueMap<String, String> responseFormData)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest() Notify");
		logger.info("LetzPay Response From PG :: " + responseFormData.toString());

		return ResponseEntity.ok().body(webhookServiceLetsPay.updateWebhookLetsPay(responseFormData));

	}

	@RequestMapping(value = "/webhook/payu", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<?> webhookpayu(@RequestBody MultiValueMap<String, String> responseFormData)
			throws ParseException, Exception {

		logger.info("Method  webhookRequest() Notify");
		logger.info("PayU Response From PG :: " + responseFormData.toString());

		return ResponseEntity.ok().body("The request has been received..");

	}

}
