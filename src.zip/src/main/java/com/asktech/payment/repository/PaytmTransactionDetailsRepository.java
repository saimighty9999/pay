package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.PaytmTransactionDetails;

public interface PaytmTransactionDetailsRepository extends JpaRepository<PaytmTransactionDetails, String> {
    PaytmTransactionDetails findByOrderId(String string);
}
