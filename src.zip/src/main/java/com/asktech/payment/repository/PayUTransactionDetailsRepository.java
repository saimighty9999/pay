package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.PayUTransactionDetails;

public interface PayUTransactionDetailsRepository extends JpaRepository<PayUTransactionDetails, String>{

	PayUTransactionDetails findByOrderId(String string);

	PayUTransactionDetails findByMerchantOrderIdAndOrderId(String merchantOrderId, String orderID);

}
