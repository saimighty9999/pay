package com.asktech.payment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.asktech.payment.model.TransactionDetails;

public interface TransactionDetailsRepository extends JpaRepository<TransactionDetails, String> {

	TransactionDetails findByOrderIDAndStatus(String string, String string2);

	List<TransactionDetails> findAllByMerchantId(String id);

	TransactionDetails findByOrderID(String string);

	List<TransactionDetails> findAllByMerchantIdAndMerchantOrderId(String merchantID, String string);

	TransactionDetails findByOrderIDAndAndMerchantId(String string, String string2);

	TransactionDetails findByMerchantIdAndMerchantOrderId(String merchantId, String orderId);

	@Query(value = "SELECT sum(amount) amount FROM transaction_details where pg_type = :pgtype and status = 'SUCCESS' and date(created) = date(now());", nativeQuery = true)
	String getPgLimitTotal(@Param("pgtype") String pgtype);

}
