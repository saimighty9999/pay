package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.EaseBuzzTransactionDetails;

public interface EaseBuzzTransactionDetailsRepository extends JpaRepository<EaseBuzzTransactionDetails, String> {

	EaseBuzzTransactionDetails findByMerchantOrderIdAndOrderId(String merchantOrderId, String checkResponseData);

}
