package com.asktech.payment.repository.seam;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.seam.CustomerRequest;

public interface CustomerRequestRepository extends JpaRepository<CustomerRequest, String>{

	CustomerRequest findAllByUuid(String uuid);
	CustomerRequest findAllBySessionToken(String sessionToken);
	CustomerRequest findByMerchantIdAndOrderId(String merchantId, String orderId);
}
