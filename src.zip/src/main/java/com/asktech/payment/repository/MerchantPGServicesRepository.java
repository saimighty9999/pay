package com.asktech.payment.repository;

import java.util.List;

import com.asktech.payment.model.MerchantPGServices;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MerchantPGServicesRepository extends JpaRepository<MerchantPGServices, String>{

	MerchantPGServices findByMerchantIDAndService(String merchantId, String service);

	List<MerchantPGServices> findByMerchantID(String merchantId);

	List<MerchantPGServices> findByMerchantIDAndPgID(String merchantId, String pgid);

	MerchantPGServices findByMerchantIDAndPgIDAndService(String merchantId, String valueOf, String service);

	List<MerchantPGServices> findAllByPgIDAndService(String pgid, String service);

	MerchantPGServices findByMerchantIDAndPgIDAndServiceAndStatus(String merchantID, String pgID, String service,
			String status);
	
	List<MerchantPGServices> findAllByMerchantIDAndStatus(String merchantID, String status);

	MerchantPGServices findByMerchantIDAndServiceAndStatus(String merchantId, String service, String status);
}
