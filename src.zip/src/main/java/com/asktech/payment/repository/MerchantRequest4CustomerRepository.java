package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.MerchantRequest4Customer;

public interface MerchantRequest4CustomerRepository extends JpaRepository<MerchantRequest4Customer, String> {

	MerchantRequest4Customer findByLinkCustomer(String dynamicStr);

	MerchantRequest4Customer findByOrderIdAndMerchantId(String merchantOrderId, String merchantId);

}
