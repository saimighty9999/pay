package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.TransactionDetailsAll;

public interface TransactionDetailsAllRepository extends JpaRepository<TransactionDetailsAll, String>{

}
