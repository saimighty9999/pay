package com.asktech.payment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.asktech.payment.model.PGConfigurationDetails;

public interface PGConfigurationDetailsRepository  extends JpaRepository<PGConfigurationDetails, String>{

	List<PGConfigurationDetails> findAllByPgUuid(String pgUuid);

	PGConfigurationDetails findByPgUuid(String pgUuid);

	PGConfigurationDetails findByPgName(String pgName);

	PGConfigurationDetails findByPgAppId(String valueOf);

	@Query(value = "SELECT  * FROM  pgconfiguration_details WHERE pg_uuid IN (SELECT b.pgid FROM merchantpgdetails a, merchantpgservices b WHERE a.merchantpgid = b.pgid AND b.status = 'ACTIVE' AND a.status = 'ACTIVE' AND b.merchantid = :merchantid AND a.merchantid = :merchantid AND b.service = :service)", nativeQuery = true) 
	PGConfigurationDetails getByPgUuidAndService(@Param("merchantid") String merchantid, @Param("service") String service);

}
