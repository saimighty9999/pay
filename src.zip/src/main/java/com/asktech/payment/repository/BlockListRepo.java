package com.asktech.payment.repository;

import java.util.List;

import com.asktech.payment.model.BlockList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface BlockListRepo extends JpaRepository<BlockList, String> {
    List<BlockList> findByVpaid(String vpaid);

    List<BlockList> findByCardno(String cardno);

    List<BlockList> findByIpaddress(String ipaddress);

    List<BlockList> findByPhonenumber(String phonenumber);

    List<BlockList> findByEmail(String email);

    List<BlockList> findByMerchantid(String merchantid);
    
    List<BlockList> findByAppid(String appid);

    @Query(value = "SELECT * FROM block_list where urlstring like '%:urlstring%'", nativeQuery = true)
    List<BlockList> getByUrlstring(@Param("urlstring") String urlstring);
}
