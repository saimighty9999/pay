package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.ResponstToMerchantDetails;

public interface ResponstToMerchantDetailsRepository extends JpaRepository<ResponstToMerchantDetails, String>{

}
