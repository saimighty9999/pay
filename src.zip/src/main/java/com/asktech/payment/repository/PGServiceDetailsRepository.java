package com.asktech.payment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.PGServiceDetails;

public interface PGServiceDetailsRepository extends JpaRepository<PGServiceDetails, String>{

	PGServiceDetails findByPgIdAndPgServices(String pgId, String upperCase);

	List<PGServiceDetails> findByPgId(String pgId);

	PGServiceDetails findByPgServicesAndDefaultService(String upperCase, String string);

}
