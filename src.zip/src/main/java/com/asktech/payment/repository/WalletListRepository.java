package com.asktech.payment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.asktech.payment.model.WalletList;
import com.asktech.payment.repository.customeinterface.IWalletList;

public interface WalletListRepository extends JpaRepository<WalletList, String>{
	
	List<WalletList> findAllByPgnameAndStatus(String pgname, String status);
	WalletList findByPaymentcode(String paymentcode);
	WalletList findByPaymentcodeAndPgnameAndStatus(String string, String merchantPGNme, String string2);
	
	@Query(value = "SELECT paymentcode, walletname FROM wallet_list  where merchant_id = :merchant_id and status = 'ACTIVE'", nativeQuery = true)
	List<IWalletList> findMerchantWalletList(@Param("merchant_id") String merchant_id);
	
	@Query(value = "SELECT * FROM wallet_list  where merchant_id = :merchant_id and status = :status and paymentcode = :wallet", nativeQuery = true)
	WalletList findMerchantWallet(@Param("merchant_id") String merchant_id, @Param("status") String status, @Param("wallet") String wallet);

//	WalletList findByPaymentcodeAndStatusMerchant_id(String wallet, String string, String merchant_id);
	
	

	WalletList findByPaymentcodeAndMerchantIdAndStatusAndPgname(String paymentCode, String merchantId, String status, String pgName);
	WalletList findByPaymentcodeAndMerchantIdAndStatus(String paymentCode, String merchantId, String status);

}
