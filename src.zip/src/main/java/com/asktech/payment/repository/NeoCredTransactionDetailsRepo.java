package com.asktech.payment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.NeoCredTransactionDetails;

public interface NeoCredTransactionDetailsRepo extends JpaRepository<NeoCredTransactionDetails, String> {
    List<NeoCredTransactionDetails> findByUpiId(String upi);

    NeoCredTransactionDetails findByOrderId(String id);
}
