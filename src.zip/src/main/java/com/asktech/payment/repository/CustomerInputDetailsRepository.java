package com.asktech.payment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.asktech.payment.model.CustomerInputDetails;

public interface CustomerInputDetailsRepository extends JpaRepository<CustomerInputDetails, String> {
    List<CustomerInputDetails> findByTrxTypeAndPaymentInfo(String trxType, String paymentInfo);
   
    @Query(value = "select * from  customer_input_details where payment_info = :paymentInfo and trx_type = :trxType and date(created) = date(now());", nativeQuery = true)
    List<CustomerInputDetails> getTodaysInputDetails(@Param("trxType") String trxType, @Param("paymentInfo") String paymentInfo);
}
