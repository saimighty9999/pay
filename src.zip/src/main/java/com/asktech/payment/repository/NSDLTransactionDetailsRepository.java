package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.NSDLTransactionDetails;

public interface NSDLTransactionDetailsRepository extends JpaRepository<NSDLTransactionDetails, String> {

	NSDLTransactionDetails findByOrderId(String orderId);

}
