package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.SetuWebhookResponse;

public interface SetuWebhookResponseRepository extends JpaRepository<SetuWebhookResponse, String>{

}
