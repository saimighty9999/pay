package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.WalletPaymentDetails;

public interface WalletPaymentDetailsRepository extends JpaRepository<WalletPaymentDetails, String>{

}
