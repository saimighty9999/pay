package com.asktech.payment.repository.customeinterface;

public interface IWalletList {

		String getPaymentCode();
		String getWalletName();

}
