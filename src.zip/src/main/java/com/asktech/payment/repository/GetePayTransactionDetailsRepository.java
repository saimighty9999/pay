package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.GetePayTransactionDetails;
import com.asktech.payment.model.GrezPayTransactionDetails;

public interface GetePayTransactionDetailsRepository extends JpaRepository<GetePayTransactionDetails, String> {

	GetePayTransactionDetails findByOrderId(String orderId);

}
