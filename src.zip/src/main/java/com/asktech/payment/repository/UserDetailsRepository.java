package com.asktech.payment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.UserDetails;

public interface UserDetailsRepository extends JpaRepository<UserDetails, String> {

	//List<UserDetails> findAllByEmailIdAndPhoneNumberAndCardNumberAndMerchantId(String customerEmail, String customerPhone,String card_number, String string);

	List<UserDetails> findAllByEmailIdAndPhoneNumberAndMerchantId(String customerEmail, String customerPhone,
			String string);

	List<UserDetails> findAllByEmailIdOrPhoneNumber(String custEmailorPhone, String custEmailorPhone2);

	/*
	UserDetails findAllByEmailIdAndPhoneNumberAndMerchantIdAndCustomerNameAndPaymentOptionAndPaymentCode(String emailId,
			String phoneNumber, String merchantId, String customerName, String paymentOption, String paymentCode);

	List<UserDetails> findAllByEmailIdAndPhoneNumberAndPaymentCodeAndMerchantId(String string, String string2, String string3,
			String merchantID);

	List<UserDetails> findAllByEmailIdAndPhoneNumberAndVpaUPIAndMerchantId(String string, String string2, String string3,
			String merchantID);
			*/

	UserDetails findById(long userID);

}
