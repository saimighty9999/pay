package com.asktech.payment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.asktech.payment.model.SabPaisaTransactionDetails;

public interface SabPaisaTransactionDetailsRepository extends JpaRepository<SabPaisaTransactionDetails, String> {

	SabPaisaTransactionDetails findByTxnId(String orderId);

	List<SabPaisaTransactionDetails> findByUpiId(String upiId);

	@Query(value = "SELECT * FROM sab_paisa_transaction_details where upi_id = :upiId and date(created) = CURDATE()", nativeQuery = true)
	List<SabPaisaTransactionDetails> getByUpiIdAndDate(@Param("upiId")  String upiId);

}
