package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.LetzpayTransactionDetails;

public interface LetzpayTransactionDetailsRepository extends JpaRepository<LetzpayTransactionDetails, String>{

	LetzpayTransactionDetails findByOrderId(String string);

}
