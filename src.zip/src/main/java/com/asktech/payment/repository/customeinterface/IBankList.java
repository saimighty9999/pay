package com.asktech.payment.repository.customeinterface;

public interface IBankList {
	String getBankCode();
	String getBankName();
	String getEntity_banner();
	String getEntity_banner_enable();
}
