package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.GrezPayTransactionDetails;

public interface GrezPayTransactionDetailsRepository extends JpaRepository<GrezPayTransactionDetails, String> {

	GrezPayTransactionDetails findByOrderId(String orderId);

}
