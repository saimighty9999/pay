package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.OnePayTransactionDetails;

public interface OnePayTransactionDetailsRepository extends JpaRepository<OnePayTransactionDetails, String> {

	OnePayTransactionDetails findByMerchantOrderIdAndOrderId(String merchantOrderId, String txnId);

}
