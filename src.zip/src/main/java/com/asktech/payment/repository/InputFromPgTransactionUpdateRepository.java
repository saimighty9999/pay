package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.InputFromPgTransactionUpdate;

public interface InputFromPgTransactionUpdateRepository extends JpaRepository<InputFromPgTransactionUpdate, String>{

}
