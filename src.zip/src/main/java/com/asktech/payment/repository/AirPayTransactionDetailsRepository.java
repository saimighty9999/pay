package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.AirPayTransactionDetails;

public interface AirPayTransactionDetailsRepository extends JpaRepository<AirPayTransactionDetails, String> {

	AirPayTransactionDetails findByOrderId(String orderid);
}
