package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.PgProfile;


public interface PgProfileRepo extends JpaRepository<PgProfile, String>{

}
