package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.RazorPayTransactionDetails;

public interface RazorPayTransactionDetailsRepository extends JpaRepository<RazorPayTransactionDetails, String> {

	RazorPayTransactionDetails findByRazorPayOrderId(String razorPayOrderId);
	RazorPayTransactionDetails findByOrderId(String orderId);

}
