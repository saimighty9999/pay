package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.AtomTransactionDetails;

public interface AtomTransactionDetailsRepository extends JpaRepository<AtomTransactionDetails, String> {

	AtomTransactionDetails findByMerchantOrderIdAndOrderId(String merchantOrderId, String string);

	AtomTransactionDetails findByOrderId(String orderId);
	
}
