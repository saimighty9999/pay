package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.ICICIBankTransactionDetails;

public interface ICICIBankTransactionDetailsRepository extends JpaRepository<ICICIBankTransactionDetails, String> {

	ICICIBankTransactionDetails findByMerchantOrderIdAndOrderId(String merchantOrderId, String checkResponseData);

}
