package com.asktech.payment.repository;

import com.asktech.payment.model.PgErrorCodes;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PgErrorCodeRepository extends JpaRepository<PgErrorCodes, String> {
    PgErrorCodes findByPgNameAndPgStatusCode(String pgname, String errorCode);
}
