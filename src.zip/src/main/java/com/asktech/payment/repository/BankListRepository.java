package com.asktech.payment.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.asktech.payment.model.BankList;
import com.asktech.payment.repository.customeinterface.IBankList;

@Repository
@Transactional
public interface BankListRepository extends JpaRepository<BankList, String>{
	List<BankList> findAllByBankcode(String code);
	
	BankList findAllByBankcodeAndPgName(String bankCode, String pgName);

	BankList findAllByBankcodeAndPgNameAndStatus(String string, String merchantPGNme, String string2);
	
	@Query(value = "SELECT  b.bankcode, b.bankname, a.entity_banner, a.entity_banner_enable FROM pg_profile a JOIN bank_list b on a.entity_code = b.bankcode and merchant_id = :merchant_id and b.status = 'ACTIVE'",nativeQuery = true) 
	List<IBankList> findMerchantBankList(@Param("merchant_id") String merchant_id);

		
	
	BankList findAllByBankcodeAndMerchantIdAndStatus(String paymentCode, String merchantId, String status);
	BankList findAllByBankcodeAndMerchantIdAndStatusAndPgName(String paymentCode, String merchantId, String status, String pgName);
}
