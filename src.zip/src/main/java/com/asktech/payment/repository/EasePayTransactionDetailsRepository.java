package com.asktech.payment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.payment.model.EasePayTransactionDetails;

public interface EasePayTransactionDetailsRepository extends JpaRepository<EasePayTransactionDetails, String> {

	EasePayTransactionDetails findByOrderId(String checkResponseData);

}
