package io.asktech.payout.service.cashfree.dto;

import org.springframework.stereotype.Component;

@Component
public class UpiVerificationDto {
    
}
