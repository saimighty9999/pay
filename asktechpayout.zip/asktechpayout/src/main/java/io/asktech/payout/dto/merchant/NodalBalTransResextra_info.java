package io.asktech.payout.dto.merchant;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter


public class NodalBalTransResextra_info {

	private String beneficiaryIfsc;
	private String creationTime;
	private String beneficiaryName;
	
}
