package io.asktech.payout.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;

import io.asktech.payout.dto.admin.ConfigPgMerchantDto;
import io.asktech.payout.dto.admin.PgConfigResponse;
import io.asktech.payout.dto.admin.PgCreationDto;
import io.asktech.payout.dto.admin.PgResponse;
import io.asktech.payout.dto.admin.TransactionChangeRequestDto;
import io.asktech.payout.dto.admin.TransactionReversalRequest;
import io.asktech.payout.exceptions.ValidationExceptions;
import io.asktech.payout.modal.merchant.MerchantPgConfig;
import io.asktech.payout.modal.merchant.PgDetails;
import io.asktech.payout.service.admin.ConfigPgMerchant;
import io.asktech.payout.service.admin.PgService;
import io.asktech.payout.service.admin.TransactionChangeRequestService;
import io.asktech.payout.service.admin.TransactionManagement;
import unirest.shaded.org.apache.http.ParseException;

@RestController
@RequestMapping("/controller")
public class PayoutAdmin {

    @Autowired
    PgService pgService;

    @PostMapping(value = "/pgCreation")
    public ResponseEntity<?> pgCreation(@RequestBody PgCreationDto dto)
            throws JsonProcessingException, ValidationExceptions, ParseException {
        PgDetails pgres = pgService.createPg(dto);

        return ResponseEntity.ok().body(new PgResponse("SUCCESS", pgres));
    }

    @PostMapping(value = "/pgUpdate")
    public ResponseEntity<?> pgUpdate(@RequestBody PgCreationDto dto)
            throws JsonProcessingException, ValidationExceptions, ParseException {
        PgDetails pgres = pgService.updatePg(dto);
        return ResponseEntity.ok().body(new PgResponse("SUCCESS", pgres));
    }

    @GetMapping(value = "/getAllPg")
    public ResponseEntity<?> getAllPg()
            throws JsonProcessingException, ValidationExceptions, ParseException {
        return ResponseEntity.ok().body(pgService.getAllPg());
    }

    @Autowired
    ConfigPgMerchant configPgMerchant;

    @PostMapping(value = "/configPgMerchant")
    public ResponseEntity<?> linkPgMerchant(@RequestBody ConfigPgMerchantDto dto)
            throws JsonProcessingException, ValidationExceptions, ParseException {
        MerchantPgConfig pgres = configPgMerchant.createConfigPgMerchant(dto);

        return ResponseEntity.ok().body(new PgConfigResponse("SUCCESS", pgres));
    }

    @PostMapping(value = "/updateConfigPgMerchant")
    public ResponseEntity<?> updateLinkPgMerchant(@RequestBody ConfigPgMerchantDto dto)
            throws JsonProcessingException, ValidationExceptions, ParseException {
        MerchantPgConfig pgres = configPgMerchant.updateConfigPgMerchant(dto);

        return ResponseEntity.ok().body(new PgConfigResponse("SUCCESS", pgres));
    }

    @GetMapping(value = "/getAllConfigPgMerchant")
    public ResponseEntity<?> getAllLinkPgMerchant()
            throws JsonProcessingException, ValidationExceptions, ParseException {
        return ResponseEntity.ok().body(configPgMerchant.getAllMerchantPgLinks());
    }

    @Autowired
    TransactionManagement transactionManagement;

    @PostMapping(value = "/transactionReversal")
    public ResponseEntity<?> transactionReversal(@RequestBody TransactionReversalRequest dto)
            throws JsonProcessingException, ValidationExceptions, ParseException {
        return ResponseEntity.ok().body(transactionManagement.transactionReversal(dto));
    }

    @PostMapping(value = "/walletRecharge")
    public ResponseEntity<?> walletRecharge(@RequestBody TransactionReversalRequest dto)
            throws JsonProcessingException, ValidationExceptions, ParseException {
        return ResponseEntity.ok().body(transactionManagement.transactionReversal(dto));
    }

    @Autowired
    private TransactionChangeRequestService transactionChangeRequestService;

    @PutMapping(value = "/updateTransactionStatus")
    public ResponseEntity<?> updateTransactionStatus(
            @RequestBody TransactionChangeRequestDto transactionChangeRequestDto)
            throws JsonProcessingException, ValidationExceptions, ParseException {
        return ResponseEntity.ok()
                .body(transactionChangeRequestService.updateTransactionStatus(transactionChangeRequestDto));
    }
}
