package io.asktech.payout.service.payg.dto;
import lombok.NoArgsConstructor;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AddContactErrorResponseInitiator {

   private List<AddContactErrorResponse> addContactErrorResponse;

}