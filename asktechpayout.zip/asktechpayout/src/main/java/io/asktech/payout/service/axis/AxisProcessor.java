package io.asktech.payout.service.axis;

import io.asktech.payout.dto.merchant.AccountTransferMerReq;
import io.asktech.payout.dto.merchant.AccountTransferUPIMerReq;
import io.asktech.payout.service.axis.dto.BenificaryDto;
import io.asktech.payout.dto.merchant.TransactionResponseMerRes;
import io.asktech.payout.dto.reqres.TransferStatusReq;
import io.asktech.payout.dto.reqres.WalletTransferRes;
import io.asktech.payout.modal.merchant.PgDetails;
import io.asktech.payout.modal.merchant.TransactionDetails;
import io.asktech.payout.service.IProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public class AxisProcessor implements IProcessor{

    @Autowired
    AxisUtility axisUtility;
    @Autowired
    AxisRequest axisRequest;

    @Override
    public WalletTransferRes doAccountTransfer(AccountTransferMerReq dto, String merchantid, PgDetails pg) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public TransactionResponseMerRes doWalletTransferStatus(TransferStatusReq dto, String merchantid,
            TransactionDetails transactionDetails, PgDetails pg) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public WalletTransferRes doAccountTransferUPI(AccountTransferUPIMerReq dto, String merchantid, PgDetails pg) {
        // TODO Auto-generated method stub
        return null;
    }


    public void doBenefiacryAdd(AccountTransferMerReq dto, String merchantid, PgDetails pg) throws JsonProcessingException{
        
        // CREATE THE BENEFICIARY REQUEST   
        BenificaryDto beneficaryRequest =  axisUtility.addBenificary(dto, merchantid, pg);

        // MAKE THE REQUEST
        axisRequest.addBeneficiaryRequest(beneficaryRequest);

    }
    
}
