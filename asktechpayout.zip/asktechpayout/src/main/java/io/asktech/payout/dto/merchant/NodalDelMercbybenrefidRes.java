package io.asktech.payout.dto.merchant;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class NodalDelMercbybenrefidRes {
	
	private String success;
	private String code;
	private String errorCode;
	private String status;
	private String message;
}
