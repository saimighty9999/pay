package io.asktech.payout.wallet.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CommissionFieldRes {
	
	private String commType;
	private String adderValue;

}
