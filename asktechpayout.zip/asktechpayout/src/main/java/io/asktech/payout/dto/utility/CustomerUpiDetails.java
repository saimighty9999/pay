package io.asktech.payout.dto.utility;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerUpiDetails {
    private String name;
    private String vpa;
}
