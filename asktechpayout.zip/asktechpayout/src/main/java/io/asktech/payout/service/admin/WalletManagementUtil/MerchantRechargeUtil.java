package io.asktech.payout.service.admin.WalletManagementUtil;

import org.springframework.stereotype.Component;

import io.asktech.payout.modal.admin.MerchantRecharge;

@Component
public class MerchantRechargeUtil {

    public boolean merchantRechargeSave(MerchantRecharge merchantRecharge) {
        
        return true;
    }

    public void getMerchantRechargeByMerchantId(String merchantId) {

    }

    public void getMerchantRechargeByDate(String fromDate, String toDate) {

    }

    public void getMerchantRechargeId(String rechargeId) {

    }

}
