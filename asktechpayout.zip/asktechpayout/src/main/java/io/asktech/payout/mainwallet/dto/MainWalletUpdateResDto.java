package io.asktech.payout.mainwallet.dto;

public class MainWalletUpdateResDto {

}
