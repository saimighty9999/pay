package io.asktech.payout.repository.reqres;

import org.springframework.data.jpa.repository.JpaRepository;

import io.asktech.payout.modal.reqres.MerAddFundreq;

public interface MerAddFundreqRepo extends JpaRepository<MerAddFundreq ,String>{

}
