package io.asktech.payout.constants;

public interface PaytmWalletConstants {

	String FAILURE = "FAILURE";
	String SUCCESS = "SUCCESS";
	String WALLET = "WALLET";
	String ACCOUNT = "ACCOUNT";
	String PENDING = "PENDING";
	
	String DATE_FORMAT = "yyyy-MM-dd";
}
