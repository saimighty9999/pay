package io.asktech.payout.enums;

public enum WalletExceptionEnums {
	FATAL_EXCEPTION, 
	ALL_FIELDS_MANDATORY ;

	WalletExceptionEnums() {

	}
}
