package io.asktech.payout.dto.reqres.cashfree;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthenticationResData {

	   private String expiry;
	   private String token;
}
