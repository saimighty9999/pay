package io.asktech.payout.dto.nodal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayTmNodalCheckTXNstatusResextra_info {
	private String beneficiary_name;
	private String custom_pmt_status_lag;
}
