package io.asktech.payout.repository.merchant;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import io.asktech.payout.modal.merchant.TransactionDetails;

public interface TransactionDetailsRepo extends JpaRepository<TransactionDetails, String> {

	TransactionDetails findByOrderId(String orderId);

	List<TransactionDetails> findByOrderIdAndMerchantId(String orderId, String merchantid);

	List<TransactionDetails> findByTransactionStatusAndMerchantId(String status, String merchantid);

	List<TransactionDetails> findByTransactionStatus(String status);
	
	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where"
			+ " tr.bankaccount = :bankaccount order by sno desc limit 5000", nativeQuery = true)
	List<TransactionDetails> findByBankaccount(String bankaccount);
	
	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where"
			+ " tr.beneficiaryName = :bankName order by sno desc limit 5000", nativeQuery = true)
	List<TransactionDetails> findByBeneficiaryName(String bankName);
	
	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where"
			+ " tr.ifsc = :ifsc order by sno desc limit 5000", nativeQuery = true)
	List<TransactionDetails> findByIfsc(String ifsc);
	
	List<TransactionDetails> findByBankaccountAndBeneficiaryNameAndIfsc(String bankaccount, String bankName, String ifsc);
	
	List<TransactionDetails> findByBankaccountAndBeneficiaryName(String bankaccount, String bankName);
	
	List<TransactionDetails> findByBeneficiaryNameAndIfsc(String bankName, String ifsc);

	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where tr.merchantId= :merchant_id "
			+ "and date(tr.created) = :dateFrom", nativeQuery = true)
	List<TransactionDetails> findTransactionDate(@Param("merchant_id") String merchantid,
			@Param("dateFrom") String dateFrom);

	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where tr.merchantId= :merchant_id "
			+ "and date(tr.created) = :dateFrom  and status = :status", nativeQuery = true)
	public List<TransactionDetails> getTransactionDateAndTransactionStatus(@Param("merchant_id") String merchant_id,
			@Param("dateFrom") String dateFrom, @Param("status") String status);
	
	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where  date(tr.created) >= :dateFrom", nativeQuery = true)
	public List<TransactionDetails> getTransactionDateFrom(@Param("dateFrom") String dateFrom);
	
	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where  date(tr.created) <= :dateTo", nativeQuery = true)
	public List<TransactionDetails> getTransactionDateTo(@Param("dateTo") String dateTo);

	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where tr.merchantId= :merchant_id "
			+ "and date(tr.created) between :dateFrom and :dateTo and status = :status", nativeQuery = true)
	public List<TransactionDetails> getTransactionDateRangeAndTransactionStatus(
			@Param("merchant_id") String merchant_id,
			@Param("dateFrom") String dateFrom, @Param("dateTo") String dateTo, @Param("status") String status);
	
	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where"
			+ " date(tr.created) between :dateFrom and :dateTo and tr.transactionStatus = :status", nativeQuery = true)
	public List<TransactionDetails> getByDateAndTransactionStatus(@Param("dateFrom") String dateFrom, @Param("dateTo") String dateTo, @Param("status") String status);

	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where"
			+ " date(tr.created) between :dateFrom and :dateTo and tr.bankaccount = :bankaccount", nativeQuery = true)
	public List<TransactionDetails> getByDateAndBankAccount(@Param("dateFrom") String dateFrom, @Param("dateTo") String dateTo, @Param("bankaccount") String bankaccount);

	
	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where"
			+ " date(tr.created) between :dateFrom and :dateTo and tr.transactionType like :transactionType", nativeQuery = true)
	public List<TransactionDetails> getByDateAndTransactionType(@Param("dateFrom") String dateFrom, @Param("dateTo") String dateTo, @Param("transactionType") String transactionType);
	
	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where date(tr.created) between :dateFrom and :dateTo", nativeQuery = true)
	public List<TransactionDetails> getTransactionDateRange(@Param("dateFrom") String dateFrom, @Param("dateTo") String dateTo);
	
	@Query(value = "select tr.* " + "from TransactionDetails tr " + "where tr.merchantId= :merchant_id "
			+ "and date(tr.created) between :dateFrom and :dateTo ", nativeQuery = true)
	public List<TransactionDetails> getTransactionDateRange(@Param("merchant_id") String merchant_id,
			@Param("dateFrom") String dateFrom, @Param("dateTo") String dateTo);

	@Query(value = "select * from TransactionDetails tr "
			+ "where created between (NOW() - INTERVAL 14 MINUTE) and (NOW() - INTERVAL 3 MINUTE) "
			+ "and transactionStatus = 'PENDING' and internalOrderId is not null "
			+ "and (reconStatus <>'R0' or reconStatus is null) order by sno", nativeQuery = true)
	List<TransactionDetails> getAllRecordsForPayout5Minutes();

	@Query(value = "select * from TransactionDetails tr "
			+ "where created between (NOW() - INTERVAL 20 MINUTE) and (NOW() - INTERVAL 10 MINUTE) "
			+ "and transactionStatus = 'PENDING' and internalOrderId is not null "
			+ "and (reconStatus <>'R1' or reconStatus is null) order by sno", nativeQuery = true)
	List<TransactionDetails> getAllRecordsForPayout15Minutes();

	@Query(value = "select * from TransactionDetails tr "
			+ "where created between (NOW() - INTERVAL 60 MINUTE) and (NOW() - INTERVAL 20 MINUTE) "
			+ "and transactionStatus = 'PENDING' and internalOrderId is not null "
			+ "and (reconStatus <>'R2' or reconStatus is null) order by sno", nativeQuery = true)
	List<TransactionDetails> getAllRecordsForPayout1Hours();

	@Query(value = "select * from TransactionDetails tr "
			+ "where created between (NOW() - INTERVAL 180 MINUTE) and (NOW() - INTERVAL 60 MINUTE) "
			+ "and transactionStatus = 'PENDING' and internalOrderId is not null "
			+ "and (reconStatus <>'R3' or reconStatus is null) order by sno", nativeQuery = true)
	List<TransactionDetails> getAllRecordsForPayout3Hours();

	@Query(value = "select * from TransactionDetails tr "
			+ "where created between (NOW() - INTERVAL 1440 MINUTE) and (NOW() - INTERVAL 720 MINUTE) "
			+ "and transactionStatus = 'PENDING' and internalOrderId is not null "
			+ "and (reconStatus <>'R4' or reconStatus is null) order by sno", nativeQuery = true)
	List<TransactionDetails> getAllRecordsForPayout12Hours();

	@Query(value = "select * from TransactionDetails tr "
			+ "where created between (NOW() - INTERVAL 2448 MINUTE) and (NOW() - INTERVAL 1440 MINUTE) "
			+ "and transactionStatus = 'PENDING' and internalOrderId is not null "
			+ "and (reconStatus <>'R5' or reconStatus is null) order by sno", nativeQuery = true)
	List<TransactionDetails> getAllRecordsForPayout24Hours();

	@Query(value = "select * from TransactionDetails tr "
			+ "where created between (NOW() - INTERVAL 3896 MINUTE) and (NOW() - INTERVAL 2448 MINUTE) "
			+ "and internalOrderId is not null "
			+ "and (reconStatus <>'R6' or reconStatus is null) order by sno", nativeQuery = true)
	List<TransactionDetails> getAllRecordsForPayout48Hours();

	@Query(value = "select * from TransactionDetails tr " + "where internalOrderId is not null "
			+ "and reconStatus is null order by sno", nativeQuery = true)
	List<TransactionDetails> getAllRecordsForPayoutOneTime();

	@Query(value = "select * from TransactionDetails tr where internalOrderId is not null and transactionStatus in ('PENDING', 'ACCEPTED') and created < (NOW() - INTERVAL 2 MINUTE) order by sno", nativeQuery = true)
	List<TransactionDetails> getAllRecordsForPayoutHourly();

	@Query(value = "SELECT * FROM TransactionDetails  where transactionStatus like :transactionStatus and transactionType like :transactionType and date(created) between :dateFrom and :dateTo and merchantId = :merchantId order by sno desc", nativeQuery = true)
	List<TransactionDetails> getSearchByDetails(@Param("transactionStatus") String transactionStatus,
			@Param("transactionType") String transactionType, @Param("dateFrom") String dateFrom,
			@Param("dateTo") String dateTo, @Param("merchantId") String merchantId);
	
	@Query(value = "SELECT * FROM TransactionDetails  where transactionStatus like :transactionStatus and transactionType like :transactionType and orderId = :orderId and merchantId = :merchantId order by sno desc", nativeQuery = true)
	List<TransactionDetails> getSearchByMerchantIdAndStatusAndTransactionType(@Param("transactionStatus") String transactionStatus,
			@Param("transactionType") String transactionType, @Param("merchantId") String merchantId, @Param("orderId") String orderId);

	TransactionDetails findByInternalOrderId(String orderId);

	@Query(value = "SELECT * FROM TransactionDetails  where merchantid = :merchantId order by sno desc limit 5000", nativeQuery = true)
	List<TransactionDetails> getByMerchantId(@Param("merchantId") String merchantid);
	
	@Query(value = "SELECT * FROM TransactionDetails  where orderId = :orderId ", nativeQuery = true)
	List<TransactionDetails> getByOrderId(@Param("orderId") String orderId);
	
	@Query(value = "SELECT * FROM TransactionDetails  where transactionType like :transactionType order by sno desc limit 5000", nativeQuery = true)
	List<TransactionDetails> getSearchByTransactionType(@Param("transactionType") String transactionType);
	
	@Query(value = "SELECT * FROM TransactionDetails  where transactionType like :transactionType and merchantId = :merchantId", nativeQuery = true)
	List<TransactionDetails> getSearchByMerchantIdAndTransactionType(@Param("transactionType") String transactionType, @Param("merchantId") String merchantId);

	@Query(value = "SELECT * FROM TransactionDetails  where transactionStatus like :transactionStatus and transactionType like :transactionType and merchantId = :merchantId order by sno desc", nativeQuery = true)
	List<TransactionDetails> getByStatusAndMerchantAndType(@Param("transactionStatus") String transactionStatus,
			@Param("transactionType") String transactionType, @Param("merchantId") String merchantId);
}
