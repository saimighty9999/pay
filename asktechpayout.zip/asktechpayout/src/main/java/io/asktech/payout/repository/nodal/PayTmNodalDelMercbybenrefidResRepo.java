package io.asktech.payout.repository.nodal;

import org.springframework.data.jpa.repository.JpaRepository;

import io.asktech.payout.modal.nodal.PayTmNodalDelMercbybenrefidRes;

public interface PayTmNodalDelMercbybenrefidResRepo extends JpaRepository<PayTmNodalDelMercbybenrefidRes, String>{

}
