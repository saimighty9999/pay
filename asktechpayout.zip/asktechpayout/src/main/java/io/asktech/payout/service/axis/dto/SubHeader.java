package io.asktech.payout.service.axis.dto;
import com.fasterxml.jackson.annotation.JsonProperty; // version 2.11.1

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SubHeader {
    public String requestUUID;
    public String serviceRequestId;
    public String serviceRequestVersion;
    public String channelId;
}
