package io.asktech.payout.service.axis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import io.asktech.payout.service.axis.dto.BenificaryDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;

import io.asktech.payout.service.sark.dto.SarkStatusRequest;
import io.asktech.payout.service.sark.dto.SarkStatusResponse;
import io.asktech.payout.service.sark.dto.SarkTransactionResponse;
import io.asktech.payout.service.sark.dto.SarkTrasactionRequest;
import io.asktech.payout.service.sark.dto.SarkUpiTransactionRequest;
import io.asktech.payout.service.sark.dto.SarkUpiTrasactionResponse;
import io.asktech.payout.utils.ApiReqResLogger;
import io.asktech.payout.utils.Utility;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

@Component
public class AxisRequest {
  
    
    static Logger logger = LoggerFactory.getLogger(AxisRequest.class);

    public void addBeneficiaryRequest(BenificaryDto beneficaryRequest){
        HttpResponse<SarkTransactionResponse> response = Unirest.post("https://sakshamuat.axisbank.co.in/gateway/api/txb/v1/payee-mgmt/beneficiary-registration")
                .header("X-IBM-Client-Id", "a6793d69-6e75-458b-9c00-c00febd8b437")
                .header("X-IBM-Client-Secret", "tE3kK3kO0rX8jL4sH7mP3eW7aT7tP3qV7fB2uJ0vW4eB6rB7pC")
                .header("Content-Type", "application/json")
                .body(beneficaryRequest).asObject(SarkTransactionResponse.class)
                .ifFailure(Object.class, r -> {
                    Object e = r.getBody();
                    try {
                        logger.info("Contact Response error::" + Utility.convertDTO2JsonString(e));
                    } catch (JsonProcessingException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                });

    }



}
