package io.asktech.payout.service.axis;

import io.asktech.payout.dto.merchant.AccountTransferMerReq;
import java.util.Arrays;
import io.asktech.payout.service.axis.dto.BeneficiaryRegistrationRequest;
import io.asktech.payout.service.axis.dto.BeneficiaryRegistrationRequestBody;
import io.asktech.payout.service.axis.dto.Beneinsert;
import io.asktech.payout.service.axis.dto.BenificaryDto;
import io.asktech.payout.service.axis.dto.PaymentDetail;
import io.asktech.payout.service.axis.dto.SubHeader;
import io.asktech.payout.service.axis.dto.TransferPaymentRequest;
import io.asktech.payout.service.axis.dto.TransferPaymentRequestBody;
import io.asktech.payout.service.axis.model.AxisBeneficiary;
import io.asktech.payout.service.axis.repo.AxisBeneficaryRepo;
import io.asktech.payout.utils.Utility;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.List;
import io.asktech.payout.modal.merchant.PgDetails;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.io.ByteArrayOutputStream;

import java.security.spec.AlgorithmParameterSpec;

@Component
public class AxisUtility {

    @Autowired
    AxisBeneficaryRepo axisBeneficaryRepo;

    public BenificaryDto addBenificary(AccountTransferMerReq dto, String merchantid, PgDetails pg) throws JsonProcessingException {

        AxisBeneficiary axisBeneficarymodel = new AxisBeneficiary();
        axisBeneficarymodel.setBeneCode(merchantid);
        axisBeneficarymodel.setBeneBankAccount(dto.getBankaccount());
        axisBeneficarymodel.setBeneName(dto.getBeneficiaryName());
        axisBeneficarymodel.setBeneIfscCode(dto.getIfsc());

        axisBeneficaryRepo.save(axisBeneficarymodel);

        BenificaryDto benificaryDto = new BenificaryDto();
        BeneficiaryRegistrationRequest beneficiaryRegistrationRequest = new BeneficiaryRegistrationRequest();
        SubHeader subHeader = new SubHeader();
        BeneficiaryRegistrationRequestBody beneficiaryRegistrationRequestBody = new BeneficiaryRegistrationRequestBody();
        Beneinsert beneinsert = new Beneinsert();

        beneinsert.setApiVersion("1.0");
        beneinsert.setBeneLEI("");
        beneinsert.setBeneCode(merchantid);
        beneinsert.setBeneName(dto.getBeneficiaryName());
        beneinsert.setBeneAccNum(dto.getBankaccount());
        beneinsert.setBeneIfscCode(dto.getIfsc());
        beneinsert.setBeneAcType("");
        beneinsert.setBeneBankName("");
        beneinsert.setBeneAddr1("");
        beneinsert.setBeneAddr2("");
        beneinsert.setBeneAddr3("");
        beneinsert.setBeneCity("");
        beneinsert.setBeneState("");
        beneinsert.setBenePincode("");
        beneinsert.setBeneEmailAddr1("");
        beneinsert.setBeneMobileNo("");

        beneficiaryRegistrationRequestBody.setChannelId("ANALYTIQ");
        beneficiaryRegistrationRequestBody.setCorpCode("DEMOCORP261");
        // USER ID
        beneficiaryRegistrationRequestBody.setUserId("ACC0336231165149");

        List<Beneinsert> beneinsertList = new ArrayList<>();

        beneinsertList.add(beneinsert);
        beneficiaryRegistrationRequestBody.setBeneinsert(beneinsertList);

        // CREATE CHECKSUM
        String checkSum = encodeCheckSumWithSHA256(beneficiaryRegistrationRequestBody.createChecsum());
        beneficiaryRegistrationRequestBody.setChecksum(checkSum);

        // ENCRYPT THE REQUESTimport java.util.Arrays;
        String encryptedRequest = encryptCallBack("1F4DC4B07AA34418A15ED37C56B64B64", Utility.convertDTO2JsonString(beneficiaryRegistrationRequestBody));

        subHeader.setRequestUUID("ABC123");
        subHeader.setServiceRequestId("OpenAPI");
        subHeader.setServiceRequestVersion("1.0");
        subHeader.setChannelId("ANALYTIQ");

        beneficiaryRegistrationRequest.setSubHeader(subHeader);
        // beneficiaryRegistrationRequest.setBeneficiaryRegistrationRequestBody(beneficiaryRegistrationRequestBody);
        beneficiaryRegistrationRequest.setBeneficiaryRegistrationRequestBodyEncrypted(encryptedRequest);
        benificaryDto.setBeneficiaryRegistrationRequest(beneficiaryRegistrationRequest);

        // Encrypt the Request
        return benificaryDto;
    }


    public TransferPaymentRequest fundTransferRequest(String merchantId) throws JsonProcessingException{

        SubHeader subHeader = new SubHeader();
        subHeader.setRequestUUID("ABC123");
        subHeader.setServiceRequestId("OpenAPI");
        subHeader.setServiceRequestVersion("1.0");
        subHeader.setChannelId("ANALYTIQ");


        PaymentDetail paymentDetail = new PaymentDetail();

        paymentDetail.setTxnPaymode("NE");
        paymentDetail.setCustUniqRef(merchantId);
        paymentDetail.setCorpAccNum("241010107618844");
        paymentDetail.setValueDate("2022-11-8");
        paymentDetail.setTxnAmount("100");
        paymentDetail.setBeneLEI("");
        paymentDetail.setBeneName("");
        paymentDetail.setBeneCode(merchantId);
        paymentDetail.setBeneAcType("");
        paymentDetail.setBeneAccNum("");
        paymentDetail.setBeneAddr1("");
        paymentDetail.setBeneAddr2("");
        paymentDetail.setBeneAddr3("");
        paymentDetail.setBeneBankName("");
        paymentDetail.setBeneEmailAddr1("");
        paymentDetail.setBeneIfscCode("");
        paymentDetail.setBeneMobileNo("");
        paymentDetail.setBeneCity("");
        paymentDetail.setBeneState("");
        paymentDetail.setBenePincode("");
        paymentDetail.setChequeDate("");
        paymentDetail.setChequeNumber("");
        paymentDetail.setEnrichment1("");
        paymentDetail.setEnrichment2("");
        paymentDetail.setEnrichment3("");
        paymentDetail.setEnrichment4("");
        paymentDetail.setEnrichment5("");
        paymentDetail.setPayableLocation("");
        paymentDetail.setPrintLocation("");
        paymentDetail.setProductCode("");
        paymentDetail.setSenderToReceiverInfo("");
       
        // paymentDetail.set

        // TODO PLEASE REST OF FIELD TO EMPTY STRING

        TransferPaymentRequestBody transferPaymentRequestBody = new TransferPaymentRequestBody();
        transferPaymentRequestBody.setChannelId("ANALYTIQ");
        transferPaymentRequestBody.setCorpCode("DEMOCORP261");

        List<PaymentDetail> paymentDetails = new ArrayList<>();
        paymentDetails.add(paymentDetail);
        transferPaymentRequestBody.setPaymentDetails(paymentDetails);
        
        // String  checkString = "";
        String checkSum = encodeCheckSumWithSHA256(transferPaymentRequestBody.createChecsum());
        transferPaymentRequestBody.setChecksum("checkString");
        String encryptedRequest = encryptCallBack("1F4DC4B07AA34418A15ED37C56B64B64", Utility.convertDTO2JsonString(transferPaymentRequestBody));


        TransferPaymentRequest transferPaymentRequest = new TransferPaymentRequest();
        transferPaymentRequest.setSubHeader(subHeader);
        transferPaymentRequest.setTransferPaymentRequestBodyEncrypted(encryptedRequest);

        return transferPaymentRequest;

    }





    public String encodeCheckSumWithSHA256(String data) {
        MessageDigest md;
        StringBuilder sb = new StringBuilder();
        String response = null;
        try {
            md = MessageDigest.getInstance("MD5");
            md.update(data.getBytes(StandardCharsets.UTF_8));
            // Get the hashbytes
            byte[] hashBytes = md.digest();
            // Converthash bytes to hex format
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            response = sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("Internal server error");
        }
        return response;

    }

    public String encryptCallBack(String key, String str_resp) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream(key.length() / 2);

        for (int i = 0; i < key.length(); i += 2) {
            String output = key.substring(i, i + 2);
            int decimal = Integer.parseInt(output, 16);
            baos.write(decimal);
        }

        try {
            SecretKeySpec skeySpec = new SecretKeySpec(baos.toByteArray(), "AES");

            byte[] iv1 = new byte[] { (byte) 0x8E, 0x12, 0x39, (byte) 0x9C, 0x07, 0x72, 0x6F, 0x5A, (byte) 0x8E, 0x12,
                    0x39, (byte) 0x9C, 0x07, 0x72, 0x6F, 0x5A };
            AlgorithmParameterSpec paramSpec = new IvParameterSpec(iv1);

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(1, skeySpec, paramSpec);

            byte[] encrypted = cipher.doFinal(str_resp.getBytes("UTF-8"));

            ByteArrayOutputStream os = new ByteArrayOutputStream();
            os.write(iv1);
            os.write(encrypted);
            byte[] encryptedWithIV = os.toByteArray();

            // return new String(Base64.encode(os.toByteArray()));
            String encryptedResult = Base64.getEncoder().encodeToString(encryptedWithIV);
            return encryptedResult;
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public String decryptCallBack(String key, String encrypted) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream(key.length() / 2);

        for (int i = 0; i < key.length(); i += 2) {
            String output = key.substring(i, i + 2);
            int decimal = Integer.parseInt(output, 16);
            baos.write(decimal);
        }

        try {
            SecretKeySpec skeySpec = new SecretKeySpec(baos.toByteArray(), "AES");

            // byte[] encryptedIVandTextAsBytes = Base64.decode(encrypted);
            byte[] encryptedIVandTextAsBytes = Base64.getDecoder().decode(encrypted);
            byte[] iv = Arrays.copyOf(encryptedIVandTextAsBytes, 16);
            byte[] ciphertextByte = Arrays.copyOfRange(encryptedIVandTextAsBytes, 16, encryptedIVandTextAsBytes.length);

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(2, skeySpec, new IvParameterSpec(iv));
            byte[] decryptedTextBytes = cipher.doFinal(ciphertextByte);

            String original = new String(decryptedTextBytes, "UTF-8");

            return original;
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

}
