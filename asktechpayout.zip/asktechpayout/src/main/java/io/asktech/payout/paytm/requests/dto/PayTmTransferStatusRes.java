package io.asktech.payout.paytm.requests.dto;

public class PayTmTransferStatusRes {

}
