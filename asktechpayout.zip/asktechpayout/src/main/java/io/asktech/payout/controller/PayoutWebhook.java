package io.asktech.payout.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.asktech.payout.service.payg.dto.webhook.PayGwebhook;

@RestController
public class PayoutWebhook {
    @PostMapping(value = "/web/payg")
	public ResponseEntity<?> PageWebhook(@RequestBody PayGwebhook dto){
			return ResponseEntity.ok().body(dto);
	}
}
