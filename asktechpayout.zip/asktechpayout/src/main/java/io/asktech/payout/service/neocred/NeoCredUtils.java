package io.asktech.payout.service.neocred;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;

import io.asktech.payout.service.neocred.Request.AuthRequest;
import io.asktech.payout.service.neocred.dto.AuthRequestDto;
import io.asktech.payout.service.neocred.dto.AuthResponseDto;
import io.asktech.payout.service.neocred.dto.SettlementReqDto;
import io.asktech.payout.service.neocred.dto.SettlementResDto;
import io.asktech.payout.service.neocred.dto.StatusReq;

@Component
public class NeoCredUtils {
    

    public static void main(String args[]) throws JsonProcessingException{  


        // GET THE TOKEN
        AuthRequestDto authreq = new AuthRequestDto();
        authreq.setUsername("vivek.jha@analytiqbv.com");
        authreq.setPassword("urcbjvEl1@As");

        AuthRequest authreqs = new AuthRequest();

        AuthResponseDto authRes = authreqs.getToken(authreq);

        // SETTLE THE PAYMENT
        String token = "Bearer "+authRes.getData();
        String clientHashId = "4cfcc68c-5eb8-4007-a4f3-f70b32e3391d";
        String amount = "100";

        SettlementReqDto settleReq = new SettlementReqDto();
        settleReq.setBankAccountHolderName("Karna");
        settleReq.setBankAccountNumber("919790220396");
        settleReq.setBankIfscCode("PYTM0123456");
        settleReq.setTransferType("IMPS");
        settleReq.setCreditorInfoRemarks("Fund Transfer");



        SettlementResDto settleRes   = authreqs.paySettlement(settleReq, clientHashId, amount, token);


        // GET THE STATUS
        StatusReq stausReq = new StatusReq();
        stausReq.setClientHashId(clientHashId);
        stausReq.setRrn("78912379182738");

        SettlementResDto statusRes =authreqs.getStatus(stausReq, clientHashId, token);

    
       }  


}
