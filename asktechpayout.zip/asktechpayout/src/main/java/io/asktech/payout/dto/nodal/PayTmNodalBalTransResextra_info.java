package io.asktech.payout.dto.nodal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class PayTmNodalBalTransResextra_info {

	private String beneficiaryIfsc;
	private String creationTime;
	private String beneficiaryName;
}
