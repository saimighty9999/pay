package io.asktech.payout.service.axis;

public class BenificaryDto {

}
