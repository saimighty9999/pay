package io.asktech.payout.repository.merchant;

import org.springframework.data.jpa.repository.JpaRepository;

import io.asktech.payout.modal.merchant.PgDetails;

public interface PgDetailsRepo extends JpaRepository<PgDetails, String>{
    PgDetails findByPgIdAndPgStatus(String pgId, String status);

    PgDetails findByPgId(String pgId);

    PgDetails findByPgName(String pgName);
}
