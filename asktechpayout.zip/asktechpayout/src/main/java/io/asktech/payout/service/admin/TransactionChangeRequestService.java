package io.asktech.payout.service.admin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.asktech.payout.dto.admin.TransactionChangeRequestDto;
import io.asktech.payout.dto.admin.TransactionChangeResponce;
import io.asktech.payout.modal.admin.TransactionChangeRequest;
import io.asktech.payout.modal.merchant.TransactionDetails;
import io.asktech.payout.repository.admin.TransactionChangeRequestRepo;
import io.asktech.payout.repository.merchant.TransactionDetailsRepo;

@Service
public class TransactionChangeRequestService {
    @Autowired
    private TransactionChangeRequestRepo transactionChangeRequestRepo;
    @Autowired
    private TransactionDetailsRepo transactionDetailsRepo;

    public TransactionChangeResponce updateTransactionStatus(TransactionChangeRequestDto transactionChangeRequestDto) {
        TransactionChangeRequest transactionChangeRequest = new TransactionChangeRequest();
        transactionChangeRequest.setComment(transactionChangeRequestDto.getComment());
        transactionChangeRequest.setOrderIds(transactionChangeRequestDto.getOrderIds());
        transactionChangeRequest.setStatus(transactionChangeRequestDto.getStatus());
        transactionChangeRequest = transactionChangeRequestRepo.save(transactionChangeRequest);

        String oderIdsString = transactionChangeRequestDto.getOrderIds();
        List<String> oderIdsListInString = new ArrayList<>(Arrays.asList(oderIdsString.split(",")));
        int count = 0;
        for (String orderId : oderIdsListInString) {
            TransactionDetails transactionDetails = new TransactionDetails();
            transactionDetails = transactionDetailsRepo.findByOrderId(orderId);
            transactionDetails.setTransactionStatus(transactionChangeRequestDto.getStatus());
            transactionDetails.setErrorMessage(transactionChangeRequestDto.getComment());
            transactionDetailsRepo.save(transactionDetails);
            count++;
        }

        System.out.println(count);
        transactionChangeRequest.setCount(oderIdsListInString.size());
        transactionChangeRequest = transactionChangeRequestRepo.save(transactionChangeRequest);

        TransactionChangeResponce transactionChangeResponce = new TransactionChangeResponce();
        transactionChangeResponce.setComment(transactionChangeRequest.getComment());
        transactionChangeResponce.setCount(oderIdsListInString.size());
        transactionChangeResponce.setOrderIds(transactionChangeRequest.getOrderIds());
        transactionChangeResponce.setStatus(transactionChangeRequest.getStatus());

        return transactionChangeResponce;

    }

}
