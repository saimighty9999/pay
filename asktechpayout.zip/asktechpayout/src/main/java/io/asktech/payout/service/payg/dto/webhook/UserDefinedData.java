package io.asktech.payout.service.payg.dto.webhook;

import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class UserDefinedData {
    private String UserDefined8;
    private String UserDefined9;
    private String UserDefined19;
    private String UserDefined6;
    private String UserDefined18;
    private String UserDefined7;
    private String UserDefined17;
    private String UserDefined16;
    private String UserDefined15;
    private String UserDefined14;
    private String UserDefined13;
    private String UserDefined1;
    private String UserDefined4;
    private String UserDefined5;
    private String UserDefined2;
    private String UserDefined3;
    private String UserDefined12;
    private String UserDefined11;
    private String UserDefined10;
    private String UserDefined20;
}
