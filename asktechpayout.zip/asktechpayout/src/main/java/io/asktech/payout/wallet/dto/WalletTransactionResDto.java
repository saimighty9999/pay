package io.asktech.payout.wallet.dto;

public class WalletTransactionResDto {

}
