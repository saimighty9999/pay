package io.asktech.payout.dto.van;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayTmVanUpdateReq {

	private String id;
	private String status;
	private String type;
	
}
