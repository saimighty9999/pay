package io.asktech.payout.dto.reqres;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayTmAddFundres {

	private String statusCode;
	private String status;
	private String statusMessage;
}
