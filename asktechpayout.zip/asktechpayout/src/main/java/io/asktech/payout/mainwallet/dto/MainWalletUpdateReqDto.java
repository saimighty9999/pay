package io.asktech.payout.mainwallet.dto;

public class MainWalletUpdateReqDto {

}
