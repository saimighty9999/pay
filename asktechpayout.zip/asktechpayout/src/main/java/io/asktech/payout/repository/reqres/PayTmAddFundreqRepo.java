package io.asktech.payout.repository.reqres;

import org.springframework.data.jpa.repository.JpaRepository;

import io.asktech.payout.modal.reqres.PayTmAddFundreq;

public interface PayTmAddFundreqRepo extends JpaRepository <PayTmAddFundreq ,String>{ 

}
