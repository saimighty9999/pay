package io.asktech.payout.service.axis.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor

public class BenficiaryRegistrationResp {
    
   private BeneficiaryRegistrationResponse benficiaryRegistrationResp;

}
