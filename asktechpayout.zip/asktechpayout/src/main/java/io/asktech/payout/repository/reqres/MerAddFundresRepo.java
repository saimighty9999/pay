package io.asktech.payout.repository.reqres;

import org.springframework.data.jpa.repository.JpaRepository;

import io.asktech.payout.modal.reqres.MerAddFundres;

public interface MerAddFundresRepo extends JpaRepository<MerAddFundres, String> {

}
