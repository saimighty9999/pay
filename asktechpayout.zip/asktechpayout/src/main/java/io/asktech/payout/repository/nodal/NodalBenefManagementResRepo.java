package io.asktech.payout.repository.nodal;

import org.springframework.data.jpa.repository.JpaRepository;

import io.asktech.payout.modal.nodal.NodalBenefManagementRes;



public interface NodalBenefManagementResRepo extends JpaRepository<NodalBenefManagementRes, String>{

}
