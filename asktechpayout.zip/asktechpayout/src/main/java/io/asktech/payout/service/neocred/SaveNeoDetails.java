package io.asktech.payout.service.neocred;
import org.springframework.stereotype.Component;

@Component
public class SaveNeoDetails {
    
}
