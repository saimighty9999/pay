package io.asktech.payout.dto.reqres;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ListVANmeta {

	private String branch;
	private String section;
}
