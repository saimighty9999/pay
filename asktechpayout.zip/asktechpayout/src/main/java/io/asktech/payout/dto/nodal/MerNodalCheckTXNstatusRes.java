package io.asktech.payout.dto.nodal;

public class MerNodalCheckTXNstatusRes {

}
