package io.asktech.payout.dto.van;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter


public class VanWebhookReqDataMeta {

	private String branch;
	private String section;
	
}
