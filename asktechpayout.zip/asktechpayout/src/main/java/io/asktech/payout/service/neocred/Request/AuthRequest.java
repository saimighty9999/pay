package io.asktech.payout.service.neocred.Request;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;

import org.springframework.stereotype.Component;

import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.core.JsonProcessingException;
// import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.asktech.payout.service.neocred.dto.AuthRequestDto;
import io.asktech.payout.service.neocred.dto.AuthResponseDto;
import io.asktech.payout.service.neocred.dto.SettlementReqDto;
import io.asktech.payout.service.neocred.dto.SettlementResDto;
import io.asktech.payout.service.neocred.dto.StatusReq;

@Component
public class AuthRequest {
    @Value("${neoCred.authUrl}")
    String authUrl;


public AuthResponseDto getToken(AuthRequestDto authReqdto) throws JsonProcessingException{

    HttpResponse<AuthResponseDto> tResponse = Unirest
    .post("https://stg-va.neokred.tech:8088/va/v1/authenticate").header("Content-Type", "application/json")
    .body(convertDTO2JsonString(authReqdto)).asObject(AuthResponseDto.class)
    .ifFailure(Object.class, r -> {
        Object e = r.getBody();
    });
    // return tResponse.getBody();
   return tResponse.getBody();
}



public SettlementResDto paySettlement(SettlementReqDto settleReq, String clientHashId, String amount, String token) throws JsonProcessingException{

    HttpResponse<SettlementResDto> tResponse = Unirest
    .post("https://stg-va.neokred.tech:8088/va/v1/ecollect/settlement").header("Content-Type", "application/json")
    .header("client-Hash-Id", clientHashId).header("amount", amount).header("Authorization", token)
    .body(convertDTO2JsonString(settleReq)).asObject(SettlementResDto.class)
    .ifFailure(Object.class, r -> {
        Object e = r.getBody();
    });

    return tResponse.getBody();


}

public SettlementResDto getStatus(StatusReq statusReq, String clientHashId, String token) throws JsonProcessingException{

    HttpResponse<SettlementResDto> tResponse = Unirest
    .post("https://stg-va.neokred.tech:8088/va/v1/payment/details").header("Content-Type", "application/json")
    .header("client-Hash-Id", clientHashId).header("Authorization", token)
    .body(convertDTO2JsonString(statusReq)).asObject(SettlementResDto.class)
    .ifFailure(Object.class, r -> {
        Object e = r.getBody();
    });
    // System.out.println(convertDTO2JsonString(tResponse.getBody()));
    return tResponse.getBody();

}







public  String convertDTO2JsonString(Object json) throws JsonProcessingException {
    ObjectMapper Obj = new ObjectMapper();
    String jsonStr = Obj.writeValueAsString(json);
    return jsonStr;

}


}
