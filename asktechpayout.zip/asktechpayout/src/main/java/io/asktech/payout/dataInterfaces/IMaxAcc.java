package io.asktech.payout.dataInterfaces;

public interface IMaxAcc {
	long getAccno();
}
