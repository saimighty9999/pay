package io.asktech.payout.service.axis.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BeneficiaryRegistrationResponse {
    @JsonProperty("beneficiarySubHeader")
    private BenficiarySubheader beneficiarySubHeader;
    @JsonProperty("benficiaryRegistrationRespBody")
    private BenficiaryRegistrationRespBody benficiaryRegistrationRespBody;
    
}
