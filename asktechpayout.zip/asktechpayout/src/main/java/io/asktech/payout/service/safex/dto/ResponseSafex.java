package io.asktech.payout.service.safex.dto;


import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ResponseSafex {
    private String code;
    private String description;
 
}
