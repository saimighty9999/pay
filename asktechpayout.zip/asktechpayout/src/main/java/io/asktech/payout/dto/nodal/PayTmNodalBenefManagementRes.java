package io.asktech.payout.dto.nodal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class PayTmNodalBenefManagementRes {
	private String response;
	private String succes;
	private String code;
	private String errorCode;
	private String status;
	private String message;
	

}
