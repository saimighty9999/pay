package io.asktech.payout.service.cashfree.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerUpiDetails {
    private String name;
    private String vpa;
}
