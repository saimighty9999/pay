package io.asktech.payout.repository.van;

import org.springframework.data.jpa.repository.JpaRepository;

import io.asktech.payout.modal.van.UpdateVANDetail;

public interface UpdateVANDetailRepo extends JpaRepository<UpdateVANDetail, String>  {

}
