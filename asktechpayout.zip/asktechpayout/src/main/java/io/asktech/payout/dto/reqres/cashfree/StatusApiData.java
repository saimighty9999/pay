package io.asktech.payout.dto.reqres.cashfree;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatusApiData {
	   private StatusApiTransfer transfer;
}
