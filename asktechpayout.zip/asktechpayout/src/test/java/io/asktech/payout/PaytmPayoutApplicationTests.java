package io.asktech.payout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaytmPayoutApplicationTests {

	@Test
	void contextLoads() {
	}



}
